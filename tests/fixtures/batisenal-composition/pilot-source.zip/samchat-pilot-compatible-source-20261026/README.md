# Fuentes compatibles completas para el piloto aislado en Surface

**Este snapshot resuelve la falta de modelos, sesión y owners del extracto de 79 archivos.** No depende de encontrar el commit local en GitHub y no sustituye la revisión por main.

Origen: `/workspace/samchat-batisenal-pilot`, recuperado el 26 de octubre de 2026. Base Git raíz local `d4afc74b3b4bb152766826b2c0fa92ce253de866` más el estado final del piloto. `PROVENANCE.json` fija el árbol Git base; `SOURCE_MANIFEST.json` registra por archivo SHA256, blob base y blob actual. No se exportan `.git`, historial ni credenciales.

## Contenido y coherencia

- `checkout/`: **586 archivos**, incluidas **todas las 507 fuentes Python presentes bajo src/** en el candidato. Contiene `devnous.gastos.models`, dependencias de sesión, rutas y owners, asistentes, componentes del dashboard, plantillas/estáticos y catálogo geográfico público que forma parte del código. Incluye las pruebas sintéticas y migraciones del piloto.
- Los **79 archivos** del paquete `libfile_32539c5cd974819199cafe96c3309ad9`, **versión 1**, SHA256 `354ab04b2ce7fcef0b91af167dacdb2fbe6cef87610854528c2be79d1be0d912`, coinciden byte por byte. `EXTRACT79.json` permite comprobar la copia ya reconstruida en Surface.
- El código del piloto se entrega en su estado final, sin parches que aplicar otra vez. Tres fuentes heredadas tienen únicamente credenciales de URLs localhost sustituidas por `REDACTED:REDACTED` en la copia de entrega; `REDACTIONS.json` y el manifiesto registran el saneamiento sin divulgar valores. No afectan a los 79 archivos del extracto ni modifican lógica; esas conexiones predeterminadas quedan inutilizables intencionalmente. No mezclar estos archivos con main ni reemplazar archivos de un checkout ajeno.
- `handoff/`: receta, versiones observadas de dependencias, recibos originales y límites. No contiene dependencias instaladas ni binarios PostgreSQL.
- `EXCLUSIONS.json`: exclusiones explícitas. Esto es un snapshot completo de las fuentes Python del candidato y los recursos necesarios del piloto; **no es un archivo íntegro del repositorio ni todos sus documentos/datos/operaciones**.

## Verificar y materializar sin ejecutar producto

Python 3, sin red, Git, PostgreSQL ni imports de SamChat:

```bash
python3 verify_source.py
# Comparación opcional con los 79 archivos reconstruidos anteriormente:
python3 verify_source.py --extract79 /ruta/al/extracto/reconstruido
# Materializar en un destino NUEVO y corto (para el límite del socket Unix):
python3 verify_source.py --output "$HOME/bs-pilot-review"
```

El verificador comprueba los hashes y el inventario, rechaza symlinks/rutas peligrosas y destinos existentes, copia los archivos exactos y vuelve a verificarlos. No ejecuta tests, instala paquetes, importa producto ni crea bases/servicios. No copiar sobre el directorio anterior de Surface. La verificación de entrega realizada se registra en `DELIVERY_VERIFICATION.json`.

## Receta y montaje

Seguir `handoff/SURFACE_LINUX_RECIPE.md`. La receta está escrita para Linux aislado, usuario no root y PostgreSQL propio sin TCP. No fue ejecutada en Surface desde este entorno. El montaje probado es `tests/batisenal_pilot/test_case_http.py::mounted`: crea la aplicación sintética con los modelos/owners reales, compone `SupportPilot(case_service=CaseService(...))` y llama `mount_pilot`. ASGI se prueba en memoria; no publica un listener web.

Se incluyen los módulos reales de sesión y negocio que faltaban en el extracto. El login/empleados/datos usados por el test siguen siendo fixtures sintéticas. No se proporcionan cuentas reales, grant operativo, claves productivas, ni una traducción de server-owner a persona.

El `copa_telmex_dashboard.py` completo está incluido como fuente, **no como instrucción para arrancarlo**: su esquema global, servicios y proveedores no se acreditan mediante este piloto. No ejecutar readiness global, migraciones de negocio ajenas o arranque productivo para hacer pasar los tests del piloto.

## Requisitos y evidencia

Original verificado: Python **3.12.14**, PostgreSQL nativo **17.11 (Debian 17.11-0+deb13u1)**, socket Unix privado, TCP deshabilitado. `handoff/native-postgres-original.json` conserva el recibo. No es WASM. Los binarios deben corresponder a la arquitectura/OS de Surface; no se incluyen ni se asume que un paquete Debian sea instalable directamente en Ubuntu.

`handoff/environment-versions-observed.json` es metadata leída del entorno restaurado, sin secretos ni URLs privadas. `requirements-observed.txt` fija versiones observadas de bibliotecas y añade las cuatro dependencias JSONSchema procedentes del entorno de herramientas, identificadas en la receta. Es una ayuda de reproducción, **no un lock validado mediante instalación limpia**. Los requirements del repositorio permanecen intactos; algunos manifiestos opcionales describen versiones diferentes de las utilizadas en el venv del piloto. No instalarlos todos encima sin reconciliar el entorno aislado.

Evidencia anterior conservada: **52 pruebas pasadas**, cobertura **643/698 = 92.120343839542…%**, gate estricto ≥85 aprobado y revisión focalizada. Estos resultados proceden del entorno original; no son pruebas nuevas ni aceptación de Surface. Aquí sólo se verificó integridad, coherencia y saneamiento de entrega. No se reinició PostgreSQL ni se ejecutaron tests, migraciones o imports de producto durante esta preparación.

## Exclusiones y límites

No se incluyen `.env`, claves ni credenciales reales. Los marcadores REDACTED son inertes. Se excluyen tokens emitidos, corpus, datos reales, adjuntos, bases/dumps, logs de servidor, cachés, entornos virtuales, binarios, wheels, node_modules ni metadatos egg-info. Tampoco scripts de diagnóstico operativo ajenos al montaje. La configuración `src/devnous/tournaments/config/liga_telmex_telcel.yaml` se excluye porque contiene un campo de credencial incrustado; no se cambió ni exportó su valor. La fixture HTTP no la utiliza. Tests de ese subsistema u otros módulos podrían requerir configuración adicional; no se afirma bootstrap de toda la plataforma.

Los literales sintéticos de fixtures (CSRF, claves efímeras generadas en memoria, empleados ficticios) no son credenciales reales. Las referencias y reglas de negocio codificadas se conservan como código; no se consultaron ni copiaron registros operativos. El catálogo geográfico es una referencia pública agregada, no datos de personas.

La búsqueda de patrones de secretos complementa la selección explícita; no acredita ausencia universal por sí sola. `SANITIZATION.json` conserva la comprobación sin valores sensibles. No se leyó el corpus previamente denegado ni se accedió a Ryzen.

Este complemento no conecta Chatty, habilita Events, crea grants reales, publica endpoints ni cambia permisos. No hay QA visual nuevo ni aislamiento financiero multiempresa acreditado. Canon unchanged: transferencia de fuentes existentes y evidencia, con saneamiento explícito de credenciales sólo en copias de entrega y sin modificación de lógica/política. Originales y paquetes históricos intactos; sin push, merge, despliegue ni acceso nuevo.
