# SamChat Canon for ChatGPT

Version: 2026-09-10

Repository evidence baseline: `fmfg03/samchatint` `main` at `7684713cc2e529b8f48768553cd1acc6f7e1e39b`

Contract baseline: “Oferta Plataforma Sports SP,” dated 2025-08-28

## 1. Canonical definition

SamChat is the operational system for Plataforma Sports workflows. Its intended primary interface is a governed business assistant: the user states an objective, SamChat inspects current context and evidence, uses canonical business tools, prepares an auditable result, and executes real effects only through explicit authority.

The dashboard is an important operating and supervision surface. It is not the whole product and it is not evidence that the assistant can complete every workflow end to end.

## 2. The four truths that must not be conflated

| Truth | Meaning |
| --- | --- |
| Contract truth | What the signed proposal/SOW describes or promises |
| Repository truth | What exists and is connected in the inspected `main` commit |
| Runtime truth | What is deployed and observable in `sam.chat` |
| Acceptance truth | What Plataforma Sports users have validated and accepted in real operation |

When these disagree, preserve all four. Never upgrade a contractual promise into a live capability, or a repository capability into an accepted deliverable.

## 3. Current product spine

### Core operations

- empleados, sessions, roles, permissions, admin and user surfaces;
- solicitudes, informes, cuentas de gastos, anticipos, reembolsos, devoluciones, approvals, and payments;
- providers/beneficiaries, banking instructions, notifications, support, and audit;
- registration review, OCR, teams, players, incidents, and commit controls.

### Finance spine

- Finance command center;
- Payment Run and payment history;
- payment-order XLSX by cutoff;
- CFDI intake, linking, tax readiness, COI and DIOT-related surfaces;
- budgets, versions, concepts, lines, monthly/weekly allocations, actuals, and movement reconciliation;
- accounts receivable, CFDI-income approval, collection matching, reversals, and COI-ready export;
- cashflow planning read model and UI;
- payroll and AMEX accounting/reconciliation components.

### Assistant spine

- persistent conversations and analyst cases;
- document/media intake;
- governed tool registry;
- semantic work-frame and candidate adjudication;
- evidence quality and answer sufficiency checks;
- executive rendering and trace;
- read-only finance adapter;
- Owner Pack/entity folder readiness and evidence views;
- preview/confirmation boundaries for write-capable actions.

### Cross-domain operating views

- Sam Inbox as a role-aware, read-only queue assembled from existing sources;
- runtime artifact index as discoverability, not a universal artifact archive;
- sports/tournament command-center and dossier projections;
- SOUL coverage/draft/preview support for tournament context.

## 4. Product north star

The target interaction is:

> The user describes a business outcome, supplies files when needed, and receives a prepared, evidence-backed result with missing data, assumptions, validation, preview, authority gate, execution receipt, and resumable context.

The product is not complete when a module screen exists. It is complete when the relevant user can finish the real business outcome with evidence and controlled authority.

## 5. Non-negotiable principles

- Live governed sources outrank memory and prose documentation.
- The assistant may investigate and propose; authority stays with people and configured business rules.
- Read and write behavior must be visibly separated.
- Every write requires a canonical action, authority check, explicit confirmation, idempotency, and audit evidence.
- Missing evidence must remain missing; SamChat must not complete a plausible-looking record by invention.
- Financial states must reflect real workflow transitions, not friendly display defaults.
- Operational reference, SamChat reference, source document, approver, beneficiary, payment/collection evidence, and accounting output must remain traceable.

## 6. Current repository status by lane

| Lane | Status in current `main` | What is still not proven |
| --- | --- | --- |
| Gastos and document workflows | Connected and mature | Full Finance UAT and formal customer acceptance |
| Payment Run | Connected, with cutoff, proof, history, and export | End-to-end UAT across all roles and production reconciliation after recent fixes |
| Presupuestos | Connected and substantially expanded | Final reconciliation, catalog cleanup, and user acceptance across all tournaments |
| Accounts receivable | Connected with UI, matching, approvals, accounting, and export | Final issued-CFDI production integration and Finance UAT |
| Cashflow | Connected read model and admin UI | Forecast acceptance and full bank-source completeness |
| Assistant | Connected, governed, and broad read-only capability | A proven general-purpose write cycle equivalent to the product promise |
| Owner Pack/entity folders | Connected read-only views | Complete SOUL/source coverage and durable publication workflow |
| Tournament/OCR | Connected operational review flow | Productive FMF integration and complete contractual dedup/calendar/logistics closure |
| Sports command views | Connected projections | Full transaction-capable tournament operating system |
| Sponsor/marketing automation | Code/projection components exist | Persistent approval, external publishing, engagement analytics, and accepted proof-of-performance cycle |

## 7. SOW traceability

The 2025 proposal is scope evidence. Its descriptions and KPI percentages are not measurements of delivered performance.

| SOW area | Current evidence | Canonical status |
| --- | --- | --- |
| Project management engine | Tournament operational commitments, SOUL, Sam Inbox, assistant cases, and projections exist | Partial; no single proven general project-management engine |
| Registration, OCR, roster, compliance | Governed registration-review and OCR pipelines, teams/players, incident controls, commit rules | Strong partial / operational |
| FMF validation | Rules and references exist | Productive external integration not proven |
| Global deduplication | Duplicate and integrity controls exist in registration/OCR flows | Partial; contractual global-padrón closure not proven |
| Intelligent scheduling | Sports projections and planning artifacts exist | Not proven as a live optimizer with real venue/referee constraints |
| Uniforms, venues, referees, logistics | Data/projection concepts exist | End-to-end operating workflows not proven |
| Gastos and expense accounts | Extensive live-web models, routes, services, and tests | Strong repository evidence; UAT still required |
| Accounts payable | Solicitudes, approvals, Payment Run, payment proof, accounting/export surfaces | Strong repository evidence; UAT still required |
| Accounts receivable | AR read model, UI, CFDI link approval, collection matching, reversal, accounting, export | Implemented in repository after the June sweep; production/UAT closure unproven |
| Payroll | Substantial models, services, routes, and accounting mapping | Above-baseline implementation; UAT and contractual acceptance still separate |
| Budgets by project | Canonical budget routes and extensive service layer | Strong repository evidence; data cleanup/UAT remain |
| COI/SAE integration | COI exports/import-oriented components exist | Live bidirectional SAE/COI integration not proven |
| Dashboards/reports | Finance, budgets, AR, cashflow, sports, inbox, artifacts, executive exports | Strong repository evidence; do not infer every SOW dashboard is accepted |
| Marketing communications | Existing communications/media surfaces plus sponsor-media projections | Partial |
| Sponsor/branding approval | In-memory workflow/proof-package logic and tests | Not proven as persistent end-to-end production flow |
| Social publishing | No sufficient current evidence of accepted external publication automation | Open |
| Engagement analytics | No sufficient current evidence of complete multichannel analytics | Open |
| Proof-of-performance | Builders/projections exist | End-to-end accepted sponsor delivery not proven |
| Onboarding, training, go-live, support | Documentation and support surfaces exist | Formal contractual closeout package not proven |

## 8. Contract facts that remain contract facts

The attached SOW states:

- 854 estimated hours;
- estimated labor total of MXN 607,200 plus applicable VAT;
- MXN 35,000 plus VAT discount for AI Envision sessions;
- 30% / 40% / 30% payment structure;
- approximately 12 weeks;
- two full training days;
- six months of post-delivery monthly support;
- third-party licenses, hardware, SaaS, PAC, WhatsApp, and cloud costs outside the base amount;
- a suggested maintenance annex of MXN 45,000 plus VAT per month and 20 technical hours.

These numbers must not be silently replaced by later commercial arrangements. Actual invoices, payments, discounts, support caps, and change orders require their own evidence.

The SOW also contains aggressive outcome targets such as 70% faster setup, 90% fewer scheduling errors, 40% lower operating costs, and 90% adoption. Treat them as proposed targets unless a baseline, measurement method, observation window, and accepted result exist.

## 9. Current critical workflow rule: reimbursement after expense report

For a reimbursement created from an expense report:

1. the `INFORME` is the budget-controlled artifact;
2. the `INFORME` must be classified and approved;
3. the reimbursement request inherits the budget concept and approver;
4. the reimbursement request does not return to Control Presupuestal;
5. it enters Payment Run only after those conditions are satisfied;
6. Payment History must not label an ineligible request as `programada`.

Repository state on 2026-09-10:

- #303 merged: recover eligible reimbursements stuck in Control Presupuestal;
- #306 merged: exclude ineligible requests from false scheduled-payment history;
- #304 merged and deployed as `dcbeea8423030e0123101a35378d765ea3c96f32`:
  require a budget concept on the approved linked `INFORME` before promotion.

The deployed guard does not by itself close the business incident: historical
reconciliation and affected-reference verification remain required, and Finance
UAT is separate evidence.

### 9.1 Expense-report COI policy granularity

Date: 2026-09-29

An `INFORME` is the accounting export unit. Its active expense items, tax
movements, and CFDI evidence must be emitted under exactly one COI policy
header. A single expense that belongs to an `INFORME` must not be exported as
an independent policy.

The export is atomic. If any active item is not COI-ready, the complete
`INFORME` policy is blocked. No partial file is generated and no item is
marked `contabilizado`.
Cancelled items remain excluded. Standalone third-party requests retain their
existing policy granularity.

Amendment date: 2026-10-05. Reason: explicit human approval to remove the
cross-month export restriction. Active items may have dates in different
months or years while remaining under one complete `INFORME` policy. Their
original expense dates and CFDI evidence are preserved. Each normal report is
discovered only in its approval month for both monthly COI surfaces and Finance
batches, including all its active items regardless of their dates. Missing
approval dates remain explicit blockers, without a creation-date fallback.
Company-AMEX reports retain their canonical cut controls and are exported only
from the immutable initial cut in that cut's accounting month; this change does
not authorize cross-month cut creation or rebuilding mutable classifications.
Approval, accounting readiness, beneficiary and tax validations remain required.
Evidence: the scoped correction in
`user_routes.py` and `admin_routes.py`, with regression cases in
`tests/unit/gastos/test_coi_exportable_status_ui.py`. This amendment describes
the approved implementation scope; merge, deployment and Finance UAT remain
pending their own evidence.

Repository evidence for this amendment is the approved 2026-09-29 correction
that groups XLSX, CSV, ZIP, document, and batch exports by `INFORME` and adds
focused regression coverage. Merge, deployment, authenticated Finance UAT, and
business acceptance remain separate evidence.

Amendment date: 2026-10-13. Explicit human approval of technical specification and this canon text. Reason: use the approved expense account as accounting source without repeating its comprobacion. Evidence: `docs/roadmap/amex-approved-informe-20261013-spec.md` and its approved story. Approved candidate; implementation validation, merge, deployment and Finance UAT remain pending.

La aprobación final real de un INFORME acredita comprobación documental de su CuentaDeGastos mediante evidencia inmutable del evento autoritativo, entidad, actor, fecha y versión. No atribuye autoridad Finance al aprobador ni genera póliza. Finanzas declara tratamientos y excepciones del informe completo con una confirmación contable explícita; no repite comprobación individual ya aprobada. Falta de tarjeta, mapping, tratamiento o evidencia produce excepción, jamás inferencia o cero.

Partidas AMEX de informe aprobado pueden originar reconocimiento contable report-first con ancla real de partida y sin cargo bancario previamente seleccionado. Corte completo mantiene una póliza inicial única e inmutable por INFORME, y ajustes preservan historia. Históricos sin snapshot no reciben atestaciones retrospectivas ficticias; confirmación actual Finance se identifica como tal y no regulariza los 14 casos históricos bloqueados.


Amendment date: 2026-10-13. Explicit human approval of the technical specification and exact canon text. Reason: a clear statement-to-policy workflow and separation of report attention from AMEX manual queues. Evidence: `docs/roadmap/amex-statement-workflow-20261013-story.md` and `docs/roadmap/amex-statement-workflow-20261013-spec.md`. Approved implementation scope; merge, owner-run migration, deployment and authenticated Finance UAT require their own receipts.

AMEX dispone de un recorrido por importación de estado de cuenta con identidad persistida de archivo, tarjeta y período declarados. Su avance separa pendientes operativos, asociación bancaria y disponibilidad contable. La importación no aprueba informes ni origina pólizas. Finanzas selecciona fuentes explícitas y confirma cada INFORME completo mediante el corte canónico; vínculo de navegación no acredita conciliación. La política de atención por beneficiario explícito puede retirar informes y partidas de la cola manual sin ocultar cargos bancarios, alterar su estado ni excluirlos de controles financieros. Identidad ausente o contradictoria permanece visible. Cargas históricas no reciben identidad de estado reconstruida.

Amendment date: 2026-10-14. Explicit human approval of the technical specification and exact canon text on 2026-10-15. Reason: direct statement/SAT-to-budget/accounting workflow without a fabricated expense report. Evidence: `docs/roadmap/amex-sat-budget-direct-20261015-spec.md` and its approved story; implementation, migration, merge, deployment and Finance UAT remain separate gates.

El recorrido AMEX directo admite como fuente contable un estado identificado y sus cargos reales, con CFDI SAT/evidencia fiscal, entidad receptora explícita, clasificación de Contabilidad, asignación presupuestal por autoridad configurada y confirmación Finance. No requiere ni fabrica un INFORME. Conciliación automática utiliza política aprobada de identidad fiscal/comercio, vigencia, economía y unicidad global; faltantes o ambigüedad permanecen pendientes. Contabilidad define proyecto/torneo y categoría; Control Presupuestal asigna únicamente la partida. El corte directo íntegro e inmutable genera como máximo una póliza nueva por estado para consumos no reconocidos; los consumos ya cubiertos conservan sus receipts y pólizas. No se permiten doble gasto, base fiscal o pasivo ni exportación parcial. Programación y liquidación de la tarjeta mantienen su owner y no se condicionan por un nuevo gate de CFDI.

### 9.2 Monthly DIOT by effective payment date

Amendment date: 2026-10-09. This canon diff received explicit human approval.
The monthly DIOT period is determined by `Documento.fecha_pago_efectiva`, never
by the expense capture date or an invented fallback. A direct paid-document
relationship has priority. A single paid date on the same `CuentaDeGastos` may
resolve the period; missing or multiple possible dates remain visible outside
the monthly result until their linkage is corrected.

The accounting UI provides a period preview, an audit workbook, and the SAT TXT.
The TXT fails closed when a paid movement in the selected period lacks required
fiscal evidence or has an unconfirmed shared CFDI. Cancelled expenses and items
marked for COI reversal are excluded. Confirmed shared CFDIs are allocated in
proportion to the evidenced amount applied to each expense. IVA withholding is
read only from CFDI XML tax detail; it is never inferred from supplier type,
association status, expense totals, or accounting labels. The existing
per-report DIOT downloads remain available.

Evidence: isolated worktree based on `7d857ad326a`, focused unit and route
tests, and a production-data classification executed inside an explicit
read-only transaction. This is not a SAT submission, data correction, merge,
deployment, authenticated Finance UAT, or business acceptance.

## 10. Current closure gates

A finance capability is not “done” until it passes a real UAT path showing:

- requester and beneficiary;
- authorization route and approver;
- operational and SamChat references;
- source document and evidence;
- payment or collection proof;
- generated accounting entry;
- downloadable COI-ready output where applicable;
- final state visible in the correct operational board;
- no contradictory state in adjacent boards.

The repository UAT document remains `PENDING_FINANCE_UAT` across its listed cases at the inspected baseline.

## 11. Product priorities

1. Preserve and verify the deployed #304 reimbursement guard while completing
   historical reconciliation and reference-by-reference evidence.
2. Run focused production reconciliation for Referencia Operaciones 96 and every equivalent historical record.
3. Execute the integral Finance UAT and convert failures into bounded defects, not uncontrolled scope growth.
4. Keep stabilizing the assistant's read/evidence loop before opening broad write authority.
5. Complete source coverage for Owner Pack/SOUL before promising complete folders.
6. Treat FMF, scheduling, logistics, sponsor approval/publication, and proof-of-performance as explicit contractual closure lanes.
7. Produce a formal delivery closeout: accepted items, observations, open scope, handoff, support terms, and payment status.

## 12. Common reasoning errors

- Calling SamChat only a chatbot or only a dashboard.
- Treating every repo module as part of the live runtime.
- Saying “implemented” without specifying code, deployment, or acceptance.
- Treating a Payment Run cutoff as proof of payment.
- Treating an AR candidate as proof of collection.
- Treating an assistant artifact as the business source of truth.
- Treating sponsor package generation as external delivery.
- Treating SOW KPIs as achieved results.
- Treating all work added after the SOW as included contractual scope.

## 13. Safe short description

SamChat is Plataforma Sports' governed operational system for tournament, gastos, finance, evidence, and assistant workflows. Its current repository contains substantial live-web functionality across gastos, Payment Run, budgets, AR, cashflow, OCR, Sam Inbox, and a read-mostly governed assistant. The remaining work is not a rebuild; it is production verification, Finance UAT, contractual closure of specific operations/marketing integrations, and proof that the assistant can complete controlled end-to-end business outcomes.

## 14. Direction executive boards and reports amendment

Date: 2026-09-11

Reason: this amendment governs the pending correction to #314 and #315.
Executive boards and reports are an internal Plataforma Sports
surface for Direction and internal owners who hold an eligible organizational
position; they are not an external customer portal.

For a non-superadmin, authorization requires all of the following:

- an active internal employee identity;
- one of the initial eligible positions: `direccion_general`,
  `direccion_administracion_finanzas`, `direccion_goat`, or
  `director_operaciones`;
- active assigned portfolio and tournament scope.

`superadmin` may supervise active portfolios. An `admin` does not receive
global executive access merely from its role. No `cliente` role exists or is
required for this surface. Specific permissions may restrict actions within
this surface, but never create scope or substitute the eligible position.

Executive board and published-report consumption are read-only within assigned
scope. Report schedule configuration, draft creation and state transitions are
internal governed writes requiring their specific authority and audited actor.
Eligible Direction positions have cross-domain executive visibility over
Operations, Finance, and Marketing facts within their assigned active portfolio
and tournament scope. This visibility is read-only: it does not authorize the
viewer to create, modify, approve, pay, publish, or delete a business record.
Specific denials still prevail. Missing facts must remain visibly missing and
must never be replaced with inferred people, events, amounts, dates, or zeroes.
Personal contact data is visible only when needed for the executive purpose and
must not leak through URLs, logs, metrics, errors, or general exports.

Physical `client_*` package, table, and route-module names are temporary
internal compatibility debt, not a product or authorization concept. Their
future rename requires a separately approved migration and rollback plan.

Evidence: the internal Direction authorization correction was merged and
deployed as `06ff7d9f5bb5af85b9ae3360e66d527aec62e1a0`; health, readiness,
release guards, legacy redirects, and anonymous denial were verified. The
portfolio and tournament scope was configured for the eligible Direction
positions. The expanded executive dossier remains an approved repository
change under review until its own merge and deployment. Authenticated UAT and
business acceptance remain pending.

## 15. Direction supervision and independent documentary facts amendment

Date: 2026-10-02. Human authorization: Francisco explicitly authorized SUPERADMIN
to read all active tournaments in these boards, relayed at 18:27 UTC. This
amendment is proposed in a draft PR and requires human review before merge.

SUPERADMIN supervision now includes the active tournament catalog of the current
Plataforma Sports installation even without portfolio membership. It does not
include unrelated organizations, external catalogs, inactive tournaments, or any
new action authority. Other profiles retain their assigned active portfolios and
positions. An explicit portfolio filter narrows even SUPERADMIN's selection;
explicit denials still prevail. No persistent assignment is created by a read.

Documentary facts with their own verified source coverage must remain visible
without an approved budget. Absence of an approved budget is not an authorized
zero. Expenses use the canonical fiscal base and expense date; commitments and
documentary paid amounts use the canonical payable amount in the request creation
cohort. These stages are not added together, and none proves bank cash. Monthly
budget, operating classifications, reconciled cash and comparative periods require
their own source evidence; the supplied workbook examples are not production data.

Evidence: isolated worktree from PR452, synthetic unit/browser/export verification
and draft review evidence in `docs/evidence/direction-report-redesign`. No production
access, merge, deployment, or business acceptance is claimed.

## 16. Copa Telmex registration PostgreSQL candidate amendment

Date: 2026-10-05

Reason: human-approved first delivery of registration read-source consolidation; preserve the distinction between local candidate, production activation, and canonical intake. The final diff and this amendment were explicitly approved in the conversation.

La primera entrega de consolidación de inscripción de Copa Telmex añade un catálogo explícito de torneo y edición. Para ediciones configuradas en ese catálogo, el asistente y Dirección consumen una misma proyección del registro operativo PostgreSQL, distinguiendo equipos, jugadores activos y provisionales, revisiones pendientes y disponibilidad de fuente. La captura y el estado activo no acreditan elegibilidad externa. La revisión visual de los 11 expedientes se conserva como evidencia pendiente de admisión canónica; no constituye una importación ni autorización automática. Las ediciones sin configurar conservan su ruta anterior. La activación productiva y la aceptación autenticada deben documentarse por separado.

Evidence: `docs/roadmap/ctt-postgres-registration-first-delivery.md` and its scoped test and review receipts. This is an isolated-worktree candidate; merge, deployment, data application, authenticated UAT, and business acceptance remain separate.

### Proposed 2026-10-06 amendment: partial paid-advance comprobaciones

Requires explicit human PR review. Reason: Francisco requests applicant-confirmed
motives, approver comments, an open original report until zero, and incremental
accounting without duplicate recognition. This proposal does not establish
production or business acceptance.

For an open, unapproved, non-AMEX report with an actually paid advance and its
existing debtor posting, the applicant may explicitly submit the newly captured
expenses as a child `INFORME`. The original report remains an open case container;
it must never be approved or exported again in partial mode. Each child owns
only its explicitly assigned expenses and retains its confirmed applicant motive.
The authorized approver must read that motive and record comments. Budget-control
and accounting-readiness gates still apply. Each approved child has its own
idempotent debtor recognition and one atomic COI policy in its approval month.
Previously approved expenses cannot be reassigned or mutated; corrections require
accounting reversal rather than overwriting recognized evidence.

Actual, evidenced advance returns reduce the same collaborator debtor balance.
Repeated submissions reuse the original result; additional returns require new
submission identities. The original closes only when all children are approved,
no active expenses remain unassigned, and the persisted debtor auxiliary is zero.
Ordinary full reimbursement and company-AMEX immutable-cut rules remain intact.

Evidence: `docs/roadmap/partial-advance-comprobaciones.md`, scoped implementation,
SQLite-backed workflow/ledger tests and isolated PostgreSQL/WASM migration tests.
No production migration, deployment, authenticated UAT, or historical mutation
has been performed.

## 17. Copa Telmex reviewed-dossier admission candidate amendment

Date: 2026-10-06

Reason: add a review-only, source-bound admission path for the 11 manually
reconciled Copa Telmex 2026 dossiers while preserving the distinction between
draft admission, governed team commit, eligibility, production data application,
and business acceptance.

The candidate accepts an authenticated private batch manifest bound to the exact
tournament edition, PDF hashes, ordered source pages, extraction payloads, and
two technical-staff slots. It creates idempotent registration-review drafts and
receipts; it does not create teams, players, staff, or eligibility. Director
tecnico and auxiliar evidence remains visible in review. Because the current
REG-S05/Zaubern decision contract authorizes player slots only, any draft with
technical staff fails closed with `STAFF_GOVERNANCE_CONTRACT_REQUIRED`. Staff
commit requires a separately approved external contract expansion and a later
SamChat commit integration. The 11 dossiers remain pending production admission
until the owner migration, deployment, authenticated submission, and resulting
zero-team/zero-eligibility receipt are verified.

Evidence: `docs/roadmap/ctt-pilot-batch-admission.md`, scoped tests, isolated
PostgreSQL migration verification, and independent implementation validation.
This remains an isolated-worktree candidate; merge, deployment, migration/data
application, authenticated UAT, and business acceptance are separate.


### AMEX directo: recuperación auditada de cobertura temporal

Fecha: 2026-10-15. Texto y especificación técnica aprobados explícitamente por el usuario con «aprobada». Razón: corregir cargos omitidos por período conservando fuentes y controles financieros. Evidencia: `docs/roadmap/amex-qa-remediation-20261015-spec.md`, sección 9, y assessment QA asociado. Candidato aprobado para implementación; migración, aplicación productiva, promoción y UAT mantienen sus propios checkpoints.

Contabilidad puede corregir explícitamente la cobertura temporal declarada de un estado directo todavía no reconocido cuando el archivo original demuestra cargos omitidos únicamente por estar fuera del período capturado. La recuperación preserva el original y sus recibos, conserva los cargos ya creados y agrega sólo los cargos faltantes mediante evidencia auditada e idempotente. No cambia identidad fiscal, no crea informes, no aprueba gastos ni modifica fuentes reconocidas. La fecha contable sigue siendo una declaración explícita dentro de la cobertura efectiva confirmada y un período abierto.
## 18. Approved budget distribution revision rules

Date: 2026-10-14. Human approval: Francisco, evidence
`Sentinel_e34dca62ad888191ae00a160c9ee5b09`. Reason: complete the distribution
of authorized budgets without changing their amounts or losing history.
Evidence: `docs/roadmap/budget-distribution-20261014-candidate.md`.

Una revisión de distribución puede sustituir al presupuesto activo, incluso
congelado, únicamente al aprobarse con las mismas partidas e importes y con
las semanas conciliadas al total. El original conserva su historial; otro
ajuste requiere otra revisión. Cada semana se asigna al mes en que empieza;
el acumulado incluye completo el mes seleccionado. Las 26 categorías fijas
quedan en N/D hasta que Finanzas confirme qué partidas corresponden a cada
una. La tabla por partidas reales sí muestra los periodos.

This records approved candidate rules, not production correction or business
acceptance. Git publication was separately authorized through
`Sentinel_a80479c5cb1081919315d4fa293a5777`; merge and deployment are not
authorized. Finance crosswalk, the identified incident case and authenticated
UAT remain pending. Economic replacement and historical retirement are outside
this distribution-only scope.


### AMEX: sugerencias y cancelación de cuenta de gastos

Fecha:2026-10-20. Especificación y texto exacto aprobados explícitamente por el usuario mediante «aprobada». Razón: sugerencias de CFDI y contabilización sin duplicidades según la política operativa indicada por Plataforma Sports. Evidencia: `docs/roadmap/amex-suggestions-settlement-20261020-story.md` y `docs/roadmap/amex-suggestions-settlement-20261020-spec.md`, sección10. Estado: implementación autorizada; pruebas, validación, publicación, migración, despliegue y aceptación financiera conservan evidencia y checkpoints separados.

AMEX directo presenta sugerencias de CFDI descargados de la entidad autorizada según evidencia de importe, comercio y fechas; distancia de fechas o cambio de mes no descartan por sí solos una candidata. La semejanza es propuesta y no confirma identidad, propina, uso compartido ni contabilización. PUE/PPD, fecha del cargo y emisión fiscal se conservan diferenciados. Conforme a la política operativa indicada por Plataforma Sports para todas sus tarjetas AMEX, la ausencia del complemento de pago se informa y no bloquea conciliación, registro del IVA acreditable desde el CFDI ni póliza; no altera requisitos restantes ni reescribe historia. Un gasto nuevo se clasifica/presupuesta; un pasivo AMEX ya reconocido sólo se asocia; un crédito real pendiente en cuenta de gastos se cancela contra AMEX mediante evidencia de origen y saldo, sin nuevo gasto, IVA o presupuesto. Ninguna de estas acciones registra el pago bancario de la tarjeta.


### AMEX directo: declaración explícita Sin CFDI

Fecha:2026-10-21. Texto exacto y especificación aprobados por el usuario mediante «aprobada». Razón: resolver cargos nuevos que no tendrán CFDI sin fabricar evidencia fiscal. Evidencia: `docs/roadmap/amex-no-cfdi-20261021-story.md` y `docs/roadmap/amex-no-cfdi-20261021-spec.md`, §10. Estado: construcción y pruebas autorizadas; validación final, publicación, migración, despliegue y aceptación financiera requieren sus propios recibos.

AMEX directo permite que un operador autorizado de Contabilidad declare explícitamente un cargo nuevo Sin CFDI, con motivo, tratamiento y evidencia bancaria conservados. La declaración no fabrica factura, identidad fiscal o aprobación presupuestal. Para el tratamiento importe completo como gasto sin movimientos fiscales, la partida presupuestal determina la cuenta de gasto y la tarjeta determina el pasivo; no se estima IVA, retención, propina ni deducibilidad por ausencia de factura. El estado completo mantiene sus controles y una póliza inmutable. Una factura recibida después no altera una declaración o corte automáticamente; antes del corte se requiere revocación explícita y las correcciones posteriores conservan su autoridad e historia.
