"""Reversible entrypoint retirement; no business or conversation mutations."""

import os
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from devnous.gastos.routes.batisenal_routes import widget_html
from devnous.gastos.routes.dependencies import get_current_empleado

router = APIRouter(tags=["assistant-history"])
HISTORY_PATH = "/assistant/history"
TEMPLATE = Path(__file__).resolve().parents[3] / "templates/assistant_history.html"
HEADERS = {
    "Cache-Control": "no-store",
    "Referrer-Policy": "no-referrer",
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
}


def enabled() -> bool:
    """Opt-in UI switch, never an authorization or provider activation gate."""
    return os.getenv("ASSISTANT_UI_RETIREMENT_ENABLED") == "1"


def entry() -> tuple[str, str]:
    return (
        (HISTORY_PATH, "Ayuda e historial")
        if enabled()
        else ("/assistant", "BI/assistant")
    )


def legacy_entry() -> str:
    """Keep dependent admin workflows reachable until their replacement is accepted."""
    return "/assistant?legacy=1" if enabled() else "/assistant"


def redirect_entry(request: Request, path: str = ""):
    """Only retire identified chat entrypoints; preserve other SPA surfaces.

    legacy=1 is a documented presentation escape for dependent workflows,
    not an auth bypass. Existing API and SPA auth gates still apply.
    No query/context values are forwarded to the new surface.
    """
    if enabled() and path.strip("/") in {"", "history"}:
        if request.query_params.get("legacy") != "1":
            return RedirectResponse(HISTORY_PATH, status_code=307, headers=HEADERS)
    return None


@router.get(HISTORY_PATH, response_class=HTMLResponse, include_in_schema=False)
async def history_page(current_empleado=Depends(get_current_empleado)):
    # Same assistant.shell policy and active local identity as the API.
    if not enabled():
        raise HTTPException(404, "History entry is not enabled", headers=HEADERS)
    widget = widget_html("soporte")
    help_markup = widget or (
        "<p>La ayuda contextual no está habilitada en esta instancia. "
        "Tu historial continúa disponible.</p>"
    )
    return HTMLResponse(
        TEMPLATE.read_text(encoding="utf-8").replace("<!-- HELP -->", help_markup),
        headers=HEADERS,
    )
