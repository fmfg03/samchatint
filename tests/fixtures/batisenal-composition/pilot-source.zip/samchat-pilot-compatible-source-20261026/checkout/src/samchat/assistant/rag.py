from __future__ import annotations

import json
import hashlib
import math
import os
import re
from urllib import request as urllib_request
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from threading import Lock
from typing import Any, Dict, List, Optional


ALLOWED_EXTENSIONS = {
    ".txt",
    ".md",
    ".markdown",
    ".rst",
    ".json",
    ".csv",
    ".log",
    ".yaml",
    ".yml",
    ".py",
    ".sql",
    ".js",
    ".jsx",
    ".ts",
    ".tsx",
    ".html",
}


@dataclass
class RAGChunk:
    chunk_id: str
    source: str
    text: str
    embedding: List[float]
    metadata: Dict[str, Any]


class LocalRAGStore:
    def __init__(self, *, index_path: Optional[str] = None) -> None:
        base_dir = Path(os.getenv("ASSISTANT_RAG_BASE_DIR", "/root/samchat"))
        default_path = base_dir / "data" / "assistant_rag_index.json"
        self.index_path = Path(
            index_path or os.getenv("ASSISTANT_RAG_INDEX_PATH", str(default_path))
        )
        self.index_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = Lock()
        self._index: Dict[str, Any] = {
            "created_at": datetime.utcnow().isoformat(),
            "updated_at": datetime.utcnow().isoformat(),
            "chunks": [],
        }
        self._load()

    def _load(self) -> None:
        if not self.index_path.exists():
            return
        try:
            data = json.loads(self.index_path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and isinstance(data.get("chunks"), list):
                self._index = data
        except (ValueError, OSError) as exc:
            raise RuntimeError("RAG_INDEX_UNAVAILABLE") from exc

    def _save(self) -> None:
        self._index["updated_at"] = datetime.utcnow().isoformat()
        self.index_path.write_text(
            json.dumps(self._index, ensure_ascii=False, separators=(",", ":")),
            encoding="utf-8",
        )

    def _chunk_text(
        self, text: str, *, chunk_size: int = 1200, overlap: int = 180
    ) -> List[str]:
        t = (text or "").strip()
        if not t:
            return []
        if len(t) <= chunk_size:
            return [t]
        chunks: List[str] = []
        start = 0
        while start < len(t):
            end = min(len(t), start + chunk_size)
            chunk = t[start:end].strip()
            if chunk:
                chunks.append(chunk)
            if end >= len(t):
                break
            start = max(start + 1, end - overlap)
        return chunks

    def _iter_files(
        self,
        paths: List[str],
        *,
        max_files: int,
    ) -> List[Path]:
        base_dir = Path(os.getenv("ASSISTANT_RAG_BASE_DIR", "/root/samchat"))
        collected: List[Path] = []
        for item in paths:
            p = Path(item)
            if not p.is_absolute():
                p = base_dir / p
            if not p.exists():
                continue
            if p.is_file():
                if p.suffix.lower() in ALLOWED_EXTENSIONS:
                    collected.append(p)
            else:
                for f in p.rglob("*"):
                    if f.is_file() and f.suffix.lower() in ALLOWED_EXTENSIONS:
                        collected.append(f)
                        if len(collected) >= max_files:
                            return collected
            if len(collected) >= max_files:
                return collected
        return collected

    def _embedding_backend(self) -> Dict[str, str]:
        provider = (os.getenv("ASSISTANT_RAG_EMBED_PROVIDER") or "auto").strip().lower()
        model = (
            os.getenv("ASSISTANT_RAG_EMBED_MODEL")
            or os.getenv("OLLAMA_EMBED_MODEL")
            or "nomic-embed-text"
        ).strip()
        base_url = (
            (os.getenv("OLLAMA_BASE_URL") or "http://127.0.0.1:11434")
            .strip()
            .rstrip("/")
        )
        return {
            "provider": provider or "auto",
            "model": model or "nomic-embed-text",
            "base_url": base_url or "http://127.0.0.1:11434",
        }

    def _embed_texts_openai(self, client: Any, texts: List[str]) -> List[List[float]]:
        model = os.getenv("OPENAI_EMBEDDING_MODEL", "text-embedding-3-small")
        embeddings: List[List[float]] = []
        batch_size = int(os.getenv("ASSISTANT_RAG_EMBED_BATCH_SIZE", "64"))
        for i in range(0, len(texts), batch_size):
            batch = texts[i : i + batch_size]
            resp = client.embeddings.create(model=model, input=batch)
            for row in resp.data:
                embeddings.append([float(x) for x in row.embedding])
        return embeddings

    def _embed_texts_ollama(self, texts: List[str]) -> List[List[float]]:
        cfg = self._embedding_backend()
        payload = json.dumps({"model": cfg["model"], "input": texts}).encode("utf-8")
        req = urllib_request.Request(
            f"{cfg['base_url']}/api/embed",
            data=payload,
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            method="POST",
        )
        timeout_sec = max(5, int(os.getenv("ASSISTANT_RAG_EMBED_TIMEOUT_SEC", "60")))
        with urllib_request.urlopen(req, timeout=timeout_sec) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
        data = json.loads(raw)
        embeddings = data.get("embeddings")
        if not isinstance(embeddings, list):
            raise RuntimeError("Ollama /api/embed returned no embeddings")
        out: List[List[float]] = []
        for row in embeddings:
            if not isinstance(row, list):
                out.append([])
                continue
            out.append([float(x) for x in row])
        return out

    def _embed_texts(self, client: Any, texts: List[str]) -> List[List[float]]:
        cfg = self._embedding_backend()
        provider = cfg["provider"]
        errors: List[str] = []

        if provider in {"auto", "ollama", "local"}:
            try:
                return self._embed_texts_ollama(texts)
            except Exception as exc:
                errors.append(f"ollama:{exc}")
                if provider in {"ollama", "local"}:
                    raise

        if provider in {"auto", "openai"}:
            if client is None:
                errors.append("openai:no_client")
            else:
                try:
                    return self._embed_texts_openai(client, texts)
                except Exception as exc:
                    errors.append(f"openai:{exc}")
                    if provider == "openai":
                        raise

        if errors:
            raise RuntimeError("; ".join(errors))
        raise RuntimeError(f"Unsupported embedding provider: {provider}")

    def ingest(
        self,
        *,
        client: Any = None,
        paths: List[str],
        reset: bool = False,
        max_files: int = 200,
        max_chars_per_file: int = 300_000,
    ) -> Dict[str, Any]:
        with self._lock:
            files = self._iter_files(paths, max_files=max_files)
            if reset:
                self._index = {
                    "created_at": datetime.utcnow().isoformat(),
                    "updated_at": datetime.utcnow().isoformat(),
                    "chunks": [],
                }

            new_chunks_payload: List[Dict[str, Any]] = []
            chunk_texts: List[str] = []
            chunk_meta: List[Dict[str, Any]] = []
            skipped: List[str] = []
            for f in files:
                try:
                    text = f.read_text(encoding="utf-8", errors="ignore")
                    text = text[:max_chars_per_file]
                    chunks = self._chunk_text(text)
                    for idx, c in enumerate(chunks):
                        source = str(f)
                        chunk_id = f"{source}::#{idx}"
                        chunk_texts.append(c)
                        chunk_meta.append(
                            {
                                "chunk_id": chunk_id,
                                "source": source,
                                "metadata": {
                                    "filename": f.name,
                                    "extension": f.suffix.lower(),
                                    "chunk_index": idx,
                                },
                            }
                        )
                except Exception:
                    skipped.append(str(f))

            embedding_error = None
            vectors: List[List[float]] = []
            if chunk_texts:
                try:
                    vectors = self._embed_texts(client, chunk_texts)
                except Exception as exc:
                    embedding_error = str(exc)
                    vectors = [[] for _ in chunk_texts]
                for meta, text, emb in zip(chunk_meta, chunk_texts, vectors):
                    new_chunks_payload.append(
                        {
                            "chunk_id": meta["chunk_id"],
                            "source": meta["source"],
                            "text": text,
                            "embedding": emb,
                            "metadata": meta["metadata"],
                        }
                    )

            existing = self._index.get("chunks", [])
            by_id: Dict[str, Dict[str, Any]] = {
                str(c.get("chunk_id")): c for c in existing
            }
            for c in new_chunks_payload:
                by_id[str(c["chunk_id"])] = c
            self._index["chunks"] = list(by_id.values())
            self._save()

            sources = sorted({c["source"] for c in new_chunks_payload})
            return {
                "indexed_files": len(files),
                "indexed_chunks": len(new_chunks_payload),
                "total_chunks": len(self._index["chunks"]),
                "sources": sources,
                "skipped_files": skipped,
                "embedding_error": embedding_error,
                "index_path": str(self.index_path),
            }

    def status(self) -> Dict[str, Any]:
        with self._lock:
            chunks = self._public_chunks(self._index.get("chunks", []))
            sources = sorted({str(c.get("source")) for c in chunks})
            cfg = self._embedding_backend()
            return {
                "index_path": None,
                "created_at": self._index.get("created_at"),
                "updated_at": self._index.get("updated_at"),
                "source_policy": "reviewed_public_only",
                "private_sources_enabled": False,
                "availability": (
                    "public_sources_configured"
                    if json.loads(os.getenv("ASSISTANT_RAG_PUBLIC_CHUNKS", "{}"))
                    else "public_sources_not_configured"
                ),
                "total_chunks": len(chunks),
                "total_sources": len(sources),
                "sources_sample": sources[:50],
                "embed_provider": cfg["provider"],
                "embed_model": cfg["model"],
            }

    @staticmethod
    def _public_chunks(chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Only exact, owner-reviewed public content can leave the legacy index.

        No tenant authority can be inferred from filenames, roles or chunk labels.
        Private/unclassified chunks stay quarantined until a scoped owner exists.
        """
        try:
            approved = json.loads(os.getenv("ASSISTANT_RAG_PUBLIC_CHUNKS", "{}"))
            if not isinstance(approved, dict):
                raise ValueError("invalid public source manifest")
        except (ValueError, TypeError) as exc:
            raise RuntimeError("RAG_PUBLIC_MANIFEST_UNAVAILABLE") from exc
        return [
            chunk
            for chunk in chunks
            if isinstance(chunk.get("text"), str)
            and isinstance(approved.get(chunk.get("source")), list)
            and hashlib.sha256(chunk["text"].encode()).hexdigest()
            in approved[chunk["source"]]
        ]

    def search(
        self,
        *,
        client: Any = None,
        query: str,
        top_k: int = 6,
        min_score: float = 0.15,
    ) -> List[Dict[str, Any]]:
        q = (query or "").strip()
        if not q:
            return []
        with self._lock:
            chunks = self._public_chunks(self._index.get("chunks", []))
            if not chunks:
                return []
            q_vec: Optional[List[float]] = None
            try:
                q_vec = self._embed_texts(client, [q])[0]
            except Exception:
                q_vec = None
            lexical_min_score = float(
                os.getenv("ASSISTANT_RAG_LEXICAL_MIN_SCORE", "0.02")
            )
            scored: List[Dict[str, Any]] = []
            for c in chunks:
                emb = c.get("embedding")
                text = str(c.get("text") or "")
                lexical_score = _lexical_similarity(q, text)
                vector_score: Optional[float] = None
                if q_vec and isinstance(emb, list) and emb:
                    vector_score = _cosine_similarity(q_vec, emb)
                    # Exact business terms, names, and policy phrases matter.  Embeddings
                    # are useful for semantic recall, but a strong lexical hit must not be
                    # buried behind a semantically-near but operationally-wrong document.
                    lexical_boost = min(1.0, lexical_score * 2.5)
                    score = max(
                        (vector_score * 0.65) + lexical_boost,
                        lexical_score * 3.5,
                    )
                    threshold = min(min_score, lexical_min_score)
                else:
                    score = lexical_score
                    threshold = lexical_min_score
                if score >= threshold:
                    scored.append(
                        {
                            "score": round(score, 4),
                            "vector_score": (
                                round(vector_score, 4)
                                if vector_score is not None
                                else None
                            ),
                            "lexical_score": round(lexical_score, 4),
                            "chunk_id": "public:"
                            + hashlib.sha256(
                                (str(c["source"]) + "\n" + c["text"]).encode()
                            ).hexdigest(),
                            "source": c.get("source"),
                            "text": c.get("text"),
                            # Approval covers source and exact text only. Legacy
                            # envelopes may contain unreviewed tenant data.
                            "metadata": {},
                        }
                    )
            scored.sort(key=lambda x: x["score"], reverse=True)
            return scored[: max(1, min(top_k, 20))]


def _cosine_similarity(v1: List[float], v2: List[float]) -> float:
    if not v1 or not v2 or len(v1) != len(v2):
        return 0.0
    dot = 0.0
    n1 = 0.0
    n2 = 0.0
    for a, b in zip(v1, v2):
        dot += a * b
        n1 += a * a
        n2 += b * b
    if n1 <= 0 or n2 <= 0:
        return 0.0
    return float(dot / (math.sqrt(n1) * math.sqrt(n2)))


def _lexical_similarity(q: str, text: str) -> float:
    q_tokens = set(_tokenize(q))
    t_tokens = set(_tokenize(text))
    if not q_tokens or not t_tokens:
        return 0.0
    inter = len(q_tokens.intersection(t_tokens))
    union_denom = len(q_tokens.union(t_tokens))
    if union_denom <= 0:
        return 0.0
    jaccard = float(inter / union_denom)
    query_coverage = float(inter / len(q_tokens))
    # Business questions are often short and documents are long.  Jaccard alone
    # dilutes exact user terms in long canon documents, so retain a bounded
    # query-coverage signal while keeping the score below vector dominance unless
    # many query terms are explicitly present.
    return max(jaccard, query_coverage * 0.35)


def _tokenize(s: str) -> List[str]:
    parts = re.split(r"[^a-zA-Z0-9_]+", (s or "").lower())
    return [p for p in parts if len(p) > 1]


_RAG_STORE: Optional[LocalRAGStore] = None
_RAG_STORE_LOCK = Lock()


def get_rag_store() -> LocalRAGStore:
    global _RAG_STORE
    with _RAG_STORE_LOCK:
        if _RAG_STORE is None:
            _RAG_STORE = LocalRAGStore()
        return _RAG_STORE
