from __future__ import annotations

import asyncio
import functools
import json
import os
import time
import threading
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from typing import Any, Awaitable, Callable, Dict, List, Optional

from fastapi import HTTPException

from .turn_service import build_turn_messages

RunReadToolFn = Callable[..., Awaitable[Dict[str, Any]]]
OllamaChatFn = Callable[..., Awaitable[Dict[str, Any]]]
ToolPolicyEvaluatorFn = Callable[[str, Dict[str, Any], Optional[str]], Dict[str, Any]]
DeterministicToolAnswerFn = Callable[[str, Dict[str, Any]], Optional[str]]

PROVIDER_TIMEOUT_REASON = "PROVIDER_TIMEOUT"
RUNTIME_BUDGET_REASON = "RUNTIME_BUDGET_EXCEEDED"

_ANTHROPIC_EXECUTOR: ThreadPoolExecutor | None = None
_ANTHROPIC_EXECUTOR_LIMIT: int | None = None
_ANTHROPIC_SEMAPHORE: asyncio.Semaphore | None = None
_ANTHROPIC_SEMAPHORE_LIMIT: int | None = None


def _env_float(name: str, default: float, *, minimum: float, maximum: float) -> float:
    try:
        value = float((os.getenv(name) or "").strip() or default)
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(value, maximum))


def _env_int(name: str, default: int, *, minimum: int, maximum: int) -> int:
    try:
        value = int((os.getenv(name) or "").strip() or default)
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(value, maximum))


def _provider_timeout_seconds() -> float:
    return _env_float(
        "ASSISTANT_AGENT_PROVIDER_TIMEOUT_SECONDS",
        15.0,
        minimum=0.01,
        maximum=300.0,
    )


def _runtime_total_budget_seconds() -> float:
    return _env_float(
        "ASSISTANT_AGENT_RUNTIME_TOTAL_BUDGET_SECONDS",
        20.0,
        minimum=0.01,
        maximum=600.0,
    )


def _provider_max_concurrency() -> int:
    return _env_int(
        "ASSISTANT_AGENT_PROVIDER_MAX_CONCURRENCY",
        2,
        minimum=1,
        maximum=16,
    )


def _anthropic_executor(limit: int) -> ThreadPoolExecutor:
    global _ANTHROPIC_EXECUTOR, _ANTHROPIC_EXECUTOR_LIMIT
    if _ANTHROPIC_EXECUTOR is None or _ANTHROPIC_EXECUTOR_LIMIT != limit:
        if _ANTHROPIC_EXECUTOR is not None:
            _ANTHROPIC_EXECUTOR.shutdown(wait=False, cancel_futures=True)
        _ANTHROPIC_EXECUTOR = ThreadPoolExecutor(
            max_workers=limit,
            thread_name_prefix="assistant-anthropic",
        )
        _ANTHROPIC_EXECUTOR_LIMIT = limit
    return _ANTHROPIC_EXECUTOR


def _anthropic_semaphore(limit: int) -> asyncio.Semaphore:
    global _ANTHROPIC_SEMAPHORE, _ANTHROPIC_SEMAPHORE_LIMIT
    if _ANTHROPIC_SEMAPHORE is None or _ANTHROPIC_SEMAPHORE_LIMIT != limit:
        _ANTHROPIC_SEMAPHORE = asyncio.Semaphore(limit)
        _ANTHROPIC_SEMAPHORE_LIMIT = limit
    return _ANTHROPIC_SEMAPHORE


async def _anthropic_messages_create(
    client: Any,
    *,
    timeout_seconds: float,
    concurrency_limit: int,
    **kwargs: Any,
) -> Any:
    semaphore = _anthropic_semaphore(concurrency_limit)
    call = functools.partial(client.messages.create, **kwargs)
    async with semaphore:
        future = _anthropic_executor(concurrency_limit).submit(call)
        deadline = time.monotonic() + timeout_seconds
        while True:
            if future.done():
                return future.result()
            if time.monotonic() >= deadline:
                future.cancel()
                exc = TimeoutError(PROVIDER_TIMEOUT_REASON)
                raise HTTPException(
                    status_code=504,
                    detail=PROVIDER_TIMEOUT_REASON,
                ) from exc
            sleep_seconds = min(0.01, max(0.0, deadline - time.monotonic()))
            await asyncio.sleep(sleep_seconds)


_OPENAI_EXECUTOR = ThreadPoolExecutor(
    max_workers=16, thread_name_prefix="assistant-openai"
)
_OPENAI_LOCK = threading.Lock()
_OPENAI_RUNNING = 0


async def _openai_create(create, *, timeout_seconds, **kwargs):
    # Bound queued + running work, retaining the slot if a timed-out SDK call
    # is still running. SDK calls cannot be forcibly killed by asyncio.
    global _OPENAI_RUNNING
    deadline = time.monotonic() + timeout_seconds
    while True:
        with _OPENAI_LOCK:
            if _OPENAI_RUNNING < _provider_max_concurrency():
                _OPENAI_RUNNING += 1
                break
        if time.monotonic() >= deadline:
            raise HTTPException(504, PROVIDER_TIMEOUT_REASON)
        await asyncio.sleep(0.005)

    def release(_future=None):
        global _OPENAI_RUNNING
        with _OPENAI_LOCK:
            _OPENAI_RUNNING -= 1

    try:
        future = _OPENAI_EXECUTOR.submit(functools.partial(create, **kwargs))
    except BaseException:
        release()
        raise
    future.add_done_callback(release)
    try:
        while not future.done():
            if time.monotonic() >= deadline:
                raise HTTPException(504, PROVIDER_TIMEOUT_REASON)
            await asyncio.sleep(0.005)
        return future.result()
    finally:
        # Cancel only work that has not started; running calls keep their slot.
        if not future.done():
            future.cancel()


def _pending_summary(tool_name: str, args: Dict[str, Any]) -> str:
    return (
        f"El asistente quiere ejecutar: {tool_name} con estos parametros:\n"
        f"{json.dumps(args, ensure_ascii=False, indent=2)}"
    )


def _latest_deterministic_tool_trace_answer(
    *,
    tool_trace: List[Dict[str, Any]],
    deterministic_tool_answer: Optional[DeterministicToolAnswerFn],
) -> Optional[str]:
    if deterministic_tool_answer is None:
        return None
    for step in reversed(tool_trace):
        tool_name = step.get("tool")
        result = step.get("result")
        if not tool_name or not isinstance(result, dict):
            continue
        answer = deterministic_tool_answer(str(tool_name), result)
        if answer:
            return answer
    return None


async def _provider_controlled_failure_response(
    *,
    run_id: Any,
    reason: str,
    provider: str,
    model: str,
    route_info: Dict[str, Any],
    normalized_mode: str,
    raw_message: str,
    conversation: Any,
    current_empleado: Any,
    session: Any,
    tool_trace: List[Dict[str, Any]],
    assistant_run_cls: Any,
    assistant_message_cls: Any,
    message_response_cls: Any,
    deterministic_tool_answer: Optional[DeterministicToolAnswerFn] = None,
    finalize_response: Optional[Callable[..., Any]] = None,
) -> Any:
    fallback_answer = _latest_deterministic_tool_trace_answer(
        tool_trace=tool_trace,
        deterministic_tool_answer=deterministic_tool_answer,
    )
    message = fallback_answer or (
        "El proveedor del asistente tardó demasiado en responder. "
        "No ejecuté acciones ni cambios; intenta de nuevo con una consulta más corta."
    )
    if finalize_response:
        message, tool_trace = finalize_response(message, tool_trace)
    assistant_msg = assistant_message_cls(
        conversation_id=conversation.id,
        role="assistant",
        content=message,
        tool_name=None,
        tool_payload=None,
    )
    session.add(assistant_msg)
    run = assistant_run_cls(
        id=run_id,
        conversation_id=conversation.id,
        empleado_id=current_empleado.id,
        status="provider_timeout",
        model=f"{provider}:{model}:{route_info['route']}:{normalized_mode}",
        user_message=raw_message,
        assistant_message=message,
        tool_trace=tool_trace,
        pending_tool_name=None,
        pending_tool_args=None,
        created_at=datetime.utcnow(),
    )
    session.add(run)
    conversation.updated_at = datetime.utcnow()
    await session.commit()
    return message_response_cls(
        assistant_message=message,
        run_id=str(run_id),
        tool_trace=tool_trace,
        pending_confirmation=None,
    )


def _evaluate_tool_policy(
    *,
    tool_policy_evaluator: Optional[ToolPolicyEvaluatorFn],
    tool_trace: List[Dict[str, Any]],
    tool_name: str,
    args: Dict[str, Any],
    current_role: Optional[str],
) -> Optional[Dict[str, Any]]:
    if tool_policy_evaluator is None:
        return None
    decision = tool_policy_evaluator(tool_name, args, current_role)
    tool_trace.append({"assistant_policy": decision})
    if decision.get("decision") == "deny":
        tool_trace.append(
            {"blocked_tool": {"tool": tool_name, "reason": decision.get("reason")}}
        )
        raise HTTPException(
            status_code=403,
            detail=f"Tool blocked by assistant policy: {decision.get('reason')}",
        )
    return decision


async def _provider_deterministic_tool_response(
    *,
    run_id: Any,
    provider: str,
    model: str,
    route_info: Dict[str, Any],
    normalized_mode: str,
    raw_message: str,
    conversation: Any,
    current_empleado: Any,
    session: Any,
    tool_trace: List[Dict[str, Any]],
    answer: str,
    response_cache_enabled: bool,
    cache_key: str,
    tool_trace_has_write_intent: Callable[[List[Dict[str, Any]]], bool],
    assistant_response_cache_set: Callable[..., None],
    assistant_run_cls: Any,
    assistant_message_cls: Any,
    message_response_cls: Any,
    finalize_response: Optional[Callable[..., Any]] = None,
) -> Any:
    if finalize_response:
        answer, tool_trace = finalize_response(answer, tool_trace)
    assistant_msg = assistant_message_cls(
        conversation_id=conversation.id,
        role="assistant",
        content=answer,
        tool_name=None,
        tool_payload=None,
    )
    session.add(assistant_msg)
    run = assistant_run_cls(
        id=run_id,
        conversation_id=conversation.id,
        empleado_id=current_empleado.id,
        status="completed",
        model=f"{provider}:{model}:{route_info['route']}:{normalized_mode}",
        user_message=raw_message,
        assistant_message=answer,
        tool_trace=tool_trace,
        pending_tool_name=None,
        pending_tool_args=None,
        created_at=datetime.utcnow(),
    )
    session.add(run)
    conversation.updated_at = datetime.utcnow()
    await session.commit()
    if response_cache_enabled and not tool_trace_has_write_intent(tool_trace):
        assistant_response_cache_set(
            key=cache_key,
            assistant_message=answer,
            tool_trace=tool_trace,
        )
    return message_response_cls(
        assistant_message=answer,
        run_id=str(run_id),
        tool_trace=tool_trace,
        pending_confirmation=None,
    )


async def execute_ollama_provider(
    *,
    model: str,
    normalized_mode: str,
    route_info: Dict[str, Any],
    raw_message: str,
    conversation: Any,
    current_empleado: Any,
    session: Any,
    tool_trace: List[Dict[str, Any]],
    tool_defs: List[Dict[str, Any]],
    max_tokens: int,
    retrieval_sources: List[Dict[str, Any]],
    response_cache_enabled: bool,
    cache_key: str,
    tournament_key_default: Optional[str],
    bi_year: Optional[int],
    bi_scope: Optional[str],
    messages: List[Dict[str, Any]],
    write_tools: set[str],
    get_model: Callable[..., str],
    ollama_chat: OllamaChatFn,
    ollama_message_content: Callable[[Dict[str, Any]], str],
    ollama_tool_calls: Callable[[Dict[str, Any]], List[Dict[str, Any]]],
    ollama_assistant_message: Callable[[Dict[str, Any]], Dict[str, Any]],
    run_read_tool: RunReadToolFn,
    ensure_citations: Callable[[str, List[Dict[str, Any]]], str],
    tool_trace_has_write_intent: Callable[[List[Dict[str, Any]]], bool],
    assistant_response_cache_set: Callable[..., None],
    pending_confirmation_cls: Any,
    assistant_run_cls: Any,
    assistant_message_cls: Any,
    message_response_cls: Any,
    tool_policy_evaluator: Optional[ToolPolicyEvaluatorFn] = None,
    deterministic_tool_answer: Optional[DeterministicToolAnswerFn] = None,
    finalize_response: Optional[Callable[..., Any]] = None,
) -> Any:
    run_id = __import__("uuid").uuid4()
    ollama_messages = list(messages)
    code_tooling_active = bool(route_info.get("code_tooling_active"))
    for _ in range(6):
        active_route_info = dict(route_info)
        if code_tooling_active:
            active_route_info["code_tooling_active"] = True
        model = get_model("ollama", normalized_mode, route_info=active_route_info)
        payload = await ollama_chat(
            model=model,
            messages=ollama_messages,
            tool_defs=tool_defs,
            mode=normalized_mode,
            route_info=active_route_info,
            max_tokens=max_tokens,
        )
        assistant_text = ollama_message_content(payload)
        tool_calls = ollama_tool_calls(payload)
        tool_trace.append(
            {
                "provider_call": {
                    "provider": "ollama",
                    "model": model,
                    "done_reason": payload.get("done_reason"),
                    "load_duration": payload.get("load_duration"),
                    "eval_count": payload.get("eval_count"),
                }
            }
        )

        if tool_calls:
            if route_info.get("route") == "code_agentic":
                code_tooling_active = True
            ollama_messages.append(ollama_assistant_message(payload))
            for call in tool_calls:
                tool_name = str(((call.get("function") or {}).get("name")) or "")
                args = ((call.get("function") or {}).get("arguments")) or {}
                if not isinstance(args, dict):
                    args = {}
                tool_trace.append({"tool": tool_name, "args": args})
                policy_decision = _evaluate_tool_policy(
                    tool_policy_evaluator=tool_policy_evaluator,
                    tool_trace=tool_trace,
                    tool_name=tool_name,
                    args=args,
                    current_role=getattr(current_empleado, "rol", None),
                )

                if tool_name in write_tools or (
                    policy_decision and policy_decision.get("decision") == "confirm"
                ):
                    pending_confirmation = pending_confirmation_cls(
                        run_id=str(run_id),
                        tool_name=tool_name,
                        tool_args=args,
                        summary=_pending_summary(tool_name, args),
                    )
                    if finalize_response:
                        assistant_text, tool_trace = finalize_response(
                            assistant_text or "", tool_trace, pending=True
                        )
                    run = assistant_run_cls(
                        id=run_id,
                        conversation_id=conversation.id,
                        empleado_id=current_empleado.id,
                        status="pending_confirmation",
                        model=f"ollama:{model}:{route_info['route']}:{normalized_mode}",
                        user_message=raw_message,
                        assistant_message=assistant_text or "",
                        tool_trace=tool_trace,
                        pending_tool_name=tool_name,
                        pending_tool_args=args,
                        created_at=datetime.utcnow(),
                    )
                    session.add(run)
                    await session.commit()

                    assistant_msg = assistant_message_cls(
                        conversation_id=conversation.id,
                        role="assistant",
                        content=assistant_text
                        or "Necesito confirmacion para continuar.",
                        tool_name=None,
                        tool_payload=None,
                    )
                    session.add(assistant_msg)
                    conversation.updated_at = datetime.utcnow()
                    await session.commit()
                    return message_response_cls(
                        assistant_message=assistant_msg.content or "",
                        run_id=str(run_id),
                        tool_trace=tool_trace,
                        pending_confirmation=pending_confirmation,
                    )

                result = await run_read_tool(
                    tool_name,
                    args,
                    gastos_session=session,
                    tournament_key_default=tournament_key_default,
                    current_role=getattr(current_empleado, "rol", None),
                    bi_year=bi_year,
                    bi_scope=bi_scope,
                )
                tool_trace.append({"tool": tool_name, "result": result})
                deterministic_answer = (
                    deterministic_tool_answer(tool_name, result)
                    if deterministic_tool_answer
                    else None
                )
                if deterministic_answer:
                    return await _provider_deterministic_tool_response(
                        run_id=run_id,
                        provider="ollama",
                        model=model,
                        route_info=route_info,
                        normalized_mode=normalized_mode,
                        raw_message=raw_message,
                        conversation=conversation,
                        current_empleado=current_empleado,
                        session=session,
                        tool_trace=tool_trace,
                        answer=deterministic_answer,
                        response_cache_enabled=response_cache_enabled,
                        cache_key=cache_key,
                        tool_trace_has_write_intent=tool_trace_has_write_intent,
                        assistant_response_cache_set=assistant_response_cache_set,
                        assistant_run_cls=assistant_run_cls,
                        assistant_message_cls=assistant_message_cls,
                        message_response_cls=message_response_cls,
                        finalize_response=finalize_response,
                    )
                ollama_messages.append(
                    {
                        "role": "tool",
                        "tool_name": tool_name,
                        "content": json.dumps(result, ensure_ascii=False),
                    }
                )
            continue

        if not assistant_text:
            raise HTTPException(
                status_code=502, detail="Ollama returned empty response"
            )

        answer = ensure_citations(assistant_text, retrieval_sources)
        if finalize_response:
            answer, tool_trace = finalize_response(answer, tool_trace)
        assistant_msg = assistant_message_cls(
            conversation_id=conversation.id,
            role="assistant",
            content=answer,
            tool_name=None,
            tool_payload=None,
        )
        session.add(assistant_msg)
        run = assistant_run_cls(
            id=run_id,
            conversation_id=conversation.id,
            empleado_id=current_empleado.id,
            status="completed",
            model=f"ollama:{model}:{route_info['route']}:{normalized_mode}",
            user_message=raw_message,
            assistant_message=answer,
            tool_trace=tool_trace,
            pending_tool_name=None,
            pending_tool_args=None,
            created_at=datetime.utcnow(),
        )
        session.add(run)
        conversation.updated_at = datetime.utcnow()
        await session.commit()
        if response_cache_enabled and not tool_trace_has_write_intent(tool_trace):
            assistant_response_cache_set(
                key=cache_key,
                assistant_message=answer,
                tool_trace=tool_trace,
            )
        return message_response_cls(
            assistant_message=answer,
            run_id=str(run_id),
            tool_trace=tool_trace,
            pending_confirmation=None,
        )

    raise HTTPException(status_code=500, detail="Tool loop exceeded")


async def execute_anthropic_provider(
    *,
    model: str,
    normalized_mode: str,
    route_info: Dict[str, Any],
    raw_message: str,
    conversation: Any,
    current_empleado: Any,
    session: Any,
    tool_trace: List[Dict[str, Any]],
    tool_defs: List[Dict[str, Any]],
    max_tokens: int,
    retrieval_sources: List[Dict[str, Any]],
    response_cache_enabled: bool,
    cache_key: str,
    tournament_key_default: Optional[str],
    bi_year: Optional[int],
    bi_scope: Optional[str],
    write_tools: set[str],
    route_prompt: str,
    language_prompt: str,
    hermes_profile_prompt: Optional[str],
    workspace_context: Optional[str],
    module_key_default: Optional[str],
    module_label_default: Optional[str],
    module_context_default: Optional[str],
    retrieval_context: Optional[str],
    assistant_system_prompt: Callable[[], str],
    history_messages: Callable[..., Awaitable[List[Dict[str, Any]]]],
    get_anthropic_client: Callable[..., Any],
    tool_defs_anthropic: Callable[[List[Dict[str, Any]]], List[Dict[str, Any]]],
    anthropic_text_from_blocks: Callable[[Any], str],
    anthropic_message_from_blocks: Callable[[Any], List[Dict[str, Any]]],
    run_read_tool: RunReadToolFn,
    ensure_citations: Callable[[str, List[Dict[str, Any]]], str],
    tool_trace_has_write_intent: Callable[[List[Dict[str, Any]]], bool],
    assistant_response_cache_set: Callable[..., None],
    pending_confirmation_cls: Any,
    assistant_run_cls: Any,
    assistant_message_cls: Any,
    message_response_cls: Any,
    tool_policy_evaluator: Optional[ToolPolicyEvaluatorFn] = None,
    deterministic_tool_answer: Optional[DeterministicToolAnswerFn] = None,
    finalize_response: Optional[Callable[..., Any]] = None,
) -> Any:
    run_id = __import__("uuid").uuid4()
    client = get_anthropic_client()
    started_at = time.monotonic()
    total_budget_seconds = _runtime_total_budget_seconds()
    provider_timeout_seconds = _provider_timeout_seconds()
    provider_concurrency = _provider_max_concurrency()
    prepared_messages = await build_turn_messages(
        session=session,
        conversation_id=conversation.id,
        raw_message=raw_message,
        route_prompt=route_prompt,
        language_prompt=language_prompt,
        hermes_profile_prompt=hermes_profile_prompt,
        workspace_context=workspace_context,
        module_key_default=module_key_default,
        module_label_default=module_label_default,
        module_context_default=module_context_default,
        retrieval_context=retrieval_context,
        assistant_system_prompt=assistant_system_prompt,
        history_messages=history_messages,
        filter_context=(getattr(conversation, "metadata_", None) or {}).get(
            "bi_filters"
        ),
    )
    system_prompt = "\n\n".join(
        m["content"] for m in prepared_messages if m["role"] == "system"
    )
    anthropic_messages = [m for m in prepared_messages if m["role"] != "system"]

    for _ in range(6):
        elapsed = time.monotonic() - started_at
        remaining_budget = total_budget_seconds - elapsed
        if remaining_budget <= 0:
            tool_trace.append(
                {
                    "provider_error": {
                        "provider": "anthropic",
                        "reason": RUNTIME_BUDGET_REASON,
                        "elapsed_seconds": round(elapsed, 3),
                        "total_budget_seconds": total_budget_seconds,
                    }
                }
            )
            return await _provider_controlled_failure_response(
                run_id=run_id,
                reason=RUNTIME_BUDGET_REASON,
                provider="anthropic",
                model=model,
                route_info=route_info,
                normalized_mode=normalized_mode,
                raw_message=raw_message,
                conversation=conversation,
                current_empleado=current_empleado,
                session=session,
                tool_trace=tool_trace,
                assistant_run_cls=assistant_run_cls,
                assistant_message_cls=assistant_message_cls,
                message_response_cls=message_response_cls,
                finalize_response=finalize_response,
                deterministic_tool_answer=deterministic_tool_answer,
            )
        call_timeout = min(provider_timeout_seconds, remaining_budget)
        call_started = time.monotonic()
        try:
            resp = await _anthropic_messages_create(
                client,
                timeout_seconds=call_timeout,
                concurrency_limit=provider_concurrency,
                model=model,
                system=system_prompt,
                messages=anthropic_messages,
                tools=tool_defs_anthropic(tool_defs),
                max_tokens=max_tokens,
                temperature=0.2,
            )
            tool_trace.append(
                {
                    "provider_call": {
                        "provider": "anthropic",
                        "model": model,
                        "duration_seconds": round(time.monotonic() - call_started, 3),
                        "timeout_seconds": call_timeout,
                        "concurrency_limit": provider_concurrency,
                    }
                }
            )
        except HTTPException as exc:
            if exc.status_code == 504:
                tool_trace.append(
                    {
                        "provider_error": {
                            "provider": "anthropic",
                            "reason": exc.detail,
                            "duration_seconds": round(
                                time.monotonic() - call_started, 3
                            ),
                            "timeout_seconds": call_timeout,
                            "concurrency_limit": provider_concurrency,
                        }
                    }
                )
                return await _provider_controlled_failure_response(
                    run_id=run_id,
                    reason=str(exc.detail or PROVIDER_TIMEOUT_REASON),
                    provider="anthropic",
                    model=model,
                    route_info=route_info,
                    normalized_mode=normalized_mode,
                    raw_message=raw_message,
                    conversation=conversation,
                    current_empleado=current_empleado,
                    session=session,
                    tool_trace=tool_trace,
                    assistant_run_cls=assistant_run_cls,
                    assistant_message_cls=assistant_message_cls,
                    message_response_cls=message_response_cls,
                    finalize_response=finalize_response,
                    deterministic_tool_answer=deterministic_tool_answer,
                )
            raise
        blocks = getattr(resp, "content", []) or []
        assistant_text = anthropic_text_from_blocks(blocks)
        tool_uses = [b for b in blocks if getattr(b, "type", "") == "tool_use"]

        if tool_uses:
            anthropic_messages.append(
                {
                    "role": "assistant",
                    "content": anthropic_message_from_blocks(blocks),
                }
            )
            tool_result_blocks: List[Dict[str, Any]] = []
            for call in tool_uses:
                tool_name = getattr(call, "name", "")
                args = getattr(call, "input", {}) or {}
                tool_trace.append({"tool": tool_name, "args": args})
                policy_decision = _evaluate_tool_policy(
                    tool_policy_evaluator=tool_policy_evaluator,
                    tool_trace=tool_trace,
                    tool_name=tool_name,
                    args=args,
                    current_role=getattr(current_empleado, "rol", None),
                )

                if tool_name in write_tools or (
                    policy_decision and policy_decision.get("decision") == "confirm"
                ):
                    pending_confirmation = pending_confirmation_cls(
                        run_id=str(run_id),
                        tool_name=tool_name,
                        tool_args=args,
                        summary=_pending_summary(tool_name, args),
                    )
                    if finalize_response:
                        assistant_text, tool_trace = finalize_response(
                            assistant_text or "", tool_trace, pending=True
                        )
                    run = assistant_run_cls(
                        id=run_id,
                        conversation_id=conversation.id,
                        empleado_id=current_empleado.id,
                        status="pending_confirmation",
                        model=(
                            f"anthropic:{model}:{route_info['route']}:"
                            f"{normalized_mode}"
                        ),
                        user_message=raw_message,
                        assistant_message=assistant_text or "",
                        tool_trace=tool_trace,
                        pending_tool_name=tool_name,
                        pending_tool_args=args,
                        created_at=datetime.utcnow(),
                    )
                    session.add(run)
                    await session.commit()

                    assistant_msg = assistant_message_cls(
                        conversation_id=conversation.id,
                        role="assistant",
                        content=assistant_text
                        or "Necesito confirmacion para continuar.",
                        tool_name=None,
                        tool_payload=None,
                    )
                    session.add(assistant_msg)
                    conversation.updated_at = datetime.utcnow()
                    await session.commit()
                    return message_response_cls(
                        assistant_message=assistant_msg.content or "",
                        run_id=str(run_id),
                        tool_trace=tool_trace,
                        pending_confirmation=pending_confirmation,
                    )

                result = await run_read_tool(
                    tool_name,
                    args,
                    gastos_session=session,
                    tournament_key_default=tournament_key_default,
                    current_role=getattr(current_empleado, "rol", None),
                    bi_year=bi_year,
                    bi_scope=bi_scope,
                )
                tool_trace.append({"tool": tool_name, "result": result})
                deterministic_answer = (
                    deterministic_tool_answer(tool_name, result)
                    if deterministic_tool_answer
                    else None
                )
                if deterministic_answer:
                    return await _provider_deterministic_tool_response(
                        run_id=run_id,
                        provider="anthropic",
                        model=model,
                        route_info=route_info,
                        normalized_mode=normalized_mode,
                        raw_message=raw_message,
                        conversation=conversation,
                        current_empleado=current_empleado,
                        session=session,
                        tool_trace=tool_trace,
                        answer=deterministic_answer,
                        response_cache_enabled=response_cache_enabled,
                        cache_key=cache_key,
                        tool_trace_has_write_intent=tool_trace_has_write_intent,
                        assistant_response_cache_set=assistant_response_cache_set,
                        assistant_run_cls=assistant_run_cls,
                        assistant_message_cls=assistant_message_cls,
                        message_response_cls=message_response_cls,
                        finalize_response=finalize_response,
                    )
                tool_result_blocks.append(
                    {
                        "type": "tool_result",
                        "tool_use_id": getattr(call, "id", ""),
                        "content": json.dumps(result, ensure_ascii=False),
                    }
                )
            if tool_result_blocks:
                anthropic_messages.append(
                    {"role": "user", "content": tool_result_blocks}
                )
            continue

        answer = ensure_citations(assistant_text or "", retrieval_sources)
        if finalize_response:
            answer, tool_trace = finalize_response(answer, tool_trace)
        assistant_msg = assistant_message_cls(
            conversation_id=conversation.id,
            role="assistant",
            content=answer,
            tool_name=None,
            tool_payload=None,
        )
        session.add(assistant_msg)
        run = assistant_run_cls(
            id=run_id,
            conversation_id=conversation.id,
            empleado_id=current_empleado.id,
            status="completed",
            model=f"anthropic:{model}:{route_info['route']}:{normalized_mode}",
            user_message=raw_message,
            assistant_message=answer,
            tool_trace=tool_trace,
            pending_tool_name=None,
            pending_tool_args=None,
            created_at=datetime.utcnow(),
        )
        session.add(run)
        conversation.updated_at = datetime.utcnow()
        await session.commit()
        if response_cache_enabled and not tool_trace_has_write_intent(tool_trace):
            assistant_response_cache_set(
                key=cache_key,
                assistant_message=answer,
                tool_trace=tool_trace,
            )
        return message_response_cls(
            assistant_message=answer,
            run_id=str(run_id),
            tool_trace=tool_trace,
            pending_confirmation=None,
        )

    raise HTTPException(status_code=500, detail="Tool loop exceeded")


async def execute_openai_provider(
    *,
    model: str,
    normalized_mode: str,
    route_info: Dict[str, Any],
    raw_message: str,
    conversation: Any,
    current_empleado: Any,
    session: Any,
    tool_trace: List[Dict[str, Any]],
    tool_defs: List[Dict[str, Any]],
    max_tokens: int,
    retrieval_sources: List[Dict[str, Any]],
    response_cache_enabled: bool,
    cache_key: str,
    tournament_key_default: Optional[str],
    bi_year: Optional[int],
    bi_scope: Optional[str],
    messages: List[Dict[str, Any]],
    openai_api_key: Optional[str],
    write_tools: set[str],
    get_openai_client: Callable[..., Any],
    run_read_tool: RunReadToolFn,
    ensure_citations: Callable[[str, List[Dict[str, Any]]], str],
    tool_trace_has_write_intent: Callable[[List[Dict[str, Any]]], bool],
    assistant_response_cache_set: Callable[..., None],
    pending_confirmation_cls: Any,
    assistant_run_cls: Any,
    assistant_message_cls: Any,
    message_response_cls: Any,
    tool_policy_evaluator: Optional[ToolPolicyEvaluatorFn] = None,
    deterministic_tool_answer: Optional[DeterministicToolAnswerFn] = None,
    finalize_response: Optional[Callable[..., Any]] = None,
) -> Any:
    run_id = __import__("uuid").uuid4()
    client = get_openai_client(openai_api_key)
    openai_messages = list(messages)
    deadline = time.monotonic() + _runtime_total_budget_seconds()
    for _ in range(6):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise HTTPException(504, RUNTIME_BUDGET_REASON)
        resp = await _openai_create(
            client.chat.completions.create,
            timeout_seconds=min(_provider_timeout_seconds(), remaining),
            model=model,
            messages=openai_messages,
            tools=tool_defs,
            tool_choice="auto",
            max_tokens=max_tokens,
            temperature=0.2,
        )
        choice = resp.choices[0].message
        if getattr(choice, "tool_calls", None):
            openai_messages.append(
                {
                    "role": "assistant",
                    "content": choice.content or "",
                    "tool_calls": choice.tool_calls,
                }
            )
            for call in choice.tool_calls:
                tool_name = call.function.name
                try:
                    args = json.loads(call.function.arguments or "{}")
                except json.JSONDecodeError:
                    args = {}
                tool_trace.append({"tool": tool_name, "args": args})
                policy_decision = _evaluate_tool_policy(
                    tool_policy_evaluator=tool_policy_evaluator,
                    tool_trace=tool_trace,
                    tool_name=tool_name,
                    args=args,
                    current_role=getattr(current_empleado, "rol", None),
                )
                if tool_name in write_tools or (
                    policy_decision and policy_decision.get("decision") == "confirm"
                ):
                    pending_confirmation = pending_confirmation_cls(
                        run_id=str(run_id),
                        tool_name=tool_name,
                        tool_args=args,
                        summary=_pending_summary(tool_name, args),
                    )
                    pending_answer = (
                        choice.content or "Necesito confirmacion para continuar."
                    )
                    if finalize_response:
                        pending_answer, tool_trace = finalize_response(
                            pending_answer, tool_trace, pending=True
                        )
                    run = assistant_run_cls(
                        id=run_id,
                        conversation_id=conversation.id,
                        empleado_id=current_empleado.id,
                        status="pending_confirmation",
                        model=f"openai:{model}:{route_info['route']}:{normalized_mode}",
                        user_message=raw_message,
                        assistant_message=pending_answer,
                        tool_trace=tool_trace,
                        pending_tool_name=tool_name,
                        pending_tool_args=args,
                        created_at=datetime.utcnow(),
                    )
                    session.add(run)
                    await session.commit()
                    assistant_msg = assistant_message_cls(
                        conversation_id=conversation.id,
                        role="assistant",
                        content=pending_answer,
                        tool_name=None,
                        tool_payload=None,
                    )
                    session.add(assistant_msg)
                    conversation.updated_at = datetime.utcnow()
                    await session.commit()
                    return message_response_cls(
                        assistant_message=assistant_msg.content or "",
                        run_id=str(run_id),
                        tool_trace=tool_trace,
                        pending_confirmation=pending_confirmation,
                    )
                result = await run_read_tool(
                    tool_name,
                    args,
                    gastos_session=session,
                    tournament_key_default=tournament_key_default,
                    current_role=getattr(current_empleado, "rol", None),
                    bi_year=bi_year,
                    bi_scope=bi_scope,
                )
                tool_trace.append({"tool": tool_name, "result": result})
                deterministic_answer = (
                    deterministic_tool_answer(tool_name, result)
                    if deterministic_tool_answer
                    else None
                )
                if deterministic_answer:
                    return await _provider_deterministic_tool_response(
                        run_id=run_id,
                        provider="openai",
                        model=model,
                        route_info=route_info,
                        normalized_mode=normalized_mode,
                        raw_message=raw_message,
                        conversation=conversation,
                        current_empleado=current_empleado,
                        session=session,
                        tool_trace=tool_trace,
                        answer=deterministic_answer,
                        response_cache_enabled=response_cache_enabled,
                        cache_key=cache_key,
                        tool_trace_has_write_intent=tool_trace_has_write_intent,
                        assistant_response_cache_set=assistant_response_cache_set,
                        assistant_run_cls=assistant_run_cls,
                        assistant_message_cls=assistant_message_cls,
                        message_response_cls=message_response_cls,
                        finalize_response=finalize_response,
                    )
                openai_messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": call.id,
                        "content": json.dumps(result, ensure_ascii=False),
                    }
                )
            continue

        answer = ensure_citations(choice.content or "", retrieval_sources)
        if finalize_response:
            answer, tool_trace = finalize_response(answer, tool_trace)
        assistant_msg = assistant_message_cls(
            conversation_id=conversation.id,
            role="assistant",
            content=answer,
            tool_name=None,
            tool_payload=None,
        )
        session.add(assistant_msg)
        run = assistant_run_cls(
            id=run_id,
            conversation_id=conversation.id,
            empleado_id=current_empleado.id,
            status="completed",
            model=f"openai:{model}:{route_info['route']}:{normalized_mode}",
            user_message=raw_message,
            assistant_message=answer,
            tool_trace=tool_trace,
            pending_tool_name=None,
            pending_tool_args=None,
            created_at=datetime.utcnow(),
        )
        session.add(run)
        conversation.updated_at = datetime.utcnow()
        await session.commit()
        if response_cache_enabled and not tool_trace_has_write_intent(tool_trace):
            assistant_response_cache_set(
                key=cache_key,
                assistant_message=answer,
                tool_trace=tool_trace,
            )
        return message_response_cls(
            assistant_message=answer,
            run_id=str(run_id),
            tool_trace=tool_trace,
            pending_confirmation=None,
        )

    raise HTTPException(status_code=500, detail="Tool loop exceeded")


async def execute_provider(
    *,
    provider: str,
    model: str,
    normalized_mode: str,
    route_info: Dict[str, Any],
    raw_message: str,
    conversation: Any,
    current_empleado: Any,
    session: Any,
    tool_trace: List[Dict[str, Any]],
    tool_defs: List[Dict[str, Any]],
    max_tokens: int,
    retrieval_sources: List[Dict[str, Any]],
    response_cache_enabled: bool,
    cache_key: str,
    tournament_key_default: Optional[str],
    bi_year: Optional[int],
    bi_scope: Optional[str],
    messages: List[Dict[str, Any]],
    openai_api_key: Optional[str],
    write_tools: set[str],
    route_prompt: str,
    language_prompt: str,
    hermes_profile_prompt: Optional[str],
    workspace_context: Optional[str],
    module_key_default: Optional[str],
    module_label_default: Optional[str],
    module_context_default: Optional[str],
    retrieval_context: Optional[str],
    assistant_system_prompt: Callable[[], str],
    history_messages: Callable[..., Awaitable[List[Dict[str, Any]]]],
    get_model: Callable[..., str],
    get_openai_client: Callable[..., Any],
    get_anthropic_client: Callable[..., Any],
    ollama_chat: OllamaChatFn,
    ollama_message_content: Callable[[Dict[str, Any]], str],
    ollama_tool_calls: Callable[[Dict[str, Any]], List[Dict[str, Any]]],
    ollama_assistant_message: Callable[[Dict[str, Any]], Dict[str, Any]],
    tool_defs_anthropic: Callable[[List[Dict[str, Any]]], List[Dict[str, Any]]],
    anthropic_text_from_blocks: Callable[[Any], str],
    anthropic_message_from_blocks: Callable[[Any], List[Dict[str, Any]]],
    run_read_tool: RunReadToolFn,
    ensure_citations: Callable[[str, List[Dict[str, Any]]], str],
    tool_trace_has_write_intent: Callable[[List[Dict[str, Any]]], bool],
    assistant_response_cache_set: Callable[..., None],
    pending_confirmation_cls: Any,
    assistant_run_cls: Any,
    assistant_message_cls: Any,
    message_response_cls: Any,
    tool_policy_evaluator: Optional[ToolPolicyEvaluatorFn] = None,
    deterministic_tool_answer: Optional[DeterministicToolAnswerFn] = None,
    finalize_response: Optional[Callable[..., Any]] = None,
) -> Any:
    if provider == "ollama":
        return await execute_ollama_provider(
            model=model,
            normalized_mode=normalized_mode,
            route_info=route_info,
            raw_message=raw_message,
            conversation=conversation,
            current_empleado=current_empleado,
            session=session,
            tool_trace=tool_trace,
            tool_defs=tool_defs,
            max_tokens=max_tokens,
            retrieval_sources=retrieval_sources,
            response_cache_enabled=response_cache_enabled,
            cache_key=cache_key,
            tournament_key_default=tournament_key_default,
            bi_year=bi_year,
            bi_scope=bi_scope,
            messages=messages,
            write_tools=write_tools,
            get_model=get_model,
            ollama_chat=ollama_chat,
            ollama_message_content=ollama_message_content,
            ollama_tool_calls=ollama_tool_calls,
            ollama_assistant_message=ollama_assistant_message,
            run_read_tool=run_read_tool,
            ensure_citations=ensure_citations,
            tool_trace_has_write_intent=tool_trace_has_write_intent,
            assistant_response_cache_set=assistant_response_cache_set,
            pending_confirmation_cls=pending_confirmation_cls,
            assistant_run_cls=assistant_run_cls,
            assistant_message_cls=assistant_message_cls,
            message_response_cls=message_response_cls,
            finalize_response=finalize_response,
            tool_policy_evaluator=tool_policy_evaluator,
            deterministic_tool_answer=deterministic_tool_answer,
        )
    if provider == "anthropic":
        return await execute_anthropic_provider(
            model=model,
            normalized_mode=normalized_mode,
            route_info=route_info,
            raw_message=raw_message,
            conversation=conversation,
            current_empleado=current_empleado,
            session=session,
            tool_trace=tool_trace,
            tool_defs=tool_defs,
            max_tokens=max_tokens,
            retrieval_sources=retrieval_sources,
            response_cache_enabled=response_cache_enabled,
            cache_key=cache_key,
            tournament_key_default=tournament_key_default,
            bi_year=bi_year,
            bi_scope=bi_scope,
            write_tools=write_tools,
            route_prompt=route_prompt,
            language_prompt=language_prompt,
            hermes_profile_prompt=hermes_profile_prompt,
            workspace_context=workspace_context,
            module_key_default=module_key_default,
            module_label_default=module_label_default,
            module_context_default=module_context_default,
            retrieval_context=retrieval_context,
            assistant_system_prompt=assistant_system_prompt,
            history_messages=history_messages,
            get_anthropic_client=get_anthropic_client,
            tool_defs_anthropic=tool_defs_anthropic,
            anthropic_text_from_blocks=anthropic_text_from_blocks,
            anthropic_message_from_blocks=anthropic_message_from_blocks,
            run_read_tool=run_read_tool,
            ensure_citations=ensure_citations,
            tool_trace_has_write_intent=tool_trace_has_write_intent,
            assistant_response_cache_set=assistant_response_cache_set,
            pending_confirmation_cls=pending_confirmation_cls,
            assistant_run_cls=assistant_run_cls,
            assistant_message_cls=assistant_message_cls,
            message_response_cls=message_response_cls,
            finalize_response=finalize_response,
            tool_policy_evaluator=tool_policy_evaluator,
            deterministic_tool_answer=deterministic_tool_answer,
        )
    return await execute_openai_provider(
        model=model,
        normalized_mode=normalized_mode,
        route_info=route_info,
        raw_message=raw_message,
        conversation=conversation,
        current_empleado=current_empleado,
        session=session,
        tool_trace=tool_trace,
        tool_defs=tool_defs,
        max_tokens=max_tokens,
        retrieval_sources=retrieval_sources,
        response_cache_enabled=response_cache_enabled,
        cache_key=cache_key,
        tournament_key_default=tournament_key_default,
        bi_year=bi_year,
        bi_scope=bi_scope,
        messages=messages,
        openai_api_key=openai_api_key,
        write_tools=write_tools,
        get_openai_client=get_openai_client,
        run_read_tool=run_read_tool,
        ensure_citations=ensure_citations,
        tool_trace_has_write_intent=tool_trace_has_write_intent,
        assistant_response_cache_set=assistant_response_cache_set,
        pending_confirmation_cls=pending_confirmation_cls,
        assistant_run_cls=assistant_run_cls,
        assistant_message_cls=assistant_message_cls,
        message_response_cls=message_response_cls,
        finalize_response=finalize_response,
        tool_policy_evaluator=tool_policy_evaluator,
        deterministic_tool_answer=deterministic_tool_answer,
    )
