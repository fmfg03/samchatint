"""Admin HTML rendering for the read-only AR projection."""

from __future__ import annotations

from html import escape
from typing import Any
from urllib.parse import parse_qsl, quote, urlencode, urlsplit, urlunsplit

from .service import (
    build_ar_accounting_preview,
    build_ar_actionable_gaps,
    build_ar_billing_schedule,
    build_ar_operational_rows,
)


def _money(value: Any) -> str:
    try:
        amount = float(value or 0)
    except (TypeError, ValueError):
        amount = 0.0
    return f"${amount:,.2f}"


def _text(value: Any, fallback: str = "-") -> str:
    text = str(value or "").strip()
    return escape(text or fallback)


def _row(cells: list[str]) -> str:
    return "<tr>" + "".join(f"<td>{cell}</td>" for cell in cells) + "</tr>"


def _empty_row(colspan: int, message: str) -> str:
    return (
        f'<tr><td colspan="{colspan}" class="ar-muted">'
        f"{escape(message)}</td></tr>"
    )


def _status_pill(value: Any) -> str:
    text = str(value or "collection_unknown").strip() or "collection_unknown"
    return f'<span class="ar-pill">{escape(text)}</span>'


def _safe_count(value: Any) -> int:
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def _sum_money(rows: list[dict[str, Any]], *keys: str) -> float:
    total = 0.0
    for row in rows:
        for key in keys:
            value = row.get(key)
            if value is not None:
                try:
                    total += float(value or 0)
                except (TypeError, ValueError):
                    pass
                break
    return total


def _url_with_query_value(base_url: str, key: str, value: Any) -> str:
    parsed = urlsplit(base_url)
    query = [
        (query_key, query_value)
        for query_key, query_value in parse_qsl(parsed.query, keep_blank_values=True)
        if query_key != key
    ]
    query.append((key, str(value or "")))
    return urlunsplit(
        (
            parsed.scheme,
            parsed.netloc,
            parsed.path,
            urlencode(query),
            parsed.fragment,
        )
    )


def _accounting_cxc_href(base_url: str) -> str:
    """Carry only equivalent Finance CxC context into the accounting view."""
    parsed = urlsplit(base_url)
    finance_query = dict(parse_qsl(parsed.query, keep_blank_values=True))
    accounting_query = [
        (accounting_key, value)
        for finance_key, accounting_key in (
            ("edition_year", "edition_year"),
            ("tournament_id", "torneo_id"),
            ("cliente", "cliente"),
            ("dias_credito", "dias_credito"),
        )
        if (value := finance_query.get(finance_key))
    ]
    status = str(finance_query.get("estado") or "").strip().lower()
    accounting_status = {
        "todos": "todos",
        "cobrado": "cobrado",
        "vencido": "vencido",
    }.get(status)
    if accounting_status:
        accounting_query.append(("estado", accounting_status))
    query = urlencode(accounting_query)
    return "/admin/contabilidad/cuentas-por-cobrar" + (
        f"?{query}" if query else ""
    )


def _executive_kpi_card(
    label: str,
    value: Any,
    note: str,
    *,
    tone: str = "neutral",
    money: bool = True,
) -> str:
    display_value = _money(value) if money else str(value)
    return f"""
        <div class="ar-executive-card ar-executive-{escape(tone)}">
            <span>{escape(label)}</span>
            <strong>{escape(display_value)}</strong>
            <small>{escape(note)}</small>
        </div>
    """


def _executive_status_buckets(rows: list[dict[str, Any]], *, base_url: str) -> str:
    bucket_defs = [
        (
            "Vencido",
            "alta",
            "Cobranza fuera de fecha; requiere seguimiento inmediato.",
        ),
        (
            "Parcialmente cobrado",
            "media",
            "Tiene abono, pero aún conserva saldo abierto.",
        ),
        (
            "Cobranza desconocida",
            "alta",
            "CFDI ligado sin match aceptado de cobranza.",
        ),
        (
            "Presupuestado sin CFDI",
            "baja",
            "Ingreso planeado pendiente de facturación.",
        ),
    ]
    cards = []
    for status, priority, description in bucket_defs:
        selected = [
            row
            for row in rows
            if str(row.get("operational_status") or "").strip() == status
        ]
        amount = _sum_money(
            selected,
            "balance_amount",
            "issued_amount",
            "expected_income_amount",
        )
        href = _url_with_query_value(base_url, "estado", status)
        cards.append(
            f"""
            <a class="ar-executive-bucket" href="{escape(href)}">
                <div>
                    {_status_pill(priority)}
                    <h3>{escape(status)}</h3>
                    <p>{escape(description)}</p>
                </div>
                <div class="ar-bucket-number">
                    <strong>{len(selected)}</strong>
                    <span>{_money(amount)}</span>
                </div>
            </a>
            """
        )
    return "".join(cards)


def _executive_action_cards(rows: list[dict[str, Any]], *, return_to: str) -> str:
    if not rows:
        return (
            '<div class="ar-executive-empty">'
            "Sin acciones ejecutivas CxC para los filtros actuales.</div>"
        )
    context_query = ""
    if "?" in return_to:
        context_query = return_to.split("?", 1)[1]
    cards = []
    for item in rows[:5]:
        detail_href = (
            "/admin/finanzas/cuentas-por-cobrar/item/"
            f'{quote(str(item.get("ar_item_id") or ""), safe="")}'
            f'?{context_query + "&" if context_query else ""}'
            f'return_to={quote(return_to or "", safe="")}'
        )
        cards.append(
            f"""
            <article class="ar-action-card">
                <div>
                    {_status_pill(item.get("priority"))}
                    <h3>{_text(item.get("gap_type"), "Pendiente")}</h3>
                    <p>{_text(item.get("suggested_action"), "Revisar CxC.")}</p>
                </div>
                <div>
                    <strong>{_money(item.get("amount"))}</strong>
                    <small>{_text(item.get("payer_name") or item.get("tournament_name"), "Sin cliente")}</small>
                    <a class="button secondary compact" href="{escape(detail_href)}">Ver detalle</a>
                </div>
            </article>
            """
        )
    return "".join(cards)


def _sort_link(
    *,
    label: str,
    field: str,
    base_url: str,
    current_sort: str,
    current_dir: str,
) -> str:
    next_dir = "asc"
    if current_sort == field and current_dir == "asc":
        next_dir = "desc"
    separator = "&" if "?" in base_url else "?"
    href = f"{base_url}{separator}sort_by={field}&sort_dir={next_dir}"
    marker = ""
    if current_sort == field:
        marker = " ↑" if current_dir == "asc" else " ↓"
    return f'<a class="ar-sort" href="{escape(href)}">{escape(label + marker)}</a>'


def _operational_rows(rows: list[dict[str, Any]], *, return_to: str = "") -> str:
    if not rows:
        return _empty_row(15, "Sin cartera CxC con los filtros seleccionados.")
    context_query = ""
    if "?" in return_to:
        context_query = return_to.split("?", 1)[1]
    return "".join(
        _row(
            [
                _text(item.get("tournament_name")),
                _text(item.get("phase")),
                _text(item.get("concept_name")),
                _text(item.get("payer_name")),
                _text(item.get("payer_rfc")),
                _text(item.get("cfdi_uuid")),
                _text(item.get("issued_date")),
                _text(item.get("due_date")),
                _money(item.get("expected_income_amount")),
                _money(item.get("issued_amount")),
                _money(item.get("linked_income_amount")),
                _money(item.get("collected_amount")),
                (
                    _money(item.get("balance_amount"))
                    if item.get("balance_amount") is not None
                    else '<span class="ar-muted">sin saldo confirmado</span>'
                ),
                _status_pill(item.get("operational_status")),
                (
                    '<a class="button secondary compact" href="'
                    f'/admin/finanzas/cuentas-por-cobrar/item/'
                    f'{quote(str(item.get("ar_item_id") or ""), safe="")}'
                    f'?{context_query + "&" if context_query else ""}'
                    f'return_to={quote(return_to or "", safe="")}'
                    '">Ver detalle</a>'
                ),
            ]
        )
        for item in rows
    )


def _expected_income_rows(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return _empty_row(6, "Sin ingreso esperado para la version seleccionada.")
    return "".join(
        _row(
            [
                _text(item.get("tournament_name") or item.get("tournament_code")),
                _text(item.get("phase")),
                _text(item.get("concept_name")),
                _money(item.get("expected_income_amount")),
                _money(item.get("linked_income_amount")),
                _status_pill(item.get("collection_status")),
            ]
        )
        for item in rows
    )


def _linked_rows(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return _empty_row(7, "Sin CFDI de ingreso ligado al presupuesto.")
    return "".join(
        _row(
            [
                _text(item.get("cfdi_uuid")),
                _text(item.get("concept_name")),
                _text(item.get("payer_name")),
                _text(item.get("payer_rfc")),
                _money(item.get("issued_amount")),
                _text(item.get("recognized_income_date")),
                _status_pill(item.get("collection_status")),
            ]
        )
        for item in rows
    )


def _unlinked_rows(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return _empty_row(6, "Sin CFDI PSP candidatos sin liga presupuestal.")
    return "".join(
        _row(
            [
                _text(item.get("cfdi_uuid")),
                _text(item.get("issued_date")),
                _text(item.get("payer_name")),
                _text(item.get("payer_rfc")),
                _money(item.get("issued_amount")),
                _status_pill(item.get("collection_status")),
            ]
        )
        for item in rows
    )


def _collection_gap_rows(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return _empty_row(6, "Sin gaps de cobranza para el alcance actual.")
    return "".join(
        _row(
            [
                _text(item.get("source")),
                _text(item.get("item_id")),
                _text(item.get("payer_name")),
                _text(item.get("payer_rfc")),
                _money(item.get("amount")),
                _status_pill(item.get("collection_status")),
            ]
        )
        for item in rows
    )


def _matching_gap_rows(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return _empty_row(4, "Sin gaps de matching detectados.")
    return "".join(
        _row(
            [
                _text(item.get("severity")),
                _text(item.get("source")),
                _text(item.get("item_id")),
                _text(item.get("reason")),
            ]
        )
        for item in rows
    )


def _actionable_gap_rows(rows: list[dict[str, Any]], *, return_to: str = "") -> str:
    if not rows:
        return _empty_row(9, "Sin pendientes CxC accionables para el alcance actual.")
    context_query = ""
    if "?" in return_to:
        context_query = return_to.split("?", 1)[1]
    return "".join(
        _row(
            [
                _status_pill(item.get("priority")),
                _text(item.get("gap_type")),
                _status_pill(item.get("operational_status")),
                _text(item.get("payer_name")),
                _text(item.get("payer_rfc")),
                _text(item.get("tournament_name")),
                _text(item.get("concept_name")),
                _money(item.get("amount")),
                (
                    f'{_text(item.get("suggested_action"))}<br>'
                    '<a class="button secondary compact" href="'
                    f'/admin/finanzas/cuentas-por-cobrar/item/'
                    f'{quote(str(item.get("ar_item_id") or ""), safe="")}'
                    f'?{context_query + "&" if context_query else ""}'
                    f'return_to={quote(return_to or "", safe="")}'
                    '">Ver detalle</a>'
                ),
            ]
        )
        for item in rows
    )


def _billing_schedule_rows(rows: list[dict[str, Any]], *, return_to: str = "") -> str:
    if not rows:
        return _empty_row(9, "Sin programación por facturar para el alcance actual.")
    context_query = ""
    if "?" in return_to:
        context_query = return_to.split("?", 1)[1]
    return "".join(
        _row(
            [
                _status_pill(item.get("priority")),
                _text(item.get("tournament_name")),
                _text(item.get("phase")),
                _text(item.get("concept_name")),
                _money(item.get("budgeted_amount")),
                _money(item.get("linked_amount")),
                _money(item.get("remaining_to_invoice")),
                _text(item.get("months_label")),
                (
                    '<a class="button secondary compact" href="'
                    f'/admin/finanzas/cuentas-por-cobrar/item/'
                    f'{quote(str(item.get("ar_item_id") or ""), safe="")}'
                    f'?{context_query + "&" if context_query else ""}'
                    f'return_to={quote(return_to or "", safe="")}'
                    '">Ver detalle</a>'
                ),
            ]
        )
        for item in rows
    )


def _detail_metric(label: str, value: Any) -> str:
    return (
        '<div class="ar-detail-metric">'
        f"<span>{escape(label)}</span>"
        f"<strong>{_text(value)}</strong>"
        "</div>"
    )


def _detail_money(label: str, value: Any) -> str:
    return (
        '<div class="ar-detail-metric">'
        f"<span>{escape(label)}</span>"
        f"<strong>{_money(value)}</strong>"
        "</div>"
    )


def _detail_gap_items(item: dict[str, Any], gaps: list[dict[str, Any]]) -> str:
    item_id = str(item.get("ar_item_id") or "")
    messages: list[str] = []
    if item.get("source") == "expected_income":
        messages.append("Falta vincular CFDI a la partida de ingreso.")
    if not item.get("payer_name") and not item.get("payer_rfc"):
        messages.append("Falta cliente/RFC.")
    if not item.get("concept_name") and item.get("source") != "issued_unlinked":
        messages.append("Falta partida de ingreso.")
    if item.get("collection_status") in {None, "", "collection_unknown"}:
        messages.append("Falta comprobar cobranza con match aceptado.")
    if item.get("operational_status") == "Revisión sobrepago":
        messages.append("Sobrepago requiere revisión manual contable.")
    if item.get("issued_amount") and not item.get("due_date"):
        messages.append("Sin fecha de vencimiento confiable.")
    for gap in gaps:
        if str(gap.get("item_id") or "") == item_id:
            messages.append(str(gap.get("reason") or "Gap sin clasificar."))
    if not messages:
        return '<li class="ar-muted">Sin gaps accionables detectados.</li>'
    return "".join(f"<li>{escape(message)}</li>" for message in dict.fromkeys(messages))


def _policy_side_summary(lines: list[dict[str, Any]], side: str) -> str:
    selected = [line for line in lines if str(line.get("side") or "") == side]
    if not selected:
        return '<span class="ar-muted">-</span>'
    return "<br>".join(
        (
            f'{_text(line.get("account_code"))} '
            f'<span class="ar-muted">{_text(line.get("label"))}</span> '
            f'{_money(line.get("amount"))}'
        )
        for line in selected
    )


def _policy_issue_summary(preview: dict[str, Any]) -> str:
    issues = list(preview.get("gaps") or []) + list(preview.get("warnings") or [])
    if not issues:
        return '<span class="ar-muted">Sin gaps.</span>'
    return "<br>".join(_text(issue) for issue in issues)


def _accounting_preview_rows(preview: dict[str, Any]) -> str:
    policies = [
        ("Factura", preview.get("invoice_policy_preview") or {}),
        ("Cobro", preview.get("collection_policy_preview") or {}),
    ]
    return "".join(
        _row(
            [
                _text(label),
                _status_pill(policy.get("status")),
                _policy_side_summary(list(policy.get("lines") or []), "debe"),
                _policy_side_summary(list(policy.get("lines") or []), "haber"),
                _policy_issue_summary(policy),
            ]
        )
        for label, policy in policies
    )


def _detail_action_links(item: dict[str, Any], *, return_to: str) -> str:
    links = [
        f'<a class="button secondary" href="{escape(return_to)}">Volver a CxC</a>',
        (
            '<a class="button secondary" '
            f'href="{escape(return_to)}#prematching">Ir a pre-matching</a>'
        ),
    ]
    budget_version_id = str(item.get("budget_version_id") or "").strip()
    tournament_key = str(
        item.get("tournament_id")
        or item.get("tournament_code")
        or item.get("tournament_name")
        or ""
    ).strip()
    if tournament_key:
        query_parts = []
        if budget_version_id:
            query_parts.append(f"version_id={quote(budget_version_id, safe='')}")
        query_parts.append("budget_view=income")
        budget_href = (
            f"/admin/presupuestos/torneo/{quote(tournament_key, safe='')}"
            f"?{'&'.join(query_parts)}#presupuesto-ingresos"
        )
        links.append(
            '<a class="button secondary" '
            f'href="{escape(budget_href)}">Presupuesto ingresos</a>'
        )
        accounting_query = []
        if item.get("tournament_id"):
            accounting_query.append(
                f"torneo_id={quote(str(item.get('tournament_id')), safe='')}"
            )
        accounting_href = "/admin/contabilidad/cuentas-por-cobrar"
        if accounting_query:
            accounting_href = f"{accounting_href}?{'&'.join(accounting_query)}"
        links.append(
            '<a class="button secondary" '
            f'href="{escape(accounting_href)}">Vista contable: CFDI y pólizas</a>'
        )
    return "".join(links)


def render_ar_item_detail_html(
    item: dict[str, Any],
    payload: dict[str, Any],
    *,
    return_to: str,
    can_operate_matches: bool,
) -> str:
    """Render one CxC operational item detail from the AR read model."""

    gaps = list(payload.get("matching_gaps") or []) + list(
        payload.get("collection_gaps") or []
    )
    status = item.get("operational_status") or item.get("status")
    collection_status = item.get("collection_status") or "collection_unknown"
    balance = (
        _money(item.get("balance_amount"))
        if item.get("balance_amount") is not None
        else "sin saldo confirmado"
    )
    navigation_actions = _detail_action_links(item, return_to=return_to)
    accounting_preview = build_ar_accounting_preview(item, payload)
    mutable_actions = ""
    if can_operate_matches:
        mutable_actions = """
            <span class="ar-muted">Acciones operativas habilitadas para CxC.</span>
        """
        if item.get("collection_match_id"):
            mutable_actions += (
                '<span class="ar-muted">Match aceptado: '
                f'{_text(item.get("collection_match_id"))}</span>'
            )
    else:
        mutable_actions = '<span class="ar-muted">Sin permiso operativo para acciones mutables.</span>'

    return f"""
        <section class="workspace-card ar-warning" style="margin-bottom:18px;">
            <div class="workspace-section-title">Detalle de Cuentas por Cobrar</div>
            <div class="workspace-section-subtitle">
                Detalle construido desde el mismo read model de la tabla CxC.
            </div>
            <div style="margin-top:12px;display:flex;gap:10px;flex-wrap:wrap;">
                {navigation_actions}
                {mutable_actions}
            </div>
        </section>
        <section class="workspace-card" style="margin-bottom:18px;">
            <div class="workspace-section-title">{_text(status)}</div>
            <div class="ar-detail-grid" style="margin-top:14px;">
                {_detail_metric("Cliente/pagador", item.get("payer_name"))}
                {_detail_metric("RFC", item.get("payer_rfc"))}
                {_detail_metric("UUID CFDI", item.get("cfdi_uuid"))}
                {_detail_metric("Saldo", balance)}
            </div>
        </section>
        <section class="ar-detail-sections">
            <div class="workspace-card">
                <div class="workspace-section-title">CFDI</div>
                <div class="ar-detail-grid">
                    {_detail_metric("UUID", item.get("cfdi_uuid"))}
                    {_detail_metric("Fecha CFDI", item.get("issued_date"))}
                    {_detail_money("Monto facturado", item.get("issued_amount"))}
                    {_detail_metric("RFC emisor", item.get("emisor_rfc"))}
                    {_detail_metric("Nombre emisor", item.get("emisor_nombre"))}
                    {_detail_metric("RFC receptor", item.get("payer_rfc"))}
                    {_detail_metric("Nombre receptor", item.get("payer_name"))}
                </div>
            </div>
            <div class="workspace-card">
                <div class="workspace-section-title">Presupuesto</div>
                <div class="ar-detail-grid">
                    {_detail_metric("Torneo/proyecto", item.get("tournament_name") or item.get("tournament_code"))}
                    {_detail_metric("Fase", item.get("phase"))}
                    {_detail_metric("Concepto/partida", item.get("concept_name"))}
                    {_detail_money("Monto presupuestado", item.get("expected_income_amount"))}
                    {_detail_money("Monto reconocido", item.get("linked_income_amount"))}
                    {_detail_metric("Versión", item.get("budget_version_id"))}
                </div>
            </div>
            <div class="workspace-card">
                <div class="workspace-section-title">Cobranza</div>
                <div class="ar-detail-grid">
                    {_detail_money("Cobrado comprobado", item.get("collected_amount"))}
                    {_detail_metric("Fecha cobranza", item.get("collection_date"))}
                    {_detail_metric("Match aceptado", item.get("collection_match_id"))}
                    {_detail_metric("Estado cobranza", collection_status)}
                    {_detail_metric("Vencimiento", item.get("due_date"))}
                    {_detail_metric("Saldo", balance)}
                </div>
                <div class="workspace-section-subtitle">
                    {"" if item.get("collection_match_id") else "La cobranza no está comprobada: falta match aceptado."}
                </div>
            </div>
            <div class="workspace-card">
                <div class="workspace-section-title">Gaps / Siguientes Acciones</div>
                <ul class="ar-gap-list">{_detail_gap_items(item, gaps)}</ul>
            </div>
            <div class="workspace-card">
                <div class="workspace-section-title">Prepólizas CxC</div>
                <table class="ar-table">
                    <thead><tr><th>Tipo</th><th>Estado</th><th>Debe</th><th>Haber</th><th>Gaps</th></tr></thead>
                    <tbody>{_accounting_preview_rows(accounting_preview)}</tbody>
                </table>
            </div>
        </section>
    """


def _candidate_summary(candidates: list[dict[str, Any]]) -> str:
    if not candidates:
        return '<span class="ar-muted">sin evidencia bancaria candidata</span>'
    candidate = candidates[0]
    signals = ", ".join(candidate.get("signals") or [])
    return (
        f'{_text(candidate.get("bank_movement_id"))}<br>'
        f'{_money(candidate.get("bank_amount"))} · {_text(candidate.get("bank_date"))}'
        f'<br><span class="ar-muted">{escape(signals or "sin señales")}</span>'
    )


def _accept_match_form(
    item: dict[str, Any],
    candidate: dict[str, Any],
    *,
    budget_version_id: str,
    action_base: str,
    return_to: str,
    can_operate_matches: bool = True,
    bank_accounts: list[dict[str, Any]] | None = None,
) -> str:
    if not can_operate_matches:
        return '<span class="ar-muted">sin permiso operativo</span>'
    if item.get("status") not in {"candidate_match", "manual_match_required"}:
        return '<span class="ar-muted">revision requerida</span>'
    account_options = '<option value="">Selecciona cuenta banco</option>' + "".join(
        f'<option value="{_text(account.get("id"), "")}">{_text(account.get("codigo"), "")} · {_text(account.get("nombre"), "")}</option>'
        for account in (bank_accounts or [])
    )
    hidden = {
        "budget_version_id": budget_version_id,
        "ar_item_id": item.get("ar_item_id"),
        "budget_line_id": item.get("budget_line_id"),
        "cfdi_report_id": item.get("cfdi_report_id"),
        "ar_amount": item.get("amount"),
        "payer_rfc": item.get("payer_rfc"),
        "payer_name": item.get("payer_name"),
        "bank_movement_id": candidate.get("bank_movement_id"),
        "bank_amount": candidate.get("bank_amount"),
        "return_to": return_to,
    }
    hidden_html = "".join(
        f'<input type="hidden" name="{escape(key)}" value="{_text(value, "")}">'
        for key, value in hidden.items()
    )
    return f"""
        <form method="POST" action="{escape(action_base)}/matches/accept"
              style="display:grid;gap:6px;min-width:180px;">
            {hidden_html}
            <select name="bank_account_id" required>{account_options}</select>
            <input name="acceptance_reason" required
                   placeholder="Razon de aceptacion">
            <button class="button secondary" type="submit">Aceptar match</button>
        </form>
    """


def _prematch_rows(
    rows: list[dict[str, Any]],
    *,
    budget_version_id: str,
    action_base: str,
    return_to: str,
    can_operate_matches: bool,
    bank_accounts: list[dict[str, Any]] | None = None,
) -> str:
    if not rows:
        return _empty_row(8, "Sin items AR para pre-matching.")
    return "".join(
        (
            lambda candidates: _row(
                [
                    _text(item.get("ar_item_id")),
                    _text(item.get("source")),
                    _text(item.get("payer_name")),
                    _text(item.get("payer_rfc")),
                    _money(item.get("amount")),
                    _candidate_summary(candidates),
                    _status_pill(item.get("status")),
                    _accept_match_form(
                        item,
                        candidates[0] if candidates else {},
                        budget_version_id=budget_version_id,
                        action_base=action_base,
                        return_to=return_to,
                        can_operate_matches=can_operate_matches,
                        bank_accounts=bank_accounts,
                    ),
                ]
            )
        )(
            list(item.get("candidate_evidence") or [])
        )
        for item in rows
    )


def _unmatched_bank_rows(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return _empty_row(6, "Sin entradas bancarias no vinculadas al alcance AR.")
    return "".join(
        _row(
            [
                _text(item.get("bank_movement_id")),
                _text(item.get("bank_date")),
                _text(item.get("bank_name")),
                _text(item.get("bank_rfc")),
                _money(item.get("bank_amount")),
                _status_pill(item.get("status")),
            ]
        )
        for item in rows
    )


def _accepted_match_rows(
    rows: list[dict[str, Any]],
    *,
    action_base: str,
    return_to: str,
    can_operate_matches: bool,
) -> str:
    if not rows:
        return _empty_row(7, "Sin matches AR aceptados.")
    rendered = []
    for item in rows:
        match_id = _text(item.get("id"), "")
        reverse_form = (
            '<span class="ar-muted">sin permiso operativo</span>'
            if not can_operate_matches
            else f"""
            <form method="POST"
                  action="{escape(action_base)}/matches/{match_id}/reverse"
                  style="display:grid;gap:6px;min-width:180px;">
                <input type="hidden" name="return_to" value="{_text(return_to, "")}">
                <input name="reversal_reason" required
                       placeholder="Razon de reversion">
                <button class="button secondary" type="submit">Revertir</button>
            </form>
        """
        )
        rendered.append(
            _row(
                [
                    _text(item.get("ar_item_id")),
                    _text(item.get("bank_movement_id")),
                    _money(item.get("accepted_amount")),
                    _text(item.get("collection_date") or item.get("accepted_at")),
                    _text(item.get("payer_name")),
                    _status_pill(item.get("status")),
                    reverse_form,
                ]
            )
        )
    return "".join(rendered)


def render_ar_matching_workbench_html(
    payload: dict[str, Any],
    *,
    action_base: str = "/admin/finanzas/cuentas-por-cobrar",
    return_to: str = "",
    can_operate_matches: bool = True,
    bank_accounts: list[dict[str, Any]] | None = None,
) -> str:
    """Render AR S3 pre-matching as a read-only admin fragment."""

    summary = payload.get("summary") or {}
    items = list(payload.get("items") or [])
    accepted_matches = list(payload.get("accepted_matches") or [])
    unmatched_bank_inflows = list(payload.get("unmatched_bank_inflows") or [])
    budget_version_id = _text(payload.get("budget_version_id"), "")
    summary_cards = "".join(
        [
            "<div><span>Aceptados</span>"
            f"<strong>{int(summary.get('accepted_match_count') or 0)}</strong></div>",
            "<div><span>Candidatos</span>"
            f"<strong>{int(summary.get('candidate_match_count') or 0)}</strong></div>",
            "<div><span>Revision manual</span>"
            f"<strong>{int(summary.get('manual_match_required_count') or 0)}"
            "</strong></div>",
            "<div><span>Sin evidencia</span>"
            f"<strong>{int(summary.get('collection_unknown_count') or 0)}"
            "</strong></div>",
            "<div><span>Payer gap</span>"
            f"<strong>{int(summary.get('payer_gap_count') or 0)}</strong></div>",
            "<div><span>Banco sin AR</span>"
            f"<strong>{int(summary.get('unmatched_bank_inflow_count') or 0)}"
            "</strong></div>",
        ]
    )
    prematch_header = (
        "<thead><tr><th>AR item</th><th>Fuente</th><th>Receptor</th>"
        "<th>RFC</th><th>Monto</th><th>Evidencia bancaria candidata</th>"
        "<th>Estado</th><th>Accion</th></tr></thead>"
    )
    accepted_header = (
        "<thead><tr><th>AR item</th><th>Movimiento</th><th>Monto</th>"
        "<th>Fecha cobranza</th><th>Receptor</th><th>Estado</th>"
        "<th>Reversión auditada</th></tr></thead>"
    )
    bank_header = (
        "<thead><tr><th>Movimiento</th><th>Fecha</th><th>Ordenante</th>"
        "<th>RFC</th><th>Monto</th><th>Estado</th></tr></thead>"
    )
    evidence_heading = "Conciliación CxC: evidencia y decisión"
    candidate_heading = "1. Evidencia candidata — requiere decisión"
    accepted_heading = "2. Matches AR aceptados — cobranza comprobada"
    unmatched_heading = "3. Entradas bancarias sin AR — pendientes de investigación"
    return f"""
        <section class="ar-evidence-flow"
                 aria-labelledby="ar-conciliation-evidence-heading">
        <section class="workspace-card ar-warning" id="prematching"
                 style="margin-bottom:18px;">
            <h2 class="workspace-section-title"
                id="ar-conciliation-evidence-heading">{evidence_heading}</h2>
            <div class="workspace-section-subtitle">
                Un candidato bancario es evidencia para revisar, no prueba de cobranza.
                Sólo un match AR aceptado comprueba cobranza; ninguna acción aquí
                modifica la conciliación bancaria legacy.
            </div>
            <div class="ar-metrics">{summary_cards}</div>
        </section>
        <section class="workspace-card" style="margin-bottom:18px;">
            <div class="workspace-section-title">
                {candidate_heading}
            </div>
            <div class="workspace-section-subtitle">
                Revisa señales, cuenta bancaria y razón antes de aceptar. La evidencia
                candidata y la revisión manual no cuentan como cobro.
            </div>
            <table class="ar-table">
                {prematch_header}
                <tbody>
                    {_prematch_rows(
                        items,
                        budget_version_id=budget_version_id,
                        action_base=action_base,
                        return_to=return_to,
                        can_operate_matches=can_operate_matches,
                        bank_accounts=bank_accounts,
                    )}
                </tbody>
            </table>
        </section>
        <section class="workspace-card" style="margin-bottom:18px;">
            <div class="workspace-section-title">
                {accepted_heading}
            </div>
            <div class="workspace-section-subtitle">
                Autoridad AR dedicada. Si la evidencia aceptada resulta incorrecta,
                la reversión requiere una razón y conserva la auditoría del match.
            </div>
            <table class="ar-table">
                {accepted_header}
                <tbody>
                    {_accepted_match_rows(
                        accepted_matches,
                        action_base=action_base,
                        return_to=return_to,
                        can_operate_matches=can_operate_matches,
                    )}
                </tbody>
            </table>
        </section>
        <section class="workspace-card" style="margin-bottom:18px;">
            <div class="workspace-section-title">
                {unmatched_heading}
            </div>
            <div class="workspace-section-subtitle">
                Estas entradas no tienen un item AR candidato en el alcance actual;
                no se aceptan automáticamente.
            </div>
            <table class="ar-table">
                {bank_header}
                <tbody>{_unmatched_bank_rows(unmatched_bank_inflows)}</tbody>
            </table>
        </section>
        </section>
    """


def _pending_income_links_html(
    links: list[dict[str, Any]], *, base_url: str = ""
) -> str:
    """Show proposed invoice links through the existing budget decision surface."""
    if not links:
        return ""
    rows = []
    edition_year = dict(parse_qsl(urlsplit(base_url).query)).get("edition_year")
    for link in links:
        tournament_key = str(link.get("tournament_id") or "").strip()
        version_id = str(link.get("budget_version_id") or "").strip()
        action = "Falta torneo; revisar vínculo en Presupuestos"
        if tournament_key:
            target = (
                f"/admin/presupuestos/torneo/{quote(tournament_key, safe='')}"
                f"?budget_view=income&version_id={quote(version_id, safe='')}"
            )
            if edition_year:
                target += f"&edition_year={quote(edition_year, safe='')}"
            target += "#presupuesto-ingresos"
            action = (
                f'<a href="{escape(target)}">Revisar aprobación en Presupuestos</a>'
            )
        rows.append(
            "<tr>"
            f"<td>{escape(str(link.get('cfdi_uuid') or '—'))}</td>"
            f"<td>{escape(str(link.get('receptor_nombre') or link.get('receptor_rfc') or '—'))}</td>"
            f"<td>{escape(str(link.get('concept_name') or '—'))}</td>"
            f"<td>{_money(link.get('amount'))}</td>"
            f"<td>Pendiente de aprobación</td><td>{action}</td>"
            "</tr>"
        )
    return (
        '<section class="workspace-card" style="margin-bottom:18px;">'
        '<div class="workspace-section-title">Facturas vinculadas pendientes de aprobación</div>'
        '<p>El vínculo ya existe. Su aprobación sigue en Presupuestos; '
        'estos importes no se suman a ingresos reconocidos ni a cobros.</p>'
        '<div class="ar-table-wrap"><table class="ar-table">'
        '<thead><tr><th>CFDI</th><th>Cliente</th><th>Partida</th>'
        '<th>Importe propuesto</th><th>Estado</th><th>Acción</th></tr></thead>'
        f"<tbody>{''.join(rows)}</tbody></table></div></section>"
    )


def render_ar_read_model_html(
    payload: dict[str, Any],
    *,
    status_filter: str = "todos",
    search: str = "",
    sort_by: str = "issued_date",
    sort_dir: str = "desc",
    base_url: str = "/admin/finanzas/cuentas-por-cobrar",
    export_url: str = "/admin/finanzas/cuentas-por-cobrar/export.xlsx",
    prepoliza_export_url: str = (
        "/admin/finanzas/cuentas-por-cobrar/prepolizas-coi.xlsx"
    ),
    return_to: str = "",
) -> str:
    """Render AR S1 as an admin workspace body fragment."""

    summary = payload.get("summary") or {}
    expected_income = list(payload.get("expected_income") or [])
    issued_linked = list(payload.get("issued_linked") or [])
    issued_unlinked = list(payload.get("issued_unlinked") or [])
    collection_gaps = list(payload.get("collection_gaps") or [])
    matching_gaps = list(payload.get("matching_gaps") or [])
    operational_rows = build_ar_operational_rows(
        payload,
        status_filter=status_filter,
        search=search,
        sort_by=sort_by,
        sort_dir=sort_dir,
    )
    clean_sort_dir = "asc" if str(sort_dir).lower() == "asc" else "desc"

    summary_cards = "".join(
        [
            "<div><span>Ingreso esperado</span>"
            f"<strong>{_money(summary.get('expected_income_total'))}</strong></div>",
            "<div><span>CFDI ligado</span>"
            f"<strong>{_money(summary.get('linked_income_total'))}</strong></div>",
            "<div><span>CFDI PSP no ligado</span>"
            f"<strong>{_money(summary.get('issued_unlinked_total'))}</strong></div>",
            "<div><span>Cobrado comprobado</span>"
            f"<strong>{_money(summary.get('collected_total'))}</strong></div>",
            "<div><span>Saldo</span>"
            f"<strong>{_money(summary.get('balance_total'))}</strong></div>",
            "<div><span>Vencido</span>"
            f"<strong>{_money(summary.get('overdue_total'))}</strong></div>",
            "<div><span>Gaps cobranza</span>"
            f"<strong>{int(summary.get('collection_gap_count') or 0)}</strong></div>",
            "<div><span>Gaps matching</span>"
            f"<strong>{int(summary.get('matching_gap_count') or 0)}</strong></div>",
        ]
    )
    expected_header = (
        "<thead><tr><th>Torneo</th><th>Fase</th><th>Concepto</th>"
        "<th>Esperado</th><th>CFDI ligado</th><th>Cobranza</th></tr></thead>"
    )
    linked_header = (
        "<thead><tr><th>UUID</th><th>Concepto</th><th>Receptor</th>"
        "<th>RFC</th><th>Monto</th><th>Fecha ingreso</th>"
        "<th>Cobranza</th></tr></thead>"
    )
    unlinked_header = (
        "<thead><tr><th>UUID</th><th>Fecha</th><th>Receptor</th>"
        "<th>RFC</th><th>Monto</th><th>Cobranza</th></tr></thead>"
    )
    collection_header = (
        "<thead><tr><th>Fuente</th><th>Item</th><th>Receptor</th>"
        "<th>RFC</th><th>Monto</th><th>Estado</th></tr></thead>"
    )
    matching_header = (
        "<thead><tr><th>Severidad</th><th>Fuente</th><th>Item</th>"
        "<th>Razon</th></tr></thead>"
    )
    actionable_gaps = build_ar_actionable_gaps(payload)
    billing_schedule = build_ar_billing_schedule(
        payload,
        status_filter=status_filter,
        search=search,
    )
    filtered_balance = _sum_money(operational_rows, "balance_amount")
    filtered_invoiced = _sum_money(operational_rows, "issued_amount")
    filtered_collected = _sum_money(operational_rows, "collected_amount")
    filtered_overdue = _sum_money(
        [
            row
            for row in operational_rows
            if str(row.get("operational_status") or "") == "Vencido"
        ],
        "balance_amount",
        "issued_amount",
    )
    executive_cards = "".join(
        [
            _executive_kpi_card(
                "Ingreso presupuestado",
                summary.get("expected_income_total"),
                "Plan de ingresos de la versión activa.",
            ),
            _executive_kpi_card(
                "Facturado",
                summary.get("invoiced_total")
                if summary.get("invoiced_total") is not None
                else (
                    float(summary.get("linked_income_total") or 0)
                    + float(summary.get("issued_unlinked_total") or 0)
                ),
                "CFDI PSP ligado o pendiente de liga.",
            ),
            _executive_kpi_card(
                "Cobrado comprobado",
                summary.get("collected_total"),
                "Sólo matches aceptados cuentan como cobro.",
                tone="positive",
            ),
            _executive_kpi_card(
                "Saldo pendiente CxC",
                summary.get("balance_total"),
                "Estimado desde facturado menos cobrado comprobado.",
                tone="warning",
            ),
            _executive_kpi_card(
                "Vencido",
                summary.get("overdue_total"),
                "Cartera facturada fuera de fecha.",
                tone="danger",
            ),
            _executive_kpi_card(
                "Gaps cobranza",
                _safe_count(summary.get("collection_gap_count")),
                "Items sin evidencia suficiente de cobro.",
                tone="warning",
                money=False,
            ),
        ]
    )
    filtered_cards = "".join(
        [
            _executive_kpi_card(
                "Items filtrados",
                len(operational_rows),
                "Renglones visibles con los filtros actuales.",
                money=False,
            ),
            _executive_kpi_card(
                "Facturado filtrado",
                filtered_invoiced,
                "Suma de CFDI visibles.",
            ),
            _executive_kpi_card(
                "Cobrado filtrado",
                filtered_collected,
                "Cobro comprobado visible.",
                tone="positive",
            ),
            _executive_kpi_card(
                "Saldo filtrado",
                filtered_balance,
                "Saldo de la cartera visible.",
                tone="warning",
            ),
            _executive_kpi_card(
                "Vencido filtrado",
                filtered_overdue,
                "Parte vencida dentro del filtro.",
                tone="danger",
            ),
        ]
    )
    billing_schedule_header = (
        "<thead><tr><th>Prioridad</th><th>Torneo/proyecto</th>"
        "<th>Fase</th><th>Concepto/partida</th><th>Presupuestado</th>"
        "<th>Facturado</th><th>Saldo por facturar</th><th>Meses</th>"
        "<th>Detalle</th></tr></thead>"
    )
    actionable_header = (
        "<thead><tr><th>Prioridad</th><th>Tipo</th><th>Estado</th>"
        "<th>Cliente</th><th>RFC</th><th>Torneo/proyecto</th>"
        "<th>Concepto</th><th>Monto</th><th>Accion sugerida</th></tr></thead>"
    )
    operational_header = (
        "<thead><tr>"
        f"<th>{_sort_link(label='Torneo', field='tournament_name', base_url=base_url, current_sort=sort_by, current_dir=clean_sort_dir)}</th>"
        f"<th>{_sort_link(label='Fase', field='phase', base_url=base_url, current_sort=sort_by, current_dir=clean_sort_dir)}</th>"
        f"<th>{_sort_link(label='Concepto', field='concept_name', base_url=base_url, current_sort=sort_by, current_dir=clean_sort_dir)}</th>"
        f"<th>{_sort_link(label='Cliente', field='payer_name', base_url=base_url, current_sort=sort_by, current_dir=clean_sort_dir)}</th>"
        f"<th>{_sort_link(label='RFC', field='payer_rfc', base_url=base_url, current_sort=sort_by, current_dir=clean_sort_dir)}</th>"
        f"<th>{_sort_link(label='UUID', field='cfdi_uuid', base_url=base_url, current_sort=sort_by, current_dir=clean_sort_dir)}</th>"
        f"<th>{_sort_link(label='Fecha CFDI', field='issued_date', base_url=base_url, current_sort=sort_by, current_dir=clean_sort_dir)}</th>"
        f"<th>{_sort_link(label='Vence', field='due_date', base_url=base_url, current_sort=sort_by, current_dir=clean_sort_dir)}</th>"
        f"<th>{_sort_link(label='Presupuestado', field='expected_income_amount', base_url=base_url, current_sort=sort_by, current_dir=clean_sort_dir)}</th>"
        f"<th>{_sort_link(label='Facturado', field='issued_amount', base_url=base_url, current_sort=sort_by, current_dir=clean_sort_dir)}</th>"
        f"<th>{_sort_link(label='Reconocido', field='linked_income_amount', base_url=base_url, current_sort=sort_by, current_dir=clean_sort_dir)}</th>"
        f"<th>{_sort_link(label='Cobrado', field='collected_amount', base_url=base_url, current_sort=sort_by, current_dir=clean_sort_dir)}</th>"
        f"<th>{_sort_link(label='Saldo', field='balance_amount', base_url=base_url, current_sort=sort_by, current_dir=clean_sort_dir)}</th>"
        f"<th>{_sort_link(label='Estado', field='operational_status', base_url=base_url, current_sort=sort_by, current_dir=clean_sort_dir)}</th>"
        "<th>Detalle</th>"
        "</tr></thead>"
    )
    accounting_href = _accounting_cxc_href(base_url)

    return f"""
        <section class="workspace-card ar-warning" style="margin-bottom:18px;">
            <div class="workspace-section-title">Workbench CxC: facturación y cobranza</div>
            <div class="workspace-section-subtitle">
                Esta vista separa ingreso presupuestado, CFDI emitido, ingreso
                reconocido y cobranza comprobada. Un CFDI vinculado no prueba
                pago; solo los matches aceptados cuentan como cobro.
            </div>
            <div style="margin-top:12px;display:flex;gap:10px;flex-wrap:wrap;">
                <a class="button secondary" href="{escape(export_url)}">Descargar Excel CxC</a>
                <a class="button secondary" href="{escape(prepoliza_export_url)}">Descargar prepólizas CxC</a>
                <a class="button secondary" href="{escape(accounting_href)}">Vista contable: CFDI y pólizas</a>
            </div>
        </section>
        <section class="workspace-card" style="margin-bottom:18px;">
            <div class="workspace-section-title">Lectura ejecutiva CxC</div>
            <div class="workspace-section-subtitle">
                Cartera, facturación, cobro comprobado y riesgo vencido desde
                el mismo read model. Los candidatos bancarios siguen siendo
                evidencia candidata; no cuentan como cobro hasta ser aceptados.
            </div>
            <div class="ar-executive-grid">
                {executive_cards}
            </div>
        </section>
        <section class="workspace-card" style="margin-bottom:18px;">
            <div class="workspace-section-title">Cartera filtrada</div>
            <div class="workspace-section-subtitle">
                Estos importes responden al estado, cliente, versión y búsqueda
                activos en la pantalla.
            </div>
            <div class="ar-executive-grid ar-executive-grid-compact">
                {filtered_cards}
            </div>
        </section>
        <section class="workspace-card" style="margin-bottom:18px;">
            <div class="workspace-section-title">Prioridad ejecutiva de cartera</div>
            <div class="workspace-section-subtitle">
                Atajos por estado para llegar primero a vencidos, cobros
                parciales, cobranza no comprobada y presupuesto sin CFDI.
            </div>
            <div class="ar-bucket-grid">
                {_executive_status_buckets(operational_rows, base_url=base_url)}
            </div>
        </section>
        <section class="workspace-card" style="margin-bottom:18px;">
            <div class="workspace-section-title">Siguientes acciones CxC</div>
            <div class="workspace-section-subtitle">
                Cinco pendientes priorizados para mover la cartera sin cambiar
                reglas contables ni hacer conciliaciones automáticas.
            </div>
            <div class="ar-action-grid">
                {_executive_action_cards(actionable_gaps, return_to=return_to or base_url)}
            </div>
        </section>
        <section class="workspace-card" style="margin-bottom:18px;">
            <div class="workspace-section-title">Resumen</div>
            <div class="ar-metrics">
                {summary_cards}
            </div>
        </section>
        <section class="workspace-card" style="margin-bottom:18px;">
            <div class="workspace-section-title">Programación por facturar</div>
            <div class="workspace-section-subtitle">
                Partidas de ingreso presupuestado que aún no tienen CFDI completo.
            </div>
            <div class="ar-table-wrap">
                <table class="ar-table">
                    {billing_schedule_header}
                    <tbody>{_billing_schedule_rows(billing_schedule, return_to=return_to or base_url)}</tbody>
                </table>
            </div>
        </section>
        <section class="workspace-card" style="margin-bottom:18px;">
            <div class="workspace-section-title">Gaps accionables</div>
            <div class="workspace-section-subtitle">
                Pendientes CxC priorizados desde la misma cartera operativa.
            </div>
            <div class="ar-table-wrap">
                <table class="ar-table">
                    {actionable_header}
                    <tbody>{_actionable_gap_rows(actionable_gaps, return_to=return_to or base_url)}</tbody>
                </table>
            </div>
        </section>
        <section class="workspace-card" style="margin-bottom:18px;">
            <div class="workspace-section-title">Cartera operativa</div>
            <div class="workspace-section-subtitle">
                Click en cualquier encabezado para ordenar A-Z / Z-A o
                menor-mayor / mayor-menor.
            </div>
            <div class="ar-table-wrap">
                <table class="ar-table">
                    {operational_header}
                    <tbody>{_operational_rows(operational_rows, return_to=return_to or base_url)}</tbody>
                </table>
            </div>
        </section>
        <section class="workspace-card" style="margin-bottom:18px;">
            <div class="workspace-section-title">Ingreso esperado</div>
            <table class="ar-table">
                {expected_header}
                <tbody>{_expected_income_rows(expected_income)}</tbody>
            </table>
        </section>
        <section class="workspace-card" style="margin-bottom:18px;">
            <div class="workspace-section-title">CFDI ligado</div>
            <table class="ar-table">
                {linked_header}
                <tbody>{_linked_rows(issued_linked)}</tbody>
            </table>
        </section>
        {_pending_income_links_html(list(payload.get('pending_links') or []), base_url=base_url)}
        <section class="workspace-card" style="margin-bottom:18px;">
            <div class="workspace-section-title">CFDI PSP no ligado</div>
            <table class="ar-table">
                {unlinked_header}
                <tbody>{_unlinked_rows(issued_unlinked)}</tbody>
            </table>
        </section>
        <section class="workspace-card" style="margin-bottom:18px;">
            <div class="workspace-section-title">Gaps de cobranza</div>
            <table class="ar-table">
                {collection_header}
                <tbody>{_collection_gap_rows(collection_gaps)}</tbody>
            </table>
        </section>
        <section class="workspace-card">
            <div class="workspace-section-title">Gaps de matching</div>
            <table class="ar-table">
                {matching_header}
                <tbody>{_matching_gap_rows(matching_gaps)}</tbody>
            </table>
        </section>
    """


def ar_admin_styles() -> str:
    """CSS for the AR admin fragment."""

    return """
        .ar-warning {
            border-color:#bfdbfe;
            background:#eff6ff;
        }
        .ar-metrics {
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(170px,1fr));
            gap:12px;
            margin-top:14px;
        }
        .ar-metrics div {
            border:1px solid #e2e8f0;
            border-radius:8px;
            padding:14px;
            background:#ffffff;
        }
        .ar-metrics span {
            display:block;
            color:#64748b;
            font-size:12px;
            font-weight:800;
            text-transform:uppercase;
        }
        .ar-metrics strong {
            display:block;
            margin-top:6px;
            color:#0f172a;
            font-size:1.15rem;
        }
        .ar-executive-grid {
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(190px,1fr));
            gap:12px;
            margin-top:14px;
        }
        .ar-executive-grid-compact {
            grid-template-columns:repeat(auto-fit,minmax(170px,1fr));
        }
        .ar-executive-card {
            min-width:0;
            border:1px solid #e2e8f0;
            border-left:4px solid #64748b;
            border-radius:8px;
            padding:14px;
            background:#fff;
        }
        .ar-executive-positive {
            border-left-color:#047857;
        }
        .ar-executive-warning {
            border-left-color:#b45309;
        }
        .ar-executive-danger {
            border-left-color:#b91c1c;
        }
        .ar-executive-card span,
        .ar-bucket-number span,
        .ar-action-card small {
            display:block;
            color:#64748b;
            font-size:12px;
            font-weight:800;
            text-transform:uppercase;
        }
        .ar-executive-card strong {
            display:block;
            margin-top:6px;
            color:#0f172a;
            font-size:1.35rem;
            overflow-wrap:anywhere;
        }
        .ar-executive-card small {
            display:block;
            margin-top:6px;
            color:#475569;
            line-height:1.45;
        }
        .ar-bucket-grid,
        .ar-action-grid {
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(240px,1fr));
            gap:12px;
            margin-top:14px;
        }
        .ar-executive-bucket,
        .ar-action-card {
            min-width:0;
            display:flex;
            justify-content:space-between;
            gap:14px;
            text-decoration:none;
            border:1px solid #e2e8f0;
            border-radius:8px;
            padding:14px;
            background:#fff;
            color:#0f172a;
        }
        .ar-executive-bucket:hover,
        .ar-action-card:hover {
            border-color:#0f766e;
            box-shadow:0 12px 24px rgba(15,23,42,.08);
        }
        .ar-executive-bucket h3,
        .ar-action-card h3 {
            margin:10px 0 6px;
            font-size:16px;
            line-height:1.25;
            color:#0f172a;
        }
        .ar-executive-bucket p,
        .ar-action-card p {
            margin:0;
            color:#475569;
            font-size:13px;
            line-height:1.45;
        }
        .ar-bucket-number {
            flex:0 0 auto;
            text-align:right;
        }
        .ar-bucket-number strong,
        .ar-action-card strong {
            display:block;
            color:#0f172a;
            font-size:1.35rem;
        }
        .ar-action-card {
            align-items:flex-start;
        }
        .ar-action-card > div:last-child {
            display:grid;
            gap:6px;
            justify-items:end;
            text-align:right;
        }
        .ar-executive-empty {
            border:1px dashed #cbd5e1;
            border-radius:8px;
            padding:16px;
            color:#64748b;
            background:#f8fafc;
        }
        .ar-table {
            width:100%;
            border-collapse:separate;
            border-spacing:0;
        }
        .ar-table-wrap {
            overflow:auto;
            max-height:68vh;
            margin-top:14px;
        }
        .ar-table th,
        .ar-table td {
            text-align:left;
            padding:11px 12px;
            border-bottom:1px solid #e2e8f0;
            vertical-align:top;
        }
        .ar-table th {
            color:#64748b;
            font-size:11px;
            text-transform:uppercase;
            background:#f8fafc;
            position:sticky;
            top:0;
            z-index:1;
        }
        .ar-sort {
            color:#334155;
            text-decoration:none;
            font-weight:900;
        }
        .ar-muted {
            color:#64748b;
        }
        .ar-pill {
            display:inline-flex;
            padding:4px 8px;
            border-radius:999px;
            background:#e0f2fe;
            color:#075985;
            font-size:11px;
            font-weight:900;
            text-transform:uppercase;
        }
        .button.compact {
            padding:7px 10px;
            border-radius:10px;
            font-size:12px;
            white-space:nowrap;
        }
        .ar-detail-grid {
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(190px,1fr));
            gap:12px;
            margin-top:12px;
        }
        .ar-detail-sections {
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(320px,1fr));
            gap:16px;
            margin-bottom:18px;
        }
        .ar-detail-metric {
            border:1px solid #e2e8f0;
            border-radius:8px;
            background:#fff;
            padding:12px;
        }
        .ar-detail-metric span {
            display:block;
            color:#64748b;
            font-size:11px;
            font-weight:900;
            text-transform:uppercase;
        }
        .ar-detail-metric strong {
            display:block;
            margin-top:6px;
            color:#0f172a;
            font-size:14px;
            overflow-wrap:anywhere;
        }
        .ar-gap-list {
            margin:12px 0 0 18px;
            color:#334155;
            line-height:1.55;
        }
    """
