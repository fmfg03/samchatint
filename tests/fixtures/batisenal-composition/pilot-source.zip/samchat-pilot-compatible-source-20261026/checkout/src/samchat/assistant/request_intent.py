from __future__ import annotations

import re
import unicodedata
import uuid
from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Optional

from .finance_query_intent import detect_finance_comparison_intent


@dataclass(frozen=True)
class OperationalRequestIntent:
    request_id: str
    domain: str
    intent: str
    confidence: float
    slots: Dict[str, Any]
    missing_fields: List[str]
    raw_text: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def normalize_request_text(text: str) -> str:
    normalized = unicodedata.normalize("NFKD", text or "")
    ascii_text = "".join(ch for ch in normalized if not unicodedata.combining(ch))
    return re.sub(r"\s+", " ", ascii_text.lower()).strip()


def _request_id(text: str) -> str:
    return f"req_{uuid.uuid5(uuid.NAMESPACE_URL, text or '').hex[:16]}"


def _years(text: str) -> List[int]:
    found: List[int] = []
    for match in re.finditer(r"\b(20[0-9]{2})\b", text):
        year = int(match.group(1))
        if year not in found:
            found.append(year)
    return found[:2]


def _period(text: str) -> Optional[str]:
    if "esta semana" in text:
        return "this_week"
    if "este mes" in text:
        return "this_month"
    if "este trimestre" in text:
        return "this_quarter"
    if "este ano" in text or "este año" in text:
        return "this_year"
    return None


def _group_by(text: str) -> Optional[str]:
    if any(token in text for token in ("proveedor", "vendor")):
        return "proveedor"
    if any(token in text for token in ("proyecto", "project")):
        return "proyecto"
    if any(token in text for token in ("torneo", "tournament")):
        return "torneo"
    if any(token in text for token in ("cuenta contable", "cuenta", "account")):
        return "cuenta_contable"
    if any(token in text for token in ("categoria", "category")):
        return "categoria"
    if any(token in text for token in ("concepto", "concept")):
        return "concepto"
    return None


def _base_slots(text: str) -> Dict[str, Any]:
    return {
        "metric": None,
        "years": _years(text),
        "period": _period(text),
        "group_by": _group_by(text),
        "filters": {},
        "output": "table",
    }


def _has_document_context(text: str) -> bool:
    return any(
        token in text
        for token in (
            "contrato",
            "documento",
            "texto",
            "sow",
            "propuesta",
            "balanza",
            "contexto",
            "extracto",
            "fragmento",
        )
    )


OWNER_AI_READINESS_TERMS = (
    "que falta",
    "que nos falta",
    "que evidencia falta",
    "faltantes",
    "faltante",
    "que tan listo",
    "que tan preparado",
    "readiness",
    "listo",
    "lista",
    "listas",
    "listos",
    "listo para",
    "preparado",
    "preparada",
    "preparados",
    "preparadas",
    "preparado para",
    "contestarle al director general",
    "responderle al director general",
    "contestarle al dueno",
    "responderle al dueno",
    "tenemos datos",
    "hay datos",
    "datos para el dueno",
    "datos para dueno",
    "informacion para el dueno",
    "informacion del dueno",
    "evidencia para el dueno",
    "owner pack",
    "pack del dueno",
    "pack de dueno",
)


OWNER_AI_CONTEXT_TERMS = (
    "carpeta por entidad",
    "carpetas por entidad",
    "carpeta por cada entidad",
    "una carpeta por cada entidad",
    "carpeta de la entidad",
    "carpeta de entidad",
    "carpetas del torneo",
    "carpetas de torneo",
    "carpeta de fase nacional",
    "fase nacional",
    "fase estatal",
    "entrega de uniformes",
    "uniformes de fase estatal",
    "camas noche",
    "camas-noche",
    "box lunch",
    "servicios medicos",
    "servicios medico",
    "accidentes con traslado",
    "activacion de marcas",
    "activaciones de marca",
    "visitantes involucrados",
    "evidencia fotografica",
    "fotografias",
    "necesidades de ai",
    "pack del dueno",
    "pack de dueno",
    "owner pack",
    "datos para el dueno",
    "datos para dueno",
    "informacion para el dueno",
    "informacion del dueno",
    "evidencia para el dueno",
    "necesidades del dueno",
    "necesidades del dueño",
    "cosas que necesito que me de la ia",
    "cosas que necesito que me d? la ia",
    "para todos y cada uno de los torneos",
    "tableros preparados",
    "tableros del dueno",
    "tableros del dueno",
    "tableros para el dueno",
    "tableros para el dueno",
    "tablero del director general",
    "tablero para director general",
    "tablero del dueno",
    "tablero del dueno",
    "tablero para direccion general",
    "tablero para direccion general",
)


REGISTRATION_EXECUTIVE_REPORT_TERMS = (
    "reportes de cedulas",
    "reportes de cédulas",
    "cedulas capturadas",
    "cédulas capturadas",
    "equipos y jugadores por estado",
    "sumatoria total de equipos",
    "municipios participan",
    "municipios participantes",
    "categoria femenil",
    "categoría femenil",
    "categoria juvenil",
    "categoría juvenil",
    "categoria varonil",
    "categoría varonil",
)


def is_registration_executive_report_request(text: str) -> bool:
    normalized = normalize_request_text(text)
    if any(term in normalized for term in REGISTRATION_EXECUTIVE_REPORT_TERMS):
        return True
    return (
        "cedula" in normalized
        and any(token in normalized for token in ("reporte", "reportes", "sumatoria"))
        and any(token in normalized for token in ("equipo", "jugador", "municipio"))
    )


def _extract_tournament_slug_hint(text: str) -> Optional[str]:
    normalized = normalize_request_text(text)
    if any(token in normalized for token in ("ctt", "copa telmex", "telmex")):
        return "copa-telmex"
    if any(token in normalized for token in ("liga telmex", "beisbol")):
        return "liga-telmex-telcel"
    return None


def owner_ai_tournament_slug_hint(text: str) -> Optional[str]:
    return _extract_tournament_slug_hint(text)


def is_owner_ai_context_request(text: str) -> bool:
    normalized = normalize_request_text(text)
    return any(term in normalized for term in OWNER_AI_CONTEXT_TERMS)


def is_owner_ai_readiness_request(text: str) -> bool:
    normalized = normalize_request_text(text)
    explicit_owner_pack = any(
        term in normalized
        for term in (
            "owner pack",
            "pack del dueno",
            "pack de dueno",
        )
    )
    if "tablero" in normalized and not explicit_owner_pack:
        return False
    if not any(term in normalized for term in OWNER_AI_READINESS_TERMS):
        return False
    return is_owner_ai_context_request(text) or any(
        token in normalized
        for token in (
            "director general",
            "direccion general",
            "dueno",
            "owner pack",
            "pack del dueno",
            "pack de dueno",
            "tablero",
            "torneo",
            "carpeta",
            "evidencia",
        )
    )


def is_owner_ai_conceptual_request(text: str) -> bool:
    normalized = normalize_request_text(text)
    conceptual_terms = (
        "que debe contener",
        "que datos",
        "que necesita",
        "necesito que me de la ia",
        "necesito que me d? la ia",
        "para todos y cada uno",
        "como debe responder",
        "que puede hacer",
        "sin cambiar datos",
        "sin cambiar nada",
    )
    return is_owner_ai_context_request(text) and any(
        term in normalized for term in conceptual_terms
    )


def _intent(
    *,
    raw_text: str,
    domain: str,
    intent: str,
    confidence: float,
    slots: Dict[str, Any],
    missing_fields: Optional[List[str]] = None,
) -> OperationalRequestIntent:
    return OperationalRequestIntent(
        request_id=_request_id(raw_text),
        domain=domain,
        intent=intent,
        confidence=confidence,
        slots=slots,
        missing_fields=missing_fields or [],
        raw_text=raw_text or "",
    )


def detect_request_intent(text: str) -> OperationalRequestIntent:
    raw_text = text or ""
    normalized = normalize_request_text(raw_text)
    slots = _base_slots(normalized)

    finance_compare = detect_finance_comparison_intent(raw_text)
    if finance_compare is not None:
        slots.update(
            {
                "metric": finance_compare.metric,
                "years": finance_compare.years,
                "group_by": finance_compare.group_by,
                "comparison": finance_compare.comparison,
            }
        )
        return _intent(
            raw_text=raw_text,
            domain="finance",
            intent="compare",
            confidence=0.95,
            slots=slots,
        )

    has_finance = any(token in normalized for token in ("gasto", "gastos", "finanza"))
    if has_finance:
        slots["metric"] = "gasto"
        if any(
            token in normalized for token in ("pendiente", "comprobar", "comprobacion")
        ):
            return _intent(
                raw_text=raw_text,
                domain="finance",
                intent="list_pending",
                confidence=0.86,
                slots=slots,
            )
        if any(
            token in normalized for token in ("reporte", "dame", "cuanto", "gastamos")
        ):
            slots["group_by"] = slots.get("group_by") or "proyecto"
            return _intent(
                raw_text=raw_text,
                domain="finance",
                intent="breakdown",
                confidence=0.84,
                slots=slots,
            )

    if any(token in normalized for token in ("cfdi", "cfdis", "factura", "facturas")):
        intent_name = "list_pending"
        if any(token in normalized for token in ("sin vincular", "sin gasto")):
            intent_name = "list_unlinked"
        if any(token in normalized for token in ("pagar", "pagado", "pago")):
            intent_name = "payment_status"
        return _intent(
            raw_text=raw_text,
            domain="cfdi",
            intent=intent_name,
            confidence=0.9,
            slots={**slots, "metric": "cfdi", "output": "table"},
        )

    if any(
        token in normalized
        for token in (
            "pago",
            "pagos",
            "comprobacion",
            "comprobaciones",
            "reembolso",
            "reembolsos",
            "saldar",
        )
    ):
        due_soon = "vence" in normalized or "vencen" in normalized
        return _intent(
            raw_text=raw_text,
            domain="payments",
            intent="due_soon" if due_soon else "list_pending",
            confidence=0.88,
            slots={**slots, "metric": "payment", "output": "table"},
        )

    if is_registration_executive_report_request(raw_text):
        tournament_slug = _extract_tournament_slug_hint(raw_text)
        report_slots = {
            **slots,
            "metric": "registration_executive_reports",
            "output": "report_package",
            "filters": {
                **dict(slots.get("filters") or {}),
                "tournament_slug": tournament_slug,
            },
        }
        missing = [] if tournament_slug else ["tournament"]
        return _intent(
            raw_text=raw_text,
            domain="tournament",
            intent="registration_executive_reports",
            confidence=0.9,
            slots=report_slots,
            missing_fields=missing,
        )

    if not is_owner_ai_conceptual_request(raw_text) and any(
        token in normalized
        for token in (
            "torneo",
            "equipos",
            "equipo",
            "jugadores",
            "jugador",
            "registro",
        )
    ):
        missing: List[str] = []
        if "torneo" not in normalized and "copa telmex" not in normalized:
            missing.append("tournament")
        entity = (
            "team_documents"
            if "document" in normalized or "equip" in normalized
            else "tournament"
        )
        pending = any(
            token in normalized for token in ("pendiente", "incompleto", "faltan")
        )
        return _intent(
            raw_text=raw_text,
            domain="tournament",
            intent="list_pending" if pending else "status",
            confidence=0.86,
            slots={**slots, "metric": entity, "output": "table"},
            missing_fields=missing,
        )

    if not _has_document_context(normalized) and (
        any(
            token in normalized
            for token in ("direccion", "directivo", "ejecutivo", "atorando")
        )
        or (
            "riesgos" in normalized
            and any(
                token in normalized
                for token in ("semana", "operacion", "finanzas", "reporte")
            )
        )
    ):
        return _intent(
            raw_text=raw_text,
            domain="executive",
            intent="summarize",
            confidence=0.84,
            slots={
                **slots,
                "metric": "operations_summary",
                "output": "summary",
            },
        )

    return _intent(
        raw_text=raw_text,
        domain="unknown",
        intent="unknown",
        confidence=0.0,
        slots=slots,
        missing_fields=["intent"],
    )
