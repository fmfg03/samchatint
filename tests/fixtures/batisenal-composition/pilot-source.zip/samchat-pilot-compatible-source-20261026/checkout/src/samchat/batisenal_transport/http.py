"""Unmounted stateless JSON MCP ASGI factory. No server start, cookies or credentials.

resolve_connection(request) is a mandatory host adapter that verifies credentials
and returns a reference for the existing IdentityProvider; it is never a model
argument. current_connection is ContextVar-isolated and reset after every request.
"""

import json
from contextvars import ContextVar
from typing import Any

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.routing import Route

from devnous.gastos.services.batisenal_service import BatisenalError

_connection: ContextVar[str] = ContextVar("batisenal_connection")
PROTOCOL = "2026-07-28"
PROFILE = "samchat_batisenal_profile"
HEADERS = {"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"}


def current_connection():
    return _connection.get("")


def object_pairs(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError("DUPLICATE_FIELD")
        value[key] = item
    return value


def profile_schema():
    return {
        "name": PROFILE,
        "description": "Verified connection profile. No account selector.",
        "inputSchema": {
            "type": "object",
            "properties": {},
            "additionalProperties": False,
        },
        "outputSchema": {
            "type": "object",
            "properties": {"id": {"type": "string", "minLength": 1}},
            "required": ["id"],
            "additionalProperties": False,
        },
        "annotations": {
            "readOnlyHint": True,
            "destructiveHint": False,
            "openWorldHint": False,
        },
        "securitySchemes": [{"type": "oauth2", "scopes": ["batisenal.support"]}],
        "_meta": {"openai/profile": True},
    }


def create_app(
    bridge, *, resolve_connection=None, events=None, enabled=False, allowed_origins=()
):
    """Return inert-by-default ASGI; caller must explicitly mount after approval."""

    async def endpoint(request: Request):
        identifier = None
        token = None
        actor, method = None, "unknown"
        result: dict[str, Any]
        try:
            if enabled is not True or resolve_connection is None:
                raise BatisenalError("ACTIVATION_REQUIRED", 503)
            if request.url.query or request.headers.get("cookie"):
                raise BatisenalError("TRANSPORT_INVALID", 400)
            origin = request.headers.get("origin")
            if origin is not None and origin not in allowed_origins:
                raise BatisenalError("ORIGIN_DENIED", 403)
            if not request.headers.get("authorization", "").startswith("Bearer "):
                raise BatisenalError("UNAUTHENTICATED", 401)
            if (
                request.headers.get("content-type", "").split(";")[0]
                != "application/json"
            ):
                raise BatisenalError("CONTENT_TYPE_INVALID", 415)
            if "application/json" not in request.headers.get("accept", ""):
                raise BatisenalError("ACCEPT_INVALID", 406)
            if request.headers.get("mcp-protocol-version", PROTOCOL) != PROTOCOL:
                raise BatisenalError("PROTOCOL_UNSUPPORTED", 400)
            body = bytearray()
            async for chunk in request.stream():
                if len(body) + len(chunk) > 32768:
                    raise BatisenalError("INPUT_LIMIT", 413)
                body.extend(chunk)
            try:
                msg = json.loads(
                    body,
                    object_pairs_hook=object_pairs,
                    parse_constant=lambda _: (_ for _ in ()).throw(ValueError()),
                )
            except (ValueError, UnicodeError) as exc:
                raise BatisenalError("INVALID_JSON") from exc
            if (
                not isinstance(msg, dict)
                or msg.get("jsonrpc") != "2.0"
                or not isinstance(msg.get("method"), str)
                or set(msg) - {"jsonrpc", "id", "method", "params"}
            ):
                raise BatisenalError("INVALID_REQUEST")
            identifier = msg.get("id")
            if identifier is not None and type(identifier) not in (str, int):
                raise BatisenalError("INVALID_REQUEST")
            method, params = msg["method"], msg.get("params", {})
            if not isinstance(params, dict):
                raise BatisenalError("INVALID_ARGUMENTS")
            connection = await resolve_connection(request)
            if not isinstance(connection, str) or not connection:
                raise BatisenalError("UNAUTHENTICATED", 401)
            token = _connection.set(connection)
            async with bridge.sessions() as session:
                principal, binding, _ = await bridge.authorize(session)
            actor = str(principal.employee)
            bridge.audit_attempt(actor, method, "authorized_attempt")
            if "id" not in msg:
                if method != "notifications/initialized" or params:
                    raise BatisenalError("INVALID_REQUEST")
                return Response(status_code=202, headers=HEADERS)
            if method in {"initialize", "server/discover", "ping"}:
                capabilities: dict[str, Any] = {"tools": {}}
                if events is not None and events.enabled is True:
                    events.gate()
                    capabilities["events"] = {}
                if method == "initialize":
                    if (
                        params.get("protocolVersion") != PROTOCOL
                        or set(params)
                        != {"protocolVersion", "capabilities", "clientInfo"}
                        or not isinstance(params["capabilities"], dict)
                        or not isinstance(params["clientInfo"], dict)
                    ):
                        raise BatisenalError("PROTOCOL_UNSUPPORTED")
                    result = {
                        "protocolVersion": PROTOCOL,
                        "capabilities": capabilities,
                        "serverInfo": {
                            "name": "samchat-batisenal-candidate",
                            "version": "0.1.0",
                        },
                    }
                elif method == "server/discover":
                    if params:
                        raise BatisenalError("INVALID_ARGUMENTS")
                    result = {
                        "resultType": "complete",
                        "supportedVersions": [PROTOCOL],
                        "capabilities": capabilities,
                    }
                else:
                    if params:
                        raise BatisenalError("INVALID_ARGUMENTS")
                    result = {}
            elif method == "tools/call" and params.get("name") == PROFILE:
                if set(params) != {"name", "arguments"} or params["arguments"] != {}:
                    raise BatisenalError("INVALID_ARGUMENTS")
                result = {
                    "isError": False,
                    "structuredContent": {"id": binding.profile_id},
                    "content": [
                        {"type": "text", "text": json.dumps({"id": binding.profile_id})}
                    ],
                }
            elif method in {"tools/list", "tools/call"}:
                response = await bridge.handle(msg)
                if method == "tools/list" and "result" in response:
                    response["result"]["tools"].append(profile_schema())
                return JSONResponse(response, headers=HEADERS)
            elif method.startswith("events/") and events is not None:
                result = await events.handle(method, params)
            else:
                raise BatisenalError("METHOD_NOT_AVAILABLE")
            bridge.audit_attempt(str(principal.employee), method, "read_complete")
            return JSONResponse(
                {"jsonrpc": "2.0", "id": identifier, "result": result}, headers=HEADERS
            )
        except BatisenalError as exc:
            if enabled is True and resolve_connection is not None:
                try:
                    bridge.audit_attempt(actor, method, exc.code)
                except BatisenalError as audit_error:
                    exc = audit_error
            error: dict[str, Any] = {"code": -32000, "message": exc.code}
            if exc.code == "CALLBACK_VERIFICATION_FAILED":
                error.update(code=-32015, data={"reason": "challenge_failed"})
            return JSONResponse(
                {"jsonrpc": "2.0", "id": identifier, "error": error},
                status_code=exc.status,
                headers=HEADERS,
            )
        except Exception:
            try:
                bridge.audit_attempt(actor, method, "TRANSPORT_UNAVAILABLE")
            except Exception:
                return JSONResponse(
                    {
                        "jsonrpc": "2.0",
                        "id": identifier,
                        "error": {"code": -32000, "message": "AUDIT_UNAVAILABLE"},
                    },
                    status_code=503,
                    headers=HEADERS,
                )
            # Do not stringify host exceptions, tokens, payloads or callback material.
            return JSONResponse(
                {
                    "jsonrpc": "2.0",
                    "id": identifier,
                    "error": {"code": -32000, "message": "TRANSPORT_UNAVAILABLE"},
                },
                status_code=503,
                headers=HEADERS,
            )
        finally:
            if token is not None:
                _connection.reset(token)

    return Starlette(routes=[Route("/mcp", endpoint, methods=["POST"])])
