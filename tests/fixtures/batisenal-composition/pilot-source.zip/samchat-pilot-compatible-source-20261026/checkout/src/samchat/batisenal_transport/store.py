"""Explicitly provisioned transport-only SQLite store; never business data."""

import hashlib
import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path

from devnous.gastos.services.batisenal_service import BatisenalError

ACTIONS = {
    "initialize",
    "ping",
    "tools/list",
    "server/discover",
    "profile",
    "events/list",
    "events/subscribe",
    "events/unsubscribe",
    "enqueue",
    "samchat_batisenal_list_pending",
    "samchat_batisenal_read_case",
    "samchat_batisenal_record_activity",
    "samchat_batisenal_prepare_reply",
    "samchat_batisenal_submit_draft",
}
OUTCOMES = {
    "OK",
    "authorized_attempt",
    "read_complete",
    "scoped_attempt",
    "SUBSCRIBED",
    "UNSUBSCRIBED",
    "ENQUEUED",
    "UNAUTHENTICATED",
}


def digest(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


class Store:
    """Opening never creates schema. Provision SQL explicitly in a private store."""

    def __init__(self, path, clock):
        self.path, self.clock = Path(path).resolve(), clock

    @contextmanager
    def transaction(self):
        db = sqlite3.connect(self.path.as_uri() + "?mode=rw", uri=True, timeout=5)
        db.row_factory = sqlite3.Row
        try:
            db.execute("PRAGMA foreign_keys=ON")
            db.execute("BEGIN IMMEDIATE")
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    def _audit(self, db, actor, action, outcome):
        cur = db.execute(
            "INSERT INTO transport_audit(actor_hash,action,outcome,created_at) VALUES(?,?,?,?)",
            (
                digest(actor) if actor else None,
                action if action in ACTIONS else "unknown",
                outcome if outcome in OUTCOMES else "DENIED",
                int(self.clock()),
            ),
        )
        return str(cur.lastrowid)

    def append(self, *, actor_id, action, outcome):
        with self.transaction() as db:
            return self._audit(db, actor_id, action, outcome)

    def subscribe(self, *, owner, case_id, callback, secret_ref, expires):
        identifier = digest([owner, case_id, callback])
        with self.transaction() as db:
            count = db.execute(
                "SELECT count(*) FROM transport_subscriptions WHERE owner=? AND case_id=? AND id!=? AND active=1 AND expires>?",
                (owner, case_id, identifier, int(self.clock())),
            ).fetchone()[0]
            if count >= 20:
                raise BatisenalError("SUBSCRIPTION_LIMIT", 429)
            db.execute(
                """INSERT INTO transport_subscriptions
                (id,owner,case_id,callback,secret_ref,expires,active,generation)
                VALUES(?,?,?,?,?,?,1,1)
                ON CONFLICT(id) DO UPDATE SET secret_ref=excluded.secret_ref,
                expires=excluded.expires,active=1,generation=generation+1""",
                (identifier, owner, case_id, callback, secret_ref, expires),
            )
            self._audit(db, owner, "events/subscribe", "SUBSCRIBED")
        return identifier

    def unsubscribe(self, *, owner, case_id, callback):
        identifier = digest([owner, case_id, callback])
        with self.transaction() as db:
            db.execute(
                "UPDATE transport_subscriptions SET active=0,generation=generation+1 WHERE id=? AND owner=?",
                (identifier, owner),
            )
            self._audit(db, owner, "events/unsubscribe", "UNSUBSCRIBED")

    def enqueue(self, *, owner, case_id, version):
        """Bounded explicit reconciliation of a committed case, not a startup job."""
        with self.transaction() as db:
            rows = db.execute(
                """SELECT id FROM transport_subscriptions
                WHERE owner=? AND case_id=? AND active=1 AND expires>?""",
                (owner, case_id, int(self.clock())),
            ).fetchall()
            if len(rows) > 20:
                raise ValueError("SUBSCRIPTION_LIMIT")
            for row in rows:
                event_id = digest([row["id"], version])
                db.execute(
                    """INSERT INTO transport_deliveries
                    (id,subscription,version,created_at,state) VALUES(?,?,?,?, 'pending')
                    ON CONFLICT(subscription,version) DO NOTHING""",
                    (event_id, row["id"], version, int(self.clock())),
                )
            self._audit(db, owner, "enqueue", "ENQUEUED")
            return len(rows)

    def pending(self, owner):
        with self.transaction() as db:
            return [
                dict(row)
                for row in db.execute(
                    """SELECT d.id,d.version,d.created_at,
                s.id AS subscription_id,s.case_id FROM transport_deliveries d
                JOIN transport_subscriptions s ON s.id=d.subscription
                WHERE s.owner=? AND s.active=1 AND s.expires>? AND d.state='pending'
                ORDER BY d.created_at,d.id LIMIT 20""",
                    (owner, int(self.clock())),
                )
            ]
