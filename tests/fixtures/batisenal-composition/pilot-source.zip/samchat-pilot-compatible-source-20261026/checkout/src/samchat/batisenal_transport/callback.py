"""Pinned HTTPS + Standard Webhooks candidate. Outbound networking defaults off."""

import asyncio
import base64
import hashlib
import hmac
import ipaddress
import json
import re
import secrets
import socket
import ssl
import time
from urllib.parse import urlsplit

from devnous.gastos.services.batisenal_service import BatisenalError

from .events import callback_url

MAX_BODY = 256 * 1024


def signing_key(secret):
    try:
        if (
            not isinstance(secret, str)
            or not secret.startswith("whsec_")
            or len(secret) > 100
        ):
            raise ValueError()
        key = base64.b64decode(secret[6:], validate=True)
        if not 24 <= len(key) <= 64:
            raise ValueError()
        return key
    except (ValueError, TypeError) as exc:
        raise BatisenalError("SIGNING_SECRET_INVALID") from exc


def signed_headers(body, event_id, subscription_id, timestamp, keys):
    if (
        not isinstance(body, bytes)
        or len(body) > MAX_BODY
        or type(timestamp) is not int
        or timestamp < 0
        or not 1 <= len(keys) <= 2
    ):
        raise BatisenalError("SIGNING_INPUT_INVALID")
    if any(
        not isinstance(x, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", x)
        for x in (event_id, subscription_id)
    ):
        raise BatisenalError("SIGNING_INPUT_INVALID")
    message = f"{event_id}.{timestamp}.".encode() + body
    signatures = [
        "v1,"
        + base64.b64encode(
            hmac.new(signing_key(key), message, hashlib.sha256).digest()
        ).decode()
        for key in keys
    ]
    return {
        "Content-Type": "application/json",
        "webhook-id": event_id,
        "webhook-timestamp": str(timestamp),
        "webhook-signature": " ".join(signatures),
        "X-MCP-Subscription-Id": subscription_id,
    }


async def resolve_public(host):
    records = await asyncio.get_running_loop().getaddrinfo(
        host, 443, type=socket.SOCK_STREAM
    )
    return list(dict.fromkeys(r[4][0] for r in records))


def public_addresses(addresses):
    if not isinstance(addresses, (list, tuple)) or not 1 <= len(addresses) <= 32:
        raise BatisenalError("CALLBACK_ADDRESS_DENIED")
    for address in addresses:
        try:
            ip = ipaddress.ip_address(address)
        except ValueError as exc:
            raise BatisenalError("CALLBACK_ADDRESS_DENIED") from exc
        if not ip.is_global or ip.is_multicast or ip.is_reserved:
            raise BatisenalError("CALLBACK_ADDRESS_DENIED")
    return addresses


async def exchange_https(host, address, path, body, headers, *, before_write=None):
    """Numeric IP pinned after validation; TLS SNI/certificate use original host.

    Bounded HTTP/1.0 connection-close response. Chunked responses are rejected,
    not decoded permissively. No proxy env, redirect handler, auth or cookies.
    """
    reader, writer = await asyncio.open_connection(
        address,
        443,
        ssl=ssl.create_default_context(),
        server_hostname=host,
        family=socket.AF_INET6 if ":" in address else socket.AF_INET,
        limit=16384,
    )
    try:
        fixed = {
            "Host": host,
            "Connection": "close",
            "Content-Length": str(len(body)),
            **headers,
        }
        if any("\r" in k + v or "\n" in k + v for k, v in fixed.items()):
            raise BatisenalError("HEADER_INVALID")
        wire = (
            f"POST {path} HTTP/1.0\r\n"
            + "".join(f"{k}: {v}\r\n" for k, v in fixed.items())
            + "\r\n"
        )
        if before_write is not None:
            await before_write()
        writer.write(wire.encode("ascii") + body)
        await writer.drain()
        raw = await reader.readuntil(b"\r\n\r\n")
        lines = raw.decode("iso-8859-1").split("\r\n")
        status_parts = lines[0].split(" ")
        if len(status_parts) < 2 or status_parts[0] not in {"HTTP/1.0", "HTTP/1.1"}:
            raise BatisenalError("CALLBACK_RESPONSE_INVALID")
        status = int(status_parts[1])
        response_headers = {}
        for line in lines[1:]:
            if not line:
                continue
            name, value = line.split(":", 1)
            name = name.lower()
            if name in response_headers:
                raise BatisenalError("CALLBACK_RESPONSE_INVALID")
            response_headers[name] = value.strip()
        if "transfer-encoding" in response_headers:
            raise BatisenalError("CALLBACK_RESPONSE_INVALID")
        size = response_headers.get("content-length")
        if size is not None:
            if not size.isdigit() or int(size) > 4096:
                raise BatisenalError("CALLBACK_RESPONSE_LIMIT")
            response_body = await reader.readexactly(int(size))
        else:
            buffer = bytearray()
            while True:
                chunk = await reader.read(min(1024, 4097 - len(buffer)))
                buffer.extend(chunk)
                if len(buffer) > 4096:
                    raise BatisenalError("CALLBACK_RESPONSE_LIMIT")
                if not chunk:
                    break
            response_body = bytes(buffer)
        return status, response_body
    finally:
        writer.close()
        # Closing must not extend the outer timeout with another unbounded wait.


class PinnedHTTPS:
    def __init__(
        self,
        *,
        allowed_hosts=(),
        enabled=False,
        resolver=resolve_public,
        exchange=exchange_https,
        timeout=10,
    ):
        if not 0 < timeout <= 10:
            raise ValueError("TIMEOUT_INVALID")
        self.allowed_hosts, self.enabled = frozenset(allowed_hosts), enabled
        self.resolver, self.exchange, self.timeout = resolver, exchange, timeout

    async def post(self, url, body, headers, *, before_connect=None):
        if self.enabled is not True:
            raise BatisenalError("OUTBOUND_ACTIVATION_REQUIRED", 503)
        callback_url(url, self.allowed_hosts)
        if not isinstance(body, bytes) or len(body) > MAX_BODY:
            raise BatisenalError("EVENT_SIZE_INVALID", 413)
        parsed = urlsplit(url)
        path = parsed.path or "/"
        if parsed.query:
            path += "?" + parsed.query
        # Avoid an alternate request target or header injection.
        if not path.startswith("/") or any(ord(c) < 33 or ord(c) > 126 for c in path):
            raise BatisenalError("CALLBACK_INVALID")

        async def request():
            addresses = public_addresses(await self.resolver(parsed.hostname))
            if before_connect is not None:
                await before_connect()
            return await self.exchange(
                parsed.hostname,
                addresses[0],
                path,
                body,
                headers,
                before_write=before_connect,
            )

        try:
            return await asyncio.wait_for(request(), timeout=self.timeout)
        except asyncio.TimeoutError as exc:
            raise BatisenalError("CALLBACK_TIMEOUT", 503) from exc
        except BatisenalError:
            raise
        except Exception as exc:
            raise BatisenalError("CALLBACK_UNAVAILABLE", 503) from exc


class CallbackVerifier:
    """Single-use challenge per call; no application data or reusable auth key."""

    def __init__(
        self, client, *, clock=time.time, nonce=lambda: secrets.token_urlsafe(32)
    ):
        self.client, self.clock, self.nonce = client, clock, nonce

    async def verify(self, url, secret, *, subscription_id):
        challenge = self.nonce()
        if not isinstance(challenge, str) or not re.fullmatch(
            r"[A-Za-z0-9_-]{32,128}", challenge
        ):
            raise BatisenalError("CHALLENGE_INVALID")
        body = json.dumps(
            {"type": "verification", "challenge": challenge}, separators=(",", ":")
        ).encode()
        identifier = "verify_" + hashlib.sha256(challenge.encode()).hexdigest()
        headers = signed_headers(
            body, identifier, subscription_id, int(self.clock()), [secret]
        )
        status, response = await self.client.post(url, body, headers)
        if not 200 <= status < 300:
            return False
        try:
            data = json.loads(response)
            echoed = data["challenge"]
            return (
                isinstance(echoed, str)
                and len(echoed) <= 128
                and hmac.compare_digest(echoed.encode(), challenge.encode())
            )
        except (ValueError, KeyError, TypeError):
            return False
