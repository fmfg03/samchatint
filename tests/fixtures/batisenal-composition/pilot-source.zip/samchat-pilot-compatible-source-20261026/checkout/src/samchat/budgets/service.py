from __future__ import annotations

import csv
import json
import uuid
from functools import lru_cache
from collections import defaultdict
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from io import BytesIO, StringIO
from pathlib import Path
from typing import Any, Optional
import re
import unicodedata

from openpyxl import Workbook, load_workbook
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from devnous.gastos.services.amex_accounting_identity_service import accounting_expense_sql

from samchat.budgets.deduplication import (
    budget_concept_semantic_identity,
    is_valid_budget_concept_identifier,
    normalize_budget_identity_value,
)

_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_BUDGET_ARTIFACT = (
    _ROOT / "Conta2025" / "reportes_2025" / "borrador_presupuesto_2026.csv"
)
DEFAULT_BUDGET_CONCEPT_CATALOG = _ROOT / "docs" / "Catálogo de Torneos.xlsx"
DEMO_BUDGET_SOURCE = "demo_operaciones_analytics"
_BUDGET_STATUS_ORDER = {
    "frozen": 1,
    "approved": 2,
    "submitted": 3,
    "reforecast": 4,
    "draft": 5,
    "closed": 6,
}
_BUDGET_ALLOWED_TRANSITIONS = {
    "draft": {"submitted", "closed"},
    "submitted": {"draft", "approved", "closed"},
    "approved": {"frozen", "reforecast", "closed"},
    "frozen": {"reforecast", "closed"},
    "reforecast": {"submitted", "approved", "frozen", "closed"},
    "closed": set(),
}
_BUDGET_LINE_DIRECTION_DEFAULT = "expense"
DEFAULT_BUDGET_CONCEPT_PASIVO_ACCOUNT_CODE = "2120-002-099"
_BUDGET_LINE_DIRECTIONS = {"expense", "income"}
_BUDGET_LINE_DIRECTION_ALIASES = {
    "expense": "expense",
    "expenses": "expense",
    "gasto": "expense",
    "gastos": "expense",
    "income": "income",
    "ingreso": "income",
    "ingresos": "income",
}
_BUDGET_ALIAS_RULES: tuple[tuple[str, tuple[str, ...]], ...] = (
    (
        "LTTB",
        (
            "liga telmex telcel de beisbol",
            "liga telmex telcel",
            "beisbol",
            "béisbol",
            "lttb",
        ),
    ),
    ("DCC", ("de la calle a la cancha", "calle a la cancha", "dcc")),
    ("BIMBO", ("futbolito bimbo", "bimbo")),
    ("LA MERCED", ("la merced",)),
    ("CCA", ("copa club america", "club america", "club américa", "cca")),
    ("CTTVC", ("viaje de campeones", "cttvc")),
    ("CTT", ("copa telmex telcel", "copa telmex", "ctt")),
)


def _safe_str(value: Any) -> str:
    return str(value or "").strip()


def _safe_decimal(value: Any) -> float:
    if value is None or value == "":
        return 0.0
    if isinstance(value, Decimal):
        return float(value)
    return float(str(value).replace(",", "").strip())


def _normalize_text(value: Any) -> str:
    return _safe_str(value).lower()


def _normalize_budget_key(value: Any) -> str:
    raw = _safe_str(value)
    if not raw:
        return ""
    ascii_text = unicodedata.normalize("NFKD", raw)
    ascii_text = "".join(ch for ch in ascii_text if not unicodedata.combining(ch))
    ascii_text = re.sub(r"[^a-zA-Z0-9]+", " ", ascii_text).strip().lower()
    return re.sub(r"\s+", "_", ascii_text)


def _normalize_budget_scope_key(value: Any) -> str:
    normalized = _normalize_budget_key(value)
    if normalized.startswith("fase_"):
        normalized = normalized[len("fase_") :]
    return normalized


def _budget_scope_aliases(*values: Any) -> set[str]:
    aliases: set[str] = set()
    for value in values:
        normalized = _normalize_budget_scope_key(value)
        if not normalized:
            continue
        aliases.add(normalized)
        aliases.add(f"fase_{normalized}")
    return aliases


def _is_budget_phase_break_label(label: Any, trailing_values: list[Any]) -> bool:
    raw = _safe_str(label)
    if not raw or any(_safe_str(value) for value in trailing_values):
        return False
    compact = "".join(ch for ch in raw if ch.isalpha() or ch.isspace()).strip()
    if not compact or compact != compact.upper():
        return False
    normalized = _normalize_budget_scope_key(raw)
    return raw.startswith("FASE ") or normalized in {"viaje_de_campeones", "no_aplica"}


def _active_budget_label(value: Optional[str]) -> str:
    return _safe_str(value) or "Sin partida asignada"


def _normalize_budget_status(value: Optional[str]) -> str:
    normalized = _safe_str(value).lower()
    return normalized or "draft"


def normalize_budget_line_direction(
    value: Optional[str],
    *,
    default: str = _BUDGET_LINE_DIRECTION_DEFAULT,
) -> str:
    normalized = _BUDGET_LINE_DIRECTION_ALIASES.get(_safe_str(value).lower(), "")
    if normalized in _BUDGET_LINE_DIRECTIONS:
        return normalized
    return default


def _editable_version_status(status: Optional[str]) -> bool:
    return _normalize_budget_status(status) in {"draft", "reforecast"}


def _edition_bounds(edition_year: int) -> tuple[date, date]:
    return date(edition_year, 1, 1), date(edition_year, 12, 31)


def _build_budget_forecast(
    *,
    edition_year: int,
    budget_total: float,
    comparison: dict[str, Any],
) -> dict[str, Any]:
    today = date.today()
    period_start = date(edition_year, 1, 1)
    period_end = date(edition_year, 12, 31)
    effective_today = min(max(today, period_start), period_end)
    elapsed_days = max(1, (effective_today - period_start).days + 1)
    total_days = max(1, (period_end - period_start).days + 1)
    remaining_days = max(0, total_days - elapsed_days)

    actual_total = float(comparison.get("actual_total") or 0)
    committed_total = float(comparison.get("committed_total") or 0)
    paid_total = float(comparison.get("paid_total") or 0)
    pending_to_pay_total = float(comparison.get("pending_to_pay_total") or 0)
    run_rate_daily = actual_total / elapsed_days
    projected_actual_close = round(run_rate_daily * total_days, 2)
    projected_close_total = round(
        max(projected_actual_close, actual_total + pending_to_pay_total),
        2,
    )
    remaining_budget = round(budget_total - max(actual_total, committed_total), 2)
    projected_variance = round(budget_total - projected_close_total, 2)
    projected_cash_need = round(max(projected_close_total - paid_total, 0), 2)
    health = _budget_health_for_close(
        budget_total=budget_total,
        projected_close_total=projected_close_total,
    )

    return {
        "edition_year": edition_year,
        "as_of_date": effective_today.isoformat(),
        "elapsed_days": elapsed_days,
        "remaining_days": remaining_days,
        "total_days": total_days,
        "run_rate_daily": round(run_rate_daily, 2),
        "projected_actual_close": projected_actual_close,
        "projected_close_total": projected_close_total,
        "projected_variance": projected_variance,
        "projected_cash_need": projected_cash_need,
        "remaining_budget": remaining_budget,
        "health": health,
    }


async def require_ungoverned_gastos_project(session: AsyncSession, tournament_id: str) -> None:
    from devnous.gastos.services.tournament_authority_service import (
        require_ungoverned_gastos_project as _require_ungoverned_gastos_project,
    )

    await _require_ungoverned_gastos_project(session, tournament_id)


def _budget_health_for_close(
    *, budget_total: float, projected_close_total: float
) -> str:
    health = "healthy"
    if projected_close_total > budget_total:
        health = "over_budget"
    elif projected_close_total > (budget_total * 0.92):
        health = "at_risk"
    return health


def _build_budget_scenarios(
    *,
    edition_year: int,
    budget_total: float,
    comparison: dict[str, Any],
    forecast: dict[str, Any],
) -> dict[str, Any]:
    actual_total = float(comparison.get("actual_total") or 0)
    paid_total = float(comparison.get("paid_total") or 0)
    pending_to_pay_total = float(comparison.get("pending_to_pay_total") or 0)
    projected_actual_close = float(forecast.get("projected_actual_close") or 0)
    base_close_total = float(forecast.get("projected_close_total") or 0)
    base_run_rate = float(forecast.get("run_rate_daily") or 0)
    remaining_days = int(forecast.get("remaining_days") or 0)
    scenario_specs = {
        "optimistic": {
            "label": "Optimista",
            "run_rate_factor": 0.94,
            "pending_factor": 0.82,
            "assumption": "Menor ritmo de gasto y mejor contención de compromisos abiertos.",
        },
        "base": {
            "label": "Base",
            "run_rate_factor": 1.0,
            "pending_factor": 1.0,
            "assumption": "Continuidad del ritmo actual y cumplimiento normal de compromisos ya abiertos.",
        },
        "stressed": {
            "label": "Estresado",
            "run_rate_factor": 1.12,
            "pending_factor": 1.18,
            "assumption": "Mayor presión de gasto y materialización más alta de compromisos pendientes.",
        },
    }
    scenarios: dict[str, Any] = {}
    for key, spec in scenario_specs.items():
        projected_close_total = round(
            max(
                actual_total + (pending_to_pay_total * float(spec["pending_factor"])),
                projected_actual_close * float(spec["run_rate_factor"]),
            ),
            2,
        )
        if key == "base":
            projected_close_total = round(base_close_total, 2)
        projected_variance = round(budget_total - projected_close_total, 2)
        projected_cash_need = round(max(projected_close_total - paid_total, 0), 2)
        scenarios[key] = {
            "scenario_key": key,
            "label": spec["label"],
            "edition_year": edition_year,
            "remaining_days": remaining_days,
            "adjustment_vs_base_pct": round(
                (
                    (
                        (projected_close_total - base_close_total)
                        / base_close_total
                        * 100
                    )
                    if base_close_total
                    else 0
                ),
                2,
            ),
            "run_rate_daily": round(base_run_rate * float(spec["run_rate_factor"]), 2),
            "projected_close_total": projected_close_total,
            "projected_variance": projected_variance,
            "projected_cash_need": projected_cash_need,
            "remaining_budget": round(
                budget_total
                - max(
                    actual_total,
                    projected_close_total,
                ),
                2,
            ),
            "health": _budget_health_for_close(
                budget_total=budget_total,
                projected_close_total=projected_close_total,
            ),
            "assumption": spec["assumption"],
        }
    return scenarios


def build_budget_executive_alerts(
    summary: dict[str, Any],
    forecast: dict[str, Any],
    scenarios: dict[str, Any],
) -> list[dict[str, str]]:
    alerts: list[dict[str, str]] = []

    forecast_health = _safe_str(forecast.get("health")).lower()
    forecast_health_counts = summary.get("forecast_health_counts") or {}
    over_budget_count = int(forecast_health_counts.get("over_budget") or 0)
    at_risk_count = int(forecast_health_counts.get("at_risk") or 0)
    overdue_open_total = float(summary.get("overdue_open_total") or 0)
    due_next_30_total = float(summary.get("due_next_30_total") or 0)
    pending_to_pay_total = float(summary.get("pending_to_pay_total") or 0)
    stressed_close_total = float(
        ((scenarios.get("stressed") or {}).get("projected_close_total")) or 0
    )
    budget_total = float(summary.get("budget_total") or 0)

    if forecast_health == "over_budget" or over_budget_count > 0:
        alerts.append(
            {
                "severity": "critical",
                "title": "Forecast por encima del presupuesto",
                "detail": (
                    f"{over_budget_count} torneo(s) over budget en el snapshot actual."
                    if over_budget_count
                    else "La proyección consolidada rebasa el presupuesto."
                ),
                "playbook": "Congelar gasto discrecional, reasignar bolsa y validar recorte inmediato.",
            }
        )
    elif forecast_health == "at_risk" or at_risk_count > 0:
        alerts.append(
            {
                "severity": "warning",
                "title": "Forecast en zona de riesgo",
                "detail": (
                    f"{at_risk_count} torneo(s) cerca del techo presupuestal."
                    if at_risk_count
                    else "La proyección consolidada está cerca del techo."
                ),
                "playbook": "Revisar concentración por concepto y exigir plan de contención quincenal.",
            }
        )

    if overdue_open_total > 0:
        alerts.append(
            {
                "severity": "warning",
                "title": "Pendientes vencidos abiertos",
                "detail": f"Hay ${overdue_open_total:,.2f} vencidos sin resolver.",
                "playbook": "Depurar vencidos y escalar responsables antes del siguiente corte.",
            }
        )

    if due_next_30_total > 0 or pending_to_pay_total > 0:
        alerts.append(
            {
                "severity": "info" if due_next_30_total <= 0 else "warning",
                "title": "Salida de caja próxima",
                "detail": (
                    f"${due_next_30_total:,.2f} vence en 30 días; "
                    f"${pending_to_pay_total:,.2f} sigue pendiente por pagar."
                ),
                "playbook": "Calendarizar caja, priorizar pagos críticos y anticipar faltantes.",
            }
        )

    if budget_total > 0 and stressed_close_total > budget_total:
        alerts.append(
            {
                "severity": "warning",
                "title": "Escenario estresado rebasa el techo",
                "detail": (
                    f"El escenario estresado cerraría en ${stressed_close_total:,.2f} "
                    f"vs ${budget_total:,.2f} presupuestados."
                ),
                "playbook": "Definir contingencia y recortes activables si el escenario estresado materializa.",
            }
        )

    return alerts


def build_budget_executive_comparison(
    summary: dict[str, Any],
    forecast: dict[str, Any],
) -> list[dict[str, Any]]:
    budget_total = float(summary.get("budget_total") or 0)
    requested_total = float(summary.get("requested_total") or 0)
    committed_total = float(summary.get("committed_total") or 0)
    paid_total = float(summary.get("paid_total") or 0)
    actual_total = float(summary.get("actual_total") or 0)
    pending_to_pay_total = float(summary.get("pending_to_pay_total") or 0)
    projected_close_total = float(forecast.get("projected_close_total") or 0)

    def _pct(value: float) -> float:
        if budget_total <= 0:
            return 0.0
        return round((value / budget_total) * 100, 2)

    metrics = [
        (
            "Presupuesto",
            budget_total,
            None,
            "Base aprobada del snapshot activo.",
        ),
        (
            "Solicitado",
            requested_total,
            round(budget_total - requested_total, 2),
            "Monto ya solicitado contra la bolsa total.",
        ),
        (
            "Comprometido",
            committed_total,
            round(budget_total - committed_total, 2),
            "Compromisos abiertos y documentos ya amarrados.",
        ),
        (
            "Pagado",
            paid_total,
            round(budget_total - paid_total, 2),
            "Salida de caja ya ejecutada.",
        ),
        (
            "Real",
            actual_total,
            round(budget_total - actual_total, 2),
            "Gasto observado al corte actual.",
        ),
        (
            "Pendiente por pagar",
            pending_to_pay_total,
            round(budget_total - pending_to_pay_total, 2),
            "Compromiso reconocido que todavía no sale de caja.",
        ),
        (
            "Cierre proyectado",
            projected_close_total,
            round(budget_total - projected_close_total, 2),
            "Proyección de cierre usando run rate y pendientes.",
        ),
    ]

    rows: list[dict[str, Any]] = []
    for label, total, variance_to_budget, detail in metrics:
        row = {
            "label": label,
            "total": round(total, 2),
            "pct_of_budget": _pct(total),
            "detail": detail,
        }
        if variance_to_budget is not None:
            row["variance_to_budget"] = round(variance_to_budget, 2)
        rows.append(row)
    return rows


def build_budget_scenario_player(
    summary: dict[str, Any],
    forecast: dict[str, Any],
    *,
    run_rate_delta_pct: Any = 0,
    discretionary_cut_pct: Any = 0,
    added_commitments: Any = 0,
    cash_acceleration: Any = 0,
) -> dict[str, Any]:
    """Calculate a non-persistent what-if scenario over the active snapshot."""

    budget_total = _safe_decimal(summary.get("budget_total"))
    paid_total = _safe_decimal(summary.get("paid_total"))
    base_close_total = _safe_decimal(forecast.get("projected_close_total"))
    if base_close_total <= 0:
        base_close_total = max(
            _safe_decimal(summary.get("actual_total")),
            _safe_decimal(summary.get("committed_total")),
            _safe_decimal(summary.get("requested_total")),
        )

    run_rate_pct = _safe_decimal(run_rate_delta_pct)
    cut_pct = max(0.0, _safe_decimal(discretionary_cut_pct))
    added = _safe_decimal(added_commitments)
    accelerated_cash = max(0.0, _safe_decimal(cash_acceleration))

    run_rate_impact = round(base_close_total * (run_rate_pct / 100), 2)
    cut_impact = round(budget_total * (cut_pct / 100), 2)
    projected_close_total = round(
        base_close_total + run_rate_impact - cut_impact + added, 2
    )
    projected_variance = round(budget_total - projected_close_total, 2)
    projected_cash_need = round(
        max(projected_close_total - paid_total - accelerated_cash, 0), 2
    )
    health = _budget_health_for_close(
        budget_total=budget_total,
        projected_close_total=projected_close_total,
    )

    if health == "over_budget":
        recommendation = (
            "Requiere recorte, reasignación o aprobación explícita de excedente."
        )
    elif health == "at_risk":
        recommendation = (
            "Mantener vigilancia semanal y bloquear gasto discrecional no crítico."
        )
    else:
        recommendation = (
            "Escenario dentro de rango; documentar supuestos y monitorear ejecución."
        )

    return {
        "label": "Scenario player",
        "budget_total": round(budget_total, 2),
        "base_close_total": round(base_close_total, 2),
        "run_rate_delta_pct": round(run_rate_pct, 2),
        "run_rate_impact": run_rate_impact,
        "discretionary_cut_pct": round(cut_pct, 2),
        "cut_impact": cut_impact,
        "added_commitments": round(added, 2),
        "cash_acceleration": round(accelerated_cash, 2),
        "projected_close_total": projected_close_total,
        "projected_variance": projected_variance,
        "projected_cash_need": projected_cash_need,
        "health": health,
        "recommendation": recommendation,
        "read_only": True,
    }


def _new_breakdown_store() -> dict[str, dict[str, Any]]:
    return {}


def _merge_breakdown_row(
    store: dict[str, dict[str, Any]],
    *,
    label: Any,
    concept_id: str | None = None,
    budget_total: float = 0.0,
    reference_total: float = 0.0,
    variance_total: float = 0.0,
    requested_total: float = 0.0,
    committed_total: float = 0.0,
    paid_total: float = 0.0,
    actual_total: float = 0.0,
    pending_to_pay_total: float = 0.0,
    line_count: int = 0,
    document_count: int = 0,
    expense_count: int = 0,
) -> None:
    display_label = _safe_str(label) or "Sin dato"
    bucket = f"concept:{concept_id}" if concept_id is not None else display_label
    entry = store.setdefault(
        bucket,
        {
            "label": display_label,
            **({"concept_id": concept_id} if concept_id is not None else {}),
            "budget_total": 0.0,
            "reference_total": 0.0,
            "variance_total": 0.0,
            "requested_total": 0.0,
            "committed_total": 0.0,
            "paid_total": 0.0,
            "actual_total": 0.0,
            "pending_to_pay_total": 0.0,
            "line_count": 0,
            "document_count": 0,
            "expense_count": 0,
        },
    )
    if concept_id is not None:
        entry["label"] = display_label
    entry["budget_total"] += float(budget_total or 0)
    entry["reference_total"] += float(reference_total or 0)
    entry["variance_total"] += float(variance_total or 0)
    entry["requested_total"] += float(requested_total or 0)
    entry["committed_total"] += float(committed_total or 0)
    entry["paid_total"] += float(paid_total or 0)
    entry["actual_total"] += float(actual_total or 0)
    entry["pending_to_pay_total"] += float(pending_to_pay_total or 0)
    entry["line_count"] += int(line_count or 0)
    entry["document_count"] += int(document_count or 0)
    entry["expense_count"] += int(expense_count or 0)


def _finalize_breakdown_store(
    store: dict[str, dict[str, Any]],
    *,
    limit: int | None = 6,
) -> list[dict[str, Any]]:
    rows = []
    for entry in store.values():
        rows.append(
            {
                "label": _safe_str(entry.get("label")) or "Sin dato",
                **(
                    {"concept_id": entry["concept_id"]} if "concept_id" in entry else {}
                ),
                "budget_total": round(float(entry.get("budget_total") or 0), 2),
                "reference_total": round(float(entry.get("reference_total") or 0), 2),
                "variance_total": round(float(entry.get("variance_total") or 0), 2),
                "requested_total": round(float(entry.get("requested_total") or 0), 2),
                "committed_total": round(float(entry.get("committed_total") or 0), 2),
                "paid_total": round(float(entry.get("paid_total") or 0), 2),
                "actual_total": round(float(entry.get("actual_total") or 0), 2),
                "pending_to_pay_total": round(
                    float(entry.get("pending_to_pay_total") or 0), 2
                ),
                "line_count": int(entry.get("line_count") or 0),
                "document_count": int(entry.get("document_count") or 0),
                "expense_count": int(entry.get("expense_count") or 0),
            }
        )
    rows.sort(
        key=lambda item: (
            -max(
                float(item.get("budget_total") or 0),
                float(item.get("actual_total") or 0),
                float(item.get("committed_total") or 0),
                float(item.get("requested_total") or 0),
                float(item.get("paid_total") or 0),
                float(item.get("reference_total") or 0),
            ),
            item["label"],
        )
    )
    return rows if limit is None else rows[: max(1, limit)]


def _build_budget_line_breakdowns(
    rows: list[dict[str, Any]],
    *,
    concept_limit: int | None = 6,
    concept_identity: bool = False,
) -> dict[str, list[dict[str, Any]]]:
    by_concept = _new_breakdown_store()
    by_phase = _new_breakdown_store()
    by_entity = _new_breakdown_store()
    by_owner = _new_breakdown_store()
    by_account = _new_breakdown_store()
    for row in rows:
        budget_total = _safe_decimal(row.get("budget_amount"))
        reference_total = _safe_decimal(row.get("reference_amount"))
        variance_total = _safe_decimal(row.get("variance_amount"))
        _merge_breakdown_row(
            by_concept,
            label=(
                (row.get("current_concept_name") or row.get("concept_name"))
                if concept_identity
                else row.get("concept_name")
            ),
            concept_id=(
                (_safe_str(row.get("budget_concept_id")) or "__unassigned__")
                if concept_identity
                else None
            ),
            budget_total=budget_total,
            reference_total=reference_total,
            variance_total=variance_total,
            line_count=1,
        )
        _merge_breakdown_row(
            by_phase,
            label=row.get("phase") or "Sin fase",
            budget_total=budget_total,
            reference_total=reference_total,
            variance_total=variance_total,
            line_count=1,
        )
        _merge_breakdown_row(
            by_entity,
            label=row.get("entity_name") or "Sin entidad",
            budget_total=budget_total,
            reference_total=reference_total,
            variance_total=variance_total,
            line_count=1,
        )
        _merge_breakdown_row(
            by_owner,
            label=row.get("owner_name") or "Sin responsable",
            budget_total=budget_total,
            reference_total=reference_total,
            variance_total=variance_total,
            line_count=1,
        )
        _merge_breakdown_row(
            by_account,
            label=row.get("account_code_final")
            or row.get("account_code_suggested")
            or "Sin cuenta final",
            budget_total=budget_total,
            reference_total=reference_total,
            variance_total=variance_total,
            line_count=1,
        )
    return {
        "by_concept": _finalize_breakdown_store(by_concept, limit=concept_limit),
        "by_phase": _finalize_breakdown_store(by_phase),
        "by_entity": _finalize_breakdown_store(by_entity),
        "by_owner": _finalize_breakdown_store(by_owner),
        "by_account": _finalize_breakdown_store(by_account),
    }


def _build_artifact_breakdowns(
    rows: list[dict[str, Any]],
) -> dict[str, list[dict[str, Any]]]:
    normalized_rows = [
        {
            "concept_name": row.get("concepto"),
            "phase": row.get("etapa"),
            "entity_name": row.get("entidad") or row.get("entity_name"),
            "owner_name": row.get("responsable"),
            "account_code_final": row.get("cuenta_contable_final"),
            "account_code_suggested": row.get("cuenta_contable_sugerida"),
            "budget_amount": row.get("presupuesto_2026"),
            "reference_amount": row.get("importe_referencia_total"),
            "variance_amount": _safe_decimal(row.get("presupuesto_2026"))
            - _safe_decimal(row.get("importe_referencia_total")),
        }
        for row in rows
    ]
    breakdowns = _build_budget_line_breakdowns(normalized_rows)
    breakdowns["by_provider"] = []
    return breakdowns


def _build_budget_scope_filters(
    *,
    edition_year: int,
    tournament_id: Optional[str],
    tournament_name: Optional[str],
    tournament_code: Optional[str],
    document_tournament_id_sql: str = "d.torneo_id",
    expense_tournament_id_sql: str = "d.torneo_id",
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
) -> tuple[list[str], list[str], dict[str, Any]]:
    tournament_scope_requested = bool(
        _safe_str(tournament_name) or _safe_str(tournament_code)
    )
    aliases = budget_alias_candidates(
        _safe_str(tournament_name),
        _safe_str(tournament_code),
    )
    edition_from, edition_to = _edition_bounds(edition_year)
    date_from, date_to = date_from or edition_from, date_to or edition_to
    if not edition_from <= date_from <= date_to <= edition_to:
        raise ValueError("Budget period must stay within the selected edition")
    document_filter = [
        "d.tipo = 'SOLICITUD'",
        "COALESCE(d.concepto_pago, '') NOT ILIKE 'Reembolso de saldo a favor%'",
        "DATE(d.creado_en) >= :date_from",
        "DATE(d.creado_en) <= :date_to",
    ]
    expense_filter = [
        "e.estado_gasto != 'cancelado'",
        accounting_expense_sql("e"),
        "DATE(e.fecha) >= :date_from",
        "DATE(e.fecha) <= :date_to",
    ]
    params: dict[str, Any] = {"date_from": date_from, "date_to": date_to}
    if tournament_id:
        document_filter.append(f"({document_tournament_id_sql} = :tournament_id)")
        expense_filter.append(f"({expense_tournament_id_sql} = :tournament_id)")
        params["tournament_id"] = tournament_id
    elif aliases:
        alias_clauses = []
        expense_alias_clauses = []
        for index, alias in enumerate(sorted(aliases)):
            key = f"alias_{index}"
            params[key] = f"%{alias.lower()}%"
            alias_clauses.append(
                f"(LOWER(COALESCE(t.name, '')) LIKE :{key} OR LOWER(COALESCE(d.notas, '')) LIKE :{key} OR LOWER(COALESCE(d.concepto_pago, '')) LIKE :{key})"
            )
            expense_alias_clauses.append(
                f"(LOWER(COALESCE(t.name, '')) LIKE :{key} OR LOWER(COALESCE(e.proyecto, '')) LIKE :{key} OR LOWER(COALESCE(e.concepto, '')) LIKE :{key})"
            )
        document_filter.append(f"({' OR '.join(alias_clauses)})")
        expense_filter.append(f"({' OR '.join(expense_alias_clauses)})")
    elif tournament_scope_requested:
        document_filter.append("FALSE")
        expense_filter.append("FALSE")
    return document_filter, expense_filter, params


_BUDGET_NON_IMPACT_DOCUMENT_STATES = {"borrador", "control_presupuestal", "rechazado", "cancelado"}
_BUDGET_REQUESTED_DOCUMENT_STATES = {"enviado"}
_BUDGET_COMMITTED_DOCUMENT_STATES = {"aprobado", "en_proceso_pago"}
_BUDGET_EFFECT_TERMINAL_DOCUMENT_STATES = {"pagado", "cerrado", "comprobado", "reembolsado", "aplicado", "liquidado"}


def _budget_decimal_amount(value: Any) -> Decimal:
    try:
        amount = Decimal(str(value if value is not None else 0))
        if not amount.is_finite():
            return Decimal("0")
        return max(amount, Decimal("0"))
    except (InvalidOperation, TypeError, ValueError):
        return Decimal("0")


def _budget_round_amount(value: Decimal) -> Decimal:
    return value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def budget_expense_effect_amount(expense: Any, cfdi_report: Any = None) -> Decimal:
    """Canonical budget base for one active expense line."""
    if str(getattr(expense, "estado_gasto", "") or "").strip().lower() == "cancelado":
        return Decimal("0")
    total = _budget_decimal_amount(getattr(expense, "gasto_cantidad", None))
    if any(
        bool(getattr(a, "activo", False))
        and getattr(a, "categoria", None) == "comprobante_no_deducible"
        for a in (getattr(expense, "adjuntos", None) or [])
    ):
        return _budget_round_amount(total)
    tip = _budget_decimal_amount(getattr(expense, "propina_no_deducible", None))
    lodging = _budget_decimal_amount(getattr(expense, "hospedaje_impuesto_monto", None))
    iva = getattr(expense, "iva", None)
    if iva is not None:
        return _budget_round_amount(
            max(total - _budget_decimal_amount(iva), Decimal("0")) + lodging
        )
    if cfdi_report is not None and getattr(cfdi_report, "subtotal", None) is not None:
        base = max(
            _budget_decimal_amount(getattr(cfdi_report, "subtotal", None))
            - _budget_decimal_amount(getattr(cfdi_report, "descuento", None)),
            Decimal("0"),
        )
        fiscal_total = _budget_decimal_amount(getattr(cfdi_report, "total", None))
        applied = max(total - tip, Decimal("0"))
        if fiscal_total > 0:
            base *= min(applied / fiscal_total, Decimal("1"))
        return _budget_round_amount(base + lodging + tip)
    return _budget_round_amount(total)


def budget_document_effect_snapshot(
    documento: Any, cfdi_report: Any = None, *, expenses: Any = None
) -> dict[str, Any]:
    """State-aware budget effect for document reporting surfaces."""
    state = str(getattr(documento, "estado", "") or "").strip().lower()
    doc_type = str(getattr(documento, "tipo", "") or "").strip().upper()
    expenses = [
        e
        for e in (
            expenses
            if expenses is not None
            else (getattr(documento, "gastos", None) or [])
        )
        if str(getattr(e, "estado_gasto", "") or "").strip().lower() != "cancelado"
    ]
    doc_concept = getattr(documento, "budget_concept_id", None)
    if doc_type == "INFORME":
        assigned = [
            e for e in expenses if getattr(e, "budget_concept_id", None)
        ]
        if expenses:
            assignment = (
                "Sin asignar"
                if not assigned
                else "Asignado"
                if len(assigned) == len(expenses)
                else "Parcial"
            )
        else:
            assignment = "Sin asignar"
    else:
        assigned = []
        assignment = "Asignado" if doc_concept else "Sin asignar"

    allowed = _BUDGET_REQUESTED_DOCUMENT_STATES | _BUDGET_COMMITTED_DOCUMENT_STATES | _BUDGET_EFFECT_TERMINAL_DOCUMENT_STATES
    is_derived_reimbursement = (
        doc_type == "SOLICITUD"
        and str(getattr(documento, "concepto_pago", "") or "")
        .strip()
        .lower()
        .startswith("reembolso de saldo a favor")
    )
    if (
        state in _BUDGET_NON_IMPACT_DOCUMENT_STATES
        or state not in allowed
        or is_derived_reimbursement
        or bool(getattr(documento, "is_supplier_advance", False))
    ):
        return {
            "amount": Decimal("0"),
            "assignment_label": assignment,
            "stage": "No afecta",
            "affects_budget": False,
        }

    if doc_type == "INFORME":
        amount = sum(
            (
                budget_expense_effect_amount(e, getattr(e, "cfdi_report", None))
                for e in assigned
            ),
            Decimal("0"),
        )
    elif doc_concept:
        if cfdi_report is not None and getattr(cfdi_report, "subtotal", None) is not None:
            amount = max(
                _budget_decimal_amount(getattr(cfdi_report, "subtotal", None))
                - _budget_decimal_amount(getattr(cfdi_report, "descuento", None)),
                Decimal("0"),
            )
            fiscal_total = _budget_decimal_amount(
                getattr(cfdi_report, "total", None)
            )
            applied = _budget_decimal_amount(
                getattr(documento, "monto_solicitado", None)
                if getattr(documento, "monto_solicitado", None) is not None
                else getattr(documento, "monto_total", None)
            )
            if getattr(documento, "supplier_advance_id", None):
                applied = _budget_decimal_amount(
                    getattr(documento, "supplier_invoice_total", None)
                )
            if fiscal_total > 0:
                amount *= min(applied / fiscal_total, Decimal("1"))
        else:
            amount = _budget_decimal_amount(
                getattr(documento, "monto_solicitado", None)
                if getattr(documento, "monto_solicitado", None) is not None
                else getattr(documento, "monto_total", None)
            )
    else:
        amount = Decimal("0")

    stage = (
        "Solicitado" if state in _BUDGET_REQUESTED_DOCUMENT_STATES
        else "Comprometido" if state in _BUDGET_COMMITTED_DOCUMENT_STATES
        else "Pagado" if state in {"pagado", "cerrado"} or getattr(documento, "pagado_en", None)
        else "Ejercido"
    )
    amount = _budget_round_amount(amount)
    return {"amount": amount, "assignment_label": assignment, "stage": stage, "affects_budget": amount > 0 and assignment != "Sin asignar"}


def _budget_expense_base_amount_sql(expense_alias: str = "e", cfdi_alias: str = "cfdi") -> str:
    """SQL for canonical budget base of an expense."""
    expense = _safe_str(expense_alias) or "e"
    cfdi = _safe_str(cfdi_alias) or "cfdi"
    return f"""
        ROUND(CAST(GREATEST(
            CASE
                WHEN EXISTS (
                    SELECT 1 FROM adjuntos budget_nd
                    WHERE budget_nd.gasto_id = {expense}.id
                      AND budget_nd.categoria = 'comprobante_no_deducible'
                      AND budget_nd.activo = TRUE
                ) THEN COALESCE({expense}.gasto_cantidad, 0)
                WHEN {expense}.iva IS NOT NULL
                THEN COALESCE({expense}.gasto_cantidad, 0) - COALESCE({expense}.iva, 0)
                   + COALESCE({expense}.hospedaje_impuesto_monto, 0)
                WHEN {cfdi}.subtotal IS NOT NULL THEN (
                    GREATEST(
                        COALESCE({cfdi}.subtotal, 0) - COALESCE({cfdi}.descuento, 0), 0
                    ) * CASE
                        WHEN COALESCE({cfdi}.total, 0) > 0 THEN LEAST(
                            GREATEST(
                                (COALESCE({expense}.gasto_cantidad, 0)
                                 - COALESCE({expense}.propina_no_deducible, 0))
                                / {cfdi}.total, 0
                            ), 1
                        )
                        ELSE 1
                    END
                ) + COALESCE({expense}.hospedaje_impuesto_monto, 0)
                  + COALESCE({expense}.propina_no_deducible, 0)
                ELSE COALESCE({expense}.gasto_cantidad, 0)
            END,
            0
        ) AS NUMERIC), 2)
    """


def _budget_document_base_amount_sql(document_alias: str = "d", cfdi_alias: str = "document_cfdi") -> str:
    """SQL for canonical budget base of an assigned document."""
    document = _safe_str(document_alias) or "d"
    cfdi = _safe_str(cfdi_alias) or "document_cfdi"
    return f"""
        ROUND(CAST(GREATEST(
            CASE
                WHEN {document}.is_supplier_advance THEN 0
                WHEN {cfdi}.subtotal IS NOT NULL THEN (
                    GREATEST(COALESCE({cfdi}.subtotal, 0) - COALESCE({cfdi}.descuento, 0), 0)
                    * CASE
                        WHEN COALESCE({cfdi}.total, 0) > 0
                        THEN LEAST(
                            GREATEST(
                                COALESCE(
                                    {document}.supplier_invoice_total,
                                    {document}.monto_solicitado,
                                    {document}.monto_total,
                                    0
                                ) / {cfdi}.total,
                                0
                            ),
                            1
                        )
                        ELSE 1
                    END
                )
                ELSE COALESCE({document}.supplier_invoice_total, COALESCE({document}.monto_solicitado, {document}.monto_total, 0))
            END, 0
        ) AS NUMERIC), 2)
    """


async def _build_budget_finance_breakdowns(
    session: AsyncSession,
    *,
    edition_year: int,
    tournament_id: Optional[str],
    tournament_name: Optional[str],
    tournament_code: Optional[str],
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
    concept_limit: int | None = 6,
    concept_identity: bool = False,
) -> dict[str, list[dict[str, Any]]]:
    document_filter, expense_filter, params = _build_budget_scope_filters(
        edition_year=edition_year,
        tournament_id=tournament_id,
        tournament_name=tournament_name,
        tournament_code=tournament_code,
        date_from=date_from,
        date_to=date_to,
    )
    by_provider = _new_breakdown_store()
    by_concept = _new_breakdown_store()

    document_provider_rows = (
        (
            await session.execute(
                text(f"""
                SELECT
                    COALESCE(NULLIF(TRIM(pc.nombre), ''), 'Sin proveedor asignado') AS label,
                    COALESCE(SUM(CASE WHEN d.estado IN ('enviado', 'aprobado', 'en_proceso_pago', 'pagado', 'cerrado') THEN {_budget_document_base_amount_sql('d', 'document_cfdi')} ELSE 0 END), 0) AS requested_total,
                    COALESCE(SUM(CASE WHEN d.estado IN ('aprobado', 'en_proceso_pago', 'pagado', 'cerrado') THEN {_budget_document_base_amount_sql('d', 'document_cfdi')} ELSE 0 END), 0) AS committed_total,
                    COALESCE(SUM(CASE WHEN d.estado IN ('pagado', 'cerrado') OR d.pagado_en IS NOT NULL THEN {_budget_document_base_amount_sql('d', 'document_cfdi')} ELSE 0 END), 0) AS paid_total,
                    COUNT(*) FILTER (WHERE d.estado IN ('enviado', 'aprobado', 'en_proceso_pago', 'pagado', 'cerrado')) AS document_count
                FROM documentos d
                LEFT JOIN tournaments t ON t.id = d.torneo_id
                LEFT JOIN cfdi_reports document_cfdi ON document_cfdi.id = d.cfdi_report_id
                LEFT JOIN proveedores_clientes pc ON pc.id = d.proveedor_cliente_id
                WHERE {' AND '.join(document_filter)}
                  AND d.budget_concept_id IS NOT NULL
                GROUP BY 1
                """),
                params,
            )
        )
        .mappings()
        .all()
    )
    for row in document_provider_rows:
        requested_total = _safe_decimal(row.get("requested_total"))
        committed_total = _safe_decimal(row.get("committed_total"))
        paid_total = _safe_decimal(row.get("paid_total"))
        _merge_breakdown_row(
            by_provider,
            label=row.get("label"),
            requested_total=requested_total,
            committed_total=committed_total,
            paid_total=paid_total,
            pending_to_pay_total=max(committed_total - paid_total, 0),
            document_count=int(row.get("document_count") or 0),
        )

    expense_provider_rows = (
        (
            await session.execute(
                text(f"""
                SELECT
                    COALESCE(NULLIF(TRIM(pc.nombre), ''), 'Sin proveedor asignado') AS label,
                    COALESCE(SUM({_budget_expense_base_amount_sql('e', 'cfdi')}), 0) AS actual_total,
                    COUNT(*) AS expense_count
                FROM expense_reports e
                LEFT JOIN documentos d ON d.id = e.documento_id
                LEFT JOIN tournaments t ON t.id = d.torneo_id
                LEFT JOIN proveedores_clientes pc ON pc.id = d.proveedor_cliente_id
                LEFT JOIN cfdi_reports cfdi ON cfdi.id = e.cfdi_report_id
                WHERE {' AND '.join(expense_filter)}
                  AND COALESCE(e.budget_concept_id, CASE WHEN d.tipo = 'SOLICITUD' THEN d.budget_concept_id END) IS NOT NULL
                GROUP BY 1
                """),
                params,
            )
        )
        .mappings()
        .all()
    )
    for row in expense_provider_rows:
        _merge_breakdown_row(
            by_provider,
            label=row.get("label"),
            actual_total=_safe_decimal(row.get("actual_total")),
            expense_count=int(row.get("expense_count") or 0),
        )

    document_concept_rows = (
        (
            await session.execute(
                text(f"""
                SELECT
                    COALESCE(NULLIF(TRIM(bc.concept_name), ''), 'Sin partida asignada') AS label,
                    {"bc.id::text AS concept_id," if concept_identity else ""}
                    COALESCE(SUM(CASE WHEN d.estado IN ('enviado', 'aprobado', 'en_proceso_pago', 'pagado', 'cerrado') THEN {_budget_document_base_amount_sql('d', 'document_cfdi')} ELSE 0 END), 0) AS requested_total,
                    COALESCE(SUM(CASE WHEN d.estado IN ('aprobado', 'en_proceso_pago', 'pagado', 'cerrado') THEN {_budget_document_base_amount_sql('d', 'document_cfdi')} ELSE 0 END), 0) AS committed_total,
                    COALESCE(SUM(CASE WHEN d.estado IN ('pagado', 'cerrado') OR d.pagado_en IS NOT NULL THEN {_budget_document_base_amount_sql('d', 'document_cfdi')} ELSE 0 END), 0) AS paid_total,
                    COUNT(*) FILTER (WHERE d.estado IN ('enviado', 'aprobado', 'en_proceso_pago', 'pagado', 'cerrado')) AS document_count
                FROM documentos d
                LEFT JOIN tournaments t ON t.id = d.torneo_id
                LEFT JOIN cfdi_reports document_cfdi ON document_cfdi.id = d.cfdi_report_id
                LEFT JOIN budget_concepts bc ON bc.id = d.budget_concept_id
                WHERE {' AND '.join(document_filter)}
                  AND d.budget_concept_id IS NOT NULL
                GROUP BY 1 {", bc.id" if concept_identity else ""}
                """),
                params,
            )
        )
        .mappings()
        .all()
    )
    for row in document_concept_rows:
        requested_total = _safe_decimal(row.get("requested_total"))
        committed_total = _safe_decimal(row.get("committed_total"))
        paid_total = _safe_decimal(row.get("paid_total"))
        _merge_breakdown_row(
            by_concept,
            label=row.get("label"),
            concept_id=(
                (_safe_str(row.get("concept_id")) or "__unassigned__")
                if concept_identity
                else None
            ),
            requested_total=requested_total,
            committed_total=committed_total,
            paid_total=paid_total,
            pending_to_pay_total=max(committed_total - paid_total, 0),
            document_count=int(row.get("document_count") or 0),
        )

    expense_concept_rows = (
        (
            await session.execute(
                text(f"""
                SELECT
                    COALESCE(NULLIF(TRIM(bc.concept_name), ''), 'Sin partida asignada') AS label,
                    {"bc.id::text AS concept_id," if concept_identity else ""}
                    COALESCE(SUM({_budget_expense_base_amount_sql('e', 'cfdi')}), 0) AS actual_total,
                    COUNT(*) AS expense_count
                FROM expense_reports e
                LEFT JOIN documentos d ON d.id = e.documento_id
                LEFT JOIN tournaments t ON t.id = d.torneo_id
                LEFT JOIN budget_concepts bc ON bc.id = COALESCE(e.budget_concept_id, CASE WHEN d.tipo = 'SOLICITUD' THEN d.budget_concept_id END)
                LEFT JOIN cfdi_reports cfdi ON cfdi.id = e.cfdi_report_id
                WHERE {' AND '.join(expense_filter)}
                  AND COALESCE(e.budget_concept_id, CASE WHEN d.tipo = 'SOLICITUD' THEN d.budget_concept_id END) IS NOT NULL
                GROUP BY 1 {", bc.id" if concept_identity else ""}
                """),
                params,
            )
        )
        .mappings()
        .all()
    )
    for row in expense_concept_rows:
        _merge_breakdown_row(
            by_concept,
            label=row.get("label"),
            concept_id=(
                (_safe_str(row.get("concept_id")) or "__unassigned__")
                if concept_identity
                else None
            ),
            actual_total=_safe_decimal(row.get("actual_total")),
            expense_count=int(row.get("expense_count") or 0),
        )

    return {
        "by_provider": _finalize_breakdown_store(by_provider),
        "by_concept": _finalize_breakdown_store(by_concept, limit=concept_limit),
    }


async def list_budget_tournament_commitments(
    session: AsyncSession,
    *,
    edition_year: int,
    tournament_id: Optional[str],
    tournament_name: Optional[str],
    tournament_code: Optional[str],
    limit: int = 20,
) -> list[dict[str, Any]]:
    document_filter, _expense_filter, params = _build_budget_scope_filters(
        edition_year=edition_year,
        tournament_id=tournament_id,
        tournament_name=tournament_name,
        tournament_code=tournament_code,
    )
    rows = (
        (
            await session.execute(
                text(
                    f"""
                SELECT
                    CAST(d.id AS text) AS documento_id,
                    d.numero_referencia,
                    d.referencia_operaciones,
                    d.estado,
                    d.concepto_pago,
                    COALESCE(NULLIF(TRIM(bc_doc.concept_name), ''), NULL) AS budget_concept_name,
                    d.monto_solicitado,
                    d.monto_total,
                    d.fecha_pago,
                    d.creado_en,
                    CAST(d.gasto_generado_id AS text) AS gasto_generado_id,
                    er.numero_referencia AS gasto_generado_referencia,
                    er.concepto AS gasto_generado_concepto,
                    COALESCE(NULLIF(TRIM(bc_exp.concept_name), ''), NULL) AS gasto_generado_budget_concept_name,
                    er.gasto_cantidad AS gasto_generado_total,
                    er.fecha AS gasto_generado_fecha,
                    er.estado_gasto AS gasto_generado_estado,
                    COALESCE(NULLIF(TRIM(er.usuario_nombre), ''), NULLIF(TRIM(eg.nombre), ''), 'Sin gasto generado') AS gasto_generado_actor,
                    COALESCE(expense_link.related_expense_count, 0) AS related_expense_count,
                    COALESCE(expense_link.related_expense_total, 0) AS related_expense_total,
                    expense_link.related_expense_latest_date,
                    COALESCE(NULLIF(TRIM(pc.nombre), ''), 'Sin proveedor asignado') AS proveedor_nombre,
                    COALESCE(NULLIF(TRIM(t.name), ''), 'Sin torneo') AS torneo_nombre
                FROM documentos d
                LEFT JOIN tournaments t ON t.id = d.torneo_id
                LEFT JOIN proveedores_clientes pc ON pc.id = d.proveedor_cliente_id
                LEFT JOIN budget_concepts bc_doc ON bc_doc.id = d.budget_concept_id
                LEFT JOIN expense_reports er ON er.id = d.gasto_generado_id
                LEFT JOIN budget_concepts bc_exp ON bc_exp.id = er.budget_concept_id
                LEFT JOIN empleados eg ON eg.id = er.empleado_id
                LEFT JOIN LATERAL (
                    SELECT
                        COUNT(*) FILTER (WHERE e.estado_gasto != 'cancelado') AS related_expense_count,
                        COALESCE(
                            SUM(
                                CASE
                                    WHEN e.estado_gasto != 'cancelado' THEN COALESCE(e.gasto_cantidad, 0)
                                    ELSE 0
                                END
                            ),
                            0
                        ) AS related_expense_total,
                        MAX(e.fecha) FILTER (WHERE e.estado_gasto != 'cancelado') AS related_expense_latest_date
                    FROM expense_reports e
                    WHERE {accounting_expense_sql('e')} AND (
                        e.id = d.gasto_generado_id
                        OR e.documento_id = d.id
                        OR e.solicitud_documento_id = d.id
                        OR e.informe_documento_id = d.id
                        OR (d.cuenta_gastos_id IS NOT NULL AND e.cuenta_gastos_id = d.cuenta_gastos_id)
                    )
                ) expense_link ON TRUE
                WHERE {' AND '.join(document_filter)}
                ORDER BY d.creado_en DESC
                LIMIT :row_limit
                """
                ),
                {**params, "row_limit": int(limit)},
            )
        )
        .mappings()
        .all()
    )
    return [
        {
            "documento_id": _safe_str(row.get("documento_id")) or None,
            "numero_referencia": _safe_str(row.get("numero_referencia")) or None,
            "referencia_operaciones": _safe_str(row.get("referencia_operaciones")) or None,
            "estado": _safe_str(row.get("estado")) or None,
            "concepto_pago": _safe_str(row.get("concepto_pago")) or None,
            "budget_concept_name": _safe_str(row.get("budget_concept_name")) or None,
            "monto_solicitado": round(_safe_decimal(row.get("monto_solicitado")), 2),
            "monto_total": round(_safe_decimal(row.get("monto_total")), 2),
            "fecha_pago": (
                row.get("fecha_pago").isoformat() if row.get("fecha_pago") else None
            ),
            "creado_en": (
                row.get("creado_en").isoformat() if row.get("creado_en") else None
            ),
            "gasto_generado_id": _safe_str(row.get("gasto_generado_id")) or None,
            "gasto_generado_referencia": _safe_str(row.get("gasto_generado_referencia"))
            or None,
            "gasto_generado_concepto": _safe_str(row.get("gasto_generado_concepto"))
            or None,
            "gasto_generado_budget_concept_name": _safe_str(
                row.get("gasto_generado_budget_concept_name")
            )
            or None,
            "gasto_generado_total": round(
                _safe_decimal(row.get("gasto_generado_total")), 2
            ),
            "gasto_generado_fecha": (
                row.get("gasto_generado_fecha").isoformat()
                if row.get("gasto_generado_fecha")
                else None
            ),
            "gasto_generado_estado": _safe_str(row.get("gasto_generado_estado"))
            or None,
            "gasto_generado_actor": _safe_str(row.get("gasto_generado_actor")) or None,
            "related_expense_count": int(row.get("related_expense_count") or 0),
            "related_expense_total": round(
                _safe_decimal(row.get("related_expense_total")), 2
            ),
            "related_expense_latest_date": (
                row.get("related_expense_latest_date").isoformat()
                if row.get("related_expense_latest_date")
                else None
            ),
            "proveedor_nombre": _safe_str(row.get("proveedor_nombre"))
            or "Sin proveedor asignado",
            "torneo_nombre": _safe_str(row.get("torneo_nombre")) or "Sin torneo",
        }
        for row in rows
    ]


def budget_alias_candidates(*values: str) -> set[str]:
    haystack = " ".join(_normalize_text(value) for value in values if value).strip()
    aliases: set[str] = set()
    for code, terms in _BUDGET_ALIAS_RULES:
        if any(term in haystack for term in terms):
            aliases.add(code)
    return aliases


def _status_sort_value(status: Optional[str]) -> int:
    return _BUDGET_STATUS_ORDER.get(_normalize_budget_status(status), 999)


def _matches_aliases(
    *,
    aliases: set[str],
    tournament_code: Optional[str],
    tournament_name: Optional[str],
) -> bool:
    if not aliases:
        return True
    row_code = _safe_str(tournament_code).upper()
    if row_code and row_code in aliases:
        return True
    return bool(
        budget_alias_candidates(
            _safe_str(tournament_name),
            _safe_str(tournament_code),
        )
        & aliases
    )


def build_budget_commitment_expense_preview(
    commitment: Optional[dict[str, Any]],
) -> dict[str, Any]:
    item = commitment or {}
    generated_expense_id = str(item.get("gasto_generado_id") or "").strip() or None
    generated_expense_reference = (
        str(item.get("gasto_generado_referencia") or "").strip() or None
    )
    generated_expense_state = (
        str(item.get("gasto_generado_estado") or "").strip() or None
    )
    generated_expense_actor = (
        str(item.get("gasto_generado_actor") or "").strip() or None
    )
    generated_expense_concept = (
        str(item.get("gasto_generado_concepto") or "").strip() or None
    )
    related_expense_count = int(item.get("related_expense_count") or 0)
    related_expense_total = round(float(item.get("related_expense_total") or 0), 2)
    related_expense_latest_date = (
        str(item.get("related_expense_latest_date") or "").strip() or None
    )
    generated_expense_total = round(float(item.get("gasto_generado_total") or 0), 2)

    return {
        "has_generated_expense": bool(generated_expense_id),
        "generated_expense_id": generated_expense_id,
        "generated_expense_reference": generated_expense_reference,
        "generated_expense_state": generated_expense_state,
        "generated_expense_actor": generated_expense_actor,
        "generated_expense_concept": generated_expense_concept,
        "generated_expense_total": generated_expense_total,
        "generated_expense_href": (
            f"/gastos/{generated_expense_id}" if generated_expense_id else None
        ),
        "related_expense_count": related_expense_count,
        "related_expense_total": related_expense_total,
        "related_expense_latest_date": related_expense_latest_date,
    }


async def _load_tournament_rows(session: AsyncSession) -> list[dict[str, Any]]:
    rows = (
        (
            await session.execute(
                text(
                    """
                SELECT id, name, active, etapas
                FROM tournaments
                ORDER BY active DESC, display_order ASC, name ASC
                """
                )
            )
        )
        .mappings()
        .all()
    )
    return [dict(row) for row in rows]


def _match_tournament_id(
    tournament_rows: list[dict[str, Any]],
    *,
    tournament_code: Optional[str],
    tournament_name: Optional[str],
) -> Optional[str]:
    target_name = _normalize_text(tournament_name)
    target_aliases = budget_alias_candidates(
        _safe_str(tournament_code), _safe_str(tournament_name)
    )
    for row in tournament_rows:
        row_name = _normalize_text(row.get("name"))
        if target_name and row_name == target_name:
            return _safe_str(row.get("id")) or None
        row_aliases = budget_alias_candidates(_safe_str(row.get("name")))
        if target_aliases and row_aliases & target_aliases:
            return _safe_str(row.get("id")) or None
    return None


def _derive_budget_tournament_code(sheet_name: str, tournament_name: str) -> str:
    aliases = sorted(
        budget_alias_candidates(sheet_name, tournament_name),
        key=lambda item: (
            0 if item == _safe_str(sheet_name).upper() else 1,
            len(item),
            item,
        ),
    )
    if aliases:
        return aliases[0]
    fallback = re.sub(r"[^A-Z0-9]+", "", _safe_str(sheet_name).upper())
    return fallback[:40] or "GENERAL"


def _map_catalog_phase_label_to_etapa(
    catalog_label: Optional[str],
    tournament_etapas: Optional[list[str]],
) -> str:
    clean_label = _safe_str(catalog_label)
    if not clean_label:
        return ""
    etapas = [
        _safe_str(value) for value in (tournament_etapas or []) if _safe_str(value)
    ]
    catalog_aliases = _budget_scope_aliases(clean_label)
    for etapa in etapas:
        if _normalize_budget_scope_key(etapa) == _normalize_budget_scope_key(
            clean_label
        ):
            return etapa
        if catalog_aliases & _budget_scope_aliases(etapa):
            return etapa
    normalized = _normalize_budget_scope_key(clean_label)
    crosswalk_keys = {
        "local": {"municipal", "fase_municipal"},
        "fase_local": {"municipal", "fase_municipal"},
        "nacional": {"final_nacional", "fase_final_nacional"},
        "fase_nacional": {
            "final_nacional",
            "fase_final_nacional",
            "nacional",
            "fase_nacional",
        },
    }
    if normalized in crosswalk_keys:
        for etapa in etapas:
            etapa_aliases = _budget_scope_aliases(etapa)
            if etapa_aliases & crosswalk_keys[normalized]:
                return etapa
    fallback_map = {
        "fase_colectiva": "Fase Colectiva",
        "fase_estatal": "Fase Estatal",
        "fase_nacional": "Fase Nacional",
        "viaje_de_campeones": "Viaje de Campeones",
    }
    if normalized in fallback_map and fallback_map[normalized] in etapas:
        return fallback_map[normalized]
    return clean_label.title()


async def validate_active_cuenta_contable_id(
    session: AsyncSession,
    cuenta_contable_id: str,
) -> str:
    """Return the cuenta id when it exists and is active; raise ValueError otherwise."""
    clean_id = _safe_str(cuenta_contable_id)
    if not clean_id:
        raise ValueError("La cuenta contable seleccionada no es válida.")
    row = (
        (
            await session.execute(
                text(
                    """
                SELECT id
                FROM cuentas_contables
                WHERE CAST(id AS text) = :cuenta_contable_id
                  AND activo = TRUE
                LIMIT 1
                """
                ),
                {"cuenta_contable_id": clean_id},
            )
        )
        .mappings()
        .first()
    )
    if not row:
        raise ValueError("La cuenta contable seleccionada no existe o está inactiva.")
    return clean_id


async def resolve_active_cuenta_contable_id_by_code(
    session: AsyncSession,
    cuenta_contable_codigo: str,
) -> str:
    """Return an active cuenta id by accounting code; raise ValueError otherwise."""
    clean_code = _safe_str(cuenta_contable_codigo)
    if not clean_code:
        raise ValueError("La cuenta contable es obligatoria.")
    row = (
        (
            await session.execute(
                text(
                    """
                SELECT id
                FROM cuentas_contables
                WHERE codigo = :codigo
                  AND activo = TRUE
                LIMIT 1
                """
                ),
                {"codigo": clean_code},
            )
        )
        .mappings()
        .first()
    )
    if not row:
        raise ValueError(f"La cuenta contable {clean_code} no existe o está inactiva.")
    return _safe_str(row.get("id"))


DEFAULT_BUDGET_CONCEPT_ACCOUNT_MAPPING = (
    _ROOT
    / "docs"
    / "1.2 Catálogo de Partidas Presupuestales vs Cuenta Contable (1).xlsx"
)


def _iter_budget_concept_account_mapping_rows(
    workbook_path: str | Path = DEFAULT_BUDGET_CONCEPT_ACCOUNT_MAPPING,
    *,
    sheet_name: str = "Catálogo Final",
) -> list[dict[str, Any]]:
    path = Path(workbook_path)
    if not path.exists():
        return []
    workbook = load_workbook(path, data_only=True)
    if sheet_name not in workbook.sheetnames:
        return []
    sheet = workbook[sheet_name]
    header_row = None
    column_map: dict[str, int] = {}
    for row_index in range(1, min(sheet.max_row, 20) + 1):
        headers = {
            _normalize_budget_key(
                _safe_str(sheet.cell(row=row_index, column=col).value)
            ): col
            for col in range(1, sheet.max_column + 1)
            if _safe_str(sheet.cell(row=row_index, column=col).value)
        }
        if "partida" in headers and "cuenta_contable" in headers:
            header_row = row_index
            column_map = headers
            break
    if header_row is None:
        return []

    def _col(*aliases: str) -> Optional[int]:
        for alias in aliases:
            key = _normalize_budget_key(alias)
            if key in column_map:
                return column_map[key]
        return None

    partida_col = _col("partida")
    proyecto_col = _col("proyecto")
    subproyecto_col = _col("subproyecto")
    cuenta_col = _col("cuenta_contable", "cuenta contable")
    cuenta_nombre_col = _col("nombre_cuenta_contable", "nombre cuenta contable")
    if not partida_col or not cuenta_col:
        return []

    rows: list[dict[str, Any]] = []
    for row_index in range(header_row + 1, sheet.max_row + 1):
        partida = _safe_str(sheet.cell(row=row_index, column=partida_col).value)
        cuenta_codigo = _safe_str(sheet.cell(row=row_index, column=cuenta_col).value)
        if not partida or not cuenta_codigo:
            continue
        proyecto = (
            _safe_str(sheet.cell(row=row_index, column=proyecto_col).value)
            if proyecto_col
            else ""
        )
        subproyecto = (
            _safe_str(sheet.cell(row=row_index, column=subproyecto_col).value)
            if subproyecto_col
            else ""
        )
        cuenta_nombre = (
            _safe_str(sheet.cell(row=row_index, column=cuenta_nombre_col).value)
            if cuenta_nombre_col
            else ""
        )
        rows.append(
            {
                "partida": partida,
                "concept_key": _normalize_budget_key(partida),
                "proyecto": proyecto,
                "subproyecto": subproyecto,
                "cuenta_contable_codigo": cuenta_codigo,
                "cuenta_contable_nombre": cuenta_nombre,
                "sheet_row_index": row_index,
            }
        )
    return rows


def collect_workbook_project_configs(
    workbook_path: str | Path = DEFAULT_BUDGET_CONCEPT_ACCOUNT_MAPPING,
) -> list[dict[str, Any]]:
    """Return workbook projects with ordered Subproyecto values as tournament etapas."""
    projects: dict[str, dict[str, Any]] = {}
    for row in _iter_budget_concept_account_mapping_rows(workbook_path):
        proyecto = _safe_str(row.get("proyecto"))
        if not proyecto:
            continue
        if proyecto not in projects:
            projects[proyecto] = {"proyecto": proyecto, "etapas": []}
        subproyecto = _safe_str(row.get("subproyecto"))
        if subproyecto and subproyecto not in projects[proyecto]["etapas"]:
            projects[proyecto]["etapas"].append(subproyecto)
    return list(projects.values())


def collect_workbook_cuentas_contables(
    workbook_path: str | Path = DEFAULT_BUDGET_CONCEPT_ACCOUNT_MAPPING,
) -> dict[str, str]:
    """Return unique workbook account codes mapped to their display names."""
    catalog: dict[str, str] = {}
    for row in _iter_budget_concept_account_mapping_rows(workbook_path):
        codigo = _safe_str(row.get("cuenta_contable_codigo"))
        nombre = _safe_str(row.get("cuenta_contable_nombre"))
        if not codigo:
            continue
        if codigo not in catalog and nombre:
            catalog[codigo] = nombre
        elif codigo not in catalog:
            catalog[codigo] = codigo
    return catalog


async def ensure_missing_cuentas_contables_from_workbook(
    session: AsyncSession,
    *,
    workbook_path: str | Path = DEFAULT_BUDGET_CONCEPT_ACCOUNT_MAPPING,
    tipo: str = "gasto",
    activo: bool = True,
    commit: bool = True,
) -> dict[str, Any]:
    """Create active cuentas contables referenced by the workbook but missing in DB."""
    from devnous.gastos.models import CuentaContable

    workbook_accounts = collect_workbook_cuentas_contables(workbook_path)
    if not workbook_accounts:
        return {
            "workbook_accounts_count": 0,
            "created_count": 0,
            "existing_count": 0,
            "created": [],
        }

    existing_rows = (
        (
            await session.execute(
                text(
                    """
                SELECT codigo, nombre, activo
                FROM cuentas_contables
                WHERE codigo = ANY(:codigos)
                """
                ),
                {"codigos": sorted(workbook_accounts)},
            )
        )
        .mappings()
        .all()
    )
    existing_by_code = {
        _safe_str(row.get("codigo")): row
        for row in existing_rows
        if _safe_str(row.get("codigo"))
    }
    existing_codes = set(existing_by_code)

    created: list[dict[str, str]] = []
    updated: list[dict[str, str]] = []
    for codigo in sorted(workbook_accounts):
        nombre = workbook_accounts[codigo]
        existing = existing_by_code.get(codigo)
        if existing:
            if _safe_str(existing.get("nombre")) != nombre or bool(
                existing.get("activo")
            ) != bool(activo):
                await session.execute(
                    text(
                        """
                        UPDATE cuentas_contables
                        SET nombre = :nombre,
                            activo = :activo,
                            actualizado_en = NOW()
                        WHERE codigo = :codigo
                        """
                    ),
                    {"codigo": codigo, "nombre": nombre, "activo": bool(activo)},
                )
                updated.append(
                    {
                        "codigo": codigo,
                        "nombre": nombre,
                        "tipo": _safe_str(tipo) or "gasto",
                    }
                )
            continue
        session.add(
            CuentaContable(
                codigo=codigo,
                nombre=nombre,
                tipo=_safe_str(tipo) or "gasto",
                activo=bool(activo),
            )
        )
        created.append(
            {"codigo": codigo, "nombre": nombre, "tipo": _safe_str(tipo) or "gasto"}
        )

    if commit and (created or updated):
        await session.commit()

    return {
        "workbook_accounts_count": len(workbook_accounts),
        "created_count": len(created),
        "updated_count": len(updated),
        "existing_count": len(existing_codes),
        "created": created,
        "updated": updated,
    }


async def require_ungoverned_gastos_project(
    session: AsyncSession,
    tournament_id: str,
) -> None:
    """Lazy module-level guard hook for budget project sync monkeypatching."""
    from devnous.gastos.services.tournament_authority_service import (
        require_ungoverned_gastos_project as _require_ungoverned_gastos_project,
    )

    await _require_ungoverned_gastos_project(session, tournament_id)


async def sync_budget_projects_from_partidas_workbook(
    session: AsyncSession,
    *,
    workbook_path: str | Path = DEFAULT_BUDGET_CONCEPT_ACCOUNT_MAPPING,
    commit: bool = True,
) -> dict[str, Any]:
    """Create/update workbook projects and align their Subproyecto values to etapas."""
    project_configs = collect_workbook_project_configs(workbook_path)
    if not project_configs:
        return {
            "workbook_projects_count": 0,
            "projects_matched": 0,
            "projects_created": 0,
            "projects_updated": 0,
            "project_ids_by_name": {},
        }

    tournament_rows = await _load_tournament_rows(session)
    max_order_result = await session.execute(
        text("SELECT COALESCE(MAX(display_order), 0) FROM tournaments")
    )
    try:
        next_display_order = int(max_order_result.scalar() or 0)
    except (AttributeError, TypeError, ValueError):
        next_display_order = 0

    projects_matched = 0
    projects_created = 0
    projects_updated = 0
    project_ids_by_name: dict[str, str] = {}

    for config in project_configs:
        proyecto = _safe_str(config.get("proyecto"))
        etapas = [
            _safe_str(value)
            for value in (config.get("etapas") or [])
            if _safe_str(value)
        ]
        tournament_id = _match_tournament_id(
            tournament_rows,
            tournament_code=None,
            tournament_name=proyecto,
        )
        if tournament_id:
            projects_matched += 1
            await require_ungoverned_gastos_project(
                session,
                tournament_id,
            )
            current = next(
                (
                    row
                    for row in tournament_rows
                    if _safe_str(row.get("id")) == tournament_id
                ),
                {},
            )
            current_etapas = [
                _safe_str(value)
                for value in (current.get("etapas") or [])
                if _safe_str(value)
            ]
            if (
                _safe_str(current.get("name")) != proyecto
                or current_etapas != etapas
                or not bool(current.get("active", True))
            ):
                await session.execute(
                    text(
                        """
                        UPDATE tournaments
                        SET name = :name,
                            etapas = CAST(:etapas AS jsonb),
                            active = TRUE,
                            updated_at = NOW()
                        WHERE CAST(id AS text) = :tournament_id
                        """
                    ),
                    {
                        "tournament_id": tournament_id,
                        "name": proyecto,
                        "etapas": json.dumps(etapas, ensure_ascii=False),
                    },
                )
                current["name"] = proyecto
                current["etapas"] = etapas
                current["active"] = True
                projects_updated += 1
            project_ids_by_name[proyecto] = tournament_id
            continue

        next_display_order += 1
        tournament_id = str(uuid.uuid4())
        await session.execute(
            text(
                """
                INSERT INTO tournaments (
                    id, name, description, active, display_order,
                    cuenta_contable_relacionada, etapas, categorias,
                    created_at, updated_at
                ) VALUES (
                    :id, :name, :description, TRUE, :display_order,
                    NULL, CAST(:etapas AS jsonb), NULL,
                    NOW(), NOW()
                )
                """
            ),
            {
                "id": tournament_id,
                "name": proyecto,
                "description": "Sincronizado desde catálogo SSOT de partidas presupuestales.",
                "display_order": next_display_order,
                "etapas": json.dumps(etapas, ensure_ascii=False),
            },
        )
        tournament_rows.append(
            {
                "id": tournament_id,
                "name": proyecto,
                "active": True,
                "etapas": etapas,
            }
        )
        project_ids_by_name[proyecto] = tournament_id
        projects_created += 1

    if commit:
        await session.commit()

    return {
        "workbook_projects_count": len(project_configs),
        "projects_matched": projects_matched,
        "projects_created": projects_created,
        "projects_updated": projects_updated,
        "project_ids_by_name": project_ids_by_name,
    }


def _match_budget_concept_for_account_mapping(
    concepts: list[dict[str, Any]],
    *,
    row: dict[str, Any],
    tournament_code: str = "",
) -> Optional[dict[str, Any]]:
    """Resolve a workbook row to a budget concept using scoped keys and SSOT metadata."""
    base_key = _safe_str(row.get("concept_key"))
    subproyecto = _safe_str(row.get("subproyecto"))
    proyecto = _safe_str(row.get("proyecto"))
    sheet_row_index = row.get("sheet_row_index")
    if not base_key:
        return None

    def _proyecto_matches(item: dict[str, Any]) -> bool:
        metadata = (
            item.get("metadata") if isinstance(item.get("metadata"), dict) else {}
        )
        if not proyecto and not tournament_code:
            return True
        if tournament_code and (
            _safe_str(item.get("tournament_code") or "").upper()
            == tournament_code.upper()
        ):
            return True
        if _safe_str(item.get("tournament_name") or "").lower() == proyecto.lower():
            return True
        if _safe_str(metadata.get("ssot_proyecto")).lower() == proyecto.lower():
            return True
        row_aliases = budget_alias_candidates(proyecto)
        item_aliases = budget_alias_candidates(
            _safe_str(item.get("tournament_code")),
            _safe_str(item.get("tournament_name")),
            _safe_str(metadata.get("ssot_proyecto")),
        )
        return bool(row_aliases & item_aliases)

    scoped_key = (
        f"{base_key}__{_normalize_budget_key(subproyecto)}" if subproyecto else base_key
    )
    exact = [
        item
        for item in concepts
        if _safe_str(item.get("concept_key")) == scoped_key and _proyecto_matches(item)
    ]
    if len(exact) == 1:
        return exact[0]
    if len(exact) > 1 and subproyecto:
        phased = [
            item for item in exact if budget_concept_matches_fase(item, subproyecto)
        ]
        if len(phased) == 1:
            return phased[0]

    ssot_matches = [
        item
        for item in concepts
        if isinstance(item.get("metadata"), dict)
        and item["metadata"].get("ssot_row_index") == sheet_row_index
        and (
            _safe_str(item["metadata"].get("ssot_proyecto")).lower() == proyecto.lower()
            or _proyecto_matches(item)
        )
    ]
    if len(ssot_matches) == 1:
        return ssot_matches[0]

    if subproyecto:
        return None

    name_matches = [
        item
        for item in concepts
        if _normalize_budget_key(item.get("concept_name") or "") == base_key
        and _proyecto_matches(item)
    ]
    if subproyecto:
        scoped_name = [
            item
            for item in name_matches
            if budget_concept_matches_fase(item, subproyecto)
        ]
        if len(scoped_name) == 1:
            return scoped_name[0]
        if len(scoped_name) > 1:
            name_matches = scoped_name
    if len(name_matches) == 1:
        return name_matches[0]

    loose = [
        item
        for item in concepts
        if base_key in _safe_str(item.get("concept_key")) and _proyecto_matches(item)
    ]
    if subproyecto:
        loose = [
            item for item in loose if budget_concept_matches_fase(item, subproyecto)
        ]
    if len(loose) == 1:
        return loose[0]
    return None


async def preview_budget_concept_account_mappings(
    session: AsyncSession,
    *,
    workbook_path: str | Path = DEFAULT_BUDGET_CONCEPT_ACCOUNT_MAPPING,
) -> dict[str, Any]:
    """Dry-run report for partida→cuenta contable mappings from the client workbook."""
    await ensure_budget_schema(session)
    mapping_rows = _iter_budget_concept_account_mapping_rows(workbook_path)
    concepts = await list_budget_concepts(session, active_only=False, limit=5000)
    tournament_rows = await _load_tournament_rows(session)
    account_rows = (
        (
            await session.execute(
                text(
                    """
                SELECT id, codigo, nombre, activo
                FROM cuentas_contables
                ORDER BY codigo ASC
                """
                )
            )
        )
        .mappings()
        .all()
    )
    accounts_by_code = {
        _normalize_budget_key(_safe_str(row.get("codigo"))): row for row in account_rows
    }

    matched: list[dict[str, Any]] = []
    skipped_no_concept: list[dict[str, Any]] = []
    skipped_missing_account: list[dict[str, Any]] = []
    skipped_inactive_account: list[dict[str, Any]] = []

    for row in mapping_rows:
        tournament_id = _match_tournament_id(
            tournament_rows,
            tournament_code=None,
            tournament_name=row.get("proyecto") or "",
        )
        tournament_code = ""
        if tournament_id:
            tournament = next(
                (
                    item
                    for item in tournament_rows
                    if str(item.get("id")) == tournament_id
                ),
                None,
            )
            if tournament:
                tournament_code = _derive_budget_tournament_code(
                    tournament.get("name") or "",
                    row.get("proyecto") or "",
                )
        subproyecto = _safe_str(row.get("subproyecto"))
        concept = _match_budget_concept_for_account_mapping(
            concepts,
            row=row,
            tournament_code=tournament_code,
        )
        account = accounts_by_code.get(
            _normalize_budget_key(_safe_str(row.get("cuenta_contable_codigo")))
        )
        if concept is None:
            skipped_no_concept.append(row)
            continue
        if account is None:
            skipped_missing_account.append({**row, "concept_id": concept.get("id")})
            continue
        if not bool(account.get("activo")):
            skipped_inactive_account.append(
                {
                    **row,
                    "concept_id": concept.get("id"),
                    "account_id": account.get("id"),
                }
            )
            continue
        matched.append(
            {
                **row,
                "concept_id": concept.get("id"),
                "concept_name": concept.get("concept_name"),
                "cuenta_contable_id": _safe_str(account.get("id")),
                "cuenta_contable_nombre": _safe_str(account.get("nombre")),
            }
        )

    return {
        "workbook_path": str(Path(workbook_path)),
        "rows_total": len(mapping_rows),
        "matched_count": len(matched),
        "skipped_no_concept_count": len(skipped_no_concept),
        "skipped_missing_account_count": len(skipped_missing_account),
        "skipped_inactive_account_count": len(skipped_inactive_account),
        "matched": matched,
        "skipped_no_concept": skipped_no_concept,
        "skipped_missing_account": skipped_missing_account,
        "skipped_inactive_account": skipped_inactive_account,
    }


async def import_budget_concept_account_mappings(
    session: AsyncSession,
    *,
    workbook_path: str | Path = DEFAULT_BUDGET_CONCEPT_ACCOUNT_MAPPING,
    dry_run: bool = True,
    create_missing_cuentas: bool = False,
) -> dict[str, Any]:
    cuenta_bootstrap: dict[str, Any] = {}
    if create_missing_cuentas and not dry_run:
        cuenta_bootstrap = await ensure_missing_cuentas_contables_from_workbook(
            session,
            workbook_path=workbook_path,
            commit=True,
        )
    preview = await preview_budget_concept_account_mappings(
        session,
        workbook_path=workbook_path,
    )
    if dry_run:
        return preview
    updated = 0
    for item in preview.get("matched") or []:
        concept_id = _safe_str(item.get("concept_id"))
        cuenta_id = _safe_str(item.get("cuenta_contable_id"))
        if not concept_id:
            continue
        await update_budget_concept(
            session,
            concept_id=concept_id,
            cuenta_contable_id=cuenta_id or None,
            cuenta_contable_provided=True,
            commit=False,
        )
        updated += 1
    await session.commit()
    return {
        **preview,
        **cuenta_bootstrap,
        "updated": updated,
        "dry_run": False,
        "create_missing_cuentas": create_missing_cuentas,
    }


_DEFINITIVE_VERSION_STATUS_ORDER = {
    "approved": 0,
    "frozen": 1,
    "reforecast": 2,
    "draft": 3,
    "submitted": 4,
    "closed": 5,
}


async def resolve_definitive_budget_version(
    session: AsyncSession,
    *,
    edition_year: int,
) -> Optional[dict[str, Any]]:
    """Return the single operational budget version for an edition year."""
    versions = await list_budget_versions(session, edition_year=edition_year)
    return resolve_definitive_budget_version_from_versions(versions)


def resolve_definitive_budget_version_from_versions(
    versions: list[dict[str, Any]],
) -> Optional[dict[str, Any]]:
    """Return the operational budget version from an already-loaded list."""
    from .distribution import select_version

    return select_version(versions)


def _scoped_budget_concept_key(partida: str, subproyecto: str = "") -> str:
    base_key = _normalize_budget_key(partida)
    sub_key = _normalize_budget_key(subproyecto)
    if base_key and sub_key:
        return f"{base_key}__{sub_key}"
    return base_key


async def sync_budget_concepts_from_partidas_workbook(
    session: AsyncSession,
    *,
    workbook_path: str | Path = DEFAULT_BUDGET_CONCEPT_ACCOUNT_MAPPING,
    actor_empleado_id: Optional[str] = None,
    create_missing_cuentas: bool = True,
) -> dict[str, Any]:
    """Upsert budget_concepts from the client partidas/cuenta workbook SSOT."""
    await ensure_budget_schema(session)
    mapping_rows = _iter_budget_concept_account_mapping_rows(workbook_path)
    if not mapping_rows:
        raise ValueError(
            "No se encontraron partidas en el catálogo SSOT de partidas vs cuenta contable."
        )
    project_report = await sync_budget_projects_from_partidas_workbook(
        session,
        workbook_path=workbook_path,
        commit=False,
    )
    cuenta_report: dict[str, Any] = {}
    if create_missing_cuentas:
        cuenta_report = (
            await ensure_missing_cuentas_contables_from_workbook(
                session,
                workbook_path=workbook_path,
                commit=True,
            )
            or {}
        )

    concepts = await list_budget_concepts(session, active_only=False, limit=5000)
    tournament_rows = await _load_tournament_rows(session)
    account_rows = (
        (
            await session.execute(
                text(
                    """
                SELECT id, codigo, nombre, activo
                FROM cuentas_contables
                ORDER BY codigo ASC
                """
                )
            )
        )
        .mappings()
        .all()
    )
    accounts_by_code = {
        _normalize_budget_key(_safe_str(row.get("codigo"))): row for row in account_rows
    }

    created = 0
    updated = 0
    skipped_no_tournament = 0
    skipped_no_account = 0
    matched_tournament_ids: set[str] = set()
    workbook_concept_keys_by_tournament: dict[str, set[str]] = defaultdict(set)

    for row in mapping_rows:
        tournament_id = _match_tournament_id(
            tournament_rows,
            tournament_code=None,
            tournament_name=row.get("proyecto") or "",
        )
        if not tournament_id:
            skipped_no_tournament += 1
            continue

        tournament = await _resolve_tournament_for_budget_concept(
            session,
            tournament_id=tournament_id,
        )
        subproyecto = _safe_str(row.get("subproyecto"))
        partida = _safe_str(row.get("partida"))
        concept_key = _scoped_budget_concept_key(partida, subproyecto)
        if not concept_key:
            continue
        matched_tournament_ids.add(tournament_id)
        workbook_concept_keys_by_tournament[tournament_id].add(concept_key)
        account = accounts_by_code.get(
            _normalize_budget_key(_safe_str(row.get("cuenta_contable_codigo")))
        )
        cuenta_id = _safe_str(account.get("id")) if account else ""
        if not cuenta_id:
            skipped_no_account += 1
            continue

        tournament_code = tournament.get("tournament_code") or ""
        existing = _match_budget_concept_for_account_mapping(
            concepts,
            row=row,
            tournament_code=tournament_code,
        )
        if existing is None:
            existing = next(
                (
                    item
                    for item in concepts
                    if _safe_str(item.get("tournament_id")) == tournament_id
                    and _safe_str(item.get("concept_key")) == concept_key
                ),
                None,
            )

        ssot_metadata = {
            "ssot_proyecto": _safe_str(row.get("proyecto")) or None,
            "ssot_subproyecto": subproyecto or None,
            "ssot_row_index": row.get("sheet_row_index"),
            "ssot_source": "partidas_cuenta_workbook",
            "ssot_cuenta_contable_codigo": _safe_str(row.get("cuenta_contable_codigo")),
        }

        if existing:
            concept_id = _safe_str(existing.get("id"))
            await update_budget_concept(
                session,
                concept_id=concept_id,
                concept_name=partida,
                tournament_id=tournament_id,
                scope_labels=[subproyecto] if subproyecto else [],
                cuenta_contable_id=cuenta_id,
                cuenta_contable_provided=True,
                active=True,
                actor_empleado_id=actor_empleado_id,
                commit=False,
            )
            await session.execute(
                text(
                    """
                    UPDATE budget_concepts
                    SET concept_key = :concept_key,
                        source = 'ssot_workbook',
                        metadata = COALESCE(metadata, '{}'::jsonb) || CAST(:metadata AS jsonb),
                        updated_at = NOW()
                    WHERE id = :concept_id
                    """
                ),
                {
                    "concept_id": concept_id,
                    "concept_key": concept_key,
                    "metadata": json.dumps(ssot_metadata, ensure_ascii=False),
                },
            )
            existing.update(
                {
                    "concept_key": concept_key,
                    "concept_name": partida,
                    "tournament_id": tournament_id,
                    "metadata": {**(existing.get("metadata") or {}), **ssot_metadata},
                }
            )
            updated += 1
            continue

        concept = await create_budget_concept(
            session,
            tournament_id=tournament_id,
            concept_name=partida,
            scope_labels=[subproyecto] if subproyecto else [],
            cuenta_contable_id=cuenta_id,
            actor_empleado_id=actor_empleado_id,
            source="ssot_workbook",
            commit=False,
            concept_key=concept_key,
            extra_metadata=ssot_metadata,
        )
        concepts.append(concept)
        created += 1

    deactivated_stale = 0
    for tournament_id in sorted(matched_tournament_ids):
        workbook_keys = sorted(
            workbook_concept_keys_by_tournament.get(tournament_id) or []
        )
        if not workbook_keys:
            continue
        result = await session.execute(
            text(
                """
                UPDATE budget_concepts
                SET active = FALSE,
                    updated_at = NOW()
                WHERE CAST(tournament_id AS text) = :tournament_id
                  AND active = TRUE
                  AND NOT (concept_key = ANY(:workbook_keys))
                """
            ),
            {
                "tournament_id": tournament_id,
                "workbook_keys": workbook_keys,
            },
        )
        deactivated_stale += int(getattr(result, "rowcount", 0) or 0)

    await session.commit()
    return {
        "workbook_path": str(Path(workbook_path)),
        "rows_total": len(mapping_rows),
        "created": created,
        "updated": updated,
        "deactivated_stale": deactivated_stale,
        "matched_tournaments": len(matched_tournament_ids),
        "workbook_projects_count": project_report.get("workbook_projects_count", 0),
        "projects_matched": project_report.get("projects_matched", 0),
        "projects_created": project_report.get("projects_created", 0),
        "projects_updated": project_report.get("projects_updated", 0),
        "workbook_accounts_count": cuenta_report.get("workbook_accounts_count", 0),
        "accounts_created": cuenta_report.get("created_count", 0),
        "accounts_updated": cuenta_report.get("updated_count", 0),
        "accounts_existing": cuenta_report.get("existing_count", 0),
        "skipped_no_tournament": skipped_no_tournament,
        "skipped_no_account": skipped_no_account,
    }


async def attach_cuenta_contable_to_budget_lines(
    session: AsyncSession,
    lines: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Enrich budget lines with cuenta contable from linked budget concepts."""
    concept_ids = {
        _safe_str(line.get("budget_concept_id"))
        for line in lines
        if _safe_str(line.get("budget_concept_id"))
    }
    if not concept_ids:
        return lines
    concepts = await list_budget_concepts(session, active_only=False, limit=5000)
    concepts_by_id = {
        _safe_str(item.get("id")): item
        for item in concepts
        if _safe_str(item.get("id"))
    }
    enriched: list[dict[str, Any]] = []
    for line in lines:
        payload = dict(line)
        concept = concepts_by_id.get(_safe_str(line.get("budget_concept_id")) or "")
        if concept:
            payload["cuenta_contable_id"] = concept.get("cuenta_contable_id")
            payload["cuenta_contable_codigo"] = concept.get(
                "cuenta_contable_codigo"
            ) or payload.get("account_code_final")
            payload["cuenta_contable_nombre"] = concept.get("cuenta_contable_nombre")
        elif payload.get("account_code_final"):
            payload["cuenta_contable_codigo"] = payload.get("account_code_final")
        enriched.append(payload)
    return enriched


def _iter_budget_concept_catalog_phase_rows(
    workbook_path: str | Path = DEFAULT_BUDGET_CONCEPT_CATALOG,
    *,
    sheet_name: Optional[str] = None,
) -> list[dict[str, Any]]:
    """
    Parse catalog rows assigning each partida to the subproyecto/fase row that
    appears immediately below it in the spreadsheet.
    """
    path = Path(workbook_path)
    if not path.exists():
        return []
    workbook = load_workbook(path, data_only=True)
    worksheets = []
    if sheet_name:
        if sheet_name not in workbook.sheetnames:
            return []
        worksheets = [workbook[sheet_name]]
    else:
        worksheets = list(workbook.worksheets)

    rows: list[dict[str, Any]] = []
    for sheet in worksheets:
        title_candidates = [
            _safe_str(sheet.cell(row=row_index, column=1).value)
            for row_index in range(1, min(sheet.max_row, 4) + 1)
            if _safe_str(sheet.cell(row=row_index, column=1).value)
        ]
        tournament_name = (
            title_candidates[0] if title_candidates else _safe_str(sheet.title)
        )
        tournament_code = _derive_budget_tournament_code(sheet.title, tournament_name)
        header_row = None
        dimension_headers: list[str] = []
        for row_index in range(1, sheet.max_row + 1):
            first_value = _safe_str(sheet.cell(row=row_index, column=1).value)
            if first_value.lower() == "concepto":
                header_row = row_index
                dimension_headers = [
                    _safe_str(sheet.cell(row=row_index, column=col_index).value)
                    for col_index in range(2, sheet.max_column + 1)
                    if _safe_str(sheet.cell(row=row_index, column=col_index).value)
                ]
                break
        if header_row is None:
            continue

        pending_rows: list[tuple[int, str, list[str]]] = []

        def _flush_pending(phase_label: Optional[str]) -> None:
            for row_index, concept_name, trailing_values in pending_rows:
                base_key = _normalize_budget_key(concept_name)
                if not base_key:
                    continue
                phase_key = _normalize_budget_key(phase_label or "general")
                concept_key = f"{base_key}__{phase_key}" if phase_label else base_key
                metadata: dict[str, Any] = {
                    "sheet_name": sheet.title,
                    "sheet_headers": dimension_headers,
                    "sheet_row_index": row_index,
                    "catalog_phase_break_label": _safe_str(phase_label) or None,
                }
                if any(trailing_values):
                    metadata["sheet_dimension_values"] = trailing_values
                rows.append(
                    {
                        "tournament_code": tournament_code,
                        "tournament_name": tournament_name,
                        "concept_name": concept_name,
                        "concept_key": concept_key,
                        "catalog_phase_break_label": _safe_str(phase_label) or None,
                        "metadata": metadata,
                    }
                )
            pending_rows.clear()

        for row_index in range(header_row + 1, sheet.max_row + 1):
            concept_name = _safe_str(sheet.cell(row=row_index, column=1).value)
            trailing_values = [
                _safe_str(sheet.cell(row=row_index, column=col_index).value)
                for col_index in range(2, sheet.max_column + 1)
            ]
            if not concept_name:
                continue
            if _is_budget_phase_break_label(concept_name, trailing_values):
                _flush_pending(concept_name)
                continue
            pending_rows.append((row_index, concept_name, trailing_values))
        _flush_pending(None)
    return rows


async def replace_tournament_budget_concepts_from_catalog_sheet(
    session: AsyncSession,
    *,
    tournament_id: str,
    sheet_name: str,
    workbook_path: str | Path = DEFAULT_BUDGET_CONCEPT_CATALOG,
    actor_empleado_id: Optional[str] = None,
    source: str = "catalog_sheet",
) -> dict[str, Any]:
    """Replace all budget partidas for one project from a catalog worksheet."""
    await ensure_budget_schema(session)
    tournament = await _resolve_tournament_for_budget_concept(
        session,
        tournament_id=tournament_id,
    )
    catalog_rows = _iter_budget_concept_catalog_phase_rows(
        workbook_path,
        sheet_name=sheet_name,
    )
    if not catalog_rows:
        raise ValueError(
            f"No se encontraron partidas en la hoja «{sheet_name}» del catálogo."
        )
    if (
        _safe_str(catalog_rows[0].get("tournament_code")).upper()
        != _safe_str(tournament.get("tournament_code")).upper()
        and _safe_str(sheet_name).upper()
        != _safe_str(tournament.get("tournament_code")).upper()
    ):
        # Allow explicit sheet selection even when code differs from derived alias.
        pass

    await session.execute(
        text(
            """
            DELETE FROM budget_concepts
            WHERE tournament_id = CAST(:tournament_id AS uuid)
               OR (
                    COALESCE(tournament_code, '') = :tournament_code
                    AND tournament_id IS NULL
               )
            """
        ),
        {
            "tournament_id": tournament["tournament_id"],
            "tournament_code": tournament["tournament_code"] or "",
        },
    )

    created = 0
    for row in catalog_rows:
        mapped_phase = _map_catalog_phase_label_to_etapa(
            row.get("catalog_phase_break_label"),
            tournament.get("etapas"),
        )
        metadata = build_budget_concept_scope_metadata(
            [mapped_phase] if mapped_phase else [],
            tournament_etapas=tournament.get("etapas"),
            tournament_categorias=[],
        )
        metadata.update(
            {
                "sheet_name": sheet_name,
                "sheet_row_index": row.get("metadata", {}).get("sheet_row_index"),
                "catalog_phase_break_label": row.get("catalog_phase_break_label"),
            }
        )
        await session.execute(
            text(
                """
                INSERT INTO budget_concepts (
                    id, tournament_id, tournament_code, tournament_name,
                    concept_name, concept_key, active, source, metadata,
                    created_by_empleado_id, created_at, updated_at
                ) VALUES (
                    :id, CAST(:tournament_id AS uuid), :tournament_code, :tournament_name,
                    :concept_name, :concept_key, TRUE, :source, CAST(:metadata AS jsonb),
                    :created_by_empleado_id, NOW(), NOW()
                )
                """
            ),
            {
                "id": str(uuid.uuid4()),
                "tournament_id": tournament["tournament_id"],
                "tournament_code": tournament["tournament_code"],
                "tournament_name": tournament["tournament_name"],
                "concept_name": row.get("concept_name"),
                "concept_key": row.get("concept_key"),
                "source": _safe_str(source) or "catalog_sheet",
                "metadata": json.dumps(metadata, ensure_ascii=False),
                "created_by_empleado_id": actor_empleado_id,
            },
        )
        created += 1

    await session.commit()
    return {
        "ok": True,
        "tournament_id": tournament["tournament_id"],
        "tournament_name": tournament["tournament_name"],
        "sheet_name": sheet_name,
        "created": created,
    }


def _iter_budget_concept_catalog_rows(
    workbook_path: str | Path = DEFAULT_BUDGET_CONCEPT_CATALOG,
) -> list[dict[str, Any]]:
    path = Path(workbook_path)
    if not path.exists():
        return []
    workbook = load_workbook(path, data_only=True)
    rows: list[dict[str, Any]] = []
    for sheet in workbook.worksheets:
        title_candidates = [
            _safe_str(sheet.cell(row=row_index, column=1).value)
            for row_index in range(1, min(sheet.max_row, 4) + 1)
            if _safe_str(sheet.cell(row=row_index, column=1).value)
        ]
        tournament_name = (
            title_candidates[0] if title_candidates else _safe_str(sheet.title)
        )
        tournament_code = _derive_budget_tournament_code(sheet.title, tournament_name)
        header_row = None
        dimension_headers: list[str] = []
        for row_index in range(1, sheet.max_row + 1):
            first_value = _safe_str(sheet.cell(row=row_index, column=1).value)
            if first_value.lower() == "concepto":
                header_row = row_index
                dimension_headers = [
                    _safe_str(sheet.cell(row=row_index, column=col_index).value)
                    for col_index in range(2, sheet.max_column + 1)
                    if _safe_str(sheet.cell(row=row_index, column=col_index).value)
                ]
                break
        if header_row is None:
            continue
        sheet_rows: list[tuple[int, str, list[str]]] = []
        has_phase_breaks = False
        for row_index in range(header_row + 1, sheet.max_row + 1):
            concept_name = _safe_str(sheet.cell(row=row_index, column=1).value)
            trailing_values = [
                _safe_str(sheet.cell(row=row_index, column=col_index).value)
                for col_index in range(2, sheet.max_column + 1)
            ]
            if not concept_name:
                continue
            if _is_budget_phase_break_label(concept_name, trailing_values):
                has_phase_breaks = True
            sheet_rows.append((row_index, concept_name, trailing_values))

        aggregated_rows: dict[str, dict[str, Any]] = {}
        current_phase_label: Optional[str] = None
        for row_index, concept_name, trailing_values in sheet_rows:
            if _is_budget_phase_break_label(concept_name, trailing_values):
                current_phase_label = concept_name
                continue
            concept_key = _normalize_budget_key(concept_name)
            if not concept_key:
                continue
            entry = aggregated_rows.setdefault(
                concept_key,
                {
                    "tournament_code": tournament_code,
                    "tournament_name": tournament_name,
                    "concept_name": concept_name,
                    "concept_key": concept_key,
                    "metadata": {
                        "sheet_name": sheet.title,
                        "sheet_headers": dimension_headers,
                        "sheet_row_indexes": [],
                        "applicable_phase_labels": [],
                        "applicable_phase_keys": [],
                        "applicable_subproject_labels": [],
                        "applicable_subproject_keys": [],
                    },
                },
            )
            metadata = entry["metadata"]
            metadata["sheet_row_indexes"].append(row_index)
            if has_phase_breaks:
                if current_phase_label:
                    phase_labels = metadata["applicable_phase_labels"]
                    if current_phase_label not in phase_labels:
                        phase_labels.append(current_phase_label)
                    phase_keys = metadata["applicable_phase_keys"]
                    for key in sorted(_budget_scope_aliases(current_phase_label)):
                        if key not in phase_keys:
                            phase_keys.append(key)
            elif dimension_headers:
                subproject_labels = metadata["applicable_subproject_labels"]
                subproject_keys = metadata["applicable_subproject_keys"]
                for header in dimension_headers:
                    if not header:
                        continue
                    if header not in subproject_labels:
                        subproject_labels.append(header)
                    for key in sorted(_budget_scope_aliases(header)):
                        if key not in subproject_keys:
                            subproject_keys.append(key)
            if any(trailing_values):
                metadata["sheet_dimension_values"] = trailing_values
        for entry in aggregated_rows.values():
            metadata = entry["metadata"]
            has_scope = bool(
                metadata["applicable_phase_keys"]
                or metadata["applicable_subproject_keys"]
            )
            metadata["scope_mode"] = "phase_scoped" if has_scope else "global"
        rows.extend(aggregated_rows.values())
    return rows


@lru_cache(maxsize=2)
def _budget_catalog_scope_index(
    workbook_path: str = str(DEFAULT_BUDGET_CONCEPT_CATALOG),
) -> dict[tuple[str, str], dict[str, Any]]:
    index: dict[tuple[str, str], dict[str, Any]] = {}
    for row in _iter_budget_concept_catalog_rows(workbook_path):
        tournament_code = _safe_str(row.get("tournament_code")).upper()
        concept_key = _safe_str(row.get("concept_key"))
        metadata = row.get("metadata") if isinstance(row.get("metadata"), dict) else {}
        if tournament_code and concept_key and metadata:
            index[(tournament_code, concept_key)] = metadata
    return index


def _merge_budget_concept_metadata(
    stored_metadata: dict[str, Any],
    catalog_metadata: dict[str, Any],
    *,
    source: Optional[str] = None,
) -> dict[str, Any]:
    merged = dict(stored_metadata or {})
    if _safe_str(source) == "admin_ui":
        return merged
    for key in (
        "sheet_name",
        "sheet_headers",
        "sheet_row_indexes",
        "sheet_dimension_values",
        "applicable_phase_labels",
        "applicable_phase_keys",
        "applicable_subproject_labels",
        "applicable_subproject_keys",
    ):
        if key not in merged and key in catalog_metadata:
            merged[key] = catalog_metadata[key]
    return merged


def budget_concept_matches_fase(
    concept: Optional[dict[str, Any]],
    fase: Optional[str],
) -> bool:
    if concept is None:
        return False
    selected_aliases = _budget_scope_aliases(fase)
    if not selected_aliases:
        return True
    metadata = (
        concept.get("metadata") if isinstance(concept.get("metadata"), dict) else {}
    )
    applicable_keys = {
        _safe_str(key)
        for key in (
            list(metadata.get("applicable_phase_keys") or [])
            + list(metadata.get("applicable_subproject_keys") or [])
        )
        if _safe_str(key)
    }
    if not applicable_keys:
        # Empty legacy metadata is not evidence that a concept applies to every
        # phase. Only records explicitly saved as global may bypass the filter.
        return _safe_str(metadata.get("scope_mode")).lower() == "global"
    return bool(applicable_keys & selected_aliases)


async def list_budget_concepts(
    session: AsyncSession,
    *,
    tournament_id: Optional[str] = None,
    tournament_code: Optional[str] = None,
    budget_direction: Optional[str] = None,
    active_only: bool = True,
    limit: int = 2000,
) -> list[dict[str, Any]]:
    # Schema compatibility is established by the application startup guard.
    # Listing the catalog is a request-path read and must not acquire DDL locks.
    filters = []
    params: dict[str, Any] = {"limit": max(1, min(limit, 5000))}
    clean_direction = _safe_str(budget_direction)
    if clean_direction:
        filters.append("COALESCE(bc.budget_direction, 'expense') = :budget_direction")
        params["budget_direction"] = normalize_budget_line_direction(clean_direction)
    if active_only:
        filters.append("bc.active = TRUE")
    if tournament_id:
        filters.append("CAST(bc.tournament_id AS text) = :tournament_id")
        params["tournament_id"] = tournament_id
    elif tournament_code:
        aliases = sorted(budget_alias_candidates(tournament_code))
        if aliases:
            filters.append("UPPER(COALESCE(bc.tournament_code, '')) = ANY(:aliases)")
            params["aliases"] = aliases
    where_clause = f"WHERE {' AND '.join(filters)}" if filters else ""
    rows = (
        (
            await session.execute(
                text(
                    f"""
                SELECT
                    bc.id,
                    bc.tournament_id,
                    bc.tournament_code,
                    bc.tournament_name,
                    bc.concept_name,
                    bc.concept_key,
                    COALESCE(bc.budget_direction, 'expense') AS budget_direction,
                    bc.active,
                    bc.source,
                    bc.metadata,
                    bc.cuenta_contable_id,
                    cc.codigo AS cuenta_contable_codigo,
                    cc.nombre AS cuenta_contable_nombre,
                    bc.pasivo_cuenta_contable_id,
                    pcc.codigo AS pasivo_cuenta_contable_codigo,
                    pcc.nombre AS pasivo_cuenta_contable_nombre,
                    bc.created_by_empleado_id,
                    bc.created_at,
                    bc.updated_at
                FROM budget_concepts bc
                LEFT JOIN cuentas_contables cc
                    ON cc.id = bc.cuenta_contable_id
                LEFT JOIN cuentas_contables pcc
                    ON pcc.id = bc.pasivo_cuenta_contable_id
                {where_clause}
                ORDER BY bc.tournament_name ASC, bc.concept_name ASC
                LIMIT :limit
                """
                ),
                params,
            )
        )
        .mappings()
        .all()
    )
    return [
        {
            "id": _safe_str(row.get("id")) or None,
            "tournament_id": _safe_str(row.get("tournament_id")) or None,
            "tournament_code": _safe_str(row.get("tournament_code")) or None,
            "tournament_name": _safe_str(row.get("tournament_name")) or None,
            "concept_name": _safe_str(row.get("concept_name")) or None,
            "concept_key": _safe_str(row.get("concept_key")) or None,
            "budget_direction": normalize_budget_line_direction(
                _safe_str(row.get("budget_direction"))
            ),
            "active": bool(row.get("active")),
            "source": _safe_str(row.get("source")) or None,
            "cuenta_contable_id": _safe_str(row.get("cuenta_contable_id")) or None,
            "cuenta_contable_codigo": _safe_str(row.get("cuenta_contable_codigo"))
            or None,
            "cuenta_contable_nombre": _safe_str(row.get("cuenta_contable_nombre"))
            or None,
            "pasivo_cuenta_contable_id": _safe_str(row.get("pasivo_cuenta_contable_id"))
            or None,
            "pasivo_cuenta_contable_codigo": _safe_str(
                row.get("pasivo_cuenta_contable_codigo")
            )
            or None,
            "pasivo_cuenta_contable_nombre": _safe_str(
                row.get("pasivo_cuenta_contable_nombre")
            )
            or None,
            "metadata": _merge_budget_concept_metadata(
                row.get("metadata") if isinstance(row.get("metadata"), dict) else {},
                _budget_catalog_scope_index().get(
                    (
                        _safe_str(row.get("tournament_code")).upper(),
                        _safe_str(row.get("concept_key")),
                    ),
                    {},
                ),
                source=_safe_str(row.get("source")) or None,
            ),
            "created_by_empleado_id": _safe_str(row.get("created_by_empleado_id"))
            or None,
            "created_at": (
                row.get("created_at").isoformat() if row.get("created_at") else None
            ),
            "updated_at": (
                row.get("updated_at").isoformat() if row.get("updated_at") else None
            ),
        }
        for row in rows
    ]


async def resolve_budget_concept(
    session: AsyncSession,
    *,
    budget_concept_id: Optional[str],
    tournament_id: Optional[str] = None,
    tournament_code: Optional[str] = None,
    fase: Optional[str] = None,
    budget_direction: Optional[str] = None,
) -> Optional[dict[str, Any]]:
    concept_id = _safe_str(budget_concept_id)
    if not concept_id:
        return None
    concepts = await list_budget_concepts(
        session,
        budget_direction=budget_direction,
        active_only=True,
        limit=5000,
    )
    concept = next((item for item in concepts if item["id"] == concept_id), None)
    if concept is None:
        return None
    if tournament_id and concept.get("tournament_id") not in {None, tournament_id}:
        return None
    if tournament_code:
        aliases = budget_alias_candidates(tournament_code)
        concept_aliases = budget_alias_candidates(
            concept.get("tournament_code") or "",
            concept.get("tournament_name") or "",
        )
        if aliases and concept_aliases and not (aliases & concept_aliases):
            return None
    if not budget_concept_matches_fase(concept, fase):
        return None
    return concept


def build_budget_concept_scope_metadata(
    scope_labels: Optional[list[str]] = None,
    *,
    tournament_etapas: Optional[list[str]] = None,
    tournament_categorias: Optional[list[str]] = None,
) -> dict[str, Any]:
    labels = [_safe_str(label) for label in (scope_labels or []) if _safe_str(label)]
    if not labels:
        return {
            "scope_mode": "global",
            "applicable_phase_labels": [],
            "applicable_phase_keys": [],
            "applicable_subproject_labels": [],
            "applicable_subproject_keys": [],
        }
    etapa_lookup = {
        _safe_str(label).lower(): _safe_str(label)
        for label in (tournament_etapas or [])
        if _safe_str(label)
    }
    categoria_lookup = {
        _safe_str(label).lower(): _safe_str(label)
        for label in (tournament_categorias or [])
        if _safe_str(label)
    }
    phase_labels: list[str] = []
    subproject_labels: list[str] = []
    for label in labels:
        normalized = label.lower()
        if normalized in categoria_lookup:
            canonical = categoria_lookup[normalized]
            if canonical not in subproject_labels:
                subproject_labels.append(canonical)
        elif normalized in etapa_lookup:
            canonical = etapa_lookup[normalized]
            if canonical not in phase_labels:
                phase_labels.append(canonical)
        else:
            if label not in phase_labels:
                phase_labels.append(label)
    phase_keys: list[str] = []
    for label in phase_labels:
        for key in sorted(_budget_scope_aliases(label)):
            if key not in phase_keys:
                phase_keys.append(key)
    subproject_keys: list[str] = []
    for label in subproject_labels:
        for key in sorted(_budget_scope_aliases(label)):
            if key not in subproject_keys:
                subproject_keys.append(key)
    return {
        "scope_mode": "phase_scoped",
        "applicable_phase_labels": phase_labels,
        "applicable_phase_keys": phase_keys,
        "applicable_subproject_labels": subproject_labels,
        "applicable_subproject_keys": subproject_keys,
    }


def budget_concept_scope_summary(metadata: Optional[dict[str, Any]]) -> str:
    payload = metadata if isinstance(metadata, dict) else {}
    labels = [
        _safe_str(label)
        for label in (
            list(payload.get("applicable_phase_labels") or [])
            + list(payload.get("applicable_subproject_labels") or [])
        )
        if _safe_str(label)
    ]
    if not labels:
        return (
            "Todas las fases / subproyectos"
            if _safe_str(payload.get("scope_mode")).lower() == "global"
            else "Sin alcance configurado"
        )
    return ", ".join(labels)


_BUDGET_SCOPE_METADATA_KEYS = (
    "scope_mode",
    "applicable_phase_labels",
    "applicable_phase_keys",
    "applicable_subproject_labels",
    "applicable_subproject_keys",
)


def cleared_budget_concept_scope_metadata(
    stored_metadata: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    """Preserve non-scope metadata while resetting partida to all fases/subproyectos."""
    merged = dict(stored_metadata or {})
    empty_scope = build_budget_concept_scope_metadata([])
    for key in _BUDGET_SCOPE_METADATA_KEYS:
        merged[key] = empty_scope[key]
    return merged


def _merge_budget_concept_scope_metadata(
    stored_metadata: dict[str, Any],
    scope_labels: Optional[list[str]],
    *,
    tournament_etapas: Optional[list[str]] = None,
    tournament_categorias: Optional[list[str]] = None,
) -> dict[str, Any]:
    merged = dict(stored_metadata or {})
    scope_metadata = build_budget_concept_scope_metadata(
        scope_labels,
        tournament_etapas=tournament_etapas,
        tournament_categorias=tournament_categorias,
    )
    for key in _BUDGET_SCOPE_METADATA_KEYS:
        merged[key] = scope_metadata[key]
    return merged


async def clear_budget_concept_scope_for_tournament(
    session: AsyncSession,
    *,
    tournament_id: str,
    commit: bool = False,
) -> int:
    """Reset scoped partidas for a tournament so they apply to all fases/subproyectos."""
    await ensure_budget_schema(session)
    clean_id = _safe_str(tournament_id)
    if not clean_id:
        return 0
    rows = (
        (
            await session.execute(
                text(
                    """
                SELECT id, metadata
                FROM budget_concepts
                WHERE CAST(tournament_id AS text) = :tournament_id
                """
                ),
                {"tournament_id": clean_id},
            )
        )
        .mappings()
        .all()
    )
    updated = 0
    for row in rows:
        stored = row.get("metadata") if isinstance(row.get("metadata"), dict) else {}
        cleared = cleared_budget_concept_scope_metadata(stored)
        if all(not cleared.get(key) for key in _BUDGET_SCOPE_METADATA_KEYS) and all(
            not stored.get(key) for key in _BUDGET_SCOPE_METADATA_KEYS
        ):
            continue
        await session.execute(
            text(
                """
                UPDATE budget_concepts
                SET metadata = CAST(:metadata AS jsonb),
                    updated_at = NOW()
                WHERE id = :concept_id
                """
            ),
            {
                "concept_id": row.get("id"),
                "metadata": json.dumps(cleared, ensure_ascii=False),
            },
        )
        updated += 1
    if commit:
        await session.commit()
    return updated


async def _resolve_tournament_for_budget_concept(
    session: AsyncSession,
    *,
    tournament_id: str,
) -> dict[str, str]:
    clean_id = _safe_str(tournament_id)
    if not clean_id:
        raise ValueError("Debe seleccionar un proyecto.")
    row = (
        (
            await session.execute(
                text(
                    """
                SELECT id, name, etapas, categorias
                FROM tournaments
                WHERE id = :tournament_id
                LIMIT 1
                """
                ),
                {"tournament_id": clean_id},
            )
        )
        .mappings()
        .first()
    )
    if not row:
        raise ValueError("Proyecto no encontrado.")
    tournament_name = _safe_str(row.get("name")) or "Sin proyecto"
    tournament_code = _derive_budget_tournament_code(tournament_name, tournament_name)
    etapas = row.get("etapas") if isinstance(row.get("etapas"), list) else []
    categorias = (
        row.get("categorias") if isinstance(row.get("categorias"), list) else []
    )
    return {
        "tournament_id": _safe_str(row.get("id")) or clean_id,
        "tournament_code": tournament_code,
        "tournament_name": tournament_name,
        "etapas": [_safe_str(value) for value in etapas if _safe_str(value)],
        "categorias": [_safe_str(value) for value in categorias if _safe_str(value)],
    }


async def get_budget_concept(
    session: AsyncSession,
    *,
    concept_id: str,
    ensure_schema: bool = True,
) -> Optional[dict[str, Any]]:
    clean_id = _safe_str(concept_id)
    if not clean_id:
        return None
    if ensure_schema:
        await ensure_budget_schema(session)
    row = (
        (
            await session.execute(
                text(
                    """
                SELECT
                    bc.id,
                    bc.tournament_id,
                    bc.tournament_code,
                    bc.tournament_name,
                    bc.concept_name,
                    bc.concept_key,
                    COALESCE(bc.budget_direction, 'expense') AS budget_direction,
                    bc.active,
                    bc.source,
                    bc.metadata,
                    bc.cuenta_contable_id,
                    cc.codigo AS cuenta_contable_codigo,
                    cc.nombre AS cuenta_contable_nombre,
                    bc.pasivo_cuenta_contable_id,
                    pcc.codigo AS pasivo_cuenta_contable_codigo,
                    pcc.nombre AS pasivo_cuenta_contable_nombre,
                    bc.created_by_empleado_id,
                    bc.created_at,
                    bc.updated_at
                FROM budget_concepts bc
                LEFT JOIN cuentas_contables cc
                    ON cc.id = bc.cuenta_contable_id
                LEFT JOIN cuentas_contables pcc
                    ON pcc.id = bc.pasivo_cuenta_contable_id
                WHERE bc.id = :concept_id
                LIMIT 1
                """
                ),
                {"concept_id": clean_id},
            )
        )
        .mappings()
        .first()
    )
    if not row:
        return None
    metadata = _merge_budget_concept_metadata(
        row.get("metadata") if isinstance(row.get("metadata"), dict) else {},
        _budget_catalog_scope_index().get(
            (
                _safe_str(row.get("tournament_code")).upper(),
                _safe_str(row.get("concept_key")),
            ),
            {},
        ),
        source=_safe_str(row.get("source")) or None,
    )
    return {
        "id": _safe_str(row.get("id")) or None,
        "tournament_id": _safe_str(row.get("tournament_id")) or None,
        "tournament_code": _safe_str(row.get("tournament_code")) or None,
        "tournament_name": _safe_str(row.get("tournament_name")) or None,
        "concept_name": _safe_str(row.get("concept_name")) or None,
        "concept_key": _safe_str(row.get("concept_key")) or None,
        "budget_direction": normalize_budget_line_direction(
            _safe_str(row.get("budget_direction"))
        ),
        "active": bool(row.get("active")),
        "source": _safe_str(row.get("source")) or None,
        "cuenta_contable_id": _safe_str(row.get("cuenta_contable_id")) or None,
        "cuenta_contable_codigo": _safe_str(row.get("cuenta_contable_codigo"))
        or None,
        "cuenta_contable_nombre": _safe_str(row.get("cuenta_contable_nombre"))
        or None,
        "pasivo_cuenta_contable_id": _safe_str(row.get("pasivo_cuenta_contable_id"))
        or None,
        "pasivo_cuenta_contable_codigo": _safe_str(
            row.get("pasivo_cuenta_contable_codigo")
        )
        or None,
        "pasivo_cuenta_contable_nombre": _safe_str(
            row.get("pasivo_cuenta_contable_nombre")
        )
        or None,
        "metadata": metadata,
        "created_by_empleado_id": _safe_str(row.get("created_by_empleado_id"))
        or None,
        "created_at": (
            row.get("created_at").isoformat() if row.get("created_at") else None
        ),
        "updated_at": (
            row.get("updated_at").isoformat() if row.get("updated_at") else None
        ),
    }


async def create_budget_concept(
    session: AsyncSession,
    *,
    tournament_id: str,
    concept_name: str,
    scope_labels: Optional[list[str]] = None,
    cuenta_contable_id: Optional[str] = None,
    pasivo_cuenta_contable_id: Optional[str] = None,
    cxc_cuenta_contable_id: Optional[str] = None,
    budget_direction: Optional[str] = None,
    actor_empleado_id: Optional[str] = None,
    source: str = "admin_ui",
    commit: bool = True,
    concept_key: Optional[str] = None,
    extra_metadata: Optional[dict[str, Any]] = None,
    ensure_schema: bool = True,
) -> dict[str, Any]:
    if ensure_schema:
        await ensure_budget_schema(session)
    tournament = await _resolve_tournament_for_budget_concept(
        session,
        tournament_id=tournament_id,
    )
    clean_name = _safe_str(concept_name)
    resolved_concept_key = _safe_str(concept_key) or _normalize_budget_key(clean_name)
    if not clean_name or not resolved_concept_key:
        raise ValueError("El nombre de la partida presupuestal es obligatorio.")
    clean_direction = normalize_budget_line_direction(budget_direction)
    existing = (
        (
            await session.execute(
                text(
                    """
                SELECT id
                FROM budget_concepts
                WHERE COALESCE(tournament_code, '') = :tournament_code
                  AND concept_key = :concept_key
                  AND active = TRUE
                LIMIT 1
                """
                ),
                {
                    "tournament_code": tournament["tournament_code"] or "",
                    "concept_key": resolved_concept_key,
                },
            )
        )
        .mappings()
        .first()
    )
    if existing:
        raise ValueError(
            "Ya existe una partida con ese nombre para el proyecto seleccionado."
        )
    concept_id = str(uuid.uuid4())
    metadata = build_budget_concept_scope_metadata(
        scope_labels,
        tournament_etapas=tournament.get("etapas"),
        tournament_categorias=tournament.get("categorias") or [],
    )
    if isinstance(extra_metadata, dict):
        metadata.update(extra_metadata)
    resolved_cuenta_id: Optional[str] = None
    clean_cuenta = _safe_str(cuenta_contable_id)
    if clean_cuenta:
        resolved_cuenta_id = await validate_active_cuenta_contable_id(
            session, clean_cuenta
        )
    resolved_pasivo_id: Optional[str] = None
    clean_pasivo = _safe_str(pasivo_cuenta_contable_id)
    if clean_pasivo:
        resolved_pasivo_id = await validate_active_cuenta_contable_id(
            session, clean_pasivo
        )
    resolved_cxc_id: Optional[str] = None
    if _safe_str(cxc_cuenta_contable_id):
        resolved_cxc_id = await validate_active_cuenta_contable_id(session, _safe_str(cxc_cuenta_contable_id))
    await session.execute(
        text(
            """
            INSERT INTO budget_concepts (
                id, tournament_id, tournament_code, tournament_name,
                concept_name, concept_key, budget_direction, active, source, metadata,
                cuenta_contable_id, pasivo_cuenta_contable_id, cxc_cuenta_contable_id,
                created_by_empleado_id, created_at, updated_at
            ) VALUES (
                :id, :tournament_id, :tournament_code, :tournament_name,
                :concept_name, :concept_key, :budget_direction, TRUE, :source, CAST(:metadata AS jsonb),
                :cuenta_contable_id, :pasivo_cuenta_contable_id, :cxc_cuenta_contable_id,
                :created_by_empleado_id, NOW(), NOW()
            )
            """
        ),
        {
            "id": concept_id,
            "tournament_id": tournament["tournament_id"],
            "tournament_code": tournament["tournament_code"],
            "tournament_name": tournament["tournament_name"],
            "concept_name": clean_name,
            "concept_key": resolved_concept_key,
            "budget_direction": clean_direction,
            "source": _safe_str(source) or "admin_ui",
            "metadata": json.dumps(metadata, ensure_ascii=False),
            "cuenta_contable_id": resolved_cuenta_id,
            "pasivo_cuenta_contable_id": resolved_pasivo_id,
            "cxc_cuenta_contable_id": resolved_cxc_id,
            "created_by_empleado_id": actor_empleado_id,
        },
    )
    if commit:
        await session.commit()
    concept = await get_budget_concept(
        session, concept_id=concept_id, ensure_schema=False
    )
    if concept is None:
        raise ValueError("No se pudo crear la partida presupuestal.")
    return concept


async def update_budget_concept(
    session: AsyncSession,
    *,
    concept_id: str,
    concept_name: Optional[str] = None,
    tournament_id: Optional[str] = None,
    scope_labels: Optional[list[str]] = None,
    cuenta_contable_id: Optional[str] = None,
    cuenta_contable_provided: bool = False,
    pasivo_cuenta_contable_id: Optional[str] = None,
    pasivo_cuenta_contable_provided: bool = False,
    cxc_cuenta_contable_id: Optional[str] = None,
    cxc_cuenta_contable_provided: bool = False,
    budget_direction: Optional[str] = None,
    budget_direction_provided: bool = False,
    active: Optional[bool] = None,
    actor_empleado_id: Optional[str] = None,
    commit: bool = True,
    concept_key: Optional[str] = None,
    ensure_schema: bool = True,
) -> dict[str, Any]:
    del actor_empleado_id  # reserved for future audit events
    if ensure_schema:
        await ensure_budget_schema(session)
    current = await get_budget_concept(
        session, concept_id=concept_id, ensure_schema=False
    )
    if current is None:
        raise ValueError("Partida presupuestal no encontrada.")
    updates: dict[str, Any] = {}
    if tournament_id is not None:
        tournament = await _resolve_tournament_for_budget_concept(
            session,
            tournament_id=tournament_id,
        )
        updates["tournament_id"] = tournament["tournament_id"]
        updates["tournament_code"] = tournament["tournament_code"]
        updates["tournament_name"] = tournament["tournament_name"]
    clean_concept_key = _safe_str(concept_key)
    if concept_name is not None:
        clean_name = _safe_str(concept_name)
        current_name = _safe_str(current.get("concept_name"))
        resolved_concept_key = clean_concept_key or _normalize_budget_key(clean_name)
        current_key = _safe_str(current.get("concept_key"))
        if clean_name != current_name or (
            clean_concept_key and clean_concept_key != current_key
        ):
            if not clean_name or not resolved_concept_key:
                raise ValueError("El nombre de la partida presupuestal es obligatorio.")
            tournament_code = (
                _safe_str(
                    updates.get("tournament_code") or current.get("tournament_code")
                )
                or ""
            )
            duplicate = (
                (
                    await session.execute(
                        text(
                            """
                        SELECT id
                        FROM budget_concepts
                        WHERE COALESCE(tournament_code, '') = :tournament_code
                          AND concept_key = :concept_key
                          AND active = TRUE
                          AND id <> :concept_id
                        LIMIT 1
                        """
                        ),
                        {
                            "tournament_code": tournament_code,
                            "concept_key": resolved_concept_key,
                            "concept_id": concept_id,
                        },
                    )
                )
                .mappings()
                .first()
            )
            if duplicate:
                raise ValueError(
                    "Ya existe otra partida con ese nombre para el mismo proyecto."
                )
            updates["concept_name"] = clean_name
            updates["concept_key"] = resolved_concept_key
    if scope_labels is not None:
        stored_metadata = (
            current.get("metadata") if isinstance(current.get("metadata"), dict) else {}
        )
        tournament_etapas = None
        if tournament_id is not None:
            tournament = await _resolve_tournament_for_budget_concept(
                session,
                tournament_id=tournament_id,
            )
            tournament_etapas = tournament.get("etapas")
        elif updates.get("tournament_id"):
            tournament = await _resolve_tournament_for_budget_concept(
                session,
                tournament_id=str(updates.get("tournament_id")),
            )
            tournament_etapas = tournament.get("etapas")
        else:
            current_tid = _safe_str(current.get("tournament_id"))
            if current_tid:
                tournament = await _resolve_tournament_for_budget_concept(
                    session,
                    tournament_id=current_tid,
                )
                tournament_etapas = tournament.get("etapas")
        updates["metadata"] = json.dumps(
            _merge_budget_concept_scope_metadata(
                stored_metadata,
                scope_labels,
                tournament_etapas=tournament_etapas,
                tournament_categorias=[],
            ),
            ensure_ascii=False,
        )
    if active is not None:
        updates["active"] = bool(active)
    if cuenta_contable_provided:
        clean_cuenta = _safe_str(cuenta_contable_id)
        if clean_cuenta:
            updates["cuenta_contable_id"] = await validate_active_cuenta_contable_id(
                session, clean_cuenta
            )
        else:
            updates["cuenta_contable_id"] = None
    if pasivo_cuenta_contable_provided:
        clean_pasivo = _safe_str(pasivo_cuenta_contable_id)
        if clean_pasivo:
            updates["pasivo_cuenta_contable_id"] = (
                await validate_active_cuenta_contable_id(session, clean_pasivo)
            )
        else:
            updates["pasivo_cuenta_contable_id"] = None
    if cxc_cuenta_contable_provided:
        clean_cxc = _safe_str(cxc_cuenta_contable_id)
        updates["cxc_cuenta_contable_id"] = (
            await validate_active_cuenta_contable_id(session, clean_cxc) if clean_cxc else None
        )
    if budget_direction_provided:
        updates["budget_direction"] = normalize_budget_line_direction(
            budget_direction
        )
    if not updates:
        return current
    updates["source"] = "admin_ui"
    set_clause = ", ".join(f"{column} = :{column}" for column in updates)
    await session.execute(
        text(
            f"""
            UPDATE budget_concepts
            SET {set_clause},
                updated_at = NOW()
            WHERE id = :concept_id
            """
        ),
        {**updates, "concept_id": concept_id},
    )
    if commit:
        await session.commit()
    updated = await get_budget_concept(
        session, concept_id=concept_id, ensure_schema=False
    )
    if updated is None:
        raise ValueError("No se pudo actualizar la partida presupuestal.")
    return updated


async def hide_budget_concept(
    session: AsyncSession,
    *,
    concept_id: str,
    actor_empleado_id: Optional[str] = None,
    commit: bool = True,
) -> dict[str, Any]:
    """Soft-hide a budget partida from selectors without deleting the row."""
    return await update_budget_concept(
        session,
        concept_id=concept_id,
        active=False,
        actor_empleado_id=actor_empleado_id,
        commit=commit,
    )


async def bulk_save_budget_concepts(
    session: AsyncSession,
    *,
    rows: list[dict[str, Any]],
    actor_empleado_id: Optional[str] = None,
) -> dict[str, Any]:
    created = 0
    updated = 0
    for row in rows:
        concept_id = _safe_str(row.get("concept_id"))
        concept_name = _safe_str(row.get("concept_name"))
        tournament_id = _safe_str(row.get("tournament_id"))
        sub_proyecto = _safe_str(row.get("sub_proyecto"))
        concept_key = _safe_str(row.get("concept_key"))
        cuenta_contable_id = row.get("cuenta_contable_id")
        pasivo_cuenta_contable_id = row.get("pasivo_cuenta_contable_id")
        pasivo_cuenta_contable_provided = "pasivo_cuenta_contable_id" in row
        budget_direction = row.get("budget_direction")
        budget_direction_provided = "budget_direction" in row
        active_provided = "active" in row
        active = bool(row.get("active")) if active_provided else True
        if not concept_name and not concept_id:
            continue
        if not active and not concept_id:
            continue
        if not concept_name or not tournament_id:
            raise ValueError(
                "Cada partida requiere nombre y proyecto. Revise las filas del catálogo."
            )
        scope_labels = [sub_proyecto] if sub_proyecto else []
        cuenta_kwargs = {
            "cuenta_contable_id": cuenta_contable_id,
            "cuenta_contable_provided": True,
        }
        if pasivo_cuenta_contable_provided:
            cuenta_kwargs.update(
                {
                    "pasivo_cuenta_contable_id": pasivo_cuenta_contable_id,
                    "pasivo_cuenta_contable_provided": True,
                }
            )
        if budget_direction_provided:
            cuenta_kwargs.update(
                {
                    "budget_direction": budget_direction,
                    "budget_direction_provided": True,
                }
            )
        if concept_id:
            await update_budget_concept(
                session,
                concept_id=concept_id,
                concept_name=concept_name,
                tournament_id=tournament_id,
                scope_labels=scope_labels,
                active=active,
                actor_empleado_id=actor_empleado_id,
                commit=False,
                concept_key=concept_key or None,
                ensure_schema=False,
                **cuenta_kwargs,
            )
            updated += 1
        else:
            await create_budget_concept(
                session,
                tournament_id=tournament_id,
                concept_name=concept_name,
                scope_labels=scope_labels,
                cuenta_contable_id=_safe_str(cuenta_contable_id) or None,
                pasivo_cuenta_contable_id=_safe_str(pasivo_cuenta_contable_id) or None,
                budget_direction=budget_direction,
                actor_empleado_id=actor_empleado_id,
                source="admin_ui",
                commit=False,
                concept_key=concept_key or None,
            )
            created += 1
    await session.commit()
    return {"created": created, "updated": updated, "total": created + updated}


def _budget_catalog_active_value(value: Any) -> bool:
    raw = _safe_str(value).lower()
    if raw in {"", "1", "true", "si", "sí", "yes", "y", "activo", "active"}:
        return True
    if raw in {"0", "false", "no", "n", "inactivo", "inactive"}:
        return False
    raise ValueError(f"Valor activo inválido: {_safe_str(value)}")


def _budget_catalog_direction_value(value: Any, *, default: str = "expense") -> str:
    raw = _normalize_budget_key(value)
    if not raw:
        return normalize_budget_line_direction(default)
    if raw in {"egreso", "egresos", "gasto", "gastos", "expense", "expenses"}:
        return "expense"
    if raw in {"ingreso", "ingresos", "income", "incomes"}:
        return "income"
    if raw in {"cargo", "debe"}:
        return "expense"
    if raw in {"abono", "haber"}:
        return "income"
    if _safe_str(default):
        return normalize_budget_line_direction(default)
    raise ValueError(f"Tipo inválido: {_safe_str(value)}")


def _budget_catalog_direction_label(value: Any) -> str:
    return "ingreso" if normalize_budget_line_direction(value) == "income" else "egreso"


def _budget_catalog_scope_key_from_metadata(metadata: Any) -> str:
    payload = metadata if isinstance(metadata, dict) else {}
    for key in ("applicable_phase_labels", "applicable_subproject_labels"):
        labels = [
            _safe_str(label)
            for label in list(payload.get(key) or [])
            if _safe_str(label)
        ]
        if labels:
            return _normalize_budget_scope_key(labels[0])
    return ""


def generate_budget_concepts_catalog_xlsx(
    budget_concepts: list[dict[str, Any]],
) -> bytes:
    """Generate the editable catalog workbook used by admin import/export."""
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "catalogo"
    headers = [
        "id",
        "tipo",
        "partida",
        "proyecto",
        "sub_proyecto",
        "cuenta_presupuestal",
        "contracuenta_presupuestal",
        "activo",
    ]
    sheet.append(headers)
    for concept in sorted(
        budget_concepts,
        key=lambda item: (
            _safe_str(item.get("tournament_name")).lower(),
            _safe_str(item.get("concept_name")).lower(),
        ),
    ):
        metadata = (
            concept.get("metadata") if isinstance(concept.get("metadata"), dict) else {}
        )
        sheet.append(
            [
                _safe_str(concept.get("id")),
                _budget_catalog_direction_label(concept.get("budget_direction")),
                _safe_str(concept.get("concept_name")),
                _safe_str(concept.get("tournament_name")),
                _budget_catalog_scope_label_for_export(metadata),
                _safe_str(concept.get("cuenta_contable_codigo")),
                _safe_str(concept.get("pasivo_cuenta_contable_codigo")),
                "true" if concept.get("active") else "false",
            ]
        )
    widths = {
        "A": 38,
        "B": 14,
        "C": 32,
        "D": 30,
        "E": 28,
        "F": 18,
        "G": 24,
        "H": 12,
    }
    for column, width in widths.items():
        sheet.column_dimensions[column].width = width
    output = BytesIO()
    workbook.save(output)
    return output.getvalue()


def _budget_catalog_scope_label_for_export(metadata: dict[str, Any]) -> str:
    payload = metadata if isinstance(metadata, dict) else {}
    for key in ("applicable_phase_labels", "applicable_subproject_labels"):
        labels = [
            _safe_str(label)
            for label in list(payload.get(key) or [])
            if _safe_str(label)
        ]
        if labels:
            return labels[0]
    return ""


async def import_budget_concepts_upload(
    session: AsyncSession,
    *,
    actor_empleado_id: Optional[str],
    file_bytes: bytes,
    filename: str,
) -> dict[str, Any]:
    """Import editable budget concept catalog rows from CSV/XLSX."""
    await ensure_budget_schema(session)
    rows = _load_tabular_upload_rows(file_bytes=file_bytes, filename=filename)
    if not rows:
        raise ValueError("El archivo no contiene partidas presupuestales.")
    normalized_headers = {
        _normalize_budget_key(key) for key in rows[0].keys() if _safe_str(key)
    }
    required_headers = {"partida", "proyecto"}
    missing_headers = sorted(required_headers - normalized_headers)
    if missing_headers:
        raise ValueError(
            "El archivo no contiene las columnas requeridas: "
            + ", ".join(missing_headers)
        )

    tournament_rows = await _load_tournament_rows(session)
    active_tournament_rows = [row for row in tournament_rows if bool(row.get("active"))]
    concepts = await list_budget_concepts(session, active_only=False, limit=5000)
    concepts_by_id = {
        _safe_str(item.get("id")): item
        for item in concepts
        if _safe_str(item.get("id"))
    }
    concepts_by_stable_key: dict[tuple[str, str], list[dict[str, Any]]] = (
        defaultdict(list)
    )
    concepts_by_semantic_identity: dict[
        tuple[str, ...], list[dict[str, Any]]
    ] = defaultdict(list)
    for item in concepts:
        tournament_id = _safe_str(item.get("tournament_id"))
        concept_key = _safe_str(item.get("concept_key"))
        if tournament_id and concept_key:
            concepts_by_stable_key[(tournament_id, concept_key)].append(item)
        identity = budget_concept_semantic_identity(item)
        if identity is not None:
            concepts_by_semantic_identity[identity].append(item)
    prepared_rows: list[dict[str, Any]] = []
    errors: list[str] = []
    for index, row in enumerate(rows, start=2):
        raw_concept_id = _pick_upload_value(row, "id", "concept_id")
        concept_id = _safe_str(raw_concept_id)
        if not is_valid_budget_concept_identifier(raw_concept_id):
            errors.append(f"Fila {index}: id de partida inválido.")
            continue
        partida = _safe_str(
            _pick_upload_value(row, "partida", "concepto", "concept_name")
        )
        proyecto = _safe_str(
            _pick_upload_value(row, "proyecto", "torneo", "tournament_name")
        )
        sub_proyecto = _safe_str(
            _pick_upload_value(row, "sub_proyecto", "subproyecto", "fase", "phase")
        )
        direction_raw = _pick_upload_value(
            row,
            "tipo",
            "direccion",
            "budget_direction",
            "line_direction",
        )
        default_direction = (
            "income"
            if _pick_upload_value(row, "cuenta_contable_ingresos")
            or _pick_upload_value(row, "cuenta_contable_cuenta_por_cobrar")
            else "expense"
        )
        try:
            budget_direction = _budget_catalog_direction_value(
                direction_raw,
                default=default_direction,
            )
        except ValueError as exc:
            errors.append(f"Fila {index}: {exc}")
            continue
        cuenta_codigo = _safe_str(
            _pick_upload_value(
                row,
                "cuenta_presupuestal",
                "cuenta_contable",
                "cuenta_contable_codigo",
                "cuenta_contable_ingresos",
            )
        )
        contracuenta_codigo = _safe_str(
            _pick_upload_value(
                row,
                "contracuenta_presupuestal",
                "cuenta_pasivo",
                "pasivo",
                "cuenta_pasivo_codigo",
                "cuenta_contable_cuenta_por_cobrar",
            )
        )
        try:
            active = _budget_catalog_active_value(
                _pick_upload_value(row, "activo", "active")
            )
        except ValueError as exc:
            errors.append(f"Fila {index}: {exc}")
            continue
        if not partida and not concept_id:
            continue
        if not partida:
            errors.append(f"Fila {index}: partida es obligatoria.")
            continue
        if concept_id and concept_id not in concepts_by_id:
            errors.append(f"Fila {index}: id de partida no encontrado.")
            continue
        existing = concepts_by_id.get(concept_id) if concept_id else None
        tournament_id = _safe_str((existing or {}).get("tournament_id"))
        if not tournament_id:
            if not proyecto:
                errors.append(f"Fila {index}: proyecto es obligatorio.")
                continue
            tournament_id = _match_tournament_id(
                active_tournament_rows,
                tournament_code=proyecto,
                tournament_name=proyecto,
            )
            if not tournament_id:
                errors.append(
                    f"Fila {index}: proyecto {proyecto} no existe o está inactivo."
                )
                continue
        cuenta_id = None
        if cuenta_codigo:
            try:
                cuenta_id = await resolve_active_cuenta_contable_id_by_code(
                    session, cuenta_codigo
                )
            except ValueError as exc:
                errors.append(f"Fila {index}: {exc}")
                continue
        pasivo_id = None
        if contracuenta_codigo:
            try:
                pasivo_id = await resolve_active_cuenta_contable_id_by_code(
                    session, contracuenta_codigo
                )
            except ValueError as exc:
                errors.append(f"Fila {index}: {exc}")
                continue
        if existing is None:
            stable_key = (
                tournament_id,
                _scoped_budget_concept_key(partida, sub_proyecto),
            )
            stable_matches = concepts_by_stable_key.get(stable_key, [])
            candidate_identity = budget_concept_semantic_identity(
                {
                    "tournament_id": tournament_id,
                    "concept_name": partida,
                    "budget_direction": budget_direction,
                    "cuenta_contable_id": cuenta_id,
                    "metadata": build_budget_concept_scope_metadata(
                        [sub_proyecto] if sub_proyecto else []
                    ),
                }
            )
            semantic_matches = concepts_by_semantic_identity.get(
                candidate_identity, []
            )
            matches_by_id = {
                _safe_str(item.get("id")): item
                for item in [*stable_matches, *semantic_matches]
                if _safe_str(item.get("id"))
            }
            if len(matches_by_id) > 1:
                errors.append(
                    f"Fila {index}: el catálogo contiene partidas duplicadas; "
                    "depúrelas antes de importar."
                )
                continue
            if matches_by_id:
                existing = next(iter(matches_by_id.values()))
        prepared_rows.append(
            {
                "concept_id": _safe_str((existing or {}).get("id"))
                or concept_id
                or None,
                "concept_name": partida,
                "tournament_id": tournament_id,
                "sub_proyecto": sub_proyecto,
                "cuenta_contable_id": cuenta_id,
                "pasivo_cuenta_contable_id": pasivo_id,
                "budget_direction": budget_direction,
                "active": active,
                "concept_key": _scoped_budget_concept_key(partida, sub_proyecto),
            }
        )

    if errors:
        raise ValueError("; ".join(errors[:8]))
    if not prepared_rows:
        raise ValueError("No se encontraron registros válidos para importar.")
    result = await bulk_save_budget_concepts(
        session,
        rows=prepared_rows,
        actor_empleado_id=actor_empleado_id,
    )
    result["rows_processed"] = len(prepared_rows)
    return result


async def import_budget_concepts_catalog(
    session: AsyncSession,
    *,
    workbook_path: str | Path = DEFAULT_BUDGET_CONCEPT_CATALOG,
    actor_empleado_id: Optional[str] = None,
    source: str = "catalog_xlsx",
    force_overwrite: bool = False,
) -> dict[str, Any]:
    await ensure_budget_schema(session)
    concept_rows = _iter_budget_concept_catalog_rows(workbook_path)
    if not concept_rows:
        raise ValueError("No se encontraron conceptos presupuestales en el archivo.")
    tournament_rows = await _load_tournament_rows(session)
    created = 0
    updated = 0
    skipped = 0
    affected_codes: set[str] = set()
    for row in concept_rows:
        tournament_code = _safe_str(row.get("tournament_code")) or None
        tournament_name = _safe_str(row.get("tournament_name")) or "Sin torneo"
        concept_key = _safe_str(row.get("concept_key"))
        concept_name = _safe_str(row.get("concept_name"))
        if not concept_key or not concept_name:
            continue
        tournament_id = _match_tournament_id(
            tournament_rows,
            tournament_code=tournament_code,
            tournament_name=tournament_name,
        )
        if tournament_id:
            try:
                tournament = await _resolve_tournament_for_budget_concept(
                    session,
                    tournament_id=tournament_id,
                )
                tournament_name = tournament["tournament_name"]
            except ValueError:
                pass
        existing = (
            (
                await session.execute(
                    text(
                        """
                    SELECT id, source
                    FROM budget_concepts
                    WHERE COALESCE(tournament_code, '') = :tournament_code
                      AND concept_key = :concept_key
                    LIMIT 1
                    """
                    ),
                    {
                        "tournament_code": tournament_code or "",
                        "concept_key": concept_key,
                    },
                )
            )
            .mappings()
            .first()
        )
        if (
            existing
            and _safe_str(existing.get("source")) == "admin_ui"
            and not force_overwrite
        ):
            skipped += 1
            continue
        payload = {
            "tournament_id": tournament_id,
            "tournament_code": tournament_code,
            "tournament_name": tournament_name,
            "concept_name": concept_name,
            "concept_key": concept_key,
            "source": _safe_str(source) or "catalog_xlsx",
            "metadata": json.dumps(row.get("metadata") or {}, ensure_ascii=False),
            "created_by_empleado_id": actor_empleado_id,
        }
        if existing:
            await session.execute(
                text(
                    """
                    UPDATE budget_concepts
                    SET tournament_id = :tournament_id,
                        tournament_code = :tournament_code,
                        tournament_name = :tournament_name,
                        concept_name = :concept_name,
                        source = :source,
                        metadata = CAST(:metadata AS jsonb),
                        active = TRUE,
                        updated_at = NOW()
                    WHERE id = :id
                    """
                ),
                {**payload, "id": existing["id"]},
            )
            updated += 1
        else:
            await session.execute(
                text(
                    """
                    INSERT INTO budget_concepts (
                        id, tournament_id, tournament_code, tournament_name,
                        concept_name, concept_key, active, source, metadata,
                        created_by_empleado_id, created_at, updated_at
                    ) VALUES (
                        :id, :tournament_id, :tournament_code, :tournament_name,
                        :concept_name, :concept_key, TRUE, :source, CAST(:metadata AS jsonb),
                        :created_by_empleado_id, NOW(), NOW()
                    )
                    """
                ),
                {**payload, "id": str(uuid.uuid4())},
            )
            created += 1
        if tournament_code:
            affected_codes.add(tournament_code)
    await session.commit()
    return {
        "ok": True,
        "created": created,
        "updated": updated,
        "skipped": skipped,
        "tournaments_count": len(affected_codes),
        "concepts_count": created + updated,
        "workbook_path": str(Path(workbook_path)),
    }


COPA_TELMEX_TELCEL_2026_TOURNAMENT_ID = "67c556df-f953-4f99-8cab-87ed4d111b05"


async def restore_budget_concepts_for_tournament(
    session: AsyncSession,
    *,
    tournament_id: str,
    workbook_path: str | Path = DEFAULT_BUDGET_CONCEPT_CATALOG,
    source: str = "catalog_snapshot",
    actor_empleado_id: Optional[str] = None,
) -> dict[str, Any]:
    """Re-apply catalog metadata for one project without touching admin_ui rows."""
    await ensure_budget_schema(session)
    tournament = await _resolve_tournament_for_budget_concept(
        session,
        tournament_id=tournament_id,
    )
    catalog_by_key = {
        _safe_str(row.get("concept_key")): row
        for row in _iter_budget_concept_catalog_rows(workbook_path)
        if _safe_str(row.get("tournament_code")).upper()
        == _safe_str(tournament["tournament_code"]).upper()
    }
    if not catalog_by_key:
        raise ValueError(
            f"No hay partidas de catálogo para el código {tournament['tournament_code']}."
        )
    rows = (
        (
            await session.execute(
                text(
                    """
                SELECT id, concept_key, source
                FROM budget_concepts
                WHERE tournament_id = CAST(:tournament_id AS uuid)
                   OR (
                        COALESCE(tournament_code, '') = :tournament_code
                        AND tournament_id IS NULL
                   )
                """
                ),
                {
                    "tournament_id": tournament["tournament_id"],
                    "tournament_code": tournament["tournament_code"] or "",
                },
            )
        )
        .mappings()
        .all()
    )
    restored = 0
    skipped = 0
    for row in rows:
        if _safe_str(row.get("source")) == "admin_ui":
            skipped += 1
            continue
        concept_key = _safe_str(row.get("concept_key"))
        catalog_row = catalog_by_key.get(concept_key)
        if catalog_row is None:
            continue
        await session.execute(
            text(
                """
                UPDATE budget_concepts
                SET tournament_id = CAST(:tournament_id AS uuid),
                    tournament_code = :tournament_code,
                    tournament_name = :tournament_name,
                    concept_name = :concept_name,
                    metadata = CAST(:metadata AS jsonb),
                    source = :source,
                    active = TRUE,
                    updated_at = NOW()
                WHERE id = :id
                """
            ),
            {
                "id": row["id"],
                "tournament_id": tournament["tournament_id"],
                "tournament_code": tournament["tournament_code"],
                "tournament_name": tournament["tournament_name"],
                "concept_name": _safe_str(catalog_row.get("concept_name")),
                "metadata": json.dumps(
                    catalog_row.get("metadata") or {},
                    ensure_ascii=False,
                ),
                "source": _safe_str(source) or "catalog_snapshot",
            },
        )
        restored += 1
    await session.commit()
    return {
        "ok": True,
        "tournament_id": tournament["tournament_id"],
        "tournament_name": tournament["tournament_name"],
        "restored": restored,
        "skipped_admin_ui": skipped,
        "catalog_rows": len(catalog_by_key),
    }


def _load_tabular_upload_rows(
    *,
    file_bytes: bytes,
    filename: str,
) -> list[dict[str, Any]]:
    suffix = Path(filename or "").suffix.lower()
    if suffix == ".csv":
        text_data = file_bytes.decode("utf-8-sig")
        reader = csv.DictReader(StringIO(text_data))
        return [dict(row) for row in reader]
    if suffix in {".xlsx", ".xlsm", ".xltx", ".xltm"}:
        workbook = load_workbook(BytesIO(file_bytes), data_only=True)
        sheet = workbook.active
        headers = [
            _safe_str(cell)
            for cell in next(sheet.iter_rows(min_row=1, max_row=1, values_only=True))
        ]
        rows: list[dict[str, Any]] = []
        for values in sheet.iter_rows(min_row=2, values_only=True):
            if not any(value not in (None, "") for value in values):
                continue
            rows.append(
                {
                    headers[index] or f"column_{index+1}": values[index]
                    for index in range(min(len(headers), len(values)))
                }
            )
        if rows and not any(key for key in headers):
            raise ValueError("El archivo no tiene encabezados válidos.")
        return rows
    raise ValueError("Solo se permiten archivos CSV o XLSX.")


def _pick_upload_value(row: dict[str, Any], *keys: str) -> Any:
    normalized_row = {
        _normalize_budget_key(key): value
        for key, value in row.items()
        if _safe_str(key)
    }
    for key in keys:
        normalized_key = _normalize_budget_key(key)
        if normalized_key in normalized_row and normalized_row[normalized_key] not in (
            None,
            "",
        ):
            return normalized_row[normalized_key]
    return None


async def import_budget_lines_upload(
    session: AsyncSession,
    *,
    version_id: str,
    actor_empleado_id: Optional[str],
    file_bytes: bytes,
    filename: str,
    line_direction: Optional[str] = None,
) -> dict[str, Any]:
    await ensure_budget_schema(session)
    current = await get_budget_version(
        session, version_id=version_id, ensure_schema=False
    )
    if not _editable_version_status(current.get("status")):
        raise ValueError("Only draft or reforecast versions allow line imports")
    if current.get("source") == "distribution_revision":
        raise ValueError("La revisión de distribución no admite reimportar partidas")
    rows = _load_tabular_upload_rows(file_bytes=file_bytes, filename=filename)
    if not rows:
        raise ValueError("El archivo no contiene líneas presupuestales.")
    default_direction = (
        normalize_budget_line_direction(line_direction) if line_direction else None
    )
    concepts = await list_budget_concepts(session, active_only=True, limit=5000)
    concepts_by_scope: dict[tuple[str, str, str], dict[str, Any]] = {}
    for concept in concepts:
        concepts_by_scope[
            (
                _safe_str(concept.get("tournament_code")),
                _safe_str(concept.get("concept_key")),
                normalize_budget_line_direction(concept.get("budget_direction")),
            )
        ] = concept
    existing_lines = await list_budget_lines(session, version_id=version_id, limit=5000)
    existing_by_scope = {
        (
            _safe_str(line.get("tournament_code")),
            _safe_str(line.get("budget_concept_id") or ""),
            normalize_budget_line_direction(line.get("line_direction")),
        ): line
        for line in existing_lines
    }
    created = 0
    updated = 0
    for row in rows:
        tournament_value = _safe_str(
            _pick_upload_value(
                row, "torneo", "tournament", "torneo_codigo", "tournament_code"
            )
        )
        concept_value = _safe_str(
            _pick_upload_value(
                row, "partida_presupuestal", "concepto", "partida", "concept_name"
            )
        )
        amount_value = _pick_upload_value(
            row, "monto_anual", "presupuesto", "budget_amount"
        )
        direction_value = _pick_upload_value(
            row,
            "tipo",
            "direccion",
            "dirección",
            "line_direction",
            "budget_direction",
            "naturaleza",
        )
        clean_direction = default_direction or normalize_budget_line_direction(
            direction_value
        )
        if not tournament_value or not concept_value:
            raise ValueError("Cada fila debe incluir torneo y partida presupuestal.")
        tournament_code = _derive_budget_tournament_code(
            tournament_value, tournament_value
        )
        concept_key = _normalize_budget_key(concept_value)
        concept = concepts_by_scope.get((tournament_code, concept_key, clean_direction))
        if concept is None:
            raise ValueError(
                f"No existe la partida presupuestal '{concept_value}' para '{tournament_value}'."
            )
        budget_amount = _safe_decimal(amount_value)
        line_key = (tournament_code, _safe_str(concept.get("id")), clean_direction)
        line_updates = {
            "budget_concept_id": _safe_str(concept.get("id")),
            "concept_name": _safe_str(concept.get("concept_name")),
            "account_code_final": _safe_str(
                _pick_upload_value(row, "cuenta_final", "account_code_final")
            )
            or None,
            "phase": _safe_str(_pick_upload_value(row, "fase", "phase")) or None,
            "owner_name": _safe_str(
                _pick_upload_value(row, "responsable", "owner_name")
            )
            or None,
            "priority": _safe_str(_pick_upload_value(row, "prioridad", "priority"))
            or None,
            "criteria_note": _safe_str(
                _pick_upload_value(row, "criterio", "criteria_note")
            )
            or None,
            "observations": _safe_str(
                _pick_upload_value(row, "observaciones", "observations")
            )
            or None,
            "budget_amount": budget_amount,
        }
        monthly_plan: dict[int, dict[str, float]] = {}
        for month in range(1, BUDGET_WEEK_COUNT + 1):
            month_value = _pick_upload_value(
                row,
                f"semana_{month}",
                f"week_{month}",
                f"week_{month}_{clean_direction}",
                f"month_{month}",
                f"month_{month}_{clean_direction}",
                budget_period_label(month),
            )
            if month_value in (None, ""):
                continue
            monthly_plan.setdefault(month, {})
            if clean_direction == "income":
                monthly_plan[month]["expected_income_amount"] = _safe_decimal(
                    month_value
                )
            else:
                monthly_plan[month]["budget_expense_amount"] = _safe_decimal(
                    month_value
                )
        if monthly_plan and clean_direction == "expense":
            validate_budget_expense_plan_total(
                monthly_plan,
                budget_amount=budget_amount,
            )
        existing_line = existing_by_scope.get(line_key)
        if existing_line:
            updated_line = await update_budget_line(
                session,
                line_id=_safe_str(existing_line.get("id")),
                actor_empleado_id=actor_empleado_id,
                updates=line_updates,
            )
            if monthly_plan:
                await replace_budget_line_monthly_plan(
                    session,
                    budget_line_id=_safe_str(updated_line.get("id")),
                    actor_empleado_id=actor_empleado_id,
                    plan=monthly_plan,
                )
            existing_by_scope[line_key] = updated_line
            updated += 1
            continue
        created_line = await create_budget_line(
            session,
            version_id=version_id,
            actor_empleado_id=actor_empleado_id,
            tournament_code=_safe_str(concept.get("tournament_code"))
            or tournament_code,
            tournament_name=_safe_str(concept.get("tournament_name"))
            or tournament_value,
            budget_concept_id=_safe_str(concept.get("id")),
            concept_name=_safe_str(concept.get("concept_name")) or concept_value,
            line_direction=clean_direction,
            account_code_final=line_updates["account_code_final"],
            phase=line_updates["phase"],
            owner_name=line_updates["owner_name"],
            priority=line_updates["priority"],
            budget_amount=budget_amount,
            criteria_note=line_updates["criteria_note"],
            observations=line_updates["observations"],
        )
        if monthly_plan:
            await replace_budget_line_monthly_plan(
                session,
                budget_line_id=_safe_str(created_line.get("id")),
                actor_empleado_id=actor_empleado_id,
                plan=monthly_plan,
            )
        existing_by_scope[line_key] = created_line
        created += 1
    return {
        "ok": True,
        "created": created,
        "updated": updated,
        "rows_processed": created + updated,
        "filename": filename,
    }


def load_budget_artifact_rows(
    artifact_path: str | Path = DEFAULT_BUDGET_ARTIFACT,
) -> list[dict[str, Any]]:
    path = Path(artifact_path)
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        return [dict(row) for row in reader]


def build_budget_artifact_snapshot(
    rows: list[dict[str, Any]],
    *,
    artifact_path: str | Path = DEFAULT_BUDGET_ARTIFACT,
    tournament_name: Optional[str] = None,
    tournament_slug: Optional[str] = None,
    edition_year: int = 2026,
) -> dict[str, Any]:
    aliases = budget_alias_candidates(tournament_name or "", tournament_slug or "")
    filtered_rows = [
        row
        for row in rows
        if _matches_aliases(
            aliases=aliases,
            tournament_code=_safe_str(row.get("torneo_codigo")),
            tournament_name=_safe_str(row.get("torneo")),
        )
    ]

    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in filtered_rows:
        grouped[_safe_str(row.get("torneo")) or "Torneo sin nombre"].append(row)

    tournaments: list[dict[str, Any]] = []
    total_budget = 0.0
    total_reference = 0.0
    total_lines = 0

    for tournament, items in sorted(grouped.items()):
        budget_total = sum(
            _safe_decimal(item.get("presupuesto_2026")) for item in items
        )
        reference_total = sum(
            _safe_decimal(item.get("importe_referencia_total")) for item in items
        )
        total_budget += budget_total
        total_reference += reference_total
        total_lines += len(items)
        priorities = defaultdict(int)
        stages = defaultdict(int)
        for item in items:
            priorities[_safe_str(item.get("prioridad")) or "sin_prioridad"] += 1
            stages[_safe_str(item.get("etapa")) or "sin_etapa"] += 1
        comparison = {
            "requested_total": 0.0,
            "committed_total": 0.0,
            "paid_total": 0.0,
            "actual_total": 0.0,
            "pending_to_pay_total": 0.0,
        }
        forecast = _build_budget_forecast(
            edition_year=edition_year,
            budget_total=round(budget_total, 2),
            comparison=comparison,
        )
        tournaments.append(
            {
                "tournament_id": None,
                "tournament_code": _safe_str(items[0].get("torneo_codigo")),
                "tournament_name": tournament,
                "edition_year": edition_year,
                "line_count": len(items),
                "budget_total": round(budget_total, 2),
                "reference_total": round(reference_total, 2),
                "comparison": comparison,
                "forecast": forecast,
                "scenarios": _build_budget_scenarios(
                    edition_year=edition_year,
                    budget_total=round(budget_total, 2),
                    comparison=comparison,
                    forecast=forecast,
                ),
                "top_concepts": [
                    {
                        "concepto": _safe_str(item.get("concepto")),
                        "presupuesto_2026": round(
                            _safe_decimal(item.get("presupuesto_2026")), 2
                        ),
                        "cuenta_contable_final": _safe_str(
                            item.get("cuenta_contable_final")
                        )
                        or _safe_str(item.get("cuenta_contable_sugerida")),
                        "prioridad": _safe_str(item.get("prioridad")) or None,
                        "etapa": _safe_str(item.get("etapa")) or None,
                    }
                    for item in sorted(
                        items,
                        key=lambda entry: _safe_decimal(entry.get("presupuesto_2026")),
                        reverse=True,
                    )[:8]
                ],
                "priorities": dict(sorted(priorities.items())),
                "stages": dict(sorted(stages.items())),
                "breakdowns": _build_artifact_breakdowns(items),
            }
        )

    artifact_breakdowns = _build_artifact_breakdowns(filtered_rows)
    summary_comparison = {
        "requested_total": 0.0,
        "committed_total": 0.0,
        "paid_total": 0.0,
        "actual_total": 0.0,
        "pending_to_pay_total": 0.0,
    }
    summary_forecast = _build_budget_forecast(
        edition_year=edition_year,
        budget_total=round(total_budget, 2),
        comparison=summary_comparison,
    )
    return {
        "ok": True,
        "source": "budget_artifact_csv",
        "artifact_path": str(Path(artifact_path)),
        "summary": {
            "edition_year": edition_year,
            "tournaments_count": len(tournaments),
            "line_count": total_lines,
            "budget_total": round(total_budget, 2),
            "reference_total": round(total_reference, 2),
        },
        "comparison": summary_comparison,
        "forecast": summary_forecast,
        "scenarios": _build_budget_scenarios(
            edition_year=edition_year,
            budget_total=round(total_budget, 2),
            comparison=summary_comparison,
            forecast=summary_forecast,
        ),
        "breakdowns": artifact_breakdowns,
        "tournaments": tournaments,
    }


async def ensure_budget_schema(session: AsyncSession) -> None:
    await session.execute(
        text(
            """
            CREATE TABLE IF NOT EXISTS budget_concepts (
                id UUID PRIMARY KEY,
                tournament_id UUID NULL REFERENCES tournaments(id) ON DELETE SET NULL,
                tournament_code VARCHAR(40) NULL,
                tournament_name VARCHAR(200) NOT NULL,
                concept_name VARCHAR(200) NOT NULL,
                concept_key VARCHAR(200) NOT NULL,
                budget_direction VARCHAR(20) NOT NULL DEFAULT 'expense',
                active BOOLEAN NOT NULL DEFAULT TRUE,
                source VARCHAR(80) NOT NULL DEFAULT 'manual',
                metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
                created_by_empleado_id UUID NULL REFERENCES empleados(id) ON DELETE SET NULL,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
            """
        )
    )
    await session.execute(
        text(
            """
            ALTER TABLE budget_concepts
            ADD COLUMN IF NOT EXISTS cuenta_contable_id UUID NULL
            REFERENCES cuentas_contables(id) ON DELETE SET NULL
            """
        )
    )
    await session.execute(
        text(
            """
            ALTER TABLE budget_concepts
            ADD COLUMN IF NOT EXISTS pasivo_cuenta_contable_id UUID NULL
            REFERENCES cuentas_contables(id) ON DELETE SET NULL
            """
        )
    )
    await session.execute(
        text(
            """
            ALTER TABLE budget_concepts
            ADD COLUMN IF NOT EXISTS budget_direction VARCHAR(20) NOT NULL DEFAULT 'expense'
            """
        )
    )
    await session.execute(
        text(
            """
            UPDATE budget_concepts
            SET budget_direction = 'expense'
            WHERE budget_direction IS NULL
               OR budget_direction NOT IN ('expense', 'income')
            """
        )
    )
    await session.execute(
        text(
            """
            UPDATE budget_concepts bc
            SET pasivo_cuenta_contable_id = cc.id
            FROM cuentas_contables cc
            WHERE bc.active = TRUE
              AND bc.pasivo_cuenta_contable_id IS NULL
              AND cc.codigo = :default_pasivo_codigo
              AND cc.activo = TRUE
            """
        ),
        {"default_pasivo_codigo": DEFAULT_BUDGET_CONCEPT_PASIVO_ACCOUNT_CODE},
    )
    await session.execute(
        text(
            """
            CREATE TABLE IF NOT EXISTS budget_versions (
                id UUID PRIMARY KEY,
                edition_year INTEGER NOT NULL,
                version_name VARCHAR(120) NOT NULL,
                status VARCHAR(40) NOT NULL DEFAULT 'draft',
                source VARCHAR(80) NOT NULL DEFAULT 'manual',
                notes TEXT NULL,
                artifact_path TEXT NULL,
                created_by_empleado_id UUID NULL REFERENCES empleados(id),
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
            """
        )
    )
    await session.execute(
        text(
            """
            ALTER TABLE expense_reports
            ADD COLUMN IF NOT EXISTS budget_concept_id UUID NULL
            REFERENCES budget_concepts(id) ON DELETE SET NULL
            """
        )
    )
    await session.execute(
        text(
            """
            ALTER TABLE documentos
            ADD COLUMN IF NOT EXISTS budget_concept_id UUID NULL
            REFERENCES budget_concepts(id) ON DELETE SET NULL
            """
        )
    )
    await session.execute(
        text(
            """
            CREATE TABLE IF NOT EXISTS budget_lines (
                id UUID PRIMARY KEY,
                budget_version_id UUID NOT NULL REFERENCES budget_versions(id) ON DELETE CASCADE,
                budget_concept_id UUID NULL REFERENCES budget_concepts(id) ON DELETE SET NULL,
                tournament_id UUID NULL REFERENCES tournaments(id) ON DELETE SET NULL,
                tournament_code VARCHAR(40) NULL,
                tournament_name VARCHAR(200) NOT NULL,
                sport VARCHAR(40) NULL,
                phase VARCHAR(80) NULL,
                entity_name VARCHAR(200) NULL,
                concept_name VARCHAR(200) NOT NULL,
                line_direction VARCHAR(20) NOT NULL DEFAULT 'expense',
                account_code_suggested VARCHAR(80) NULL,
                account_code_final VARCHAR(80) NULL,
                budget_amount NUMERIC(18,2) NOT NULL DEFAULT 0,
                reference_amount NUMERIC(18,2) NOT NULL DEFAULT 0,
                variance_amount NUMERIC(18,2) NOT NULL DEFAULT 0,
                priority VARCHAR(40) NULL,
                owner_name VARCHAR(200) NULL,
                criteria_note TEXT NULL,
                observations TEXT NULL,
                metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
            """
        )
    )
    await session.execute(
        text(
            """
            ALTER TABLE budget_lines
            ADD COLUMN IF NOT EXISTS budget_concept_id UUID NULL
            REFERENCES budget_concepts(id) ON DELETE SET NULL
            """
        )
    )
    await session.execute(
        text(
            """
            ALTER TABLE budget_lines
            ADD COLUMN IF NOT EXISTS line_direction VARCHAR(20) NOT NULL DEFAULT 'expense'
            """
        )
    )
    await session.execute(
        text(
            """
            UPDATE budget_lines
            SET line_direction = 'expense'
            WHERE line_direction IS NULL
               OR line_direction NOT IN ('expense', 'income')
            """
        )
    )
    await session.execute(
        text(
            """
            CREATE TABLE IF NOT EXISTS budget_scenarios (
                id UUID PRIMARY KEY,
                budget_version_id UUID NOT NULL REFERENCES budget_versions(id) ON DELETE CASCADE,
                scenario_key VARCHAR(80) NOT NULL,
                scenario_name VARCHAR(120) NOT NULL,
                status VARCHAR(40) NOT NULL DEFAULT 'draft',
                assumptions JSONB NOT NULL DEFAULT '{}'::jsonb,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                UNIQUE (budget_version_id, scenario_key)
            )
            """
        )
    )
    await session.execute(
        text(
            """
            CREATE TABLE IF NOT EXISTS budget_line_monthly_allocations (
                id UUID PRIMARY KEY,
                budget_line_id UUID NOT NULL REFERENCES budget_lines(id) ON DELETE CASCADE,
                month_number INTEGER NOT NULL,
                allocated_amount NUMERIC(18,2) NOT NULL DEFAULT 0,
                metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                UNIQUE (budget_line_id, month_number)
            )
            """
        )
    )
    await session.execute(
        text(
            """
            CREATE TABLE IF NOT EXISTS budget_approvals (
                id UUID PRIMARY KEY,
                budget_version_id UUID NOT NULL REFERENCES budget_versions(id) ON DELETE CASCADE,
                approved_by_empleado_id UUID NULL REFERENCES empleados(id),
                approval_status VARCHAR(40) NOT NULL DEFAULT 'draft',
                approval_note TEXT NULL,
                approved_at TIMESTAMPTZ NULL,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
            """
        )
    )
    await session.execute(
        text(
            """
            CREATE TABLE IF NOT EXISTS budget_actuals_bridge (
                id UUID PRIMARY KEY,
                budget_line_id UUID NOT NULL REFERENCES budget_lines(id) ON DELETE CASCADE,
                expense_report_id UUID NULL REFERENCES expense_reports(id) ON DELETE SET NULL,
                documento_id UUID NULL REFERENCES documentos(id) ON DELETE SET NULL,
                actual_amount NUMERIC(18,2) NOT NULL DEFAULT 0,
                source VARCHAR(40) NOT NULL DEFAULT 'expense_report',
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
            """
        )
    )
    await session.execute(
        text(
            """
            CREATE TABLE IF NOT EXISTS budget_movement_assignments (
                id UUID PRIMARY KEY,
                budget_version_id UUID NOT NULL REFERENCES budget_versions(id) ON DELETE CASCADE,
                budget_concept_id UUID NOT NULL REFERENCES budget_concepts(id) ON DELETE RESTRICT,
                budget_line_id UUID NOT NULL REFERENCES budget_lines(id) ON DELETE CASCADE,
                movement_key VARCHAR(200) NOT NULL,
                assigned_by_empleado_id UUID NULL REFERENCES empleados(id) ON DELETE SET NULL,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                UNIQUE (budget_version_id, movement_key)
            )
            """
        )
    )
    await session.execute(
        text(
            """
            DO $$
            DECLARE constraint_name text;
            BEGIN
                SELECT con.conname INTO constraint_name
                FROM pg_constraint con
                WHERE con.conrelid = 'budget_movement_assignments'::regclass
                  AND con.confrelid = 'budget_lines'::regclass
                  AND con.contype = 'f'
                  AND con.confdeltype <> 'c'
                LIMIT 1;
                IF constraint_name IS NOT NULL THEN
                    EXECUTE format(
                        'ALTER TABLE budget_movement_assignments DROP CONSTRAINT %I',
                        constraint_name
                    );
                    ALTER TABLE budget_movement_assignments
                    ADD CONSTRAINT budget_movement_assignments_budget_line_id_fkey
                    FOREIGN KEY (budget_line_id) REFERENCES budget_lines(id)
                    ON DELETE CASCADE;
                END IF;
            END $$;
            """
        )
    )
    await session.execute(
        text(
            """
            CREATE TABLE IF NOT EXISTS budget_version_audit_log (
                id UUID PRIMARY KEY,
                budget_version_id UUID NOT NULL REFERENCES budget_versions(id) ON DELETE CASCADE,
                event_type VARCHAR(60) NOT NULL,
                actor_empleado_id UUID NULL REFERENCES empleados(id),
                from_status VARCHAR(40) NULL,
                to_status VARCHAR(40) NULL,
                note TEXT NULL,
                payload JSONB NOT NULL DEFAULT '{}'::jsonb,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
            """
        )
    )
    await session.execute(
        text(
            "CREATE UNIQUE INDEX IF NOT EXISTS ux_budget_concepts_tournament_code_key "
            "ON budget_concepts(COALESCE(tournament_code, ''), concept_key)"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_concepts_tournament_id "
            "ON budget_concepts(tournament_id)"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_concepts_active "
            "ON budget_concepts(active)"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_concepts_direction "
            "ON budget_concepts(budget_direction)"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_concepts_pasivo_cuenta_contable_id "
            "ON budget_concepts(pasivo_cuenta_contable_id)"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_versions_edition_year "
            "ON budget_versions(edition_year)"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_versions_status "
            "ON budget_versions(status)"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_lines_version "
            "ON budget_lines(budget_version_id)"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_lines_tournament_id "
            "ON budget_lines(tournament_id)"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_lines_tournament_code "
            "ON budget_lines(tournament_code)"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_lines_direction "
            "ON budget_lines(line_direction)"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_lines_budget_concept "
            "ON budget_lines(budget_concept_id)"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_movement_assignments_version_concept "
            "ON budget_movement_assignments(budget_version_id, budget_concept_id)"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_line_monthly_allocations_line "
            "ON budget_line_monthly_allocations(budget_line_id)"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_version_audit_log_version "
            "ON budget_version_audit_log(budget_version_id)"
        )
    )
    await session.execute(
        text(
            """
            CREATE TABLE IF NOT EXISTS budget_line_monthly_plan (
                id UUID PRIMARY KEY,
                budget_line_id UUID NOT NULL REFERENCES budget_lines(id) ON DELETE CASCADE,
                month_number INTEGER NOT NULL,
                budget_expense_amount NUMERIC(18,2) NOT NULL DEFAULT 0,
                expected_income_amount NUMERIC(18,2) NOT NULL DEFAULT 0,
                metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                UNIQUE (budget_line_id, month_number)
            )
            """
        )
    )
    await session.execute(
        text(
            """
            CREATE TABLE IF NOT EXISTS budget_income_bridge (
                id UUID PRIMARY KEY,
                budget_line_id UUID NOT NULL REFERENCES budget_lines(id) ON DELETE CASCADE,
                income_event_id UUID NULL,
                actual_amount NUMERIC(18,2) NOT NULL DEFAULT 0,
                paid_at TIMESTAMPTZ NULL,
                source VARCHAR(80) NOT NULL DEFAULT 'manual',
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
            """
        )
    )
    await session.execute(
        text(
            """
            CREATE TABLE IF NOT EXISTS budget_cfdi_income_links (
                id UUID PRIMARY KEY,
                cfdi_report_id UUID NOT NULL REFERENCES cfdi_reports(id) ON UPDATE CASCADE ON DELETE RESTRICT,
                budget_line_id UUID NOT NULL REFERENCES budget_lines(id) ON UPDATE CASCADE ON DELETE CASCADE,
                budget_version_id UUID NOT NULL REFERENCES budget_versions(id) ON UPDATE CASCADE ON DELETE CASCADE,
                tournament_id UUID NULL REFERENCES tournaments(id) ON UPDATE CASCADE ON DELETE SET NULL,
                phase VARCHAR(200) NULL,
                budget_concept_id UUID NULL REFERENCES budget_concepts(id) ON UPDATE CASCADE ON DELETE SET NULL,
                amount NUMERIC(18,2) NOT NULL DEFAULT 0,
                income_date TIMESTAMPTZ NOT NULL,
                budget_month SMALLINT NULL CHECK (budget_month BETWEEN 1 AND 12),
                linked_by_empleado_id UUID NULL REFERENCES empleados(id) ON UPDATE CASCADE ON DELETE SET NULL,
                source VARCHAR(80) NOT NULL DEFAULT 'admin_ui',
                status VARCHAR(40) NOT NULL DEFAULT 'pending_approval',
                approved_by_empleado_id UUID NULL REFERENCES empleados(id) ON UPDATE CASCADE ON DELETE SET NULL,
                approved_at TIMESTAMPTZ NULL,
                rejected_by_empleado_id UUID NULL REFERENCES empleados(id) ON UPDATE CASCADE ON DELETE SET NULL,
                rejected_at TIMESTAMPTZ NULL,
                decision_comment TEXT NULL,
                accounting_poliza_id UUID NULL REFERENCES accounting_polizas(id) ON UPDATE CASCADE ON DELETE SET NULL,
                collection_date TIMESTAMPTZ NULL,
                collected_by_empleado_id UUID NULL REFERENCES empleados(id) ON UPDATE CASCADE ON DELETE SET NULL,
                collection_poliza_id UUID NULL REFERENCES accounting_polizas(id) ON UPDATE CASCADE ON DELETE SET NULL,
                metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                unlinked_at TIMESTAMPTZ NULL,
                unlinked_by_empleado_id UUID NULL REFERENCES empleados(id) ON UPDATE CASCADE ON DELETE SET NULL
            )
            """
        )
    )
    await session.execute(
        text(
            """
            ALTER TABLE budget_concepts
            ADD COLUMN IF NOT EXISTS lineage_key VARCHAR(200) NULL
            """
        )
    )
    await session.execute(text("ALTER TABLE budget_concepts ADD COLUMN IF NOT EXISTS cxc_cuenta_contable_id UUID NULL REFERENCES cuentas_contables(id) ON UPDATE CASCADE ON DELETE SET NULL"))
    for column_sql in (
        "ADD COLUMN IF NOT EXISTS budget_month SMALLINT NULL CHECK (budget_month BETWEEN 1 AND 12)",
        "ADD COLUMN IF NOT EXISTS status VARCHAR(40) NOT NULL DEFAULT 'pending_approval'",
        "ADD COLUMN IF NOT EXISTS approved_by_empleado_id UUID NULL REFERENCES empleados(id) ON UPDATE CASCADE ON DELETE SET NULL",
        "ADD COLUMN IF NOT EXISTS approved_at TIMESTAMPTZ NULL",
        "ADD COLUMN IF NOT EXISTS rejected_by_empleado_id UUID NULL REFERENCES empleados(id) ON UPDATE CASCADE ON DELETE SET NULL",
        "ADD COLUMN IF NOT EXISTS rejected_at TIMESTAMPTZ NULL",
        "ADD COLUMN IF NOT EXISTS decision_comment TEXT NULL",
        "ADD COLUMN IF NOT EXISTS accounting_poliza_id UUID NULL REFERENCES accounting_polizas(id) ON UPDATE CASCADE ON DELETE SET NULL",
        "ADD COLUMN IF NOT EXISTS collection_date TIMESTAMPTZ NULL",
        "ADD COLUMN IF NOT EXISTS collected_by_empleado_id UUID NULL REFERENCES empleados(id) ON UPDATE CASCADE ON DELETE SET NULL",
        "ADD COLUMN IF NOT EXISTS collection_poliza_id UUID NULL REFERENCES accounting_polizas(id) ON UPDATE CASCADE ON DELETE SET NULL",
    ):
        await session.execute(text(f"ALTER TABLE budget_cfdi_income_links {column_sql}"))
    await session.execute(text("""
        UPDATE budget_cfdi_income_links
        SET budget_month = EXTRACT(MONTH FROM income_date)::smallint
        WHERE budget_month IS NULL AND income_date IS NOT NULL
    """))
    # Links created by the prior workflow already have a CxC policy. Preserve
    # their recognized-income semantics when introducing approval states.
    await session.execute(text("""
        UPDATE budget_cfdi_income_links link
        SET status = 'approved'
        WHERE link.unlinked_at IS NULL AND link.status = 'pending_approval'
          AND EXISTS (
              SELECT 1 FROM accounting_polizas poliza
              WHERE poliza.origen = 'cxc_cfdi_income'
                AND poliza.cfdi_report_id = link.cfdi_report_id
          )
    """))
    await session.execute(
        text(
            """
            UPDATE budget_concepts
            SET lineage_key = concept_key
            WHERE lineage_key IS NULL OR TRIM(lineage_key) = ''
            """
        )
    )
    await session.execute(
        text(
            """
            INSERT INTO budget_line_monthly_plan (
                id, budget_line_id, month_number,
                budget_expense_amount, expected_income_amount, metadata, created_at, updated_at
            )
            SELECT
                gen_random_uuid(),
                a.budget_line_id,
                a.month_number,
                a.allocated_amount,
                0,
                a.metadata,
                a.created_at,
                a.updated_at
            FROM budget_line_monthly_allocations a
            ON CONFLICT (budget_line_id, month_number) DO NOTHING
            """
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_line_monthly_plan_line "
            "ON budget_line_monthly_plan(budget_line_id)"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_income_bridge_line "
            "ON budget_income_bridge(budget_line_id)"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_cfdi_income_links_cfdi "
            "ON budget_cfdi_income_links(cfdi_report_id)"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_cfdi_income_links_line "
            "ON budget_cfdi_income_links(budget_line_id)"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_cfdi_income_links_version_tournament "
            "ON budget_cfdi_income_links(budget_version_id, tournament_id)"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_cfdi_income_links_income_date "
            "ON budget_cfdi_income_links(income_date)"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_cfdi_income_links_budget_month "
            "ON budget_cfdi_income_links(budget_version_id, budget_month)"
        )
    )
    await session.execute(
        text(
            "CREATE UNIQUE INDEX IF NOT EXISTS ux_budget_cfdi_income_links_active_cfdi_version "
            "ON budget_cfdi_income_links(cfdi_report_id, budget_version_id) "
            "WHERE unlinked_at IS NULL"
        )
    )
    await session.execute(
        text(
            "CREATE INDEX IF NOT EXISTS ix_budget_concepts_lineage_key "
            "ON budget_concepts(lineage_key)"
        )
    )
    await session.commit()


async def _audit_budget_event(
    session: AsyncSession,
    *,
    budget_version_id: str,
    event_type: str,
    actor_empleado_id: Optional[str],
    from_status: Optional[str] = None,
    to_status: Optional[str] = None,
    note: Optional[str] = None,
    payload: Optional[dict[str, Any]] = None,
) -> None:
    await session.execute(
        text(
            """
            INSERT INTO budget_version_audit_log (
                id, budget_version_id, event_type, actor_empleado_id,
                from_status, to_status, note, payload, created_at
            ) VALUES (
                :id, :budget_version_id, :event_type, :actor_empleado_id,
                :from_status, :to_status, :note, CAST(:payload AS jsonb), NOW()
            )
            """
        ),
        {
            "id": str(uuid.uuid4()),
            "budget_version_id": budget_version_id,
            "event_type": event_type,
            "actor_empleado_id": actor_empleado_id,
            "from_status": from_status,
            "to_status": to_status,
            "note": note,
            "payload": json.dumps(payload or {}, ensure_ascii=False),
        },
    )


async def list_budget_audit_events(
    session: AsyncSession,
    *,
    version_id: Optional[str] = None,
    limit: int = 80,
) -> list[dict[str, Any]]:
    await ensure_budget_schema(session)
    filters = []
    params: dict[str, Any] = {"limit": max(1, min(limit, 300))}
    if version_id:
        filters.append("log.budget_version_id = :version_id")
        params["version_id"] = version_id
    where_clause = f"WHERE {' AND '.join(filters)}" if filters else ""
    rows = (
        (
            await session.execute(
                text(
                    f"""
                SELECT
                    log.id,
                    log.budget_version_id,
                    v.version_name,
                    v.status AS version_status,
                    log.event_type,
                    log.actor_empleado_id,
                    actor.nombre AS actor_nombre,
                    actor.correo AS actor_correo,
                    log.from_status,
                    log.to_status,
                    log.note,
                    log.payload,
                    log.created_at
                FROM budget_version_audit_log log
                JOIN budget_versions v ON v.id = log.budget_version_id
                LEFT JOIN empleados actor ON actor.id = log.actor_empleado_id
                {where_clause}
                ORDER BY log.created_at DESC
                LIMIT :limit
                """
                ),
                params,
            )
        )
        .mappings()
        .all()
    )
    events: list[dict[str, Any]] = []
    for row in rows:
        payload = row["payload"] if isinstance(row["payload"], dict) else {}
        events.append(
            {
                "id": _safe_str(row["id"]),
                "budget_version_id": _safe_str(row["budget_version_id"]),
                "version_name": _safe_str(row["version_name"]) or None,
                "version_status": _safe_str(row["version_status"]) or None,
                "event_type": _safe_str(row["event_type"]) or None,
                "actor_empleado_id": _safe_str(row["actor_empleado_id"]) or None,
                "actor_nombre": _safe_str(row["actor_nombre"]) or "Sistema",
                "actor_correo": _safe_str(row["actor_correo"]) or None,
                "from_status": _safe_str(row["from_status"]) or None,
                "to_status": _safe_str(row["to_status"]) or None,
                "note": _safe_str(row["note"]) or None,
                "payload": payload,
                "created_at": (
                    row["created_at"].isoformat() if row["created_at"] else None
                ),
            }
        )
    return events


async def _link_budget_lines_to_tournaments(
    session: AsyncSession,
    *,
    budget_version_id: str,
    line_ids: Optional[list[str]] = None,
) -> None:
    tournament_rows = await _load_tournament_rows(session)
    if not tournament_rows:
        return
    line_rows = (
        (
            await session.execute(
                text("""
                SELECT id, tournament_code, tournament_name
                FROM budget_lines
                WHERE budget_version_id = :budget_version_id
                  AND (:all_lines OR id::text = ANY(CAST(:line_ids AS text[])))
                """),
                {
                    "budget_version_id": budget_version_id,
                    "all_lines": line_ids is None,
                    "line_ids": line_ids or [],
                },
            )
        )
        .mappings()
        .all()
    )
    for row in line_rows:
        tournament_id = _match_tournament_id(
            tournament_rows,
            tournament_code=_safe_str(row.get("tournament_code")),
            tournament_name=_safe_str(row.get("tournament_name")),
        )
        if not tournament_id:
            continue
        await session.execute(
            text("""
                UPDATE budget_lines
                SET tournament_id = :tournament_id, updated_at = NOW()
                WHERE id = :line_id
                """),
            {"line_id": row["id"], "tournament_id": tournament_id},
        )


async def import_budget_artifact(
    session: AsyncSession,
    *,
    artifact_path: str | Path = DEFAULT_BUDGET_ARTIFACT,
    edition_year: int = 2026,
    version_name: str = "Presupuesto 2026 Draft",
    status: str = "draft",
    source: str = "artifact_csv",
    created_by_empleado_id: Optional[str] = None,
    replace_existing: bool = False,
) -> dict[str, Any]:
    await ensure_budget_schema(session)
    artifact_rows = load_budget_artifact_rows(artifact_path)
    if not artifact_rows:
        raise ValueError("No budget artifact rows were found")

    existing_version_id = (
        await session.execute(
            text(
                """
                SELECT id
                FROM budget_versions
                WHERE edition_year = :edition_year
                  AND version_name = :version_name
                ORDER BY created_at DESC
                LIMIT 1
                """
            ),
            {"edition_year": edition_year, "version_name": version_name},
        )
    ).scalar_one_or_none()
    if existing_version_id and not replace_existing:
        return {
            "ok": True,
            "created": False,
            "version_id": str(existing_version_id),
            "message": "Budget version already exists",
        }

    if existing_version_id and replace_existing:
        await session.execute(
            text("DELETE FROM budget_versions WHERE id = :version_id"),
            {"version_id": existing_version_id},
        )

    version_id = str(uuid.uuid4())
    normalized_status = _normalize_budget_status(status)
    await session.execute(
        text(
            """
            INSERT INTO budget_versions (
                id, edition_year, version_name, status, source, notes, artifact_path,
                created_by_empleado_id, created_at, updated_at
            ) VALUES (
                :id, :edition_year, :version_name, :status, :source, :notes, :artifact_path,
                :created_by_empleado_id, NOW(), NOW()
            )
            """
        ),
        {
            "id": version_id,
            "edition_year": edition_year,
            "version_name": version_name,
            "status": normalized_status,
            "source": source,
            "notes": "Importado desde artefacto presupuestal 2026.",
            "artifact_path": str(Path(artifact_path)),
            "created_by_empleado_id": created_by_empleado_id,
        },
    )

    for row in artifact_rows:
        metadata = {
            "confianza_base": _safe_str(row.get("confianza_base")) or None,
            "referencias_usadas": _safe_str(row.get("referencias_usadas")) or None,
            "importe_referencia_promedio": _safe_decimal(
                row.get("importe_referencia_promedio")
            ),
            "importe_referencia_maximo": _safe_decimal(
                row.get("importe_referencia_maximo")
            ),
            "proveedores_distintos": _safe_str(row.get("proveedores_distintos"))
            or None,
            "estatus_torneo": _safe_str(row.get("estatus_torneo")) or None,
        }
        await session.execute(
            text(
                """
                INSERT INTO budget_lines (
                    id, budget_version_id, tournament_code, tournament_name, phase,
                    concept_name, account_code_suggested, account_code_final,
                    budget_amount, reference_amount, variance_amount, priority,
                    owner_name, criteria_note, observations, metadata,
                    created_at, updated_at
                ) VALUES (
                    :id, :budget_version_id, :tournament_code, :tournament_name, :phase,
                    :concept_name, :account_code_suggested, :account_code_final,
                    :budget_amount, :reference_amount, :variance_amount, :priority,
                    :owner_name, :criteria_note, :observations, CAST(:metadata AS jsonb),
                    NOW(), NOW()
                )
                """
            ),
            {
                "id": str(uuid.uuid4()),
                "budget_version_id": version_id,
                "tournament_code": _safe_str(row.get("torneo_codigo")) or None,
                "tournament_name": _safe_str(row.get("torneo")) or "Torneo sin nombre",
                "phase": _safe_str(row.get("etapa")) or None,
                "concept_name": _safe_str(row.get("concepto")) or "Sin concepto",
                "account_code_suggested": _safe_str(row.get("cuenta_contable_sugerida"))
                or None,
                "account_code_final": _safe_str(row.get("cuenta_contable_final"))
                or None,
                "budget_amount": _safe_decimal(row.get("presupuesto_2026")),
                "reference_amount": _safe_decimal(row.get("importe_referencia_total")),
                "variance_amount": _safe_decimal(row.get("ajuste_vs_referencia")),
                "priority": _safe_str(row.get("prioridad")) or None,
                "owner_name": _safe_str(row.get("responsable")) or None,
                "criteria_note": _safe_str(row.get("criterio_presupuesto")) or None,
                "observations": _safe_str(row.get("observaciones_presupuesto")) or None,
                "metadata": json.dumps(metadata, ensure_ascii=False),
            },
        )
    await _link_budget_lines_to_tournaments(session, budget_version_id=version_id)
    await _audit_budget_event(
        session,
        budget_version_id=version_id,
        event_type="imported",
        actor_empleado_id=created_by_empleado_id,
        to_status=normalized_status,
        note="Importación inicial del artefacto presupuestal.",
        payload={
            "artifact_path": str(Path(artifact_path)),
            "line_count": len(artifact_rows),
        },
    )
    await session.commit()
    return {
        "ok": True,
        "created": True,
        "version_id": version_id,
        "line_count": len(artifact_rows),
    }


async def create_budget_version(
    session: AsyncSession,
    *,
    edition_year: int = 2026,
    version_name: str,
    notes: Optional[str] = None,
    source: str = "ui_manual",
    created_by_empleado_id: Optional[str] = None,
) -> dict[str, Any]:
    await ensure_budget_schema(session)
    clean_name = _safe_str(version_name)
    if not clean_name:
        raise ValueError("Budget version name is required")

    version_id = str(uuid.uuid4())
    await session.execute(
        text(
            """
            INSERT INTO budget_versions (
                id, edition_year, version_name, status, source, notes, artifact_path,
                created_by_empleado_id, created_at, updated_at
            ) VALUES (
                :id, :edition_year, :version_name, 'draft', :source, :notes, NULL,
                :created_by_empleado_id, NOW(), NOW()
            )
            """
        ),
        {
            "id": version_id,
            "edition_year": edition_year,
            "version_name": clean_name,
            "source": _safe_str(source) or "ui_manual",
            "notes": notes,
            "created_by_empleado_id": created_by_empleado_id,
        },
    )
    await _audit_budget_event(
        session,
        budget_version_id=version_id,
        event_type="version_created",
        actor_empleado_id=created_by_empleado_id,
        to_status="draft",
        note=notes,
        payload={"source": _safe_str(source) or "ui_manual"},
    )
    await session.commit()
    return await get_budget_version(session, version_id=version_id)


async def list_budget_versions(
    session: AsyncSession,
    *,
    edition_year: Optional[int] = None,
    ensure_schema: bool = True,
) -> list[dict[str, Any]]:
    if ensure_schema:
        await ensure_budget_schema(session)
    filters = []
    params: dict[str, Any] = {}
    if edition_year is not None:
        filters.append("v.edition_year = :edition_year")
        params["edition_year"] = edition_year
    where_clause = f"WHERE {' AND '.join(filters)}" if filters else ""
    rows = (
        (
            await session.execute(
                text(f"""
                SELECT
                    v.id,
                    v.edition_year,
                    v.version_name,
                    v.status,
                    v.source,
                    v.notes,
                    v.artifact_path,
                    v.created_by_empleado_id,
                    v.created_at,
                    v.updated_at,
                    COUNT(l.id) AS line_count,
                    COALESCE(SUM(l.budget_amount), 0) AS budget_total,
                    COALESCE(SUM(l.reference_amount), 0) AS reference_total,
                    (SELECT MAX(approval.approved_at)
                     FROM budget_approvals approval
                     WHERE approval.budget_version_id=v.id) AS latest_approved_at,
                    (SELECT log.payload->>'source_version_id'
                     FROM budget_version_audit_log log
                     WHERE log.budget_version_id=v.id
                       AND log.event_type='distribution_revision_created'
                     ORDER BY log.created_at DESC LIMIT 1) AS distribution_source_version_id
                FROM budget_versions v
                LEFT JOIN budget_lines l ON l.budget_version_id = v.id
                {where_clause}
                GROUP BY
                    v.id, v.edition_year, v.version_name, v.status, v.source,
                    v.notes, v.artifact_path, v.created_by_empleado_id,
                    v.created_at, v.updated_at
                ORDER BY v.edition_year DESC, v.updated_at DESC, v.created_at DESC
                """),
                params,
            )
        )
        .mappings()
        .all()
    )
    return [
        {
            "id": _safe_str(row["id"]),
            "edition_year": int(row["edition_year"] or 0),
            "version_name": _safe_str(row["version_name"]),
            "status": _safe_str(row["status"]),
            "source": _safe_str(row["source"]),
            "distribution_source_version_id": row.get("distribution_source_version_id"),
            "notes": _safe_str(row["notes"]) or None,
            "artifact_path": _safe_str(row["artifact_path"]) or None,
            "created_by_empleado_id": _safe_str(row["created_by_empleado_id"]) or None,
            "created_at": row["created_at"].isoformat() if row["created_at"] else None,
            "updated_at": row["updated_at"].isoformat() if row["updated_at"] else None,
            "line_count": int(row["line_count"] or 0),
            "budget_total": round(_safe_decimal(row["budget_total"]), 2),
            "reference_total": round(_safe_decimal(row["reference_total"]), 2),
            "latest_approved_at": (
                row["latest_approved_at"].isoformat()
                if row["latest_approved_at"]
                else None
            ),
        }
        for row in rows
    ]


async def create_budget_line(
    session: AsyncSession,
    *,
    version_id: str,
    actor_empleado_id: Optional[str] = None,
    tournament_code: Optional[str] = None,
    tournament_name: Optional[str] = None,
    budget_concept_id: Optional[str] = None,
    line_direction: Optional[str] = None,
    concept_name: str,
    account_code_final: Optional[str] = None,
    phase: Optional[str] = None,
    owner_name: Optional[str] = None,
    priority: Optional[str] = None,
    budget_amount: Any = 0,
    reference_amount: Any = 0,
    criteria_note: Optional[str] = None,
    observations: Optional[str] = None,
    commit: bool = True,
    ensure_schema: bool = True,
    extra_metadata: Optional[dict[str, Any]] = None,
    tournament_id: Optional[str] = None,
) -> dict[str, Any]:
    if ensure_schema:
        await ensure_budget_schema(session)
    current = await get_budget_version(
        session, version_id=version_id, ensure_schema=False
    )
    if not _editable_version_status(current.get("status")):
        raise ValueError("Only draft or reforecast versions allow line creation")
    if current.get("source") == "distribution_revision":
        raise ValueError("La revisión de distribución conserva las partidas originales")

    clean_direction = normalize_budget_line_direction(line_direction)
    clean_concept = _safe_str(concept_name)
    if tournament_id:
        concept = await get_budget_concept(
            session, concept_id=_safe_str(budget_concept_id), ensure_schema=False
        )
        if concept is not None and (
            not concept.get("active")
            or normalize_budget_line_direction(concept.get("budget_direction"))
            != clean_direction
        ):
            concept = None
    else:
        concept = await resolve_budget_concept(
            session,
            budget_concept_id=budget_concept_id,
            tournament_code=tournament_code,
            budget_direction=clean_direction,
        )
    if concept is not None:
        clean_concept = _safe_str(concept.get("concept_name"))
        tournament_code = _safe_str(concept.get("tournament_code")) or tournament_code
        tournament_name = _safe_str(concept.get("tournament_name")) or tournament_name
    if tournament_id and (
        concept is None or str(concept.get("tournament_id")) != str(tournament_id)
    ):
        raise ValueError("Budget concept does not belong to the exact tournament")
    if not clean_concept:
        raise ValueError("Budget line concept is required")
    amount = _safe_decimal(budget_amount)
    reference = _safe_decimal(reference_amount)
    line_id = str(uuid.uuid4())
    await session.execute(
        text("""
            INSERT INTO budget_lines (
                id, budget_version_id, budget_concept_id, tournament_code, tournament_name, phase,
                concept_name, line_direction, account_code_suggested, account_code_final,
                budget_amount, reference_amount, variance_amount, priority,
                owner_name, criteria_note, observations, metadata,
                created_at, updated_at
            ) VALUES (
                :id, :budget_version_id, :budget_concept_id, :tournament_code, :tournament_name, :phase,
                :concept_name, :line_direction, NULL, :account_code_final,
                :budget_amount, :reference_amount, :variance_amount, :priority,
                :owner_name, :criteria_note, :observations, CAST(:metadata AS jsonb),
                NOW(), NOW()
            )
            """),
        {
            "id": line_id,
            "budget_version_id": version_id,
            "budget_concept_id": (
                _safe_str(concept.get("id")) or None if concept else None
            ),
            "tournament_code": _safe_str(tournament_code) or None,
            "tournament_name": _safe_str(tournament_name) or "Presupuesto general",
            "phase": _safe_str(phase) or None,
            "concept_name": clean_concept,
            "line_direction": clean_direction,
            "account_code_final": _safe_str(account_code_final) or None,
            "budget_amount": amount,
            "reference_amount": reference,
            "variance_amount": round(amount - reference, 2),
            "priority": _safe_str(priority) or None,
            "owner_name": _safe_str(owner_name) or None,
            "criteria_note": _safe_str(criteria_note) or None,
            "observations": _safe_str(observations) or None,
            "metadata": json.dumps(
                {"created_from": "ui_manual", **(extra_metadata or {})},
                ensure_ascii=False,
            ),
        },
    )
    if tournament_id:
        await session.execute(
            text(
                "UPDATE budget_lines SET tournament_id = :tournament_id "
                "WHERE id = :line_id"
            ),
            {"tournament_id": tournament_id, "line_id": line_id},
        )
    else:
        await _link_budget_lines_to_tournaments(
            session, budget_version_id=version_id, line_ids=[line_id]
        )

    await _audit_budget_event(
        session,
        budget_version_id=version_id,
        event_type="line_created",
        actor_empleado_id=actor_empleado_id,
        from_status=current.get("status"),
        to_status=current.get("status"),
        payload={
            "line_id": line_id,
            "line_direction": clean_direction,
            "budget_concept_id": (
                _safe_str(concept.get("id")) or None if concept else None
            ),
            "concept_name": clean_concept,
            "budget_amount": amount,
        },
    )
    if commit:
        await session.commit()
    else:
        await session.flush()
    lines = await list_budget_lines(
        session,
        version_id=version_id,
        tournament_id=tournament_id,
        limit=5000,
        ensure_schema=False,
    )
    for line in lines:
        if line["id"] == line_id:
            return line
    raise ValueError("Budget line not found after creation")


async def transition_budget_version(
    session: AsyncSession,
    *,
    version_id: str,
    new_status: str,
    actor_empleado_id: Optional[str] = None,
    note: Optional[str] = None,
) -> dict[str, Any]:
    await ensure_budget_schema(session)
    current = (
        (
            await session.execute(
                text("""
                SELECT id, status, source, edition_year
                FROM budget_versions
                WHERE id = :version_id
                FOR UPDATE
                """),
                {"version_id": version_id},
            )
        )
        .mappings()
        .first()
    )
    if not current:
        raise ValueError("Budget version not found")
    from_status = _normalize_budget_status(current["status"])
    to_status = _normalize_budget_status(new_status)
    if to_status == from_status:
        versions = await list_budget_versions(session)
        return next(item for item in versions if item["id"] == version_id)
    allowed = _BUDGET_ALLOWED_TRANSITIONS.get(from_status, set())
    if to_status not in allowed:
        raise ValueError(
            f"Invalid budget status transition: {from_status} -> {to_status}"
        )

    from .distribution import guard_source_transition

    if (
        current.get("source") == "distribution_revision"
        and from_status in {"approved", "frozen"}
        and to_status in {"reforecast", "closed"}
    ):
        raise ValueError(
            "La distribución aprobada conserva su historial; prepara otra revisión para ajustar semanas"
        )
    await guard_source_transition(session, version_id, to_status)

    if to_status in {"approved", "frozen"}:
        from .distribution import revision_context, validate_revision, schedule_state

        if current.get("source") == "distribution_revision":
            context = await revision_context(session, version_id)
            await validate_revision(session, context)
        else:
            lines = (
                (
                    await session.execute(
                        text("""
                SELECT id::text AS id, budget_amount,
                       COALESCE(line_direction, 'expense') AS line_direction
                FROM budget_lines WHERE budget_version_id=CAST(:id AS uuid)
                FOR UPDATE
            """),
                        {"id": version_id},
                    )
                )
                .mappings()
                .all()
            )
            plans = await list_monthly_plan_for_lines(
                session, line_ids=[l["id"] for l in lines], ensure_schema=False
            )
            for line in lines:
                if line.get(
                    "line_direction", "expense"
                ) == "expense" and schedule_state(line, plans.get(line["id"], {}))[
                    "status"
                ] in {
                    "invalid",
                    "mismatch",
                }:
                    raise ValueError(
                        "La distribución existente no concilia con el autorizado; completa o corrige las semanas"
                    )

    await session.execute(
        text(
            """
            UPDATE budget_versions
            SET status = :status, updated_at = NOW()
            WHERE id = :version_id
            """
        ),
        {"version_id": version_id, "status": to_status},
    )
    if to_status == "approved":
        await session.execute(
            text(
                """
                INSERT INTO budget_approvals (
                    id, budget_version_id, approved_by_empleado_id,
                    approval_status, approval_note, approved_at, created_at
                ) VALUES (
                    :id, :budget_version_id, :approved_by_empleado_id,
                    'approved', :approval_note, NOW(), NOW()
                )
                """
            ),
            {
                "id": str(uuid.uuid4()),
                "budget_version_id": version_id,
                "approved_by_empleado_id": actor_empleado_id,
                "approval_note": note,
            },
        )
    await _audit_budget_event(
        session,
        budget_version_id=version_id,
        event_type="status_changed",
        actor_empleado_id=actor_empleado_id,
        from_status=from_status,
        to_status=to_status,
        note=note,
        payload={"action": "transition"},
    )
    await session.commit()
    versions = await list_budget_versions(session)
    return next(item for item in versions if item["id"] == version_id)


async def get_budget_version(
    session: AsyncSession,
    *,
    version_id: str,
    ensure_schema: bool = True,
) -> dict[str, Any]:
    versions = await list_budget_versions(session, ensure_schema=ensure_schema)
    for version in versions:
        if version["id"] == version_id:
            return version
    raise ValueError("Budget version not found")


async def update_budget_version_metadata(
    session: AsyncSession,
    *,
    version_id: str,
    actor_empleado_id: Optional[str] = None,
    version_name: Optional[str] = None,
    notes: Optional[str] = None,
) -> dict[str, Any]:
    await ensure_budget_schema(session)
    current = await get_budget_version(session, version_id=version_id)
    if not _editable_version_status(current.get("status")):
        raise ValueError("Only draft or reforecast versions can be edited")
    updated_name = _safe_str(version_name) or current["version_name"]
    updated_notes = notes if notes is not None else current.get("notes")
    await session.execute(
        text(
            """
            UPDATE budget_versions
            SET version_name = :version_name,
                notes = :notes,
                updated_at = NOW()
            WHERE id = :version_id
            """
        ),
        {
            "version_id": version_id,
            "version_name": updated_name,
            "notes": updated_notes,
        },
    )
    await _audit_budget_event(
        session,
        budget_version_id=version_id,
        event_type="version_updated",
        actor_empleado_id=actor_empleado_id,
        from_status=current.get("status"),
        to_status=current.get("status"),
        payload={
            "before": {
                "version_name": current.get("version_name"),
                "notes": current.get("notes"),
            },
            "after": {
                "version_name": updated_name,
                "notes": updated_notes,
            },
        },
    )
    await session.commit()
    return await get_budget_version(session, version_id=version_id)


async def list_budget_lines(
    session: AsyncSession,
    *,
    version_id: str,
    tournament_id: Optional[str] = None,
    tournament_code: Optional[str] = None,
    line_direction: Optional[str] = None,
    limit: int = 200,
    ensure_schema: bool = True,
) -> list[dict[str, Any]]:
    if ensure_schema:
        await ensure_budget_schema(session)
    filters = ["l.budget_version_id = :version_id"]
    params: dict[str, Any] = {
        "version_id": version_id,
        "limit": max(1, min(limit, 5000)),
    }
    clean_direction = _safe_str(line_direction)
    if clean_direction:
        filters.append("COALESCE(l.line_direction, 'expense') = :line_direction")
        params["line_direction"] = normalize_budget_line_direction(clean_direction)
    if tournament_id:
        filters.append("CAST(l.tournament_id AS text) = :tournament_id")
        params["tournament_id"] = tournament_id
    elif tournament_code:
        filters.append(
            "UPPER(COALESCE(l.tournament_code, '')) = UPPER(:tournament_code)"
        )
        params["tournament_code"] = _safe_str(tournament_code)
    rows = (
        (
            await session.execute(
                text(
                    f"""
                SELECT
                    l.id,
                    l.budget_version_id,
                    l.budget_concept_id,
                    l.tournament_id,
                    l.tournament_code,
                    l.tournament_name,
                    l.sport,
                    l.phase,
                    l.entity_name,
                    l.concept_name,
                    COALESCE(l.line_direction, 'expense') AS line_direction,
                    l.account_code_suggested,
                    l.account_code_final,
                    l.budget_amount,
                    l.reference_amount,
                    l.variance_amount,
                    l.priority,
                    l.owner_name,
                    l.criteria_note,
                    l.observations,
                    l.metadata,
                    l.created_at,
                    l.updated_at
                FROM budget_lines l
                WHERE {' AND '.join(filters)}
                ORDER BY l.budget_amount DESC, l.tournament_name ASC, l.concept_name ASC
                LIMIT :limit
                """
                ),
                params,
            )
        )
        .mappings()
        .all()
    )
    return [
        {
            "id": _safe_str(row["id"]),
            "budget_version_id": _safe_str(row["budget_version_id"]),
            "budget_concept_id": _safe_str(row["budget_concept_id"]) or None,
            "tournament_id": _safe_str(row["tournament_id"]) or None,
            "tournament_code": _safe_str(row["tournament_code"]) or None,
            "tournament_name": _safe_str(row["tournament_name"]),
            "sport": _safe_str(row["sport"]) or None,
            "phase": _safe_str(row["phase"]) or None,
            "entity_name": _safe_str(row["entity_name"]) or None,
            "concept_name": _safe_str(row["concept_name"]),
            "line_direction": normalize_budget_line_direction(
                _safe_str(row["line_direction"])
            ),
            "account_code_suggested": _safe_str(row["account_code_suggested"]) or None,
            "account_code_final": _safe_str(row["account_code_final"]) or None,
            "budget_amount": round(_safe_decimal(row["budget_amount"]), 2),
            "reference_amount": round(_safe_decimal(row["reference_amount"]), 2),
            "variance_amount": round(_safe_decimal(row["variance_amount"]), 2),
            "priority": _safe_str(row["priority"]) or None,
            "owner_name": _safe_str(row["owner_name"]) or None,
            "criteria_note": _safe_str(row["criteria_note"]) or None,
            "observations": _safe_str(row["observations"]) or None,
            "metadata": row["metadata"] if isinstance(row["metadata"], dict) else {},
            "created_at": row["created_at"].isoformat() if row["created_at"] else None,
            "updated_at": row["updated_at"].isoformat() if row["updated_at"] else None,
        }
        for row in rows
    ]


async def update_budget_line(
    session: AsyncSession,
    *,
    line_id: str,
    actor_empleado_id: Optional[str] = None,
    updates: dict[str, Any],
    commit: bool = True,
    ensure_schema: bool = True,
    extra_metadata: Optional[dict[str, Any]] = None,
    tournament_id: Optional[str] = None,
) -> dict[str, Any]:
    if ensure_schema:
        await ensure_budget_schema(session)
    current = (
        (
            await session.execute(
                text("""
                SELECT
                    l.id,
                    l.tournament_id,
                    l.budget_version_id,
                    l.budget_concept_id,
                    l.tournament_code,
                    l.concept_name,
                    l.account_code_final,
                    l.account_code_suggested,
                    l.budget_amount,
                    COALESCE(l.line_direction, 'expense') AS line_direction,
                    l.reference_amount,
                    l.variance_amount,
                    l.priority,
                    l.owner_name,
                    l.phase,
                    l.criteria_note,
                    l.observations,
                    l.metadata,
                    v.status AS version_status,
                    v.source AS version_source
                FROM budget_lines l
                JOIN budget_versions v ON v.id = l.budget_version_id
                WHERE l.id = :line_id
                FOR UPDATE OF l, v
                """),
                {"line_id": line_id},
            )
        )
        .mappings()
        .first()
    )
    if not current:
        raise ValueError("Budget line not found")
    if tournament_id and str(current.get("tournament_id")) != str(tournament_id):
        raise ValueError("Budget line does not belong to the exact tournament")
    if not _editable_version_status(current.get("version_status")):
        raise ValueError("Only draft or reforecast versions allow line edits")

    allowed_fields = {
        "budget_concept_id",
        "concept_name",
        "account_code_final",
        "budget_amount",
        "priority",
        "owner_name",
        "phase",
        "criteria_note",
        "observations",
    }
    requested_fields = {
        key: value for key, value in updates.items() if key in allowed_fields
    }
    if not requested_fields:
        raise ValueError("No editable budget line fields were provided")
    if current.get("version_source") == "distribution_revision":
        if (
            extra_metadata
            or any(key != "budget_amount" for key in requested_fields)
            or (
                "budget_amount" in requested_fields
                and _safe_decimal(requested_fields["budget_amount"])
                != _safe_decimal(current["budget_amount"])
            )
        ):
            raise ValueError(
                "Esta revisión permite sólo distribuir el importe autorizado original"
            )
        return dict(current)

    concept = None
    if "budget_concept_id" in requested_fields:
        concept = await resolve_budget_concept(
            session,
            budget_concept_id=_safe_str(requested_fields.get("budget_concept_id")),
            tournament_code=_safe_str(current.get("tournament_code")),
            budget_direction=normalize_budget_line_direction(
                _safe_str(current.get("line_direction"))
            ),
        )
        if concept is None:
            raise ValueError("Budget concept not found for this tournament")

    next_budget_amount = (
        _safe_decimal(requested_fields["budget_amount"])
        if "budget_amount" in requested_fields
        else _safe_decimal(current["budget_amount"])
    )
    reference_amount = _safe_decimal(current["reference_amount"])
    variance_amount = round(next_budget_amount - reference_amount, 2)
    update_payload = {
        "budget_concept_id": (
            _safe_str(concept.get("id"))
            if concept is not None
            else _safe_str(current["budget_concept_id"]) or None
        ),
        "concept_name": (
            _safe_str(concept.get("concept_name"))
            if concept is not None
            else _safe_str(requested_fields.get("concept_name"))
            or _safe_str(current["concept_name"])
        ),
        "account_code_final": _safe_str(requested_fields.get("account_code_final"))
        or _safe_str(current["account_code_final"]),
        "budget_amount": next_budget_amount,
        "priority": _safe_str(requested_fields.get("priority"))
        or _safe_str(current["priority"])
        or None,
        "owner_name": _safe_str(requested_fields.get("owner_name"))
        or _safe_str(current["owner_name"])
        or None,
        "phase": _safe_str(requested_fields.get("phase"))
        or _safe_str(current["phase"])
        or None,
        "criteria_note": _safe_str(requested_fields.get("criteria_note"))
        or _safe_str(current["criteria_note"])
        or None,
        "observations": _safe_str(requested_fields.get("observations"))
        or _safe_str(current["observations"])
        or None,
        "variance_amount": variance_amount,
        "metadata": json.dumps(
            {**(current.get("metadata") or {}), **(extra_metadata or {})},
            ensure_ascii=False,
        ),
    }
    await session.execute(
        text(
            """
            UPDATE budget_lines
            SET budget_concept_id = :budget_concept_id,
                concept_name = :concept_name,
                account_code_final = :account_code_final,
                budget_amount = :budget_amount,
                priority = :priority,
                owner_name = :owner_name,
                phase = :phase,
                criteria_note = :criteria_note,
                observations = :observations,
                variance_amount = :variance_amount,
                metadata = CAST(:metadata AS jsonb),
                updated_at = NOW()
            WHERE id = :line_id
            """
        ),
        {"line_id": line_id, **update_payload},
    )
    await _audit_budget_event(
        session,
        budget_version_id=_safe_str(current["budget_version_id"]),
        event_type="line_updated",
        actor_empleado_id=actor_empleado_id,
        from_status=_safe_str(current["version_status"]),
        to_status=_safe_str(current["version_status"]),
        payload={
            "line_id": line_id,
            "before": {
                "concept_name": _safe_str(current["concept_name"]),
                "budget_concept_id": _safe_str(current["budget_concept_id"]) or None,
                "line_direction": normalize_budget_line_direction(
                    _safe_str(current.get("line_direction"))
                ),
                "account_code_final": _safe_str(current["account_code_final"])
                or _safe_str(current["account_code_suggested"]),
                "budget_amount": round(_safe_decimal(current["budget_amount"]), 2),
                "priority": _safe_str(current["priority"]) or None,
                "owner_name": _safe_str(current["owner_name"]) or None,
                "phase": _safe_str(current["phase"]) or None,
                "criteria_note": _safe_str(current["criteria_note"]) or None,
                "observations": _safe_str(current["observations"]) or None,
            },
            "after": update_payload,
        },
    )
    if commit:
        await session.commit()
    else:
        await session.flush()
    lines = await list_budget_lines(
        session,
        version_id=_safe_str(current["budget_version_id"]),
        tournament_id=tournament_id,
        limit=5000 if tournament_id else 500,
        ensure_schema=False,
    )
    for line in lines:
        if line["id"] == line_id:
            return line
    raise ValueError("Budget line not found after update")


def _budget_version_sort_key(item: dict[str, Any]) -> tuple[int, str, str]:
    return (
        _status_sort_value(item.get("status")),
        _safe_str(item.get("updated_at")) or _safe_str(item.get("created_at")),
    )


async def _select_budget_version(
    session: AsyncSession,
    *,
    edition_year: int,
    version_id: Optional[str] = None,
    ensure_schema: bool = True,
) -> Optional[dict[str, Any]]:
    versions = await list_budget_versions(
        session, edition_year=edition_year, ensure_schema=ensure_schema
    )
    if version_id:
        for version in versions:
            if version["id"] == version_id:
                return version
    return resolve_definitive_budget_version_from_versions(versions)


async def _build_budget_finance_comparison(
    session: AsyncSession,
    *,
    edition_year: int,
    tournament_id: Optional[str],
    tournament_name: Optional[str],
    tournament_code: Optional[str],
    budget_total: float,
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
) -> dict[str, Any]:
    document_filter, expense_filter, params = _build_budget_scope_filters(
        edition_year=edition_year,
        tournament_id=tournament_id,
        tournament_name=tournament_name,
        tournament_code=tournament_code,
        date_from=date_from,
        date_to=date_to,
    )
    today = date.today()
    next_30 = today + timedelta(days=30)

    document_row = (
        (
            await session.execute(
                text(f"""
                SELECT
                    COALESCE(SUM(CASE WHEN d.estado IN ('enviado', 'aprobado', 'en_proceso_pago', 'pagado', 'cerrado') THEN {_budget_document_base_amount_sql('d', 'document_cfdi')} ELSE 0 END), 0) AS requested_total,
                    COALESCE(SUM(CASE WHEN d.estado IN ('aprobado', 'en_proceso_pago', 'pagado', 'cerrado') THEN {_budget_document_base_amount_sql('d', 'document_cfdi')} ELSE 0 END), 0) AS committed_total,
                    COALESCE(SUM(CASE WHEN d.estado IN ('pagado', 'cerrado') OR d.pagado_en IS NOT NULL THEN {_budget_document_base_amount_sql('d', 'document_cfdi')} ELSE 0 END), 0) AS paid_total,
                    COALESCE(SUM(CASE WHEN d.estado NOT IN ('pagado', 'cerrado') AND d.fecha_pago IS NOT NULL AND d.fecha_pago < :today THEN {_budget_document_base_amount_sql('d', 'document_cfdi')} ELSE 0 END), 0) AS overdue_open_total,
                    COALESCE(SUM(CASE WHEN d.estado NOT IN ('pagado', 'cerrado') AND d.fecha_pago IS NOT NULL AND d.fecha_pago >= :today AND d.fecha_pago <= :next_30 THEN {_budget_document_base_amount_sql('d', 'document_cfdi')} ELSE 0 END), 0) AS due_next_30_total,
                    COUNT(*) FILTER (WHERE d.estado IN ('enviado', 'aprobado', 'en_proceso_pago', 'pagado', 'cerrado')) AS document_count,
                    COUNT(*) FILTER (WHERE d.estado NOT IN ('pagado', 'cerrado') AND d.fecha_pago IS NOT NULL AND d.fecha_pago < :today) AS overdue_open_count,
                    COUNT(*) FILTER (WHERE d.estado NOT IN ('pagado', 'cerrado') AND d.fecha_pago IS NOT NULL AND d.fecha_pago >= :today AND d.fecha_pago <= :next_30) AS due_next_30_count
                FROM documentos d
                LEFT JOIN tournaments t ON t.id = d.torneo_id
                LEFT JOIN cfdi_reports document_cfdi ON document_cfdi.id = d.cfdi_report_id
                WHERE {' AND '.join(document_filter)}
                  AND d.budget_concept_id IS NOT NULL
                """),
                {**params, "today": today, "next_30": next_30},
            )
        )
        .mappings()
        .first()
    )
    expense_row = (
        (
            await session.execute(
                text(f"""
                SELECT
                    COALESCE(SUM({_budget_expense_base_amount_sql('e', 'cfdi')}), 0) AS actual_total,
                    COUNT(*) AS expense_count
                FROM expense_reports e
                LEFT JOIN documentos d ON d.id = e.documento_id
                LEFT JOIN tournaments t ON t.id = d.torneo_id
                LEFT JOIN cfdi_reports cfdi ON cfdi.id = e.cfdi_report_id
                WHERE {' AND '.join(expense_filter)}
                  AND COALESCE(e.budget_concept_id, CASE WHEN d.tipo = 'SOLICITUD' THEN d.budget_concept_id END) IS NOT NULL
                """),
                params,
            )
        )
        .mappings()
        .first()
    )

    requested_total = round(
        _safe_decimal(document_row["requested_total"] if document_row else 0), 2
    )
    committed_total = round(
        _safe_decimal(document_row["committed_total"] if document_row else 0), 2
    )
    paid_total = round(
        _safe_decimal(document_row["paid_total"] if document_row else 0), 2
    )
    actual_total = round(
        _safe_decimal(expense_row["actual_total"] if expense_row else 0), 2
    )
    return {
        "requested_total": requested_total,
        "committed_total": committed_total,
        "paid_total": paid_total,
        "actual_total": actual_total,
        "pending_to_pay_total": round(max(committed_total - paid_total, 0), 2),
        "variance_vs_actual": round(budget_total - actual_total, 2),
        "variance_vs_committed": round(budget_total - committed_total, 2),
        "variance_vs_paid": round(budget_total - paid_total, 2),
        "variance_vs_requested": round(budget_total - requested_total, 2),
        "document_count": (
            int(document_row["document_count"] or 0) if document_row else 0
        ),
        "expense_count": int(expense_row["expense_count"] or 0) if expense_row else 0,
        "overdue_open_total": round(
            _safe_decimal(document_row["overdue_open_total"] if document_row else 0), 2
        ),
        "due_next_30_total": round(
            _safe_decimal(document_row["due_next_30_total"] if document_row else 0), 2
        ),
        "overdue_open_count": (
            int(document_row["overdue_open_count"] or 0) if document_row else 0
        ),
        "due_next_30_count": (
            int(document_row["due_next_30_count"] or 0) if document_row else 0
        ),
    }


def _empty_budget_snapshot(
    *,
    edition_year: int,
    source: str,
    version: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    """Return zero metrics when a client scope cannot be verified."""
    comparison = {
        "requested_total": 0.0,
        "committed_total": 0.0,
        "paid_total": 0.0,
        "actual_total": 0.0,
        "pending_to_pay_total": 0.0,
    }
    summary = {
        "edition_year": edition_year,
        "tournaments_count": 0,
        "line_count": 0,
        "budget_total": 0.0,
        "reference_total": 0.0,
        **comparison,
    }
    forecast = _build_budget_forecast(
        edition_year=edition_year, budget_total=0.0, comparison=comparison
    )
    scenarios = _build_budget_scenarios(
        edition_year=edition_year,
        budget_total=0.0,
        comparison=comparison,
        forecast=forecast,
    )
    return {
        "ok": True,
        "source": source,
        "version": version,
        "summary": summary,
        "comparison": comparison,
        "forecast": forecast,
        "scenarios": scenarios,
        "executive_alerts": [],
        "executive_comparison": {},
        "tournaments": [],
        "breakdowns": {},
    }


async def build_executive_monthly_actuals(
    session: AsyncSession,
    *,
    tournament_id: str,
    edition_year: int,
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
) -> list[dict[str, Any]]:
    """Read monthly execution using the same scope and tax base as the aggregate."""
    if not tournament_id:
        raise ValueError("Executive monthly reads require a tournament UUID")
    _, filters, params = _build_budget_scope_filters(
        edition_year=edition_year,
        tournament_id=tournament_id,
        tournament_name=None,
        tournament_code=None,
        date_from=date_from,
        date_to=date_to,
    )
    rows = (
        (
            await session.execute(
                text(f"""
        SELECT EXTRACT(MONTH FROM e.fecha)::int AS month,
            SUM({_budget_expense_base_amount_sql('e', 'cfdi')}) AS actual_total
        FROM expense_reports e
        LEFT JOIN documentos d ON d.id = e.documento_id
        LEFT JOIN cfdi_reports cfdi ON cfdi.id = e.cfdi_report_id
        WHERE {' AND '.join(filters)}
          AND COALESCE(e.budget_concept_id, CASE WHEN d.tipo = 'SOLICITUD' THEN d.budget_concept_id END) IS NOT NULL
        GROUP BY EXTRACT(MONTH FROM e.fecha) ORDER BY month
    """),
                params,
            )
        )
        .mappings()
        .all()
    )
    return [dict(row) for row in rows]


async def build_budget_snapshot(
    session: AsyncSession,
    *,
    tournament_id: Optional[str] = None,
    tournament_name: Optional[str] = None,
    tournament_slug: Optional[str] = None,
    edition_year: int = 2026,
    version_id: Optional[str] = None,
    ensure_schema: bool = True,
    strict_tournament_scope: bool = False,
    executive_read: bool = False,
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
) -> dict[str, Any]:
    if ensure_schema:
        await ensure_budget_schema(session)
    selected_version = await _select_budget_version(
        session,
        edition_year=edition_year,
        version_id=version_id,
        ensure_schema=ensure_schema,
    )
    period_kwargs = (
        {"date_from": date_from, "date_to": date_to}
        if date_from is not None or date_to is not None
        else {}
    )
    if executive_read and (
        not selected_version
        or selected_version.get("status") not in {"approved", "frozen"}
    ):
        return _empty_budget_snapshot(
            edition_year=edition_year,
            source="budget_scope_unavailable",
            version=selected_version,
        )
    aliases = budget_alias_candidates(tournament_name or "", tournament_slug or "")

    if strict_tournament_scope and not tournament_id:
        raise ValueError("strict_tournament_scope requires tournament_id")

    if not selected_version and strict_tournament_scope:
        return _empty_budget_snapshot(
            edition_year=edition_year,
            source="budget_scope_unavailable",
        )

    if not selected_version:
        artifact_rows = load_budget_artifact_rows()
        artifact_snapshot = build_budget_artifact_snapshot(
            artifact_rows,
            artifact_path=DEFAULT_BUDGET_ARTIFACT,
            tournament_name=tournament_name,
            tournament_slug=tournament_slug,
            edition_year=edition_year,
        )
        artifact_snapshot["comparison"] = {
            "requested_total": 0.0,
            "committed_total": 0.0,
            "paid_total": 0.0,
            "actual_total": 0.0,
        }
        artifact_snapshot["forecast"] = _build_budget_forecast(
            edition_year=edition_year,
            budget_total=float(
                artifact_snapshot.get("summary", {}).get("budget_total") or 0
            ),
            comparison=artifact_snapshot["comparison"],
        )
        artifact_snapshot["scenarios"] = _build_budget_scenarios(
            edition_year=edition_year,
            budget_total=float(
                artifact_snapshot.get("summary", {}).get("budget_total") or 0
            ),
            comparison=artifact_snapshot["comparison"],
            forecast=artifact_snapshot["forecast"],
        )
        artifact_snapshot["executive_alerts"] = build_budget_executive_alerts(
            artifact_snapshot.get("summary", {}),
            artifact_snapshot.get("forecast", {}),
            artifact_snapshot.get("scenarios", {}),
        )
        artifact_snapshot["executive_comparison"] = build_budget_executive_comparison(
            artifact_snapshot.get("summary", {}),
            artifact_snapshot.get("forecast", {}),
        )
        return artifact_snapshot

    filters = ["l.budget_version_id = :version_id"]
    if executive_read:
        filters.append("COALESCE(l.line_direction, 'expense') = 'expense'")
    params: dict[str, Any] = {"version_id": selected_version["id"]}
    if tournament_id:
        if strict_tournament_scope:
            filters.append("CAST(l.tournament_id AS text) = :tournament_id")
        else:
            filters.append(
                "(CAST(l.tournament_id AS text) = :tournament_id OR UPPER(COALESCE(l.tournament_code, '')) = ANY(:aliases))"
            )
        params["tournament_id"] = tournament_id
        if not strict_tournament_scope:
            params["aliases"] = list(sorted(aliases)) or [""]
    elif aliases:
        filters.append("UPPER(COALESCE(l.tournament_code, '')) = ANY(:aliases)")
        params["aliases"] = list(sorted(aliases))

    rows = (
        (
            await session.execute(
                text(f"""
                SELECT
                    l.id,
                    l.tournament_id,
                    l.tournament_code,
                    l.tournament_name,
                    l.concept_name,
                    l.budget_concept_id,
                    bc.concept_name AS current_concept_name,
                    l.account_code_final,
                    l.account_code_suggested,
                    l.phase,
                    l.priority,
                    l.owner_name,
                    l.budget_amount,
                    l.reference_amount,
                    l.variance_amount
                FROM budget_lines l
                LEFT JOIN budget_concepts bc ON bc.id = l.budget_concept_id
                WHERE {' AND '.join(filters)}
                ORDER BY l.tournament_name ASC, l.budget_amount DESC, l.concept_name ASC
                """),
                params,
            )
        )
        .mappings()
        .all()
    )

    if not rows and strict_tournament_scope:
        return _empty_budget_snapshot(
            edition_year=edition_year,
            source="budget_scope_unavailable",
            version=selected_version,
        )

    if not rows:
        artifact_rows = load_budget_artifact_rows()
        artifact_snapshot = build_budget_artifact_snapshot(
            artifact_rows,
            artifact_path=DEFAULT_BUDGET_ARTIFACT,
            tournament_name=tournament_name,
            tournament_slug=tournament_slug,
            edition_year=edition_year,
        )
        artifact_snapshot["version"] = {
            "id": selected_version["id"],
            "name": selected_version["version_name"],
            "status": selected_version["status"],
            "source": selected_version["source"],
            "artifact_path": selected_version["artifact_path"],
            "edition_year": selected_version["edition_year"],
        }
        artifact_snapshot["forecast"] = _build_budget_forecast(
            edition_year=edition_year,
            budget_total=float(
                artifact_snapshot.get("summary", {}).get("budget_total") or 0
            ),
            comparison={
                "actual_total": 0.0,
                "committed_total": 0.0,
                "paid_total": 0.0,
                "pending_to_pay_total": 0.0,
            },
        )
        artifact_snapshot["scenarios"] = _build_budget_scenarios(
            edition_year=edition_year,
            budget_total=float(
                artifact_snapshot.get("summary", {}).get("budget_total") or 0
            ),
            comparison={
                "actual_total": 0.0,
                "committed_total": 0.0,
                "paid_total": 0.0,
                "pending_to_pay_total": 0.0,
            },
            forecast=artifact_snapshot["forecast"],
        )
        artifact_snapshot["executive_alerts"] = build_budget_executive_alerts(
            artifact_snapshot.get("summary", {}),
            artifact_snapshot.get("forecast", {}),
            artifact_snapshot.get("scenarios", {}),
        )
        return artifact_snapshot

    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[_safe_str(row["tournament_name"])].append(dict(row))

    tournaments: list[dict[str, Any]] = []
    total_budget = 0.0
    total_reference = 0.0
    summary_comparison = {
        "requested_total": 0.0,
        "committed_total": 0.0,
        "paid_total": 0.0,
        "actual_total": 0.0,
        "pending_to_pay_total": 0.0,
        "overdue_open_total": 0.0,
        "due_next_30_total": 0.0,
    }
    forecast_health_counts = {"healthy": 0, "at_risk": 0, "over_budget": 0}
    summary_breakdowns = _build_budget_line_breakdowns(
        [dict(row) for row in rows],
        **({"concept_limit": None, "concept_identity": True} if executive_read else {}),
    )
    summary_finance_breakdowns = await _build_budget_finance_breakdowns(
        session,
        edition_year=edition_year,
        tournament_id=tournament_id,
        tournament_name=tournament_name,
        tournament_code=None,
        **period_kwargs,
        **({"concept_limit": None, "concept_identity": True} if executive_read else {}),
    )
    by_concept_store = _new_breakdown_store()
    for item in summary_breakdowns.get("by_concept", []):
        _merge_breakdown_row(by_concept_store, **item)
    for item in summary_finance_breakdowns.get("by_concept", []):
        _merge_breakdown_row(by_concept_store, **item)
    for name, items in sorted(grouped.items()):
        budget_total = sum(_safe_decimal(item["budget_amount"]) for item in items)
        reference_total = sum(_safe_decimal(item["reference_amount"]) for item in items)
        total_budget += budget_total
        total_reference += reference_total
        comparison = await _build_budget_finance_comparison(
            session,
            edition_year=edition_year,
            tournament_id=_safe_str(items[0].get("tournament_id")) or tournament_id,
            tournament_name=name,
            tournament_code=_safe_str(items[0].get("tournament_code")) or None,
            budget_total=round(budget_total, 2),
            **period_kwargs,
        )
        for key in summary_comparison:
            summary_comparison[key] += float(comparison.get(key) or 0)
        forecast = _build_budget_forecast(
            edition_year=edition_year,
            budget_total=round(budget_total, 2),
            comparison=comparison,
        )
        forecast_health_counts[str(forecast.get("health") or "healthy")] = (
            forecast_health_counts.get(str(forecast.get("health") or "healthy"), 0) + 1
        )
        tournament_line_breakdowns = _build_budget_line_breakdowns(items)
        tournament_finance_breakdowns = await _build_budget_finance_breakdowns(
            session,
            edition_year=edition_year,
            tournament_id=_safe_str(items[0].get("tournament_id")) or tournament_id,
            tournament_name=name,
            tournament_code=_safe_str(items[0].get("tournament_code")) or None,
            **period_kwargs,
        )
        tournament_concept_store = _new_breakdown_store()
        for item in tournament_line_breakdowns.get("by_concept", []):
            _merge_breakdown_row(tournament_concept_store, **item)
        for item in tournament_finance_breakdowns.get("by_concept", []):
            _merge_breakdown_row(tournament_concept_store, **item)
        tournaments.append(
            {
                "tournament_id": _safe_str(items[0].get("tournament_id")) or None,
                "tournament_code": _safe_str(items[0].get("tournament_code")) or None,
                "tournament_name": name,
                "line_count": len(items),
                "budget_total": round(budget_total, 2),
                "reference_total": round(reference_total, 2),
                "comparison": comparison,
                "forecast": forecast,
                "scenarios": _build_budget_scenarios(
                    edition_year=edition_year,
                    budget_total=round(budget_total, 2),
                    comparison=comparison,
                    forecast=forecast,
                ),
                "top_concepts": [
                    {
                        "concepto": _safe_str(item.get("concept_name")),
                        "presupuesto_2026": round(
                            _safe_decimal(item.get("budget_amount")), 2
                        ),
                        "cuenta_contable_final": _safe_str(
                            item.get("account_code_final")
                            or item.get("account_code_suggested")
                        )
                        or None,
                        "prioridad": _safe_str(item.get("priority")) or None,
                        "etapa": _safe_str(item.get("phase")) or None,
                    }
                    for item in items[:8]
                ],
                "breakdowns": {
                    "by_concept": _finalize_breakdown_store(tournament_concept_store),
                    "by_phase": tournament_line_breakdowns.get("by_phase", []),
                    "by_entity": tournament_line_breakdowns.get("by_entity", []),
                    "by_owner": tournament_line_breakdowns.get("by_owner", []),
                    "by_account": tournament_line_breakdowns.get("by_account", []),
                    "by_provider": tournament_finance_breakdowns.get("by_provider", []),
                },
            }
        )

    summary_forecast = _build_budget_forecast(
        edition_year=edition_year,
        budget_total=round(total_budget, 2),
        comparison=summary_comparison,
    )

    scenarios = _build_budget_scenarios(
        edition_year=edition_year,
        budget_total=round(total_budget, 2),
        comparison=summary_comparison,
        forecast=summary_forecast,
    )
    summary = {
        "edition_year": edition_year,
        "tournaments_count": len(tournaments),
        "line_count": len(rows),
        "budget_total": round(total_budget, 2),
        "reference_total": round(total_reference, 2),
        "requested_total": round(summary_comparison["requested_total"], 2),
        "committed_total": round(summary_comparison["committed_total"], 2),
        "paid_total": round(summary_comparison["paid_total"], 2),
        "actual_total": round(summary_comparison["actual_total"], 2),
        "pending_to_pay_total": round(summary_comparison["pending_to_pay_total"], 2),
        "overdue_open_total": round(summary_comparison["overdue_open_total"], 2),
        "due_next_30_total": round(summary_comparison["due_next_30_total"], 2),
        "variance_vs_actual": round(
            total_budget - summary_comparison["actual_total"], 2
        ),
        "variance_vs_committed": round(
            total_budget - summary_comparison["committed_total"], 2
        ),
        "variance_vs_paid": round(total_budget - summary_comparison["paid_total"], 2),
        "forecast_health_counts": forecast_health_counts,
    }

    quality_gaps = []
    if executive_read:
        document_filters, expense_filters, quality_params = _build_budget_scope_filters(
            edition_year=edition_year,
            tournament_id=tournament_id,
            tournament_name=tournament_name,
            tournament_code=None,
            **period_kwargs,
        )
        quality = (
            (
                await session.execute(
                    text(f"""
            SELECT COUNT(*) FILTER (WHERE e.cfdi_compartido_confirmado IS TRUE
                OR EXISTS (SELECT 1 FROM expense_reports sibling
                    WHERE sibling.cfdi_report_id = e.cfdi_report_id
                      AND sibling.id <> e.id AND sibling.estado_gasto <> 'cancelado'
                      AND {accounting_expense_sql('sibling')})) AS shared_count,
                COUNT(*) FILTER (WHERE COALESCE(e.currency, '') <> 'MXN') AS currency_count,
                COUNT(*) FILTER (WHERE e.gasto_cantidad IS NULL) AS missing_amount_count
            FROM expense_reports e
            LEFT JOIN documentos d ON d.id = e.documento_id
            LEFT JOIN tournaments t ON t.id = d.torneo_id
            WHERE {' AND '.join(expense_filters)}
        """),
                    quality_params,
                )
            )
            .mappings()
            .first()
        )
        if quality and int(quality.get("shared_count") or 0):
            quality_gaps.append("shared_cfdi_allocation_requires_reconciliation")
        if quality and int(quality.get("currency_count") or 0):
            quality_gaps.append("mixed_or_unknown_currency")
        if quality and int(quality.get("missing_amount_count") or 0):
            quality_gaps.append("expense_amount_missing")
        document_quality = (
            (
                await session.execute(
                    text(f"""
            SELECT COUNT(*) FILTER (WHERE COALESCE(d.currency, '') <> 'MXN') AS currency_count,
                COUNT(*) FILTER (WHERE d.monto_total IS NULL AND d.monto_solicitado IS NULL) AS missing_amount_count
            FROM documentos d LEFT JOIN tournaments t ON t.id = d.torneo_id
            WHERE {' AND '.join(document_filters)}
        """),
                    quality_params,
                )
            )
            .mappings()
            .first()
        )
        if document_quality and int(document_quality.get("currency_count") or 0):
            quality_gaps.append("mixed_or_unknown_currency")
        if document_quality and int(document_quality.get("missing_amount_count") or 0):
            quality_gaps.append("document_amount_missing")

    executive_monthly = (
        await build_executive_monthly_actuals(
            session,
            tournament_id=tournament_id,
            edition_year=edition_year,
            **period_kwargs,
        )
        if executive_read and tournament_id
        else None
    )
    distribution = None
    if executive_read:
        from .distribution import period_projection

        distribution_lines = [dict(row) for row in rows if row.get("id")]
        plan = await list_monthly_plan_for_lines(
            session,
            line_ids=[str(row["id"]) for row in distribution_lines],
            ensure_schema=False,
        )
        distribution = period_projection(
            distribution_lines,
            plan,
            edition_year,
            date_to or date(edition_year, 12, 31),
        )
    return {
        "ok": True,
        "source": "budget_db",
        **(
            {
                "executive_quality_gaps": sorted(set(quality_gaps)),
                "executive_monthly_actuals": executive_monthly,
                "budget_distribution": distribution,
                "executive_concepts": _finalize_breakdown_store(
                    by_concept_store, limit=None
                ),
            }
            if executive_read
            else {}
        ),
        "version": {
            "id": selected_version["id"],
            "name": selected_version["version_name"],
            "status": selected_version["status"],
            "source": selected_version["source"],
            "artifact_path": selected_version["artifact_path"],
            "edition_year": edition_year,
        },
        "summary": summary,
        "breakdowns": {
            "by_concept": _finalize_breakdown_store(by_concept_store),
            "by_phase": summary_breakdowns.get("by_phase", []),
            "by_entity": summary_breakdowns.get("by_entity", []),
            "by_owner": summary_breakdowns.get("by_owner", []),
            "by_account": summary_breakdowns.get("by_account", []),
            "by_provider": summary_finance_breakdowns.get("by_provider", []),
        },
        "forecast": summary_forecast,
        "scenarios": scenarios,
        "executive_alerts": build_budget_executive_alerts(
            summary,
            summary_forecast,
            scenarios,
        ),
        "executive_comparison": build_budget_executive_comparison(
            summary,
            summary_forecast,
        ),
        "tournaments": tournaments,
    }


BUDGET_WEEK_COUNT = 52

_MONTH_LABELS_ES = {
    1: "Ene",
    2: "Feb",
    3: "Mar",
    4: "Abr",
    5: "May",
    6: "Jun",
    7: "Jul",
    8: "Ago",
    9: "Sep",
    10: "Oct",
    11: "Nov",
    12: "Dic",
}
_WEEK_LABELS_ES = {week: f"Semana {week}" for week in range(1, BUDGET_WEEK_COUNT + 1)}


def budget_period_label(period_number: int) -> str:
    period = int(period_number)
    return _WEEK_LABELS_ES.get(period, f"Semana {period}")


def month_labels_es(month_numbers: list[int]) -> list[dict[str, Any]]:
    # Historical API name retained for compatibility. The active budget grid
    # now stores weekly periods in the legacy month_number column.
    return [
        {"month_number": month, "label": budget_period_label(month)}
        for month in month_numbers
    ]


def _budget_week_number_sql(date_sql: str) -> str:
    """Return SQL for Plataforma budget week number, capped to 52.

    Week 1 starts on Jan 1 even if incomplete. Subsequent weeks start on
    Monday; the final period is capped at week 52 so every date in the year
    remains visible in the 52-column budget grid.
    """
    jan1 = f"DATE_TRUNC('year', ({date_sql})::date)::date"
    jan1_isodow = f"EXTRACT(ISODOW FROM {jan1})::int"
    days_to_next_monday = (
        f"CASE WHEN {jan1_isodow} = 1 THEN 7 ELSE 8 - {jan1_isodow} END"
    )
    first_monday_after_week1 = f"({jan1} + ({days_to_next_monday}))"
    return (
        "LEAST(52, CASE "
        f"WHEN ({date_sql})::date < {first_monday_after_week1} THEN 1 "
        f"ELSE 2 + FLOOR((({date_sql})::date - {first_monday_after_week1}) / 7)::int "
        "END)"
    )


def _budget_week_number(value: Any, edition_year: int) -> int:
    """Return the Python equivalent of ``_budget_week_number_sql``."""
    if isinstance(value, datetime):
        current = value.date()
    elif isinstance(value, date):
        current = value
    else:
        current = date.fromisoformat(str(value)[:10])
    jan1 = date(int(edition_year), 1, 1)
    days_to_next_monday = 7 if jan1.isoweekday() == 1 else 8 - jan1.isoweekday()
    first_monday = jan1 + timedelta(days=days_to_next_monday)
    if current < first_monday:
        return 1
    return min(52, 2 + (current - first_monday).days // 7)


def _date_in_edition_year(value: Any, edition_year: int) -> bool:
    """Return whether a date-like value belongs to the requested edition year."""
    if value is None:
        return False
    try:
        current = value.date() if isinstance(value, datetime) else value
        if not isinstance(current, date):
            current = date.fromisoformat(str(current)[:10])
    except (TypeError, ValueError):
        return False
    return current.year == int(edition_year)


def _first_date_in_edition_year(edition_year: int, *values: Any) -> Any:
    """Return the first candidate that falls inside the edition calendar year."""
    return next(
        (value for value in values if _date_in_edition_year(value, edition_year)),
        date(int(edition_year), 1, 1),
    )


async def list_budget_line_monthly_allocations(
    session: AsyncSession,
    *,
    budget_line_id: str,
    ensure_schema: bool = True,
) -> list[dict[str, Any]]:
    if ensure_schema:
        await ensure_budget_schema(session)
    rows = (
        (
            await session.execute(
                text(
                    """
                SELECT month_number, allocated_amount
                FROM budget_line_monthly_allocations
                WHERE budget_line_id = :budget_line_id
                ORDER BY month_number ASC
                """
                ),
                {"budget_line_id": budget_line_id},
            )
        )
        .mappings()
        .all()
    )
    return [
        {
            "month_number": int(row["month_number"]),
            "label": budget_period_label(int(row["month_number"])),
            "allocated_amount": round(_safe_decimal(row["allocated_amount"]), 2),
        }
        for row in rows
    ]


async def list_monthly_allocations_for_lines(
    session: AsyncSession,
    *,
    line_ids: list[str],
) -> dict[str, dict[int, float]]:
    await ensure_budget_schema(session)
    clean_ids = [_safe_str(line_id) for line_id in line_ids if _safe_str(line_id)]
    if not clean_ids:
        return {}
    rows = (
        (
            await session.execute(
                text(
                    """
                SELECT budget_line_id, month_number, allocated_amount
                FROM budget_line_monthly_allocations
                WHERE budget_line_id = ANY(CAST(:line_ids AS uuid[]))
                ORDER BY budget_line_id ASC, month_number ASC
                """
                ),
                {"line_ids": clean_ids},
            )
        )
        .mappings()
        .all()
    )
    result: dict[str, dict[int, float]] = defaultdict(dict)
    for row in rows:
        line_id = _safe_str(row["budget_line_id"])
        month_number = int(row["month_number"])
        result[line_id][month_number] = round(_safe_decimal(row["allocated_amount"]), 2)
    return dict(result)


async def replace_budget_line_monthly_allocations(
    session: AsyncSession,
    *,
    budget_line_id: str,
    allocations: dict[int, Any],
    ensure_schema: bool = True,
) -> list[dict[str, Any]]:
    if ensure_schema:
        await ensure_budget_schema(session)
    clean_line_id = _safe_str(budget_line_id)
    if not clean_line_id:
        raise ValueError("Budget line id is required")
    await session.execute(
        text(
            """
            DELETE FROM budget_line_monthly_allocations
            WHERE budget_line_id = :budget_line_id
            """
        ),
        {"budget_line_id": clean_line_id},
    )
    for month_number in sorted(allocations.keys()):
        month_int = int(month_number)
        if month_int < 1 or month_int > BUDGET_WEEK_COUNT:
            raise ValueError(f"Invalid month number: {month_int}")
        amount = round(_safe_decimal(allocations[month_number]), 2)
        await session.execute(
            text(
                """
                INSERT INTO budget_line_monthly_allocations (
                    id, budget_line_id, month_number, allocated_amount, metadata, created_at, updated_at
                ) VALUES (
                    :id, :budget_line_id, :month_number, :allocated_amount, CAST(:metadata AS jsonb), NOW(), NOW()
                )
                """
            ),
            {
                "id": str(uuid.uuid4()),
                "budget_line_id": clean_line_id,
                "month_number": month_int,
                "allocated_amount": amount,
                "metadata": json.dumps({"source": "ui_manual"}, ensure_ascii=False),
            },
        )
    return await list_budget_line_monthly_allocations(
        session, budget_line_id=clean_line_id, ensure_schema=False
    )


def distribute_even_monthly_allocations(budget_amount: float) -> dict[int, float]:
    total = round(_safe_decimal(budget_amount), 2)
    base = round(total / float(BUDGET_WEEK_COUNT), 2)
    allocations = {week: base for week in range(1, BUDGET_WEEK_COUNT + 1)}
    remainder = round(total - sum(allocations.values()), 2)
    if remainder:
        allocations[BUDGET_WEEK_COUNT] = round(allocations[BUDGET_WEEK_COUNT] + remainder, 2)
    return allocations


async def get_budget_version_by_source(
    session: AsyncSession,
    *,
    edition_year: int,
    source: str,
) -> Optional[dict[str, Any]]:
    await ensure_budget_schema(session)
    row = (
        (
            await session.execute(
                text(
                    """
                SELECT id
                FROM budget_versions
                WHERE edition_year = :edition_year AND source = :source
                ORDER BY updated_at DESC
                LIMIT 1
                """
                ),
                {"edition_year": edition_year, "source": _safe_str(source)},
            )
        )
        .mappings()
        .first()
    )
    if not row:
        return None
    versions = await list_budget_versions(session, edition_year=edition_year)
    target_id = _safe_str(row["id"])
    for version in versions:
        if version["id"] == target_id:
            return version
    return None


async def list_budget_lines_with_monthly(
    session: AsyncSession,
    *,
    version_id: str,
    tournament_id: Optional[str] = None,
    line_direction: Optional[str] = None,
    limit: int = 5000,
) -> list[dict[str, Any]]:
    lines = await list_budget_lines(
        session,
        version_id=version_id,
        tournament_id=tournament_id,
        line_direction=line_direction,
        limit=limit,
    )
    monthly_map = await list_monthly_allocations_for_lines(
        session,
        line_ids=[line["id"] for line in lines],
    )
    enriched: list[dict[str, Any]] = []
    for line in lines:
        monthly = monthly_map.get(line["id"], {})
        enriched.append(
            {
                **line,
                "monthly_allocations": [
                    {
                        "month_number": month,
                        "label": budget_period_label(month),
                        "allocated_amount": amount,
                    }
                    for month, amount in sorted(monthly.items())
                ],
                "monthly_total": round(sum(monthly.values()), 2),
            }
        )
    return enriched


async def upsert_budget_line_for_concept(
    session: AsyncSession,
    *,
    version_id: str,
    budget_concept_id: str,
    budget_amount: Any,
    actor_empleado_id: Optional[str] = None,
    phase: Optional[str] = None,
    line_direction: Optional[str] = None,
    monthly_allocations: Optional[dict[int, Any]] = None,
    commit: bool = True,
    preserve_existing: bool = False,
    ensure_schema: bool = True,
) -> dict[str, Any]:
    if ensure_schema:
        await ensure_budget_schema(session)
    clean_direction = normalize_budget_line_direction(line_direction)
    concept = await resolve_budget_concept(
        session,
        budget_concept_id=budget_concept_id,
        budget_direction=clean_direction,
    )
    if concept is None:
        raise ValueError("Budget concept not found")

    existing = (
        (
            await session.execute(
                text("""
                SELECT l.id, v.source AS version_source
                FROM budget_lines l JOIN budget_versions v ON v.id=l.budget_version_id
                WHERE l.budget_version_id = :version_id
                  AND l.budget_concept_id = :budget_concept_id
                  AND COALESCE(l.line_direction, 'expense') = :line_direction
                LIMIT 1
                """),
                {
                    "version_id": version_id,
                    "budget_concept_id": _safe_str(budget_concept_id),
                    "line_direction": clean_direction,
                },
            )
        )
        .mappings()
        .first()
    )

    metadata = (
        concept.get("metadata") if isinstance(concept.get("metadata"), dict) else {}
    )
    if existing and existing.get("version_source") == "distribution_revision":
        raise ValueError(
            "La revisión de distribución no altera partidas ni conciliaciones financieras"
        )
    phase_labels = metadata.get("applicable_phase_labels") or []
    resolved_phase = _safe_str(phase) or (
        str(phase_labels[0]).strip() if phase_labels else None
    )

    if existing and preserve_existing:
        line_id = _safe_str(existing["id"])
        monthly = await list_budget_line_monthly_allocations(
            session,
            budget_line_id=line_id,
            ensure_schema=False,
        )
    else:
        if budget_amount is None:
            raise ValueError("Budget amount is required when creating a line")
        amount = round(_safe_decimal(budget_amount), 2)
        if existing:
            line = await update_budget_line(
                session,
                line_id=_safe_str(existing["id"]),
                actor_empleado_id=actor_empleado_id,
                updates={"budget_amount": amount, "phase": resolved_phase},
                commit=commit,
            )
            line_id = line["id"]
        else:
            line = await create_budget_line(
                session,
                version_id=version_id,
                actor_empleado_id=actor_empleado_id,
                budget_concept_id=budget_concept_id,
                concept_name=_safe_str(concept.get("concept_name")),
                tournament_code=_safe_str(concept.get("tournament_code")) or None,
                tournament_name=_safe_str(concept.get("tournament_name"))
                or "Presupuesto general",
                phase=resolved_phase,
                line_direction=clean_direction,
                budget_amount=amount,
                commit=commit,
                ensure_schema=False,
            )
            line_id = line["id"]

        allocations = monthly_allocations
        if allocations is None:
            allocations = distribute_even_monthly_allocations(amount)
        monthly = await replace_budget_line_monthly_allocations(
            session,
            budget_line_id=line_id,
            allocations=allocations,
            ensure_schema=False,
        )
    if commit:
        await session.commit()
    refreshed = await list_budget_lines(
        session,
        version_id=version_id,
        line_direction=clean_direction,
        limit=5000,
        ensure_schema=False,
    )
    for item in refreshed:
        if item["id"] == line_id:
            return {**item, "monthly_allocations": monthly}
    raise ValueError("Budget line not found after upsert")


def budget_movement_key(movement: dict[str, Any]) -> str:
    """Identify a posting or expense without merging report concepts."""
    accounting_line_id = _safe_str(movement.get("accounting_line_id"))
    if accounting_line_id:
        return f"accounting:{accounting_line_id}"
    expense_id = _safe_str(movement.get("expense_id"))
    if expense_id:
        return f"expense:{expense_id}"
    document_id = _safe_str(movement.get("document_id"))
    if document_id:
        concept_id = _safe_str(movement.get("concept_key"))
        if concept_id and concept_id != _UNASSIGNED_BUDGET_CONCEPT_KEY:
            return f"document:{document_id}:concept:{concept_id}"
        return f"document:{document_id}"
    return ""


async def assign_budget_movement_to_line(
    session: AsyncSession,
    *,
    budget_version_id: str,
    budget_concept_id: str,
    budget_line_id: str,
    movement_key: str,
    actor_empleado_id: Optional[str],
    ensure_schema: bool = True,
    source_kind: Optional[str] = None,
) -> None:
    """Persist an explicit, per-movement assignment for a budget version."""
    clean_key = _safe_str(movement_key)
    if not clean_key or ":" not in clean_key:
        raise ValueError("Budget movement key is required")
    if source_kind not in {None, "amex_direct"}:
        raise ValueError("Unsupported budget movement source")
    if source_kind == "amex_direct" and ensure_schema:
        raise ValueError("AMEX direct assignments require owner-installed schema")
    if ensure_schema:
        await ensure_budget_schema(session)
    target_sql = """SELECT l.tournament_id::text AS tournament_id, v.edition_year,
                      v.status AS version_status
            FROM budget_lines l JOIN budget_versions v ON v.id=l.budget_version_id
            WHERE l.id=CAST(:line_id AS uuid)
              AND l.budget_version_id=CAST(:version_id AS uuid)
              AND l.budget_concept_id=CAST(:concept_id AS uuid)
              AND COALESCE(l.line_direction, 'expense')='expense'
              AND v.source <> 'distribution_revision'
            """
    target_params = {
        "line_id": _safe_str(budget_line_id),
        "version_id": _safe_str(budget_version_id),
        "concept_id": _safe_str(budget_concept_id),
    }
    target_result = await session.execute(text(target_sql), target_params)
    target = target_result.mappings().first()
    if target is None:
        raise ValueError("Partida inválida para esta versión o concepto presupuestal.")
    if source_kind == "amex_direct":
        from devnous.gastos.services.amex_direct_budget_service import (
            budget_assignment_source,
        )

        movement, permitted_version = await budget_assignment_source(
            session,
            movement_key=clean_key,
            tournament_id=target["tournament_id"],
            edition_year=int(target["edition_year"]),
            budget_concept_id=_safe_str(budget_concept_id),
            version_status=target["version_status"],
            actor_empleado_id=actor_empleado_id,
        )
        if not permitted_version or budget_movement_key(movement) != clean_key:
            raise ValueError("Fuente AMEX o versión presupuestal no autorizada.")
        # Source proof acquires import/global locks first. Lock the actual line
        # and version afterwards and reject changes made while waiting.
        locked_result = await session.execute(
            text(target_sql + " FOR UPDATE OF l,v"), target_params
        )
        locked_target = locked_result.mappings().first()
        if locked_target is None or dict(locked_target) != dict(target):
            raise ValueError("La partida o versión cambió; recarga el contexto AMEX")
        candidates = [movement]
    else:
        if not _editable_version_status(target["version_status"]):
            raise ValueError(
                "Partida inválida para esta versión o concepto presupuestal."
            )
        snapshot = await build_budget_actuals_snapshot(
            session,
            edition_year=int(target["edition_year"]),
            version_id=_safe_str(budget_version_id),
            tournament_id=target["tournament_id"],
        )
        candidates = [
            movement
            for movement in snapshot["movements"]
            if budget_movement_key(movement) == clean_key
            or (
                movement.get("document_id")
                and clean_key == f"document:{movement['document_id']}"
            )
        ]
    if source_kind is None and any(
        movement.get("source_kind") == "amex_direct"
        or movement.get("origen") == "amex_direct"
        for movement in candidates
    ):
        raise ValueError("El origen AMEX directo requiere su autoridad presupuestal")
    if not candidates or any(
        _safe_str(movement.get("concept_key")) != _safe_str(budget_concept_id)
        for movement in candidates
    ):
        raise ValueError(
            "El movimiento no corresponde a esta partida; recarga el detalle."
        )
    await session.execute(
        text("""
            INSERT INTO budget_movement_assignments (
                id, budget_version_id, budget_concept_id, budget_line_id,
                movement_key, assigned_by_empleado_id, created_at, updated_at
            ) VALUES (
                :id, :budget_version_id, :budget_concept_id, :budget_line_id,
                :movement_key, :actor_empleado_id, NOW(), NOW()
            )
            ON CONFLICT (budget_version_id, movement_key) DO UPDATE SET
                budget_concept_id = EXCLUDED.budget_concept_id,
                budget_line_id = EXCLUDED.budget_line_id,
                assigned_by_empleado_id = EXCLUDED.assigned_by_empleado_id,
                updated_at = NOW()
            """),
        {
            "id": str(uuid.uuid4()),
            "budget_version_id": _safe_str(budget_version_id),
            "budget_concept_id": _safe_str(budget_concept_id),
            "budget_line_id": _safe_str(budget_line_id),
            "movement_key": clean_key,
            "actor_empleado_id": _safe_str(actor_empleado_id) or None,
        },
    )


_UNASSIGNED_BUDGET_CONCEPT_KEY = "__unassigned__"


def _empty_monthly_actual_bucket() -> dict[str, float]:
    return {
        "real_expense_cash": 0.0,
        "real_income": 0.0,
        "committed_unpaid": 0.0,
    }


def _monthly_actual_store() -> dict[str, dict[int, dict[str, float]]]:
    return defaultdict(lambda: defaultdict(_empty_monthly_actual_bucket))


def _merge_monthly_actual(
    store: dict[str, dict[int, dict[str, float]]],
    *,
    concept_key: str,
    month_number: int,
    **values: float,
) -> None:
    if month_number < 1 or month_number > BUDGET_WEEK_COUNT:
        return
    bucket = store[concept_key][month_number]
    for key, value in values.items():
        bucket[key] = round(bucket.get(key, 0.0) + _safe_decimal(value), 2)


async def _apply_explicit_movement_assignments(
    session: AsyncSession,
    *,
    budget_version_id: str,
    movements: list[dict[str, Any]],
    store: dict[str, dict[int, dict[str, float]]],
) -> None:
    """Attach movements to lines, preserving concept-based behavior for legacy data."""
    assignment_rows = (
        (
            await session.execute(
                text("""
                    SELECT id::text AS assignment_id, movement_key,
                           budget_concept_id::text AS budget_concept_id,
                           budget_line_id::text AS budget_line_id
                    FROM budget_movement_assignments
                    WHERE budget_version_id = CAST(:budget_version_id AS uuid)
                    """),
                {"budget_version_id": _safe_str(budget_version_id)},
            )
        )
        .mappings()
        .all()
    )
    assignments = {_safe_str(row["movement_key"]): row for row in assignment_rows}
    activated_concepts = {
        _safe_str(row["budget_concept_id"]) for row in assignment_rows
    }
    line_rows = (
        (
            await session.execute(
                text("""
                    SELECT id::text AS id, budget_concept_id::text AS budget_concept_id
                    FROM budget_lines
                    WHERE budget_version_id = CAST(:budget_version_id AS uuid)
                      AND COALESCE(line_direction, 'expense') = 'expense'
                    """),
                {"budget_version_id": _safe_str(budget_version_id)},
            )
        )
        .mappings()
        .all()
    )
    legacy_lines = {
        _safe_str(row["budget_concept_id"]): _safe_str(row["id"])
        for row in line_rows
        if _safe_str(row["budget_concept_id"])
    }
    line_concepts = {
        _safe_str(row["id"]): _safe_str(row["budget_concept_id"]) for row in line_rows
    }
    # Lightweight unit seams and versions with no expense lines retain the
    # legacy concept-keyed actuals; there is nothing to reconcile to yet.
    if not legacy_lines and not assignment_rows:
        for movement in movements:
            movement["movement_key"] = budget_movement_key(movement) or None
            movement["budget_line_id"] = None
            movement["reconciliation_status"] = "unassigned"
        return

    for months in store.values():
        for values in months.values():
            values["real_expense_cash"] = 0.0
            values["committed_unpaid"] = 0.0
    for movement in movements:
        concept_id = _safe_str(movement.get("concept_key"))
        movement_key = budget_movement_key(movement)
        # Old document-level assignments remain valid for their own concept.
        # Never carry a hotel assignment onto food/transport in the same report.
        candidate_keys = [movement_key]
        if movement.get("expense_id"):
            candidate_keys.append(f"expense:{movement['expense_id']}")
        if movement.get("document_id"):
            candidate_keys.append(f"document:{movement['document_id']}")
        line_id = None
        is_direct = movement.get("source_kind") == "amex_direct"
        for candidate_key in candidate_keys:
            assignment = assignments.get(candidate_key)
            if assignment is None:
                continue
            if is_direct and (
                not movement.get("budget_assignment_id")
                or _safe_str(assignment.get("assignment_id"))
                != _safe_str(movement["budget_assignment_id"])
            ):
                continue
            assigned_line = _safe_str(assignment["budget_line_id"])
            if (
                _safe_str(assignment["budget_concept_id"]) == concept_id
                and line_concepts.get(assigned_line) == concept_id
            ):
                line_id = assigned_line
                break
        if not line_id and not is_direct and concept_id not in activated_concepts:
            line_id = legacy_lines.get(concept_id)
        movement["movement_key"] = movement_key or None
        movement["budget_line_id"] = line_id or None
        movement["reconciliation_status"] = "assigned" if line_id else "unassigned"
        if movement.get("kind") == "ledger_expense":
            _merge_monthly_actual(
                store,
                concept_key=line_id or _UNASSIGNED_BUDGET_CONCEPT_KEY,
                month_number=int(movement.get("month_number") or 1),
                real_expense_cash=_safe_decimal(movement.get("amount")),
            )
        elif movement.get("kind") == "commitment":
            _merge_monthly_actual(
                store,
                concept_key=line_id or _UNASSIGNED_BUDGET_CONCEPT_KEY,
                month_number=int(movement.get("month_number") or 1),
                committed_unpaid=_safe_decimal(movement.get("amount")),
            )


async def list_monthly_plan_for_lines(
    session: AsyncSession,
    *,
    line_ids: list[str],
    ensure_schema: bool = True,
) -> dict[str, dict[int, dict[str, float]]]:
    if ensure_schema:
        await ensure_budget_schema(session)
    clean_ids = [_safe_str(line_id) for line_id in line_ids if _safe_str(line_id)]
    if not clean_ids:
        return {}
    rows = (
        (
            await session.execute(
                text(
                    """
                SELECT budget_line_id, month_number, budget_expense_amount, expected_income_amount
                FROM budget_line_monthly_plan
                WHERE budget_line_id = ANY(CAST(:line_ids AS uuid[]))
                ORDER BY budget_line_id ASC, month_number ASC
                """
                ),
                {"line_ids": clean_ids},
            )
        )
        .mappings()
        .all()
    )
    result: dict[str, dict[int, dict[str, float]]] = defaultdict(dict)
    for row in rows:
        line_id = _safe_str(row["budget_line_id"])
        month_number = int(row["month_number"])
        result[line_id][month_number] = {
            "budget_expense_amount": round(
                _safe_decimal(row["budget_expense_amount"]), 2
            ),
            "expected_income_amount": round(
                _safe_decimal(row["expected_income_amount"]), 2
            ),
        }
    return dict(result)


def validate_budget_expense_plan_total(
    plan: dict[int, dict[str, Any]],
    *,
    budget_amount: Any,
) -> float:
    """Require the expense schedule to reconcile to the authorized total."""
    authorized_total = round(_safe_decimal(budget_amount), 2)
    scheduled_total = round(
        sum(
            round(
                _safe_decimal(
                    payload.get("budget_expense_amount", 0)
                    if isinstance(payload, dict)
                    else 0
                ),
                2,
            )
            for payload in plan.values()
        ),
        2,
    )
    if abs(authorized_total - scheduled_total) > 0.005:
        raise ValueError(
            "La calendarización del gasto debe sumar el monto total autorizado "
            f"(${authorized_total:,.2f}); actualmente suma ${scheduled_total:,.2f}."
        )
    return scheduled_total


async def replace_budget_line_monthly_plan(
    session: AsyncSession,
    *,
    budget_line_id: str,
    plan: dict[int, dict[str, Any]],
    actor_empleado_id: Optional[str] = None,
    ensure_schema: bool = True,
) -> list[dict[str, Any]]:
    if ensure_schema:
        await ensure_budget_schema(session)
    clean_line_id = _safe_str(budget_line_id)
    if not clean_line_id:
        raise ValueError("Budget line id is required")
    current = (
        (
            await session.execute(
                text("""
                SELECT
                    l.budget_version_id,
                    l.budget_amount,
                    COALESCE(l.line_direction, 'expense') AS line_direction,
                    v.status AS version_status,
                    v.source AS version_source
                FROM budget_lines l
                JOIN budget_versions v ON v.id = l.budget_version_id
                WHERE l.id = :budget_line_id
                FOR UPDATE OF l, v
                """),
                {"budget_line_id": clean_line_id},
            )
        )
        .mappings()
        .first()
    )
    if not current:
        raise ValueError("Budget line not found")
    if not _editable_version_status(current.get("version_status")):
        raise ValueError("Only draft or reforecast versions allow line edits")
    if (
        current.get("version_source") == "distribution_revision"
        and normalize_budget_line_direction(current.get("line_direction")) != "expense"
    ):
        raise ValueError(
            "Esta revisión completa sólo la distribución del gasto autorizado"
        )
    from .distribution import money

    for week, values in plan.items():
        if not 1 <= int(week) <= BUDGET_WEEK_COUNT:
            raise ValueError("Semana fuera de 1–52")
        money(values.get("budget_expense_amount", 0))
        money(values.get("expected_income_amount", 0))
    if normalize_budget_line_direction(current.get("line_direction")) == "expense":
        validate_budget_expense_plan_total(
            plan,
            budget_amount=current.get("budget_amount"),
        )
    before_plan = (
        await list_monthly_plan_for_lines(
            session, line_ids=[clean_line_id], ensure_schema=False
        )
    ).get(clean_line_id, {})
    if current.get("version_source") == "distribution_revision":
        plan = {week: dict(values) for week, values in plan.items()}
        for week in set(plan) | set(before_plan):
            income = before_plan.get(week, {}).get("expected_income_amount", 0)
            if "expected_income_amount" in plan.get(week, {}) and money(
                plan[week]["expected_income_amount"]
            ) != money(income):
                raise ValueError("Esta revisión no cambia ingresos esperados")
            if week in plan or income:
                plan.setdefault(week, {"budget_expense_amount": 0})[
                    "expected_income_amount"
                ] = income
    await session.execute(
        text(
            """
            DELETE FROM budget_line_monthly_plan
            WHERE budget_line_id = :budget_line_id
            """
        ),
        {"budget_line_id": clean_line_id},
    )
    expense_allocations: dict[int, float] = {}
    for month_number in sorted(plan.keys()):
        month_int = int(month_number)
        if month_int < 1 or month_int > BUDGET_WEEK_COUNT:
            raise ValueError(f"Invalid month number: {month_int}")
        payload = plan[month_int] if isinstance(plan[month_int], dict) else {}
        expense_amount = round(
            _safe_decimal(payload.get("budget_expense_amount", 0)), 2
        )
        income_amount = round(
            _safe_decimal(payload.get("expected_income_amount", 0)), 2
        )
        expense_allocations[month_int] = expense_amount
        await session.execute(
            text(
                """
                INSERT INTO budget_line_monthly_plan (
                    id, budget_line_id, month_number,
                    budget_expense_amount, expected_income_amount,
                    metadata, created_at, updated_at
                ) VALUES (
                    :id, :budget_line_id, :month_number,
                    :budget_expense_amount, :expected_income_amount,
                    CAST(:metadata AS jsonb), NOW(), NOW()
                )
                """
            ),
            {
                "id": str(uuid.uuid4()),
                "budget_line_id": clean_line_id,
                "month_number": month_int,
                "budget_expense_amount": expense_amount,
                "expected_income_amount": income_amount,
                "metadata": json.dumps({"source": "ui_manual"}, ensure_ascii=False),
            },
        )
    await replace_budget_line_monthly_allocations(
        session,
        budget_line_id=clean_line_id,
        allocations=expense_allocations,
        ensure_schema=False,
    )
    rows = await list_monthly_plan_for_lines(
        session, line_ids=[clean_line_id], ensure_schema=False
    )
    line_plan = rows.get(clean_line_id, {})
    await _audit_budget_event(
        session,
        budget_version_id=_safe_str(current["budget_version_id"]),
        event_type="line_monthly_plan_updated",
        actor_empleado_id=actor_empleado_id,
        from_status=_safe_str(current["version_status"]),
        to_status=_safe_str(current["version_status"]),
        payload={
            "line_id": clean_line_id,
            "before": before_plan,
            "after": line_plan,
        },
    )
    return [
        {
            "month_number": month,
            "label": budget_period_label(month),
            "budget_expense_amount": values.get("budget_expense_amount", 0.0),
            "expected_income_amount": values.get("expected_income_amount", 0.0),
        }
        for month, values in sorted(line_plan.items())
    ]


async def build_budget_monthly_plan_rollups(
    session: AsyncSession,
    *,
    version_id: str,
    tournament_id: Optional[str] = None,
    tournament_code: Optional[str] = None,
) -> dict[str, float]:
    lines = await list_budget_lines(
        session,
        version_id=version_id,
        tournament_id=tournament_id,
        tournament_code=tournament_code,
        limit=5000,
    )
    plan_map = await list_monthly_plan_for_lines(
        session,
        line_ids=[line["id"] for line in lines],
    )
    budget_expense_total = 0.0
    expected_income_total = 0.0
    for line in lines:
        monthly = plan_map.get(line["id"], {})
        if normalize_budget_line_direction(line.get("line_direction")) == "expense":
            budget_expense_total += float(line.get("budget_amount") or 0)
        if monthly:
            expected_income_total += sum(
                float(item.get("expected_income_amount") or 0)
                for item in monthly.values()
            )
    return {
        "budget_expense_total": round(budget_expense_total, 2),
        "expected_income_total": round(expected_income_total, 2),
    }


_ACCOUNTING_RESULT_ACCOUNT_PATTERN = (
    r"^(4100|5[1-6]00|6[0-9]{3}|7[0-9]{3})(-|$)"
)
_BUDGET_COMMITMENT_DOCUMENT_STATES = {"enviado", "aprobado", "en_proceso_pago"}
_BUDGET_TERMINAL_DOCUMENT_STATES = {
    "pagado",
    "cerrado",
    "comprobado",
    "reembolsado",
    "aplicado",
    "liquidado",
}


async def _load_paid_report_reimbursement_dates(
    session: AsyncSession, *, report_ids: list[str]
) -> dict[str, date | datetime]:
    """Recognize full paid reimbursements using the canonical employee saldo.

    This is read-only. A closed account, AMEX charge, partial transfer, or an
    approved but unpaid request is never sufficient evidence of reimbursement.
    Account-level matching requires exactly one INFORME to avoid ambiguity.
    """
    from types import SimpleNamespace

    from devnous.gastos.services.amex_expense_service import (
        calculate_informe_expense_totals,
        compute_informe_saldo,
        sum_paid_solicitud_amounts,
    )

    if not report_ids:
        return {}
    reports = (
        (
            await session.execute(
                text("""/* budget_report_settlement_reports */
                    SELECT report.id::text AS document_id,
                           report.cuenta_gastos_id::text AS cuenta_gastos_id,
                           (SELECT COUNT(*) FROM documentos sibling
                            WHERE sibling.cuenta_gastos_id = report.cuenta_gastos_id
                              AND sibling.tipo = 'INFORME') AS report_count
                    FROM documentos report
                    WHERE report.id::text = ANY(CAST(:report_ids AS text[]))
                      AND report.tipo = 'INFORME' AND report.estado = 'aprobado'
                      AND report.cuenta_gastos_id IS NOT NULL
                    """),
                {"report_ids": report_ids},
            )
        )
        .mappings()
        .all()
    )
    reports = [row for row in reports if row["report_count"] == 1]
    account_ids = list({row["cuenta_gastos_id"] for row in reports})
    if not account_ids:
        return {}

    async def account_rows(query: str) -> list[dict[str, Any]]:
        result = await session.execute(text(query), {"account_ids": account_ids})
        return [dict(row) for row in result.mappings().all()]

    requests = await account_rows("""/* budget_report_settlement_requests */
        SELECT cuenta_gastos_id::text AS cuenta_gastos_id, tipo, estado,
               monto_solicitado, concepto_pago, pagado_en, fecha_pago
        FROM documentos
        WHERE cuenta_gastos_id::text = ANY(CAST(:account_ids AS text[]))
          AND tipo = 'SOLICITUD'
        """)
    expenses = await account_rows("""/* budget_report_settlement_expenses */
        SELECT cuenta_gastos_id::text AS cuenta_gastos_id, gasto_cantidad,
               pagado_con_amex_empresa, origen, estado_gasto
        FROM expense_reports
        WHERE cuenta_gastos_id::text = ANY(CAST(:account_ids AS text[]))
        """)
    adjustments = await account_rows("""/* budget_report_settlement_adjustments */
        SELECT cuenta_gastos_id::text AS cuenta_gastos_id, monto
        FROM reembolsos
        WHERE cuenta_gastos_id::text = ANY(CAST(:account_ids AS text[]))
          AND estado <> 'cancelado'
        """)
    dates: dict[str, date | datetime] = {}
    for report in reports:
        account_id = report["cuenta_gastos_id"]
        account_requests = [
            SimpleNamespace(**row)
            for row in requests
            if row["cuenta_gastos_id"] == account_id
        ]
        paid_refunds = [
            row
            for row in account_requests
            if _safe_str(row.estado).lower() == "pagado"
            and _safe_str(row.concepto_pago)
            .lower()
            .startswith("reembolso de saldo a favor")
            and _safe_decimal(row.monto_solicitado) > 0
            and (row.pagado_en or row.fecha_pago) is not None
        ]
        if not paid_refunds:
            continue
        totals = calculate_informe_expense_totals(
            [
                SimpleNamespace(**row)
                for row in expenses
                if row["cuenta_gastos_id"] == account_id
            ]
        )
        saldo = compute_informe_saldo(
            employee_paid=totals.employee_paid,
            monto_entregado=sum_paid_solicitud_amounts(account_requests),
            settled_amount=sum(
                _safe_decimal(row["monto"])
                for row in adjustments
                if row["cuenta_gastos_id"] == account_id
            ),
        )
        if totals.employee_paid > 0 and saldo.saldo == 0:
            dates[report["document_id"]] = max(
                (row.pagado_en or row.fecha_pago for row in paid_refunds),
                key=lambda value: value.isoformat(),
            )
    return dates


async def _append_direct_budget_movements(
    session: AsyncSession,
    *,
    edition_year: int,
    version_id: str,
    tournament_id: Optional[str],
    tournament_scope_requested: bool,
    aliases: list[str],
    phase_filter: Optional[str],
    movements: list[dict[str, Any]],
    store: dict[str, dict[int, dict[str, float]]],
) -> None:
    """Project evidenced direct commitments once, without estimating fiscal base."""
    from devnous.gastos.services.amex_direct_budget_service import (
        list_budget_direct_movements,
    )

    rows = await list_budget_direct_movements(
        session,
        edition_year=edition_year,
        version_id=version_id,
        tournament_id=tournament_id,
        phase_filter=phase_filter,
    )
    seen_expenses = {
        _safe_str(row.get("expense_id")) for row in movements if row.get("expense_id")
    }
    for original in rows:
        row = dict(original)
        expense_id = _safe_str(row.get("expense_id"))
        if not expense_id or expense_id in seen_expenses:
            continue
        if tournament_id:
            if _safe_str(row.get("tournament_id")) != _safe_str(tournament_id):
                continue
        elif tournament_scope_requested:
            row_aliases = budget_alias_candidates(
                _safe_str(row.get("tournament_name")),
                _safe_str(row.get("tournament_code")),
            )
            if not set(aliases).intersection(row_aliases):
                continue
        movement_date = row.get("movement_date")
        if not _date_in_edition_year(movement_date, edition_year):
            raise ValueError("Fuente AMEX directa sin fecha económica en la edición")
        kind = row.get("kind")
        if kind not in {"commitment", "pending_fiscal_evidence"}:
            raise ValueError("Proyección AMEX directa incompatible")
        amount = row.get("amount")
        if kind == "commitment" and (amount is None or amount < 0):
            raise ValueError("Compromiso AMEX sin base fiscal evidenciada")
        if kind == "pending_fiscal_evidence" and amount is not None:
            raise ValueError("Pendiente fiscal AMEX con base inventada")
        week = _budget_week_number(movement_date, edition_year)
        concept_key = _safe_str(row.get("concept_key"))
        if not concept_key:
            raise ValueError("Fuente AMEX directa sin categoría presupuestal")
        if kind == "commitment":
            _merge_monthly_actual(
                store,
                concept_key=concept_key,
                month_number=week,
                committed_unpaid=_safe_decimal(amount),
            )
        row["month_number"] = week
        row["source_kind"] = "amex_direct"
        movements.append(row)
        seen_expenses.add(expense_id)


async def _scope_direct_ledger_to_budget_version(
    session: AsyncSession,
    *,
    ledger_rows: list[Any],
    version_id: str,
) -> list[Any]:
    """Retain direct costs only in their evidenced assignment's budget version."""
    direct_rows = [row for row in ledger_rows if row.get("origen") == "amex_direct"]
    if not direct_rows:
        return ledger_rows
    assignment_ids = sorted(
        {
            _safe_str((row.get("source_metadata") or {}).get("budget_assignment_id"))
            for row in direct_rows
        }
        - {""}
    )
    assignments = {}
    if assignment_ids:
        result = await session.execute(
            text(
                """
                SELECT id::text AS assignment_id, movement_key,
                       budget_concept_id::text AS concept_id
                FROM budget_movement_assignments
                WHERE budget_version_id = CAST(:version_id AS uuid)
                  AND id::text = ANY(CAST(:assignment_ids AS text[]))
                """
            ),
            {"version_id": version_id, "assignment_ids": assignment_ids},
        )
        assignments = {row["assignment_id"]: row for row in result.mappings().all()}
    scoped = []
    for row in ledger_rows:
        if row.get("origen") != "amex_direct":
            scoped.append(row)
            continue
        assignment_id = _safe_str(
            (row.get("source_metadata") or {}).get("budget_assignment_id")
        )
        assignment = assignments.get(assignment_id)
        if (
            assignment is not None
            and assignment["movement_key"] == f"expense:{row.get('expense_id')}"
            and assignment["concept_id"] == row.get("concept_key")
        ):
            scoped.append(row)
    return scoped


async def build_budget_actuals_snapshot(
    session: AsyncSession,
    *,
    edition_year: int,
    version_id: str,
    tournament_id: Optional[str] = None,
    tournament_name: Optional[str] = None,
    tournament_code: Optional[str] = None,
    phase_filter: Optional[str] = None,
    version_context: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    """Return budget actuals backed by balanced accounting result lines.

    Result-account lines are the only source of ``real_expense_cash`` and
    ledger-backed ``real_income``. Lines tied to non-terminal documents remain
    commitments. Terminal documents without a result posting are surfaced as
    pending accounting instead of being converted into an estimated tax base.
    """
    if version_context and version_context.get("source") == "distribution_revision":
        from .distribution import financial_context

        financial_id, line_map = await financial_context(session, version_context)
        snapshot = await build_budget_actuals_snapshot(
            session,
            edition_year=edition_year,
            version_id=financial_id,
            tournament_id=tournament_id,
            tournament_name=tournament_name,
            tournament_code=tournament_code,
            phase_filter=phase_filter,
        )
        snapshot["monthly"] = {
            line_map.get(key, key): values
            for key, values in snapshot["monthly"].items()
        }
        for movement in snapshot["movements"]:
            old_id = movement.get("budget_line_id")
            if old_id in line_map:
                movement["financial_budget_line_id"] = old_id
                movement["budget_line_id"] = line_map[old_id]
        snapshot["financial_version_id"] = financial_id
        return snapshot
    tournament_scope_requested = bool(
        _safe_str(tournament_name) or _safe_str(tournament_code)
    )
    aliases = sorted(
        budget_alias_candidates(
            _safe_str(tournament_name),
            _safe_str(tournament_code),
        )
    )
    alias_patterns = sorted(
        {
            f"%{term.lower()}%"
            for code, terms in _BUDGET_ALIAS_RULES
            if code in aliases
            for term in terms
        }
    )
    params: dict[str, Any] = {
        "edition_year": int(edition_year),
        "version_id": _safe_str(version_id),
        "tournament_id": _safe_str(tournament_id),
        "tournament_aliases": aliases,
        "tournament_alias_patterns": alias_patterns,
        "tournament_scope_requested": tournament_scope_requested,
        "unassigned_key": _UNASSIGNED_BUDGET_CONCEPT_KEY,
        "result_account_pattern": _ACCOUNTING_RESULT_ACCOUNT_PATTERN,
    }
    phase_clause = ""
    clean_phase = _safe_str(phase_filter)
    if clean_phase == "__general__":
        phase_clause = "AND COALESCE(NULLIF(TRIM(scoped.effective_phase), ''), '') = ''"
    elif clean_phase:
        normalized_phase = clean_phase.lower()
        if normalized_phase.startswith("fase "):
            normalized_phase = normalized_phase[5:]
        params["phase_pattern"] = f"%{normalized_phase}%"
        phase_clause = (
            "AND LOWER(COALESCE(NULLIF(TRIM(scoped.effective_phase), ''), '')) "
            "LIKE :phase_pattern"
        )

    uuid_pattern = (
        "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-"
        "[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$"
    )
    ledger_rows = (
        (
            await session.execute(
                text(f"""
                    WITH candidate_lines AS (
                        SELECT
                            apl.*,
                            ap.fecha_poliza,
                            ap.numero_poliza,
                            ap.origen,
                            ap.cfdi_report_id
                        FROM accounting_poliza_lines apl
                        JOIN accounting_polizas ap ON ap.id = apl.poliza_id
                        WHERE EXTRACT(YEAR FROM ap.fecha_poliza)::int = :edition_year
                          AND apl.cuenta_codigo ~ :result_account_pattern
                    ), candidate_polizas AS (
                        SELECT DISTINCT poliza_id
                        FROM candidate_lines
                    ), balanced AS (
                        SELECT apl.poliza_id
                        FROM accounting_poliza_lines apl
                        JOIN candidate_polizas candidate
                          ON candidate.poliza_id = apl.poliza_id
                        GROUP BY apl.poliza_id
                        HAVING ABS(
                            SUM(COALESCE(apl.debe, 0))
                            - SUM(COALESCE(apl.haber, 0))
                        ) <= 0.01
                    ), extracted AS (
                        SELECT
                            candidate_lines.*,
                            CASE WHEN COALESCE(
                                candidate_lines.raw_row_json->>'documento_id',
                                candidate_lines.raw_row_json->>'document_id'
                            ) ~* '{uuid_pattern}' THEN COALESCE(
                                candidate_lines.raw_row_json->>'documento_id',
                                candidate_lines.raw_row_json->>'document_id'
                            )::uuid END AS raw_document_id,
                            CASE WHEN candidate_lines.raw_row_json->>'expense_id'
                                ~* '{uuid_pattern}'
                                THEN (
                                    candidate_lines.raw_row_json->>'expense_id'
                                )::uuid END
                                AS raw_expense_id,
                            CASE WHEN candidate_lines.raw_row_json->>'budget_concept_id'
                                ~* '{uuid_pattern}'
                                THEN (
                                    candidate_lines.raw_row_json->>'budget_concept_id'
                                )::uuid END
                                AS raw_budget_concept_id,
                            CASE WHEN candidate_lines.raw_row_json->>'budget_line_id'
                                ~* '{uuid_pattern}'
                                THEN (
                                    candidate_lines.raw_row_json->>'budget_line_id'
                                )::uuid END
                                AS raw_budget_line_id
                        FROM candidate_lines
                        JOIN balanced
                          ON balanced.poliza_id = candidate_lines.poliza_id
                    ), scoped AS (
                        SELECT
                            extracted.*,
                            COALESCE(
                                extracted.raw_document_id,
                                informe_doc.id,
                                solicitud_doc.id,
                                expense_doc.id
                            ) AS effective_document_id,
                            COALESCE(
                                raw_doc.tipo,
                                informe_doc.tipo,
                                solicitud_doc.tipo,
                                expense_doc.tipo
                            ) AS effective_document_type,
                            COALESCE(
                                extracted.raw_budget_concept_id,
                                e.budget_concept_id,
                                informe_doc.budget_concept_id,
                                solicitud_doc.budget_concept_id,
                                expense_doc.budget_concept_id,
                                bl.budget_concept_id
                            ) AS effective_budget_concept_id,
                            COALESCE(
                                raw_doc.torneo_id,
                                informe_doc.torneo_id,
                                solicitud_doc.torneo_id,
                                expense_doc.torneo_id,
                                cuenta.torneo_id,
                                bl.tournament_id,
                                bc.tournament_id
                            ) AS effective_tournament_id,
                            COALESCE(
                                NULLIF(TRIM(raw_doc.fase), ''),
                                NULLIF(TRIM(e.fase_torneo), ''),
                                NULLIF(TRIM(informe_doc.fase), ''),
                                NULLIF(TRIM(solicitud_doc.fase), ''),
                                NULLIF(TRIM(expense_doc.fase), ''),
                                NULLIF(TRIM(cuenta.fase), ''),
                                NULLIF(TRIM(bl.phase), '')
                            ) AS effective_phase,
                            COALESCE(
                                raw_doc.numero_referencia,
                                informe_doc.numero_referencia,
                                solicitud_doc.numero_referencia,
                                expense_doc.numero_referencia
                            ) AS document_reference,
                            COALESCE(
                                raw_doc.referencia_operaciones,
                                informe_doc.referencia_operaciones,
                                solicitud_doc.referencia_operaciones,
                                expense_doc.referencia_operaciones
                            ) AS operation_reference,
                            COALESCE(raw_doc.estado, informe_doc.estado,
                                solicitud_doc.estado, expense_doc.estado) AS document_state,
                            COALESCE(
                                raw_doc.concepto_pago,
                                informe_doc.concepto_pago,
                                solicitud_doc.concepto_pago,
                                expense_doc.concepto_pago,
                                ''
                            ) AS document_payment_concept,
                            COALESCE(
                                raw_doc.enviado_en,
                                informe_doc.enviado_en,
                                solicitud_doc.enviado_en,
                                expense_doc.enviado_en,
                                raw_doc.aprobado_en,
                                informe_doc.aprobado_en,
                                solicitud_doc.aprobado_en,
                                expense_doc.aprobado_en
                            ) AS document_commitment_at,
                            COALESCE(
                                e.cuenta_gastos_id,
                                raw_doc.cuenta_gastos_id,
                                informe_doc.cuenta_gastos_id,
                                solicitud_doc.cuenta_gastos_id,
                                expense_doc.cuenta_gastos_id
                            ) AS effective_cuenta_gastos_id,
                            COALESCE(e.concepto, extracted.concepto) AS movement_concept,
                            COALESCE(bc.concept_name, bl.concept_name) AS budget_concept_name,
                            COALESCE(t.name, bc.tournament_name) AS tournament_name,
                            bc.tournament_code AS tournament_code
                        FROM extracted
                        LEFT JOIN documentos raw_doc ON raw_doc.id = extracted.raw_document_id
                        LEFT JOIN expense_reports e ON e.id = extracted.raw_expense_id
                        LEFT JOIN documentos expense_doc ON expense_doc.id = e.documento_id
                        LEFT JOIN documentos informe_doc ON informe_doc.id = COALESCE(
                            e.informe_documento_id,
                            CASE WHEN expense_doc.tipo = 'INFORME' THEN expense_doc.id END
                        )
                        LEFT JOIN documentos solicitud_doc ON solicitud_doc.id = COALESCE(
                            e.solicitud_documento_id,
                            CASE WHEN expense_doc.tipo = 'SOLICITUD' THEN expense_doc.id END
                        )
                        LEFT JOIN cuentas_de_gastos cuenta ON cuenta.id = COALESCE(
                            e.cuenta_gastos_id,
                            raw_doc.cuenta_gastos_id,
                            informe_doc.cuenta_gastos_id,
                            solicitud_doc.cuenta_gastos_id,
                            expense_doc.cuenta_gastos_id
                        )
                        LEFT JOIN budget_lines bl ON bl.id = extracted.raw_budget_line_id
                          AND bl.budget_version_id = CAST(:version_id AS uuid)
                        LEFT JOIN budget_concepts bc ON bc.id = COALESCE(
                            extracted.raw_budget_concept_id,
                            e.budget_concept_id,
                            raw_doc.budget_concept_id,
                            informe_doc.budget_concept_id,
                            solicitud_doc.budget_concept_id,
                            expense_doc.budget_concept_id,
                            bl.budget_concept_id
                        )
                        LEFT JOIN tournaments t ON t.id = COALESCE(
                            raw_doc.torneo_id,
                            informe_doc.torneo_id,
                            solicitud_doc.torneo_id,
                            expense_doc.torneo_id,
                            cuenta.torneo_id,
                            bl.tournament_id,
                            bc.tournament_id
                        )
                    )
                    SELECT
                        scoped.id::text AS accounting_line_id,
                        scoped.poliza_id::text AS poliza_id,
                        scoped.numero_poliza,
                        scoped.origen,
                        scoped.raw_row_json AS source_metadata,
                        scoped.fecha_poliza,
                        scoped.cuenta_codigo,
                        scoped.effective_document_id::text AS document_id,
                        scoped.raw_expense_id::text AS expense_id,
                        COALESCE(
                            scoped.effective_budget_concept_id::text,
                            :unassigned_key
                        ) AS concept_key,
                        scoped.document_reference,
                        scoped.operation_reference,
                        scoped.document_state,
                        scoped.effective_document_type AS document_type,
                        scoped.document_payment_concept,
                        scoped.document_commitment_at,
                        (
                            SELECT MAX(COALESCE(r.fecha_pago, r.creado_en))
                            FROM reembolsos r
                            WHERE r.estado <> 'cancelado'
                              AND (
                                  r.documento_id = scoped.effective_document_id
                                  OR (
                                      scoped.effective_cuenta_gastos_id IS NOT NULL
                                      AND r.cuenta_gastos_id =
                                          scoped.effective_cuenta_gastos_id
                                  )
                              )
                        ) AS settlement_at,
                        scoped.movement_concept,
                        scoped.budget_concept_name,
                        scoped.effective_phase,
                        scoped.tournament_name,
                        scoped.debe,
                        scoped.haber
                    FROM scoped
                    WHERE (
                        (
                            NULLIF(:tournament_id, '') IS NOT NULL
                            AND scoped.effective_tournament_id::text = :tournament_id
                        )
                        OR (
                            NULLIF(:tournament_id, '') IS NULL
                            AND (
                                NOT CAST(
                                    :tournament_scope_requested AS boolean
                                )
                                OR (
                                    COALESCE(
                                        cardinality(
                                            CAST(:tournament_aliases AS text[])
                                        ),
                                        0
                                    ) > 0
                                    AND (
                                        UPPER(COALESCE(
                                            scoped.tournament_code, ''
                                        )) = ANY(
                                            CAST(:tournament_aliases AS text[])
                                        )
                                        OR LOWER(COALESCE(
                                            scoped.tournament_name, ''
                                        )) LIKE ANY(
                                            CAST(
                                                :tournament_alias_patterns
                                                AS text[]
                                            )
                                        )
                                    )
                                )
                            )
                        )
                      )
                      AND (
                          COALESCE(scoped.origen, '') <> 'cxc_cfdi_income'
                          OR EXISTS (
                              SELECT 1
                              FROM budget_cfdi_income_links income_link
                              WHERE income_link.cfdi_report_id = scoped.cfdi_report_id
                                AND income_link.budget_version_id = CAST(
                                    :version_id AS uuid
                                )
                                AND income_link.unlinked_at IS NULL
                          )
                      )
                      {phase_clause}
                    ORDER BY scoped.fecha_poliza, scoped.numero_poliza, scoped.line_no
                    """),
                params,
            )
        )
        .mappings()
        .all()
    )

    ledger_rows = await _scope_direct_ledger_to_budget_version(
        session, ledger_rows=ledger_rows, version_id=version_id
    )
    reimbursement_dates = await _load_paid_report_reimbursement_dates(
        session,
        report_ids=list(
            {
                _safe_str(row.get("document_id"))
                for row in ledger_rows
                if _safe_str(row.get("document_type")).upper() == "INFORME"
                and _safe_str(row.get("document_state")).lower() == "aprobado"
                and row.get("settlement_at") is None
            }
        ),
    )
    store = _monthly_actual_store()
    movements: list[dict[str, Any]] = []
    ledger_document_ids: set[str] = set()
    included_document_ids: set[str] = set()
    for raw_row in ledger_rows:
        row = dict(raw_row)
        if row.get("origen") == "amex_direct":
            row["source_kind"] = "amex_direct"
            row["budget_assignment_id"] = (
                row.get("source_metadata") or {}
            ).get("budget_assignment_id")
        if row.get("settlement_at") is None:
            row["settlement_at"] = reimbursement_dates.get(
                _safe_str(row.get("document_id"))
            )
        account_code = _safe_str(row.get("cuenta_codigo"))
        is_income = account_code == "4100" or account_code.startswith("4100-")
        amount = (
            _safe_decimal(row.get("haber")) - _safe_decimal(row.get("debe"))
            if is_income
            else _safe_decimal(row.get("debe")) - _safe_decimal(row.get("haber"))
        )
        if abs(amount) < 0.005:
            continue
        concept_key = _safe_str(row.get("concept_key")) or _UNASSIGNED_BUDGET_CONCEPT_KEY
        document_id = _safe_str(row.get("document_id"))
        document_state = _safe_str(row.get("document_state")).lower()
        is_reimbursement = _safe_str(
            row.get("document_payment_concept")
        ).lower().startswith("reembolso de saldo a favor")
        is_settled_report = (
            _safe_str(row.get("document_type")).upper() == "INFORME"
            and _date_in_edition_year(row.get("settlement_at"), edition_year)
        )
        recognition_date = row.get("fecha_poliza")
        if is_settled_report:
            recognition_date = row.get("settlement_at")
        elif document_id and document_state in _BUDGET_COMMITMENT_DOCUMENT_STATES:
            commitment_at = row.get("document_commitment_at")
            if _date_in_edition_year(commitment_at, edition_year):
                recognition_date = commitment_at
        week = _budget_week_number(recognition_date, edition_year)
        if document_id and not is_income:
            ledger_document_ids.add(document_id)
        if is_income:
            _merge_monthly_actual(
                store,
                concept_key=concept_key,
                month_number=week,
                real_income=amount,
            )
            kind = "ledger_income"
            reason = "Póliza contable balanceada"
        elif is_reimbursement:
            kind = "excluded_reimbursement"
            reason = "Solicitud de reembolso representada por su informe"
        elif concept_key == _UNASSIGNED_BUDGET_CONCEPT_KEY:
            kind = "pending_budget_assignment"
            reason = "Póliza sin partida presupuestal asignada"
        elif (
            document_id
            and document_state in _BUDGET_COMMITMENT_DOCUMENT_STATES
            and not is_settled_report
        ):
            _merge_monthly_actual(
                store,
                concept_key=concept_key,
                month_number=week,
                committed_unpaid=amount,
            )
            included_document_ids.add(document_id)
            kind = "commitment"
            reason = "Póliza de resultados vinculada a documento no terminal"
        elif (
            not document_id
            or not document_state
            or document_state in _BUDGET_TERMINAL_DOCUMENT_STATES
            or is_settled_report
        ):
            _merge_monthly_actual(
                store,
                concept_key=concept_key,
                month_number=week,
                real_expense_cash=amount,
            )
            if document_id:
                included_document_ids.add(document_id)
            kind = "ledger_expense"
            reason = "Póliza contable balanceada de documento terminal"
        else:
            kind = "excluded_state"
            reason = "Póliza vinculada a documento fuera del ciclo presupuestal"
        movements.append(
            {
                **row,
                "kind": kind,
                "amount": round(amount, 2),
                "month_number": week,
                "reason": reason,
            }
        )

    document_filter, expense_filter, document_params = _build_budget_scope_filters(
        edition_year=edition_year,
        tournament_id=tournament_id,
        tournament_name=tournament_name,
        tournament_code=tournament_code,
        document_tournament_id_sql="COALESCE(d.torneo_id, document_cuenta.torneo_id)",
        expense_tournament_id_sql=(
            "COALESCE(d.torneo_id, expense_cuenta.torneo_id)"
        ),
    )
    if clean_phase:
        document_phase_sql = (
            "COALESCE(NULLIF(TRIM(d.fase), ''), "
            "NULLIF(TRIM(document_cuenta.fase), ''), '')"
        )
        expense_phase_sql = (
            "COALESCE(NULLIF(TRIM(e.fase_torneo), ''), "
            "NULLIF(TRIM(d.fase), ''), "
            "NULLIF(TRIM(expense_cuenta.fase), ''), '')"
        )
        if clean_phase == "__general__":
            document_filter.append(f"{document_phase_sql} = ''")
            expense_filter.append(f"{expense_phase_sql} = ''")
        else:
            document_params["phase_pattern"] = params["phase_pattern"]
            document_filter.append(
                f"LOWER({document_phase_sql}) LIKE :phase_pattern"
            )
            expense_filter.append(
                f"LOWER({expense_phase_sql}) LIKE :phase_pattern"
            )
    document_rows = (
        (
            await session.execute(
                text(
                    f"""
                    SELECT
                        d.id::text AS document_id,
                        d.numero_referencia AS document_reference,
                        d.referencia_operaciones AS operation_reference,
                        d.estado AS document_state,
                        d.tipo AS document_type,
                        d.concepto_pago AS movement_concept,
                        d.budget_concept_id::text AS budget_concept_id,
                        bc.concept_name AS budget_concept_name,
                        COALESCE(d.fase, document_cuenta.fase) AS effective_phase,
                        {_budget_document_base_amount_sql('d', 'document_cfdi')}
                            AS amount,
                        d.creado_en,
                        d.enviado_en,
                        d.aprobado_en,
                        d.pagado_en,
                        d.fecha_pago
                    FROM documentos d
                    LEFT JOIN cuentas_de_gastos document_cuenta
                      ON document_cuenta.id = d.cuenta_gastos_id
                    LEFT JOIN tournaments t ON t.id = COALESCE(
                        d.torneo_id, document_cuenta.torneo_id
                    )
                    LEFT JOIN budget_concepts bc ON bc.id = d.budget_concept_id
                    LEFT JOIN cfdi_reports document_cfdi
                      ON document_cfdi.id = d.cfdi_report_id
                    WHERE {' AND '.join(document_filter)}
                      AND d.budget_concept_id IS NOT NULL
                      AND d.estado IN (
                          'enviado', 'aprobado', 'en_proceso_pago',
                          'pagado', 'cerrado', 'comprobado', 'reembolsado',
                          'aplicado', 'liquidado'
                      )
                    ORDER BY d.creado_en, d.numero_referencia
                    """
                ),
                document_params,
            )
        )
        .mappings()
        .all()
    )
    for raw_row in document_rows:
        row = dict(raw_row)
        document_id = _safe_str(row.get("document_id"))
        if document_id in ledger_document_ids:
            continue
        state = _safe_str(row.get("document_state")).lower()
        amount = _safe_decimal(row.get("amount"))
        concept_key = (
            _safe_str(row.get("budget_concept_id"))
            or _UNASSIGNED_BUDGET_CONCEPT_KEY
        )
        if (
            state in _BUDGET_COMMITMENT_DOCUMENT_STATES
            and row.get("document_type") == "SOLICITUD"
        ):
            recognition_date = _first_date_in_edition_year(
                edition_year,
                row.get("enviado_en"),
                row.get("aprobado_en"),
                row.get("creado_en"),
            )
        else:
            recognition_date = _first_date_in_edition_year(
                edition_year,
                row.get("pagado_en"),
                row.get("fecha_pago"),
                row.get("aprobado_en"),
                row.get("creado_en"),
            )
        week = _budget_week_number(recognition_date, edition_year)
        if (
            state in _BUDGET_COMMITMENT_DOCUMENT_STATES
            and row.get("document_type") == "SOLICITUD"
        ):
            _merge_monthly_actual(
                store,
                concept_key=concept_key,
                month_number=week,
                committed_unpaid=amount,
            )
            included_document_ids.add(document_id)
            kind = "commitment"
            reason = "Solicitud con presupuesto asignado pendiente de liquidación"
        else:
            kind = "pending_accounting"
            reason = "Documento avanzado sin póliza de resultados trazable"
        movements.append(
            {
                **row,
                "concept_key": concept_key,
                "kind": kind,
                "amount": round(amount, 2),
                "month_number": week,
                "reason": reason,
                "accounting_line_id": None,
                "poliza_id": None,
                "numero_poliza": None,
                "cuenta_codigo": None,
            }
        )

    report_expense_rows = (
        (
            await session.execute(
                text(f"""
                    SELECT
                        e.id::text AS expense_id,
                        e.fecha AS expense_date,
                        d.id::text AS document_id,
                        e.solicitud_documento_id::text AS solicitud_documento_id,
                        d.numero_referencia AS document_reference,
                        d.referencia_operaciones AS operation_reference,
                        d.estado AS document_state,
                        d.tipo AS document_type,
                        e.concepto AS movement_concept,
                        e.budget_concept_id::text AS budget_concept_id,
                        bc.concept_name AS budget_concept_name,
                        COALESCE(
                            e.fase_torneo, d.fase, expense_cuenta.fase
                        ) AS effective_phase,
                        {_budget_expense_base_amount_sql('e', 'expense_cfdi')}
                            AS amount,
                        d.creado_en,
                        d.enviado_en,
                        d.aprobado_en,
                        d.pagado_en,
                        d.fecha_pago,
                        (
                            SELECT MAX(COALESCE(r.fecha_pago, r.creado_en))
                            FROM reembolsos r
                            WHERE r.estado <> 'cancelado'
                              AND (
                                  r.documento_id = d.id
                                  OR (
                                      d.cuenta_gastos_id IS NOT NULL
                                      AND r.cuenta_gastos_id = d.cuenta_gastos_id
                                  )
                              )
                        ) AS settlement_at
                    FROM expense_reports e
                    JOIN LATERAL (
                        SELECT report.*
                        FROM documentos report
                        WHERE report.tipo = 'INFORME'
                          AND (
                              report.id = e.informe_documento_id
                              OR report.id = e.documento_id
                              OR (
                                  e.cuenta_gastos_id IS NOT NULL
                                  AND report.cuenta_gastos_id = e.cuenta_gastos_id
                                  AND 1 = (
                                      SELECT COUNT(*)
                                      FROM documentos account_report
                                      WHERE account_report.tipo = 'INFORME'
                                        AND account_report.cuenta_gastos_id =
                                            e.cuenta_gastos_id
                                  )
                              )
                          )
                        ORDER BY
                            CASE
                                WHEN report.id = e.informe_documento_id THEN 0
                                WHEN report.id = e.documento_id THEN 1
                                ELSE 2
                            END,
                            report.creado_en ASC
                        LIMIT 1
                    ) d ON TRUE
                    LEFT JOIN cuentas_de_gastos expense_cuenta
                      ON expense_cuenta.id = COALESCE(
                          e.cuenta_gastos_id, d.cuenta_gastos_id
                      )
                    LEFT JOIN tournaments t ON t.id = COALESCE(
                        d.torneo_id, expense_cuenta.torneo_id
                    )
                    LEFT JOIN budget_concepts bc
                      ON bc.id = e.budget_concept_id
                    LEFT JOIN cfdi_reports expense_cfdi
                      ON expense_cfdi.id = e.cfdi_report_id
                    WHERE {' AND '.join(expense_filter)}
                      AND e.budget_concept_id IS NOT NULL
                      AND d.estado IN (
                          'enviado', 'aprobado', 'en_proceso_pago',
                          'pagado', 'cerrado', 'comprobado', 'reembolsado',
                          'aplicado', 'liquidado'
                      )
                    ORDER BY d.creado_en, d.numero_referencia, e.fecha, e.id
                    """),
                document_params,
            )
        )
        .mappings()
        .all()
    )
    reimbursement_dates.update(
        await _load_paid_report_reimbursement_dates(
            session,
            report_ids=list(
                {
                    _safe_str(row.get("document_id"))
                    for row in report_expense_rows
                    if _safe_str(row.get("document_id")) not in ledger_document_ids
                    and _safe_str(row.get("document_state")).lower() == "aprobado"
                    and row.get("settlement_at") is None
                }
            ),
        )
    )
    for raw_row in report_expense_rows:
        row = dict(raw_row)
        if row.get("settlement_at") is None:
            row["settlement_at"] = reimbursement_dates.get(
                _safe_str(row.get("document_id"))
            )
        document_id = _safe_str(row.get("document_id"))
        if document_id in ledger_document_ids:
            continue
        solicitud_documento_id = _safe_str(row.get("solicitud_documento_id"))
        if solicitud_documento_id in included_document_ids:
            continue
        state = _safe_str(row.get("document_state")).lower()
        is_settled = _date_in_edition_year(row.get("settlement_at"), edition_year)
        amount = _safe_decimal(row.get("amount"))
        concept_key = (
            _safe_str(row.get("budget_concept_id"))
            or _UNASSIGNED_BUDGET_CONCEPT_KEY
        )
        if state in _BUDGET_COMMITMENT_DOCUMENT_STATES and not is_settled:
            recognition_date = _first_date_in_edition_year(
                edition_year,
                row.get("enviado_en"),
                row.get("aprobado_en"),
                row.get("creado_en"),
                row.get("expense_date"),
            )
            week = _budget_week_number(recognition_date, edition_year)
            _merge_monthly_actual(
                store,
                concept_key=concept_key,
                month_number=week,
                committed_unpaid=amount,
            )
            kind = "commitment"
            reason = "Gasto de informe con presupuesto asignado"
        else:
            recognition_date = _first_date_in_edition_year(
                edition_year,
                row.get("settlement_at"),
                row.get("pagado_en"),
                row.get("fecha_pago"),
                row.get("aprobado_en"),
                row.get("creado_en"),
                row.get("expense_date"),
            )
            week = _budget_week_number(recognition_date, edition_year)
            kind = "pending_accounting"
            reason = "Informe terminal sin póliza de resultados trazable"
        movements.append(
            {
                **row,
                "concept_key": concept_key,
                "kind": kind,
                "amount": round(amount, 2),
                "month_number": week,
                "reason": reason,
                "accounting_line_id": None,
                "poliza_id": None,
                "numero_poliza": None,
                "cuenta_codigo": None,
            }
        )

    income_filters = [
        "l.budget_version_id = CAST(:version_id AS uuid)",
        "EXTRACT(YEAR FROM COALESCE(b.paid_at, b.created_at))::int = :edition_year",
    ]
    if tournament_id:
        income_filters.append("l.tournament_id = CAST(:tournament_id AS uuid)")
    elif tournament_scope_requested:
        if aliases:
            income_filters.append(
                "(UPPER(COALESCE(l.tournament_code, '')) = "
                "ANY(CAST(:tournament_aliases AS text[])) OR "
                "LOWER(COALESCE(l.tournament_name, '')) LIKE "
                "ANY(CAST(:tournament_alias_patterns AS text[])))"
            )
        else:
            income_filters.append("FALSE")
    if clean_phase == "__general__":
        income_filters.append("COALESCE(NULLIF(TRIM(l.phase), ''), '') = ''")
    elif clean_phase:
        income_filters.append(
            "LOWER(COALESCE(NULLIF(TRIM(l.phase), ''), '')) LIKE :phase_pattern"
        )
    income_rows = (
        (
            await session.execute(
                text(
                    f"""
                    SELECT l.budget_concept_id::text AS concept_key,
                           COALESCE(b.paid_at, b.created_at) AS recognized_at,
                           SUM(b.actual_amount) AS income_total
                    FROM budget_income_bridge b
                    JOIN budget_lines l ON l.id = b.budget_line_id
                    WHERE {' AND '.join(income_filters)}
                    GROUP BY l.budget_concept_id, COALESCE(b.paid_at, b.created_at)
                    """
                ),
                params,
            )
        )
        .mappings()
        .all()
    )
    for row in income_rows:
        week = _budget_week_number(row["recognized_at"], edition_year)
        _merge_monthly_actual(
            store,
            concept_key=_safe_str(row["concept_key"])
            or _UNASSIGNED_BUDGET_CONCEPT_KEY,
            month_number=week,
            real_income=_safe_decimal(row["income_total"]),
        )

    cfdi_filters = [
        "l.budget_version_id = CAST(:version_id AS uuid)",
        "b.budget_version_id = CAST(:version_id AS uuid)",
        "b.unlinked_at IS NULL",
        "b.budget_month IS NOT NULL",
        "NOT EXISTS (SELECT 1 FROM accounting_polizas ap "
        "WHERE ap.origen = 'cxc_cfdi_income' "
        "AND ap.cfdi_report_id = b.cfdi_report_id)",
    ]
    if tournament_id:
        cfdi_filters.append("b.tournament_id = CAST(:tournament_id AS uuid)")
    elif tournament_scope_requested:
        if aliases:
            cfdi_filters.append(
                "(UPPER(COALESCE(l.tournament_code, '')) = "
                "ANY(CAST(:tournament_aliases AS text[])) OR "
                "LOWER(COALESCE(l.tournament_name, '')) LIKE "
                "ANY(CAST(:tournament_alias_patterns AS text[])))"
            )
        else:
            cfdi_filters.append("FALSE")
    if clean_phase == "__general__":
        cfdi_filters.append("COALESCE(NULLIF(TRIM(l.phase), ''), '') = ''")
    elif clean_phase:
        cfdi_filters.append(
            "LOWER(COALESCE(NULLIF(TRIM(l.phase), ''), '')) LIKE :phase_pattern"
        )
    cfdi_rows = (
        (
            await session.execute(
                text(
                    f"""
                    SELECT COALESCE(
                               b.budget_concept_id::text,
                               l.budget_concept_id::text,
                               :unassigned_key
                           ) AS concept_key,
                           b.income_date AS recognized_at,
                           b.budget_month AS budget_month,
                           SUM(b.amount) AS income_total
                    FROM budget_cfdi_income_links b
                    JOIN budget_lines l ON l.id = b.budget_line_id
                    WHERE {' AND '.join(cfdi_filters)}
                      AND b.status = 'approved'
                    GROUP BY 1, b.income_date, b.budget_month
                    """
                ),
                params,
            )
        )
        .mappings()
        .all()
    )
    for row in cfdi_rows:
        week = int(row.get("budget_month") or _budget_week_number(row["recognized_at"], edition_year))
        _merge_monthly_actual(
            store,
            concept_key=_safe_str(row["concept_key"])
            or _UNASSIGNED_BUDGET_CONCEPT_KEY,
            month_number=week,
            real_income=_safe_decimal(row["income_total"]),
        )

    await _append_direct_budget_movements(
        session,
        edition_year=edition_year,
        version_id=version_id,
        tournament_id=tournament_id,
        tournament_scope_requested=tournament_scope_requested,
        aliases=aliases,
        phase_filter=phase_filter,
        movements=movements,
        store=store,
    )

    await _apply_explicit_movement_assignments(
        session,
        budget_version_id=version_id,
        movements=movements,
        store=store,
    )

    concept_ids = sorted(
        {
            _safe_str(movement.get("concept_key"))
            for movement in movements
            if re.fullmatch(uuid_pattern, _safe_str(movement.get("concept_key")))
        }
    )
    budget_accounts: dict[str, dict[str, Optional[str]]] = {}
    if concept_ids:
        account_rows = (
            (
                await session.execute(
                    text(
                        """
                        SELECT
                            bc.id::text AS budget_concept_id,
                            cc.codigo AS budget_account_code,
                            cc.nombre AS budget_account_name
                        FROM budget_concepts bc
                        LEFT JOIN cuentas_contables cc
                          ON cc.id = bc.cuenta_contable_id
                        WHERE bc.id = ANY(CAST(:concept_ids AS uuid[]))
                        """
                    ),
                    {"concept_ids": concept_ids},
                )
            )
            .mappings()
            .all()
        )
        budget_accounts = {
            _safe_str(row["budget_concept_id"]): {
                "budget_account_code": _safe_str(row["budget_account_code"]) or None,
                "budget_account_name": _safe_str(row["budget_account_name"]) or None,
            }
            for row in account_rows
        }
    for movement in movements:
        movement.update(
            budget_accounts.get(
                _safe_str(movement.get("concept_key")),
                {"budget_account_code": None, "budget_account_name": None},
            )
        )

    return {
        "monthly": {key: dict(months) for key, months in store.items()},
        "movements": movements,
    }


async def build_budget_monthly_actuals(
    session: AsyncSession,
    *,
    edition_year: int,
    version_id: str,
    tournament_id: Optional[str] = None,
    tournament_name: Optional[str] = None,
    tournament_code: Optional[str] = None,
    phase_filter: Optional[str] = None,
    version_context: Optional[dict[str, Any]] = None,
) -> dict[str, dict[int, dict[str, float]]]:
    snapshot = await build_budget_actuals_snapshot(
        session,
        edition_year=edition_year,
        version_id=version_id,
        tournament_id=tournament_id,
        tournament_name=tournament_name,
        tournament_code=tournament_code,
        phase_filter=phase_filter,
        **({"version_context": version_context} if version_context else {}),
    )
    return snapshot["monthly"]


async def resolve_budget_tournament_context(
    session: AsyncSession,
    *,
    tournament_key: str,
) -> Optional[dict[str, Any]]:
    clean_key = _safe_str(tournament_key)
    if not clean_key:
        return None
    row = (
        (
            await session.execute(
                text(
                    """
                SELECT id, name
                FROM tournaments
                WHERE CAST(id AS text) = :key
                   OR UPPER(name) = UPPER(:key)
                LIMIT 1
                """
                ),
                {"key": clean_key},
            )
        )
        .mappings()
        .first()
    )
    if row:
        return {
            "tournament_id": _safe_str(row["id"]),
            "tournament_name": _safe_str(row["name"]),
            "tournament_code": clean_key.upper(),
            "tournament_key": clean_key,
        }
    return {
        "tournament_id": None,
        "tournament_name": clean_key,
        "tournament_code": clean_key.upper(),
        "tournament_key": clean_key,
    }


async def copy_budget_version_forward(
    session: AsyncSession,
    *,
    source_version_id: str,
    target_edition_year: int,
    version_name: str,
    actor_empleado_id: Optional[str] = None,
) -> dict[str, Any]:
    await ensure_budget_schema(session)
    source = await get_budget_version(session, version_id=source_version_id)
    if source is None:
        raise ValueError("Source budget version not found")
    source_lines = await list_budget_lines(
        session,
        version_id=source_version_id,
        limit=5000,
    )
    plan_map = await list_monthly_plan_for_lines(
        session,
        line_ids=[line["id"] for line in source_lines],
    )
    allocation_map = await list_monthly_allocations_for_lines(
        session,
        line_ids=[line["id"] for line in source_lines],
    )
    source_plans: dict[str, dict[int, dict[str, Any]]] = {}
    for line in source_lines:
        monthly_plan = plan_map.get(line["id"]) or {}
        if not monthly_plan:
            monthly_plan = {
                month: {
                    "budget_expense_amount": amount,
                    "expected_income_amount": 0.0,
                }
                for month, amount in allocation_map.get(line["id"], {}).items()
            }
        if monthly_plan and normalize_budget_line_direction(
            line.get("line_direction")
        ) == "expense":
            validate_budget_expense_plan_total(
                monthly_plan,
                budget_amount=line.get("budget_amount"),
            )
        source_plans[line["id"]] = monthly_plan

    target = await create_budget_version(
        session,
        edition_year=target_edition_year,
        version_name=version_name,
        source="copy_forward",
        notes=f"Copiado desde {source.get('version_name') or source_version_id}",
        created_by_empleado_id=actor_empleado_id,
    )
    copied_lines = 0
    for line in source_lines:
        new_line = await create_budget_line(
            session,
            version_id=target["id"],
            actor_empleado_id=actor_empleado_id,
            tournament_code=line.get("tournament_code"),
            tournament_name=line.get("tournament_name"),
            budget_concept_id=line.get("budget_concept_id"),
            line_direction=line.get("line_direction"),
            concept_name=line.get("concept_name"),
            account_code_final=line.get("account_code_final"),
            phase=line.get("phase"),
            owner_name=line.get("owner_name"),
            priority=line.get("priority"),
            budget_amount=line.get("budget_amount"),
            reference_amount=line.get("reference_amount"),
            criteria_note=line.get("criteria_note"),
            observations=line.get("observations"),
        )
        monthly_plan = source_plans[line["id"]]
        if monthly_plan:
            await replace_budget_line_monthly_plan(
                session,
                budget_line_id=new_line["id"],
                plan=monthly_plan,
            )
        copied_lines += 1
    await _audit_budget_event(
        session,
        budget_version_id=target["id"],
        event_type="copy_forward",
        actor_empleado_id=actor_empleado_id,
        note=f"Copied {copied_lines} lines from {source_version_id}",
        payload={"source_version_id": source_version_id, "copied_lines": copied_lines},
    )
    await session.commit()
    return {
        "version": target,
        "copied_lines": copied_lines,
        "source_version_id": source_version_id,
    }


async def build_budget_yoy_comparison(
    session: AsyncSession,
    *,
    current_version_id: str,
    prior_version_id: str,
    tournament_id: Optional[str] = None,
    tournament_code: Optional[str] = None,
) -> list[dict[str, Any]]:
    current_lines = await list_budget_lines(
        session,
        version_id=current_version_id,
        tournament_id=tournament_id,
        tournament_code=tournament_code,
        limit=5000,
    )
    prior_lines = await list_budget_lines(
        session,
        version_id=prior_version_id,
        tournament_id=tournament_id,
        tournament_code=tournament_code,
        limit=5000,
    )
    concept_ids = {
        _safe_str(line.get("budget_concept_id"))
        for line in current_lines + prior_lines
        if _safe_str(line.get("budget_concept_id"))
    }
    lineage_map: dict[str, str] = {}
    if concept_ids:
        rows = (
            (
                await session.execute(
                    text(
                        """
                    SELECT id, concept_name, lineage_key, concept_key
                    FROM budget_concepts
                    WHERE id = ANY(CAST(:concept_ids AS uuid[]))
                    """
                    ),
                    {"concept_ids": list(concept_ids)},
                )
            )
            .mappings()
            .all()
        )
        for row in rows:
            lineage_map[_safe_str(row["id"])] = (
                _safe_str(row.get("lineage_key"))
                or _safe_str(row.get("concept_key"))
                or _safe_str(row["id"])
            )

    def _index_lines(lines: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
        indexed: dict[str, dict[str, Any]] = {}
        for line in lines:
            concept_id = _safe_str(line.get("budget_concept_id"))
            lineage = (
                lineage_map.get(concept_id)
                or concept_id
                or _safe_str(line.get("concept_name"))
            )
            indexed[lineage] = line
        return indexed

    current_index = _index_lines(current_lines)
    prior_index = _index_lines(prior_lines)
    all_keys = sorted(set(current_index) | set(prior_index))
    rows: list[dict[str, Any]] = []
    for key in all_keys:
        current = current_index.get(key)
        prior = prior_index.get(key)
        current_amount = float((current or {}).get("budget_amount") or 0)
        prior_amount = float((prior or {}).get("budget_amount") or 0)
        status = "stable"
        if current and not prior:
            status = "new"
        elif prior and not current:
            status = "retired"
        delta = round(current_amount - prior_amount, 2)
        delta_pct = round((delta / prior_amount) * 100, 2) if prior_amount else None
        rows.append(
            {
                "lineage_key": key,
                "concept_name": _safe_str((current or prior or {}).get("concept_name")),
                "prior_budget": round(prior_amount, 2),
                "current_budget": round(current_amount, 2),
                "delta": delta,
                "delta_pct": delta_pct,
                "status": status,
            }
        )
    return rows
