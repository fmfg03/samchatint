"""Portfolio-scoped budget and operational read models for internal Direction."""

from __future__ import annotations

import json
import unicodedata
from collections import OrderedDict
from datetime import date, datetime, timezone
from typing import Any, Optional
from weakref import WeakKeyDictionary

from sqlalchemy import text

from devnous.copa_telmex.registration_read_model import (
    dispatch_registration_snapshot,
)

from samchat.budgets.service import budget_alias_candidates, build_budget_snapshot
from samchat.client_executive.accounting_bridge import (
    build_tournament_accounting,
    unavailable as unavailable_accounting,
)
from samchat.sports_platform import build_director_general_entity_dossier
from samchat.tournaments_v2.services import build_tournament_soul_snapshot
from samchat.tournaments_v2.supabase_client import TournamentsV2Error


class ClientExecutiveAccessError(PermissionError):
    """Raised when Direction asks for a tournament outside its assigned scope."""


DIRECTION_POSITION_KEYS = frozenset(
    {
        "direccion_general",
        "direccion_administracion_finanzas",
        "direccion_goat",
        "director_operaciones",
    }
)


async def ensure_client_executive_schema(session: Any) -> None:
    """Provision portfolio configuration outside client read requests."""
    await session.execute(text("""
            CREATE TABLE IF NOT EXISTS client_executive_portfolios (
                id UUID PRIMARY KEY,
                label VARCHAR(200) NOT NULL,
                active BOOLEAN NOT NULL DEFAULT TRUE,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
            """))
    await session.execute(text("""
            CREATE TABLE IF NOT EXISTS client_executive_access_audit_logs (
                id UUID PRIMARY KEY,
                actor_empleado_id UUID NULL REFERENCES empleados(id),
                portfolio_id UUID NULL REFERENCES client_executive_portfolios(id),
                event_type VARCHAR(80) NOT NULL,
                detail JSONB NULL,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
            """))
    await session.execute(text("""
            CREATE TABLE IF NOT EXISTS client_executive_portfolio_positions (
                portfolio_id UUID NOT NULL REFERENCES client_executive_portfolios(id),
                position_key VARCHAR(100) NOT NULL REFERENCES authorization_positions(position_key),
                active BOOLEAN NOT NULL DEFAULT TRUE,
                PRIMARY KEY (portfolio_id, position_key)
            )
            """))
    await session.execute(text("""
            CREATE TABLE IF NOT EXISTS client_executive_portfolio_tournaments (
                portfolio_id UUID NOT NULL REFERENCES client_executive_portfolios(id),
                tournament_id UUID NOT NULL REFERENCES tournaments(id),
                active BOOLEAN NOT NULL DEFAULT TRUE,
                PRIMARY KEY (portfolio_id, tournament_id)
            )
            """))
    await session.execute(text("""
            CREATE INDEX IF NOT EXISTS ix_client_executive_portfolio_positions_key
            ON client_executive_portfolio_positions(position_key)
            """))


async def _authorized_tournaments(
    session: Any, empleado_id: str, *, is_superadmin: bool = False
) -> list[dict[str, str]]:
    """Return tournaments assigned to the caller's configured position.

    This function is deliberately query-only: schema installation belongs to the
    schema guard or the explicit provisioning command.
    """
    if is_superadmin:
        result = await session.execute(
            # This catalog belongs to the current installation, not an external
            # organization directory. No Supabase/global catalog is consulted.
            text("""SELECT t.id::text AS id, t.name, NULL::text AS slug
                FROM tournaments t
                WHERE t.active = TRUE
                ORDER BY t.name ASC""")
        )
        return [
            {"id": str(row.id), "name": str(row.name), "slug": str(row.slug or "")}
            for row in result
        ]
    result = await session.execute(
        text("""
            SELECT DISTINCT t.id::text AS id, t.name, NULL::text AS slug
            FROM authorization_position_assignments holder
            JOIN client_executive_portfolio_positions position
              ON position.position_key = holder.position_key AND position.active = TRUE
            JOIN client_executive_portfolios portfolio
              ON portfolio.id = position.portfolio_id AND portfolio.active = TRUE
            JOIN client_executive_portfolio_tournaments assignment
              ON assignment.portfolio_id = portfolio.id AND assignment.active = TRUE
            JOIN tournaments t ON t.id = assignment.tournament_id AND t.active = TRUE
            WHERE holder.empleado_id = :empleado_id
              AND holder.active = TRUE
              AND holder.position_key = ANY(:position_keys)
            ORDER BY t.name ASC
            """),
        {
            "empleado_id": str(empleado_id),
            "position_keys": sorted(DIRECTION_POSITION_KEYS),
        },
    )
    return [
        {"id": str(row.id), "name": str(row.name), "slug": str(row.slug or "")}
        for row in result
    ]


async def authorized_direction_portfolio_ids(
    session: Any,
    empleado_id: str,
    *,
    is_superadmin: bool = False,
    limit: int | None = None,
) -> list[str]:
    """Return active Direction portfolios visible to an internal identity."""
    if limit is not None and limit != 1:
        raise ValueError("Only an existence probe may limit authorized portfolios")
    if is_superadmin:
        result = await session.execute(
            text(
                "SELECT id::text AS id FROM client_executive_portfolios WHERE active = TRUE"
                + (" LIMIT 1" if limit else "")
            )
        )
    else:
        result = await session.execute(
            text("""
                SELECT DISTINCT portfolio.id::text AS id
                FROM authorization_position_assignments holder
                JOIN client_executive_portfolio_positions position
                  ON position.position_key = holder.position_key AND position.active = TRUE
                JOIN client_executive_portfolios portfolio
                  ON portfolio.id = position.portfolio_id AND portfolio.active = TRUE
                WHERE holder.empleado_id = :empleado_id
                  AND holder.active = TRUE
                  AND holder.position_key = ANY(:position_keys)
                ORDER BY portfolio.id::text
                """ + (" LIMIT 1" if limit else "")),
            {
                "empleado_id": str(empleado_id),
                "position_keys": sorted(DIRECTION_POSITION_KEYS),
            },
        )
    return [str(row.id) for row in result]


# Per-engine and per-identity metadata only, never financial facts or labels.
# PostgreSQL validates the MVCC revision in the SAME statement as every page.
_CATALOG_METADATA = WeakKeyDictionary()


async def authorized_direction_catalog_page(
    session: Any,
    actor: str,
    *,
    is_superadmin: bool,
    offset: int,
    limit: int = 25,
    after_portfolio: str | None = None,
    after_tournament: str | None = None,
) -> dict:
    """Return one bounded catalog page plus a current full-scope digest/count.

    Metadata is reused only while PostgreSQL's MVCC snapshot is identical and
    this transaction has no assigned write XID. Any concurrent commit or own
    write forces recomputation; scope/role predicates still guard every page.
    Keyset selectors avoid rescanning prior pages. No organization is inferred.
    """
    if type(offset) is not int or offset < 0 or limit != 25:
        raise ValueError("Invalid catalog page")
    # Engines isolate databases; actors/roles isolate authorization decisions.
    # A small LRU bounds memory; eviction only causes safe recomputation.
    bind = session.get_bind() if callable(getattr(session, "get_bind", None)) else None
    engine = getattr(bind, "engine", bind)
    cache = (
        _CATALOG_METADATA.setdefault(engine, OrderedDict())
        if engine is not None
        else OrderedDict()
    )
    key = (str(actor), bool(is_superadmin))
    cached = cache.get(key, {})
    portfolio_predicate = (
        "TRUE"
        if is_superadmin
        else """EXISTS (
        SELECT 1 FROM authorization_position_assignments holder
        JOIN client_executive_portfolio_positions position
          ON position.position_key = holder.position_key AND position.active = TRUE
        WHERE holder.empleado_id = :actor AND holder.active = TRUE
          AND holder.position_key = ANY(:position_keys)
          AND position.portfolio_id = p.id)"""
    )
    tournament_predicate = (
        "TRUE"
        if is_superadmin
        else """EXISTS (
        SELECT 1 FROM client_executive_portfolio_tournaments assignment
        JOIN portfolios p ON p.id = assignment.portfolio_id
        WHERE assignment.tournament_id = t.id AND assignment.active = TRUE)"""
    )
    result = await session.execute(
        text(f"""
        WITH revision AS MATERIALIZED (
            SELECT pg_current_snapshot()::text AS value,
                   pg_current_xact_id_if_assigned() IS NULL AS reusable
        ), reuse AS MATERIALIZED (
            SELECT CAST(:cached AS jsonb) AS value FROM revision
            WHERE reusable AND value = :cached_revision
        ), portfolios AS NOT MATERIALIZED (
            SELECT p.id, p.label FROM client_executive_portfolios p
            WHERE p.active = TRUE AND {portfolio_predicate}
        ), tournaments AS NOT MATERIALIZED (
            SELECT t.id, t.name AS label FROM tournaments t
            WHERE t.active = TRUE AND {tournament_predicate}
        ), fresh AS MATERIALIZED (
            SELECT
              (SELECT COALESCE(jsonb_agg(id::text ORDER BY id), '[]'::jsonb) FROM portfolios) AS pids,
              (SELECT COALESCE(jsonb_agg(id::text ORDER BY id), '[]'::jsonb) FROM tournaments) AS tids
            FROM revision WHERE NOT EXISTS (SELECT 1 FROM reuse)
        ), metadata AS (
            SELECT (value->>'portfolio_count')::int AS portfolio_count,
                   (value->>'tournament_count')::int AS tournament_count,
                   value->'portfolio_ids' AS portfolio_ids,
                   value->>'scope_digest' AS scope_digest FROM reuse
            UNION ALL
            SELECT jsonb_array_length(pids), jsonb_array_length(tids),
                   CASE WHEN jsonb_array_length(pids) <= 200 THEN pids ELSE '[]'::jsonb END,
                   encode(sha256(convert_to(
                       '{{"portfolio_id": null, "portfolio_ids": ' || pids::text ||
                       ', "tournament_id": null, "tournament_ids": ' || tids::text || '}}',
                       'UTF8')), 'hex') FROM fresh
        )
        SELECT metadata.*, revision.value AS _revision, revision.reusable AS _reusable,
               (SELECT COALESCE(jsonb_agg(page ORDER BY id), '[]'::jsonb)
                FROM (SELECT * FROM portfolios
                      WHERE CAST(:after_portfolio AS uuid) IS NULL OR id > CAST(:after_portfolio AS uuid)
                      ORDER BY id LIMIT :limit OFFSET :portfolio_offset) page) AS portfolios,
               (SELECT COALESCE(jsonb_agg(page ORDER BY id), '[]'::jsonb)
                FROM (SELECT * FROM tournaments
                      WHERE CAST(:after_tournament AS uuid) IS NULL OR id > CAST(:after_tournament AS uuid)
                      ORDER BY id LIMIT :limit OFFSET :tournament_offset) page) AS tournaments
        FROM metadata CROSS JOIN revision
    """),
        {
            "actor": actor,
            "position_keys": sorted(DIRECTION_POSITION_KEYS),
            "portfolio_offset": 0 if after_portfolio is not None else offset,
            "tournament_offset": 0 if after_tournament is not None else offset,
            "after_portfolio": after_portfolio,
            "after_tournament": after_tournament,
            "limit": limit,
            "cached_revision": cached.get("revision"),
            "cached": json.dumps(cached.get("metadata", {})),
        },
    )
    row = dict(result.mappings().first())
    revision, reusable = row.pop("_revision"), row.pop("_reusable")
    if reusable:
        cache[key] = {
            "revision": revision,
            "metadata": {
                k: list(row[k]) if k == "portfolio_ids" else row[k]
                for k in (
                    "portfolio_count",
                    "tournament_count",
                    "portfolio_ids",
                    "scope_digest",
                )
            },
        }
        cache.move_to_end(key)
        while len(cache) > 64:
            cache.popitem(last=False)
    else:
        cache.pop(key, None)
    if not row["portfolio_count"] and not is_superadmin:
        raise ClientExecutiveAccessError("No active Direction portfolio assignment")
    return row


def _optional_money(mapping: dict[str, Any], *keys: str) -> Optional[float]:
    """Return the first present numeric value without turning absence into zero."""
    for key in keys:
        if key in mapping and mapping.get(key) is not None:
            try:
                return float(mapping[key])
            except (TypeError, ValueError):
                return None
    return None


def _budget_metric(
    summary: dict[str, Any], comparison: dict[str, Any], key: str
) -> Optional[float]:
    """Read canonical aggregates from summary with legacy comparison fallback."""
    value = _optional_money(summary, key)
    return value if value is not None else _optional_money(comparison, key)


def _executive_card(
    tournament: dict[str, str], snapshot: dict[str, Any]
) -> dict[str, Any]:
    summary = (
        snapshot.get("summary") if isinstance(snapshot.get("summary"), dict) else {}
    )
    comparison = (
        snapshot.get("comparison")
        if isinstance(snapshot.get("comparison"), dict)
        else {}
    )
    forecast = (
        snapshot.get("forecast") if isinstance(snapshot.get("forecast"), dict) else {}
    )
    alerts = (
        snapshot.get("executive_alerts")
        if isinstance(snapshot.get("executive_alerts"), list)
        else []
    )
    source_state = str(snapshot.get("source") or "").strip()
    scope_available = source_state != "budget_scope_unavailable"

    card: dict[str, Any] = {
        "tournament_id": tournament["id"],
        "tournament_name": tournament["name"],
        "budget": _optional_money(summary, "budget_total") if scope_available else None,
        "actual": (
            _budget_metric(summary, comparison, "actual_total")
            if scope_available
            else None
        ),
        "committed": (
            _budget_metric(summary, comparison, "committed_total")
            if scope_available
            else None
        ),
        "projected": (
            _optional_money(forecast, "projected_close_total", "projected_total")
            if scope_available
            else None
        ),
        "alerts": [
            {
                "severity": str(item.get("severity") or "info"),
                "title": str(item.get("title") or "Alerta"),
            }
            for item in alerts[:3]
            if isinstance(item, dict)
        ],
        "source": "samchat.budgets.service.build_budget_snapshot",
        "as_of": datetime.now(timezone.utc).isoformat(),
    }

    # Production snapshots carry source metadata. Test fixtures historically did
    # not, so these fields stay conditional for backwards-compatible contracts.
    if source_state:
        card["budget_source_status"] = (
            "unavailable" if source_state == "budget_scope_unavailable" else "available"
        )
        card["budget_snapshot_source"] = source_state
        card["budget_version"] = snapshot.get("version")
        card["available"] = (
            _optional_money(forecast, "remaining_budget") if scope_available else None
        )
        card["paid"] = (
            _budget_metric(summary, comparison, "paid_total")
            if scope_available
            else None
        )
        card["requested"] = (
            _budget_metric(summary, comparison, "requested_total")
            if scope_available
            else None
        )
        card["pending_to_pay"] = (
            _budget_metric(summary, comparison, "pending_to_pay_total")
            if scope_available
            else None
        )
        card["budget_breakdowns"] = (
            snapshot.get("breakdowns")
            if isinstance(snapshot.get("breakdowns"), dict)
            else {}
        )
        bridge = snapshot.get("direction_scope_bridge")
        if isinstance(bridge, dict):
            card["budget_scope_bridge"] = dict(bridge)
    return card


def _unavailable_dossier(tournament: dict[str, str]) -> dict[str, Any]:
    """Return a safe contract when the scoped operations source is unavailable."""
    return {
        "ok": False,
        "read_only": True,
        "schema_version": "samchat.dg_entity_dossier.v1",
        "source": "tournament_soul_snapshot",
        "source_status": "unavailable",
        "tournament": {
            "id": tournament["id"],
            "name": tournament["name"],
            "slug": tournament["slug"],
        },
        "summary": {},
        "entities": [],
        "national_phase": {
            "status": "unavailable",
            "matches": [],
            "standings": [],
        },
        "marketing": {"status": "unavailable", "media": {}},
        "non_claims": [
            "La fuente operativa no estuvo disponible; no se sustituyeron datos con ceros.",
        ],
    }


def _identity_text(value: object) -> str:
    raw = unicodedata.normalize("NFKD", str(value or "").strip().lower())
    ascii_text = "".join(ch for ch in raw if not unicodedata.combining(ch))
    return " ".join(ascii_text.split())


def _source_year(item: dict[str, Any]) -> Optional[int]:
    raw = str(item.get("start_date") or "")[:4]
    return int(raw) if raw.isdigit() else None


def _uuid_snapshot_matches(
    snapshot: dict[str, Any], tournament: dict[str, str], edition_year: int
) -> bool:
    source_tournaments = [
        item
        for item in list(snapshot.get("tournaments") or [])
        if isinstance(item, dict)
    ]
    if len(source_tournaments) != 1:
        return False
    item = source_tournaments[0]
    return str(item.get("id") or "") == str(tournament["id"]) and _source_year(
        item
    ) == int(edition_year)


def _exact_name_snapshot_matches(
    snapshot: dict[str, Any], tournament: dict[str, str], edition_year: int
) -> bool:
    source_tournaments = [
        item
        for item in list(snapshot.get("tournaments") or [])
        if isinstance(item, dict)
    ]
    if len(source_tournaments) != 1:
        return False
    item = source_tournaments[0]
    source_name = str(item.get("name") or "").strip().casefold()
    authorized_name = str(tournament.get("name") or "").strip().casefold()
    if source_name != authorized_name:
        return False
    if _source_year(item) != int(edition_year):
        return False
    soul = snapshot.get("soul") if isinstance(snapshot.get("soul"), dict) else {}
    soul_tournament = (
        soul.get("tournament") if isinstance(soul.get("tournament"), dict) else {}
    )
    if soul_tournament.get("id") and str(soul_tournament.get("id")) != str(
        item.get("id")
    ):
        return False
    return True


async def _load_soul_snapshot(
    tournament: dict[str, str],
    *,
    edition_year: int,
    include_registration: bool = True,
    client: Any = None,
) -> tuple[Optional[dict[str, Any]], str]:
    """Resolve SOUL without allowing display names to broaden Direction scope."""
    observed_wrong_edition = False
    registration_options: dict[str, Any] = (
        {} if include_registration else {"include_registration": False}
    )
    try:
        uuid_snapshot = await build_tournament_soul_snapshot(
            tournament_key="all",
            tournament_slug=tournament["id"],
            include_communications=False,
            include_media=True,
            limit=1000,
            **registration_options,
            **({"client": client} if client is not None else {}),
        )
    except TournamentsV2Error:
        uuid_snapshot = None

    if isinstance(uuid_snapshot, dict):
        if _uuid_snapshot_matches(uuid_snapshot, tournament, edition_year):
            return uuid_snapshot, "authorized_uuid"
        years = {
            _source_year(item)
            for item in list(uuid_snapshot.get("tournaments") or [])
            if isinstance(item, dict)
        }
        observed_wrong_edition = bool(years - {None, int(edition_year)})

    # The operational store can have a different UUID namespace. The only safe
    # bridge is one unique exact normalized name in the requested edition. Any
    # ambiguous/sub-string result fails closed.
    if tournament.get("name"):
        try:
            name_snapshot = await build_tournament_soul_snapshot(
                tournament_key="all",
                tournament_slug=tournament["name"],
                include_communications=False,
                include_media=True,
                limit=1000,
                **registration_options,
                **({"client": client} if client is not None else {}),
            )
        except TournamentsV2Error:
            name_snapshot = None
        if isinstance(name_snapshot, dict):
            if _exact_name_snapshot_matches(name_snapshot, tournament, edition_year):
                return name_snapshot, "exact_name_edition_bridge"
            years = {
                _source_year(item)
                for item in list(name_snapshot.get("tournaments") or [])
                if isinstance(item, dict)
            }
            observed_wrong_edition = observed_wrong_edition or bool(
                years - {None, int(edition_year)}
            )

    return None, "edition_unavailable" if observed_wrong_edition else "unavailable"


async def _build_operational_dossier(
    tournament: dict[str, str],
    *,
    edition_year: int,
    include_registration: bool = True,
    client: Any = None,
) -> dict[str, Any]:
    """Build one strictly tournament-scoped dossier without operational writes."""
    registration_options: dict[str, Any] = (
        {} if include_registration else {"include_registration": False}
    )
    snapshot, bridge = await _load_soul_snapshot(
        tournament,
        edition_year=edition_year,
        **registration_options,
        **({"client": client} if client is not None else {}),
    )
    if snapshot is None:
        unavailable = _unavailable_dossier(tournament)
        if bridge == "edition_unavailable":
            unavailable["source_status"] = "edition_unavailable"
            unavailable["non_claims"] = [
                "La fuente operativa no acredita datos para la edición solicitada; "
                "no se mostraron datos de otra edición.",
            ]
        return unavailable

    dossier = (
        build_director_general_entity_dossier(snapshot)
        if include_registration
        else {
            "read_only": True,
            "schema_version": "samchat.dg_entity_dossier.v1",
            "source": "tournament_soul_snapshot",
            "summary": {},
            "entities": [],
            "non_claims": ["La inscripción se consulta por separado desde SamChat."],
        }
    )
    soul = snapshot.get("soul") if isinstance(snapshot.get("soul"), dict) else {}
    optional_sources = snapshot.get("optional_sources")
    optional_sources = optional_sources if isinstance(optional_sources, dict) else {}

    def optional_source_unavailable(name: str) -> bool:
        state = optional_sources.get(name)
        return isinstance(state, dict) and state.get("available") is False

    national_phase = dict((soul or {}).get("national_phase") or {})
    if optional_source_unavailable("matches"):
        national_phase["matches_source_status"] = "unavailable"
    if optional_source_unavailable("team_standings"):
        national_phase["standings_source_status"] = "unavailable"

    marketing = dict((soul or {}).get("marketing") or {})
    media = dict(marketing.get("media") or {})
    if optional_source_unavailable("gallery_photos"):
        media["photos_source_status"] = "unavailable"
    if optional_source_unavailable("featured_videos"):
        media["videos_source_status"] = "unavailable"
    if optional_source_unavailable("live_streams"):
        media["streams_source_status"] = "unavailable"
    marketing["media"] = media

    dossier["source_status"] = "available"
    dossier["source_bridge"] = bridge
    dossier["national_phase"] = national_phase
    dossier["marketing"] = marketing
    return dossier


async def _build_operational_summaries(tournaments, *, edition_year, client=None):
    """Batch canonical SOUL reads for the two counts consumed by Direction home."""
    import asyncio

    from samchat.tournaments_v2.config import load_tournaments_v2_config
    from samchat.tournaments_v2.services.summary_batches import SummaryBatchClient
    from samchat.tournaments_v2.supabase_client import SupabaseRestClient

    client = SummaryBatchClient(
        client or SupabaseRestClient(load_tournaments_v2_config())
    )
    summaries = {}

    async def read(tournament):
        try:
            dossier = await _build_operational_dossier(
                tournament, edition_year=edition_year, client=client
            )
            if dossier.get("source_status") == "available":
                summary = dossier.get("summary") or {}
                return {
                    key: summary.get(key) for key in ("teams_count", "players_count")
                }
        except Exception:
            pass
        return None

    try:
        for offset in range(0, len(tournaments), 25):
            chunk = tournaments[offset : offset + 25]
            values = await asyncio.gather(*(read(t) for t in chunk))
            summaries.update({t["id"]: value for t, value in zip(chunk, values)})
    finally:
        await client.close()
    return summaries


async def _budget_alias_bridge_is_safe(
    session: Any,
    *,
    tournament: dict[str, str],
    edition_year: int,
    version_id: str,
    aliases: list[str],
) -> bool:
    """Verify that every downstream alias candidate stays in authorized scope."""
    if not version_id or not aliases or not tournament.get("name"):
        return False
    result = await session.execute(
        text("""
            SELECT
                COUNT(*) AS line_count,
                COUNT(*) FILTER (
                    WHERE UPPER(TRIM(COALESCE(l.tournament_name, '')))
                          <> UPPER(TRIM(:tournament_name))
                ) AS foreign_name_count,
                COUNT(*) FILTER (
                    WHERE l.tournament_id IS NOT NULL
                      AND CAST(l.tournament_id AS text) <> :tournament_id
                ) AS foreign_id_count
            FROM budget_lines l
            WHERE CAST(l.budget_version_id AS text) = :version_id
              AND (
                    UPPER(COALESCE(l.tournament_code, '')) = ANY(:aliases)
                    OR UPPER(TRIM(COALESCE(l.tournament_name, '')))
                       = UPPER(TRIM(:tournament_name))
              )
            """),
        {
            "version_id": str(version_id),
            "tournament_id": str(tournament["id"]),
            "tournament_name": str(tournament["name"]),
            "aliases": aliases,
        },
    )
    row = result.mappings().first()
    if not row:
        return False
    return (
        int(row.get("line_count") or 0) > 0
        and int(row.get("foreign_name_count") or 0) == 0
        and int(row.get("foreign_id_count") or 0) == 0
    )


class _DirectionBudgetScopeViolation(RuntimeError):
    """Raised when consumed legacy budget rows escape the authorized tournament."""


class _BufferedMappingResult:
    """Minimal buffered mapping result used after validating consumed rows."""

    def __init__(self, rows: list[Any]) -> None:
        self._rows = list(rows)

    def mappings(self) -> "_BufferedMappingResult":
        return self

    def all(self) -> list[Any]:
        return list(self._rows)

    def first(self) -> Any:
        return self._rows[0] if self._rows else None


class _DirectionBudgetReadSession:
    """Validate the exact budget rows consumed by the legacy alias snapshot."""

    def __init__(
        self,
        session: Any,
        *,
        tournament: dict[str, str],
        aliases: list[str],
    ) -> None:
        self._session = session
        self._tournament = tournament
        self._aliases = aliases

    def __getattr__(self, name: str) -> Any:
        return getattr(self._session, name)

    @staticmethod
    def _is_budget_line_consuming_query(statement: Any, params: Any) -> bool:
        sql = str(statement)
        return (
            isinstance(params, dict)
            and bool(params.get("version_id"))
            and "FROM budget_lines l" in sql
            and "l.budget_version_id = :version_id" in sql
            and "l.tournament_name" in sql
            and "l.budget_amount" in sql
        )

    async def execute(
        self, statement: Any, params: Any = None, *args: Any, **kwargs: Any
    ) -> Any:
        if params is None:
            result = await self._session.execute(statement, *args, **kwargs)
        else:
            result = await self._session.execute(statement, params, *args, **kwargs)
        if not self._is_budget_line_consuming_query(statement, params):
            return result

        rows = list(result.mappings().all())
        authorized_name = str(self._tournament.get("name") or "").strip().casefold()
        authorized_id = str(self._tournament.get("id") or "")
        for row in rows:
            row_name = str(row.get("tournament_name") or "").strip().casefold()
            row_id = row.get("tournament_id")
            if row_name != authorized_name or (
                row_id is not None and str(row_id) != authorized_id
            ):
                raise _DirectionBudgetScopeViolation(
                    "Legacy budget row escaped authorized Direction scope."
                )
        return _BufferedMappingResult(rows)


async def _build_direction_budget_snapshot(
    session: Any,
    *,
    tournament: dict[str, str],
    edition_year: int,
    executive_read: bool = False,
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
) -> dict[str, Any]:
    """Read budget truth with a guarded bridge for legacy name/code rows."""
    extra = (
        {"executive_read": True, "date_from": date_from, "date_to": date_to}
        if executive_read
        else {}
    )
    strict = await build_budget_snapshot(
        session,
        tournament_id=tournament["id"],
        tournament_name=tournament.get("name"),
        tournament_slug=tournament.get("slug"),
        edition_year=edition_year,
        ensure_schema=False,
        strict_tournament_scope=True,
        **extra,
    )
    if strict.get("source") != "budget_scope_unavailable":
        return strict

    version = strict.get("version") if isinstance(strict.get("version"), dict) else {}
    version_id = str(version.get("id") or "")
    aliases = sorted(budget_alias_candidates(tournament.get("name") or ""))
    if not await _budget_alias_bridge_is_safe(
        session,
        tournament=tournament,
        edition_year=edition_year,
        version_id=version_id,
        aliases=aliases,
    ):
        return strict

    guarded_session = _DirectionBudgetReadSession(
        session,
        tournament=tournament,
        aliases=aliases,
    )
    try:
        bridged = await build_budget_snapshot(
            guarded_session,
            tournament_id=tournament["id"],
            tournament_name=tournament.get("name"),
            tournament_slug=tournament.get("slug"),
            edition_year=edition_year,
            version_id=version_id,
            ensure_schema=False,
            strict_tournament_scope=False,
            **extra,
        )
    except _DirectionBudgetScopeViolation:
        return strict
    if bridged.get("source") != "budget_db":
        return strict
    bridged["direction_scope_bridge"] = {
        "status": "exact_name_alias_bridge",
        "authorized_tournament_id": tournament["id"],
        "budget_version_id": version_id,
        "aliases": aliases,
        "read_only": True,
    }
    return bridged


def build_client_executive_summary(payload: dict[str, Any]) -> dict[str, Any]:
    """Create a deterministic, read-only Sam summary from safe dashboard data."""
    cards = payload.get("cards") if isinstance(payload.get("cards"), list) else []
    high_alerts = sum(
        1
        for card in cards
        for alert in (card.get("alerts") or [])
        if isinstance(alert, dict)
        and str(alert.get("severity") or "").strip().lower() in {"critical", "high"}
    )
    return {
        "scope": payload.get("scope"),
        "message": (
            "No hay proyectos o torneos en tu alcance asignado."
            if not cards
            else "Alcance con {} proyecto(s)/torneo(s) y {} alerta(s) alta(s).".format(
                len(cards), high_alerts
            )
        ),
        "high_alert_count": high_alerts,
        "source": "direction_executive.read_model",
        "read_only": True,
    }


async def build_client_dashboard(
    session: Any,
    *,
    empleado_id: str,
    edition_year: int,
    tournament_id: Optional[str] = None,
    is_superadmin: bool = False,
    include_operational_detail: bool = False,
    accounting_access: bool = True,
) -> dict[str, Any]:
    """Build a Direction portfolio or one authorized tournament executive view."""
    tournaments = await _authorized_tournaments(
        session, empleado_id, is_superadmin=is_superadmin
    )
    if not tournaments:
        raise ClientExecutiveAccessError("No active portfolio position is assigned.")
    if tournament_id:
        tournaments = [item for item in tournaments if item["id"] == str(tournament_id)]
        if not tournaments:
            raise ClientExecutiveAccessError(
                "Tournament is not in the assigned Direction scope."
            )

    cards = []
    for tournament in tournaments:
        if not (tournament.get("name") or tournament.get("slug")):
            # A blank selector would make the legacy artifact fallback global.
            # Do not request a snapshot unless its tournament scope is verifiable.
            continue
        snapshot = await _build_direction_budget_snapshot(
            session,
            tournament=tournament,
            edition_year=edition_year,
        )
        card = _executive_card(tournament, snapshot)
        if "source" in snapshot and accounting_access:
            card["accounting"] = await build_tournament_accounting(
                session,
                tournament_id=tournament["id"],
                edition_year=edition_year,
                budget_version_id=(
                    (snapshot.get("version") or {}).get("id")
                    if snapshot.get("source") == "budget_db"
                    else None
                ),
            )
            card["accounting_previous_year"] = await build_tournament_accounting(
                session,
                tournament_id=tournament["id"],
                edition_year=edition_year - 1,
            )
        elif "source" in snapshot:
            card["accounting"] = unavailable_accounting(
                "La lectura contable está denegada para esta identidad."
            )
        if include_operational_detail:
            registration = await dispatch_registration_snapshot(
                session,
                tournament_id=tournament["id"],
                edition_year=edition_year,
            )
            dossier_options: dict[str, Any] = (
                {} if registration is None else {"include_registration": False}
            )
            card["dossier"] = await _build_operational_dossier(
                tournament,
                edition_year=edition_year,
                **dossier_options,
            )
            if registration is not None:
                card["registration"] = registration
                card["dossier"]["registration_source"] = registration["source"]
        cards.append(card)

    return {
        "edition_year": edition_year,
        "scope": "tournament" if tournament_id else "portfolio",
        "cards": cards,
        "data_boundary": {
            "operations": "tournament_soul_snapshot",
            "registration": "postgres_registration_for_configured_editions",
            "budget": "samchat.budgets.service.build_budget_snapshot",
            "entity_finance": "evidenced_historical_accounting_bridge",
            "writes": False,
        },
        "unavailable_metrics": ["cashflow", "accounts_receivable", "payments"],
    }


async def build_portfolio_dashboard(
    session: Any,
    *,
    portfolio_id: str,
    edition_year: int,
    accounting_access: bool = True,
) -> dict[str, Any]:
    """Build a CEO view for one configured portfolio, never a global fallback."""
    result = await session.execute(
        text(
            """
            SELECT t.id::text AS id, t.name, NULL::text AS slug
            FROM client_executive_portfolio_tournaments assignment
            JOIN client_executive_portfolios portfolio
              ON portfolio.id = assignment.portfolio_id AND portfolio.active = TRUE
            JOIN tournaments t ON t.id = assignment.tournament_id AND t.active = TRUE
            WHERE assignment.portfolio_id = :portfolio_id AND assignment.active = TRUE
            ORDER BY t.name ASC
            """
        ),
        {"portfolio_id": str(portfolio_id)},
    )
    tournaments = [
        {"id": str(row.id), "name": str(row.name), "slug": str(row.slug or "")}
        for row in result
    ]
    if not tournaments:
        raise ClientExecutiveAccessError(
            "No active tournaments are assigned to this portfolio."
        )
    cards = []
    for tournament in tournaments:
        snapshot = await _build_direction_budget_snapshot(
            session,
            tournament=tournament,
            edition_year=edition_year,
        )
        card = _executive_card(tournament, snapshot)
        if "source" in snapshot and accounting_access:
            card["accounting"] = await build_tournament_accounting(
                session,
                tournament_id=tournament["id"],
                edition_year=edition_year,
                budget_version_id=(
                    (snapshot.get("version") or {}).get("id")
                    if snapshot.get("source") == "budget_db"
                    else None
                ),
            )
            card["accounting_previous_year"] = await build_tournament_accounting(
                session,
                tournament_id=tournament["id"],
                edition_year=edition_year - 1,
            )
        elif "source" in snapshot:
            card["accounting"] = unavailable_accounting(
                "La lectura contable está denegada para esta identidad."
            )
        cards.append(card)
    return {
        "edition_year": edition_year,
        "scope": "portfolio",
        "portfolio_id": str(portfolio_id),
        "cards": cards,
        "unavailable_metrics": [
            "cashflow",
            "accounts_receivable",
            "payments",
            "operational_detail",
        ],
    }
