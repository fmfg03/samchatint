"""Transport store upgrade: leases, bounded retries and immutable receipts."""

from devnous.gastos.services.batisenal_service import BatisenalError

from .store import Store, digest


class DeliveryStore(Store):
    def subscribe(self, *, owner, case_id, callback, secret_ref, expires):
        identifier = digest([owner, case_id, callback])
        now = int(self.clock())
        with self.transaction() as db:
            count = db.execute(
                """SELECT count(*) FROM transport_subscriptions
                WHERE owner=? AND case_id=? AND id!=? AND active=1 AND expires>?""",
                (owner, case_id, identifier, now),
            ).fetchone()[0]
            if count >= 20:
                raise BatisenalError("SUBSCRIPTION_LIMIT", 429)
            old = db.execute(
                "SELECT * FROM transport_subscriptions WHERE id=?", (identifier,)
            ).fetchone()
            if old is None:
                db.execute(
                    """INSERT INTO transport_subscriptions
                    (id,owner,case_id,callback,secret_ref,expires,active,generation)
                    VALUES(?,?,?,?,?,?,1,1)""",
                    (identifier, owner, case_id, callback, secret_ref, expires),
                )
            else:
                previous, until = old["previous_secret_ref"], old["previous_until"]
                if old["secret_ref"] != secret_ref:
                    if previous and until > now:
                        raise BatisenalError("ROTATION_PENDING", 409)
                    previous, until = old["secret_ref"], now + 300
                db.execute(
                    """UPDATE transport_subscriptions SET secret_ref=?,expires=?,active=1,
                    generation=generation+1,previous_secret_ref=?,previous_until=? WHERE id=?""",
                    (secret_ref, expires, previous, until, identifier),
                )
            self._audit(db, owner, "events/subscribe", "SUBSCRIBED")
        return identifier

    def claim(self, owner):
        now = int(self.clock())
        with self.transaction() as db:
            exhausted = db.execute(
                """SELECT d.id,d.attempts FROM transport_deliveries d
                JOIN transport_subscriptions s ON s.id=d.subscription
                WHERE s.owner=? AND d.state='pending' AND d.attempts>=3 AND d.lease_until<=?""",
                (owner, now),
            ).fetchall()
            for dead in exhausted:
                db.execute(
                    "UPDATE transport_deliveries SET state='stopped' WHERE id=?",
                    (dead["id"],),
                )
                db.execute(
                    """INSERT OR IGNORE INTO transport_delivery_receipts
                    (delivery_id,attempt,outcome,http_status,created_at) VALUES(?,?,'uncertain',NULL,?)""",
                    (dead["id"], dead["attempts"], now),
                )
            row = db.execute(
                """SELECT d.*,s.owner,s.case_id,s.callback,s.secret_ref,
                s.previous_secret_ref,s.previous_until,s.generation AS subscription_generation,
                s.id AS subscription_id FROM transport_deliveries d
                JOIN transport_subscriptions s ON d.subscription=s.id
                WHERE s.owner=? AND s.active=1 AND s.expires>? AND d.state='pending'
                AND d.next_attempt<=? AND d.lease_until<=? AND d.attempts<3
                ORDER BY d.created_at,d.id LIMIT 1""",
                (owner, now, now, now),
            ).fetchone()
            if row is None:
                return None
            if row["attempts"] > 0:
                db.execute(
                    """INSERT OR IGNORE INTO transport_delivery_receipts
                    (delivery_id,attempt,outcome,http_status,created_at)
                    VALUES(?,?,'uncertain',NULL,?)""",
                    (row["id"], row["attempts"], now),
                )
            result = dict(row)
            token, attempt = row["lease_generation"] + 1, row["attempts"] + 1
            db.execute(
                """UPDATE transport_deliveries SET lease_until=?,lease_generation=?,attempts=? WHERE id=?""",
                (now + 30, token, attempt, row["id"]),
            )
            result.update(lease_generation=token, attempts=attempt)
            return result

    def valid(self, claim):
        with self.transaction() as db:
            return (
                db.execute(
                    """SELECT 1 FROM transport_deliveries d
                JOIN transport_subscriptions s ON s.id=d.subscription
                WHERE d.id=? AND d.state='pending' AND d.lease_generation=? AND d.lease_until>?
                AND s.owner=? AND s.generation=? AND s.active=1 AND s.expires>?""",
                    (
                        claim["id"],
                        claim["lease_generation"],
                        int(self.clock()),
                        claim["owner"],
                        claim["subscription_generation"],
                        int(self.clock()),
                    ),
                ).fetchone()
                is not None
            )

    def refreshed(self, claim):
        """Only an active same-owner subscription refresh may retry a stale claim."""
        with self.transaction() as db:
            return (
                db.execute(
                    """SELECT 1 FROM transport_deliveries d
                JOIN transport_subscriptions s ON s.id=d.subscription
                WHERE d.id=? AND d.state='pending' AND d.lease_generation=?
                AND s.owner=? AND s.generation!=? AND s.active=1 AND s.expires>?""",
                    (
                        claim["id"],
                        claim["lease_generation"],
                        claim["owner"],
                        claim["subscription_generation"],
                        int(self.clock()),
                    ),
                ).fetchone()
                is not None
            )

    def finish(self, claim, outcome, status=None):
        if outcome not in {"received", "retry", "stopped", "uncertain"}:
            raise ValueError("OUTCOME_INVALID")
        now = int(self.clock())
        with self.transaction() as db:
            row = db.execute(
                "SELECT * FROM transport_deliveries WHERE id=? AND lease_generation=? AND state='pending'",
                (claim["id"], claim["lease_generation"]),
            ).fetchone()
            if row is None:
                return False
            state = (
                "delivered"
                if outcome == "received"
                else (
                    "stopped"
                    if outcome == "stopped" or row["attempts"] >= 3
                    else "pending"
                )
            )
            delay = min(300, 5 * 2 ** (row["attempts"] - 1))
            db.execute(
                """UPDATE transport_deliveries SET state=?,lease_until=0,next_attempt=? WHERE id=?""",
                (state, now + delay, claim["id"]),
            )
            db.execute(
                """INSERT INTO transport_delivery_receipts
                (delivery_id,attempt,outcome,http_status,created_at) VALUES(?,?,?,?,?)""",
                (claim["id"], row["attempts"], outcome, status, now),
            )
            return True
