"""Response sufficiency gate for Claude-Code-like SamChat turns.

A selected tool is not enough. The assistant must also prove that the rendered
answer satisfies the WorkFrame. This module is deterministic, read-only and
fail-closed for known semantic mismatches.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Iterable, Mapping

from .direct_read_contracts import business_evidence_limit
from .financial_claims import is_safe_clarification, validate_financial_claims
from .read_evidence import validate_read_evidence
from .tool_adjudicator import adjudicate_tool_candidate
from .work_frame import WorkFrame, normalize_work_text


@dataclass(frozen=True)
class ResponseSufficiencyResult:
    ok: bool
    reason: str
    action: str
    tool: str
    diagnostics: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _primary_tool(tool_trace: Iterable[Mapping[str, Any]] | None) -> str:
    for trace in tool_trace or []:
        tool = str(trace.get("tool") or "").strip()
        if tool and not tool.startswith("assistant."):
            return tool
    for trace in tool_trace or []:
        tool = str(trace.get("tool") or "").strip()
        if tool:
            return tool
    return ""


def _result_payload(
    tool_trace: Iterable[Mapping[str, Any]] | None,
) -> Mapping[str, Any]:
    for trace in tool_trace or []:
        result = trace.get("result")
        if isinstance(result, Mapping):
            return result
    return {}


def _deterministic_surface(tool_trace: Iterable[Mapping[str, Any]] | None) -> str:
    """Return controlled non-Q&A surfaces that already render safe output."""

    for trace in tool_trace or []:
        for key in (
            "document_intake_live_wiring",
            "receipt_workflow_draft",
            "analyst_workbench_live_wiring",
        ):
            if key in trace:
                return key
    return ""


def evaluate_response_sufficiency(
    *,
    work_frame: WorkFrame,
    assistant_message: str,
    tool_trace: Iterable[Mapping[str, Any]] | None,
) -> ResponseSufficiencyResult:
    """Evaluate whether the visible answer satisfies the current WorkFrame."""

    tool = _primary_tool(tool_trace)
    adjudication = adjudicate_tool_candidate(work_frame=work_frame, tool=tool)
    message = normalize_work_text(assistant_message)
    result = _result_payload(tool_trace)

    surface = _deterministic_surface(tool_trace)
    diagnostics = {
        "work_frame_domain": work_frame.domain,
        "work_frame_task_kind": work_frame.task_kind,
        "required_evidence": list(work_frame.required_evidence),
        "forbidden_interpretations": list(work_frame.forbidden_interpretations),
        "primary_tool": tool,
        "deterministic_surface": surface,
        "result_status": result.get("status") or result.get("question_type"),
    }

    if surface:
        return ResponseSufficiencyResult(
            ok=True,
            reason="controlled_deterministic_surface_already_rendered_safe_output",
            action="allow",
            tool=tool or surface,
            diagnostics=diagnostics,
        )

    if work_frame.answer_contract.get("require_current_read_evidence"):
        # A question-only clarification is safe; appending a question to an
        # unsupported assertion is not. Do not accept figures in this fallback.
        clarification = is_safe_clarification(message)
        if clarification:
            return ResponseSufficiencyResult(
                True, "contextual_read_clarification", "allow", tool, diagnostics
            )
        reads: list[tuple[str, Mapping[str, Any]]] = []
        for step in tool_trace or []:
            name = str(step.get("tool") or "")
            payload = step.get("result")
            if (
                name
                and not name.startswith("assistant.")
                and isinstance(payload, Mapping)
            ):
                reads.append((name, payload))
        unavailable = any(
            payload.get("status") == "capability_unavailable"
            or payload.get("coverage") == "not_queried"
            for _, payload in reads
        )
        limits = {
            name: business_evidence_limit(name, message, work_frame.domain)
            for name, _ in reads
        }
        diagnostics["read_scope_limits"] = {
            name: reason for name, reason in limits.items() if reason
        }
        validated = [
            (False, name) if limits[name] else validate_read_evidence(name, payload)
            for name, payload in reads
        ]
        diagnostics["read_contracts"] = [
            {"tool": name, "valid": valid} for valid, name in validated
        ]
        valid = any(
            supported
            and adjudicate_tool_candidate(work_frame=work_frame, tool=name).accepted
            for supported, name in validated
        )
        if unavailable or not valid:
            return ResponseSufficiencyResult(
                False,
                (
                    "contextual_capability_unavailable"
                    if unavailable
                    else (
                        "contextual_reader_scope_insufficient"
                        if any(limits.values())
                        else "contextual_read_requires_current_successful_evidence"
                    )
                ),
                "replace_with_gap_answer",
                tool,
                diagnostics,
            )

        if work_frame.domain in {"finance", "mixed"}:
            supported_reads = [
                (name, payload)
                for (name, payload), (supported, semantic) in zip(reads, validated)
                if supported
                and adjudicate_tool_candidate(
                    work_frame=work_frame, tool=semantic
                ).accepted
            ]
            claim_text = "\n".join(
                normalize_work_text(line) for line in assistant_message.splitlines()
            )
            claims_ok, bindings = validate_financial_claims(claim_text, supported_reads)
            diagnostics["financial_claim_bindings"] = bindings
            if not claims_ok:
                return ResponseSufficiencyResult(
                    False,
                    "financial_claim_not_bound_to_evidence",
                    "replace_with_gap_answer",
                    tool,
                    diagnostics,
                )

    if work_frame.needs_clarification and not tool:
        return ResponseSufficiencyResult(
            ok=True,
            reason="unknown_work_frame_provider_or_clarification_fallback_allowed",
            action="allow",
            tool=tool,
            diagnostics=diagnostics,
        )

    if not adjudication.accepted:
        return ResponseSufficiencyResult(
            ok=False,
            reason=adjudication.reason,
            action="replace_with_gap_answer",
            tool=tool,
            diagnostics=diagnostics,
        )

    if (
        "zero_pending_payments_as_evidence" in work_frame.forbidden_interpretations
        and (
            "pagos pendientes" in message
            or "solicitudes pendientes" in message
            or tool == "receipts.pending_payment_overview"
        )
        and "no hay dato soportado" not in message
    ):
        return ResponseSufficiencyResult(
            ok=False,
            reason="pending_payment_summary_does_not_answer_payment_evidence_question",
            action="replace_with_gap_answer",
            tool=tool,
            diagnostics=diagnostics,
        )

    if work_frame.domain == "owner" and work_frame.task_kind == "readiness":
        if "readiness" not in message and "faltantes" not in message:
            return ResponseSufficiencyResult(
                ok=False,
                reason="owner_readiness_answer_missing_readiness_or_gaps",
                action="replace_with_gap_answer",
                tool=tool,
                diagnostics=diagnostics,
            )

    if work_frame.domain == "owner" and work_frame.task_kind == "evidence":
        has_supported = any(
            token in message
            for token in (
                "si tengo ese dato",
                "sí tengo ese dato",
                "evidencia visible",
                "fuente",
                "fuentes",
            )
        )
        has_gap = any(
            token in message
            for token in (
                "no hay dato soportado",
                "no encontre evidencia",
                "no encontré evidencia",
                "no hay evidencia viva suficiente",
            )
        )
        if not (has_supported or has_gap):
            return ResponseSufficiencyResult(
                ok=False,
                reason="owner_evidence_answer_missing_supported_evidence_or_explicit_gap",
                action="replace_with_gap_answer",
                tool=tool,
                diagnostics=diagnostics,
            )

    if work_frame.domain == "finance" and work_frame.task_kind in {
        "status",
        "diagnostic",
        "evidence",
    }:
        if tool == "receipts.pending_payment_overview" and any(
            token in message for token in ("pagos pendientes", "solicitudes pendientes")
        ):
            return ResponseSufficiencyResult(
                ok=True,
                reason="pending_payment_answer_matches_pending_payment_work_frame",
                action="allow",
                tool=tool,
                diagnostics=diagnostics,
            )
        if tool == "receipts.cfdi_matching_overview" and any(
            token in message for token in ("cfdi", "cfdis", "factura", "facturas")
        ):
            return ResponseSufficiencyResult(
                ok=True,
                reason="cfdi_answer_matches_finance_evidence_work_frame",
                action="allow",
                tool=tool,
                diagnostics=diagnostics,
            )
        if not any(
            token in message
            for token in (
                "fuente",
                "ruta",
                "snapshot",
                "evidencia",
                "no pude consultar",
            )
        ):
            return ResponseSufficiencyResult(
                ok=False,
                reason="finance_answer_missing_source_or_route",
                action="replace_with_gap_answer",
                tool=tool,
                diagnostics=diagnostics,
            )

    return ResponseSufficiencyResult(
        ok=True,
        reason="answer_satisfies_known_work_frame_invariants",
        action="allow",
        tool=tool,
        diagnostics=diagnostics,
    )


def render_sufficiency_gap_answer(
    *,
    work_frame: WorkFrame,
    result: ResponseSufficiencyResult,
) -> str:
    """Render a safe executive answer when the selected path was insufficient."""

    if result.reason == "contextual_capability_unavailable":
        return (
            "No puedo determinar ese importe con la capacidad de consulta disponible. "
            "No se consultó una población completa ni se obtuvo evidencia suficiente "
            "para calcularlo; esto no significa que el importe sea cero. "
            "Para IVA pagado hacen falta el desglose de IVA, evidencia y fecha de pago, "
            "y la asignación de CFDI compartidos y parcialidades sin duplicarlos. "
            "Aprobado no equivale a pagado. No ejecuté cambios."
        )

    if result.reason == "financial_claim_not_bound_to_evidence":
        return (
            "La cifra propuesta no está respaldada por un importe de la evidencia consultada. "
            "Necesito verificar el importe y su alcance; no presentaré un cálculo sin soporte. "
            "No ejecuté cambios."
        )

    if result.reason == "contextual_reader_scope_insufficient":
        return (
            "El resultado consultado no acredita la conclusión solicitada. "
            "Un inventario, borrador o diagnóstico técnico no prueba hechos financieros; "
            "una lista limitada de documentos solo permite un estimado de esos registros, "
            "no un total completo ni un desglose de IVA. "
            "Necesito evidencia canónica para ese alcance. No ejecuté cambios."
        )

    evidence = ", ".join(work_frame.required_evidence) or "evidencia canónica"
    forbidden = ", ".join(work_frame.forbidden_interpretations) or "atajos sin soporte"
    return "\n".join(
        [
            "No tengo evidencia suficiente para contestar eso todavía.",
            "",
            f"Lo que entendí: {work_frame.interpreted_goal}",
            f"Necesito revisar: {evidence}.",
            f"No voy a usar como sustituto: {forbidden}.",
            "",
            "Siguiente paso: conectar o consultar la fuente correcta antes de darte una conclusión.",
            "No ejecuté cambios; esta respuesta es sólo lectura.",
        ]
    )


def build_response_sufficiency_trace(
    *,
    result: ResponseSufficiencyResult,
) -> dict[str, Any]:
    return {
        "tool": "assistant.response_sufficiency_gate",
        "assistant_response_sufficiency_gate": {
            "stage": "post_tool_work_frame_sufficiency_gate",
            **result.to_dict(),
        },
        "result": result.to_dict(),
    }


__all__ = [
    "ResponseSufficiencyResult",
    "evaluate_response_sufficiency",
    "render_sufficiency_gap_answer",
    "build_response_sufficiency_trace",
]
