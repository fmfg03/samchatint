"""Explicit one-attempt delivery. No daemon, startup hook or authority grant."""

import asyncio
import json
from datetime import datetime, timezone
from uuid import UUID

from devnous.gastos.services.batisenal_service import BatisenalError
from samchat.batisenal_bridge import requested_event_data

from .callback import signed_headers
from .events import EVENT


class Sender:
    def __init__(self, events, store, client, vault, *, enabled=False):
        self.events, self.store, self.client, self.vault = events, store, client, vault
        self.enabled = enabled

    async def once(self):
        if self.enabled is not True:
            raise BatisenalError("DELIVERY_ACTIVATION_REQUIRED", 503)
        self.events.gate()
        _, owner = await self.events.identity(write=True)
        claim = self.store.claim(owner)
        if claim is None:
            return {"state": "idle"}
        try:
            current = await self.events.case(claim["case_id"])
            if current["version"] != claim["version"]:
                self.store.finish(claim, "stopped")
                return {"state": "stale"}
            keys = [self.vault.get(claim["secret_ref"])]
            if claim["previous_secret_ref"] and claim["previous_until"] > int(
                self.store.clock()
            ):
                keys.append(self.vault.get(claim["previous_secret_ref"]))
            body = json.dumps(
                {
                    "eventId": claim["id"],
                    "name": EVENT,
                    "timestamp": datetime.fromtimestamp(
                        claim["created_at"], timezone.utc
                    ).isoformat(),
                    "data": requested_event_data(
                        claim["case_id"],
                        claim["version"],
                        str(UUID(hex=claim["id"][:32])),
                    ),
                    "cursor": None,
                },
                separators=(",", ":"),
                sort_keys=True,
            ).encode()
            headers = signed_headers(
                body,
                claim["id"],
                claim["subscription_id"],
                int(self.store.clock()),
                keys,
            )

            async def guard():
                _, fresh = await self.events.identity(write=True)
                if fresh != owner:
                    raise BatisenalError("DELIVERY_AUTHORITY_CHANGED", 403)
                if not self.store.valid(claim):
                    if self.store.refreshed(claim):
                        raise BatisenalError("DELIVERY_SUBSCRIPTION_REFRESHED", 409)
                    raise BatisenalError("DELIVERY_AUTHORITY_CHANGED", 403)

            await guard()
            status, _ = await self.client.post(
                claim["callback"], body, headers, before_connect=guard
            )
            if 200 <= status < 300:
                outcome = "received"
            elif status in {408, 429} or 500 <= status <= 599:
                outcome = "retry"
            else:
                outcome = (
                    "stopped"  # Includes410,413,redirects and other permanent errors.
                )
            saved = self.store.finish(claim, outcome, status)
            return {
                "state": outcome if saved else "receipt_conflict",
                "http_status": status,
            }
        except asyncio.CancelledError:
            # The receiver may have seen it; future bounded retry retains event ID.
            self.store.finish(claim, "uncertain")
            raise
        except BatisenalError as exc:
            transient = exc.code in {"CALLBACK_TIMEOUT", "CALLBACK_UNAVAILABLE"}
            outcome = (
                "uncertain"
                if transient
                else (
                    "retry"
                    if exc.code == "DELIVERY_SUBSCRIPTION_REFRESHED"
                    else "stopped"
                )
            )
            self.store.finish(claim, outcome)
            return {
                "state": outcome,
                "reason": exc.code,
            }
        except Exception:
            # Host/vault/receipt failure never leaks underlying error or credentials.
            # Leave lease to expire if durable completion itself is unavailable.
            return {"state": "unavailable"}
