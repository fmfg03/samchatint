"""Durable admission receipts for the existing conversation owner.

Schema is installed by the explicit migration, never by web startup. An uncertain
or failed operation is never automatically executed again with the same key.
"""

import hashlib
import json
from datetime import datetime, timezone
from uuid import UUID, uuid5

from fastapi import HTTPException
from sqlalchemy import (
    JSON,
    CheckConstraint,
    Column,
    DateTime,
    ForeignKey,
    Index,
    MetaData,
    String,
    Table,
    Uuid,
    select,
    update,
)
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sqlalchemy.dialects.sqlite import insert as sqlite_insert

metadata = MetaData()
# Reference-only declarations: these tables remain owned by gastos models.
Table("empleados", metadata, Column("id", Uuid(as_uuid=False), primary_key=True))
Table(
    "assistant_conversations",
    metadata,
    Column("id", Uuid(as_uuid=False), primary_key=True),
)
receipts = Table(
    "assistant_request_receipts",
    metadata,
    Column("id", Uuid(as_uuid=False), primary_key=True),
    Column(
        "empleado_id", Uuid(as_uuid=False), ForeignKey("empleados.id"), nullable=False
    ),
    Column(
        "conversation_id",
        Uuid(as_uuid=False),
        ForeignKey("assistant_conversations.id"),
        nullable=False,
    ),
    Column("request_hash", String(64), nullable=False),
    Column("state", String(20), nullable=False),
    Column("response", JSON(none_as_null=True)),
    Column("created_at", DateTime(timezone=True), nullable=False),
    Column("updated_at", DateTime(timezone=True), nullable=False),
    CheckConstraint("state IN ('processing', 'completed', 'failed')"),
    CheckConstraint("(state = 'completed') = (response IS NOT NULL)"),
)
Index(
    "uq_assistant_request_processing",
    receipts.c.conversation_id,
    unique=True,
    postgresql_where=receipts.c.state == "processing",
    sqlite_where=receipts.c.state == "processing",
)
NAMESPACE = UUID("e8e71108-d98c-4829-849b-bcfa089a68ec")


async def reserve(session, *, employee_id, conversation_id, request_key, payload):
    """Call only after current authentication and conversation ownership checks."""
    if not request_key:
        raise HTTPException(428, "request_id is required for safe retries.")
    try:
        key = str(UUID(str(request_key)))
    except ValueError as exc:
        raise HTTPException(422, "request_id must be a UUID.") from exc
    employee_id, conversation_id = str(employee_id), str(conversation_id)
    identifier = str(uuid5(NAMESPACE, f"{employee_id}:{conversation_id}:{key}"))
    encoded = json.dumps(
        payload, sort_keys=True, ensure_ascii=False, separators=(",", ":")
    ).encode()
    if len(encoded) > 65536:
        raise HTTPException(413, "Message context too large.")
    fingerprint = hashlib.sha256(encoded).hexdigest()
    dialect = session.bind.dialect.name
    insert = (
        pg_insert
        if dialect == "postgresql"
        else sqlite_insert if dialect == "sqlite" else None
    )
    if insert is None:
        raise HTTPException(503, "Request receipts require supported storage.")
    now = datetime.now(timezone.utc)
    result = await session.execute(
        insert(receipts)
        .values(
            id=identifier,
            empleado_id=employee_id,
            conversation_id=conversation_id,
            request_hash=fingerprint,
            state="processing",
            created_at=now,
            updated_at=now,
        )
        .on_conflict_do_nothing()
    )
    admitted = result.rowcount == 1
    await session.commit()
    if admitted:
        return identifier, None
    row = (
        (
            await session.execute(
                select(receipts).where(
                    receipts.c.id == identifier,
                    receipts.c.empleado_id == employee_id,
                    receipts.c.conversation_id == conversation_id,
                )
            )
        )
        .mappings()
        .one_or_none()
    )
    if row is None:
        raise HTTPException(
            409,
            "Another request is pending in this conversation.",
            headers={"Retry-After": "3"},
        )
    if row["request_hash"] != fingerprint:
        raise HTTPException(409, "request_id was already used with different content.")
    if row["state"] == "completed":
        return identifier, row["response"]
    if row["state"] == "failed":
        raise HTTPException(
            503,
            "Previous request did not complete; history was preserved. Do not resend automatically.",
        )
    raise HTTPException(
        409,
        "Request received; outcome pending. It was not executed again.",
        headers={"Retry-After": "3"},
    )


async def finish(session, identifier, *, response=None):
    result = await session.execute(
        update(receipts)
        .where(
            receipts.c.id == identifier,
            receipts.c.state == "processing",
        )
        .values(
            state="completed" if response is not None else "failed",
            response=response,
            updated_at=datetime.now(timezone.utc),
        )
    )
    if result.rowcount != 1:
        raise HTTPException(409, "Request receipt state changed.")
    await session.commit()
