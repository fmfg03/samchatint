"""Durable subscription contract; callback/secret owners must be injected.

No DNS, sockets, generated keys, sender or permanent worker. Verification must
perform the official signed challenge over a pinned public HTTPS connection.
No adapter is enabled by default; a boolean from tool arguments never approves it.
"""

import base64
import ipaddress
import re
from datetime import datetime, timezone
from urllib.parse import urlsplit
from uuid import UUID

from devnous.gastos.services.batisenal_service import BatisenalError

from .store import digest

EVENT = "batisenal.requested"


def canonical_case(value):
    try:
        if not isinstance(value, str):
            raise ValueError()
        return str(UUID(value))
    except ValueError as exc:
        raise BatisenalError("INVALID_ARGUMENTS") from exc


def callback_url(value, allowed_hosts):
    if (
        not isinstance(value, str)
        or len(value) > 2048
        or any(ord(c) < 33 for c in value)
    ):
        raise BatisenalError("CALLBACK_INVALID")
    try:
        url = urlsplit(value)
        if (
            url.scheme != "https"
            or not url.hostname
            or url.username
            or url.password
            or url.fragment
            or url.port not in (None, 443)
            or "\\" in value
            or url.hostname not in allowed_hosts
        ):
            raise ValueError()
        # Literal IPs are never admissible, including encoded/IPv6 local targets.
        try:
            ipaddress.ip_address(url.hostname)
        except ValueError:
            pass
        else:
            raise ValueError()
        if not re.fullmatch(r"[a-z0-9.-]+", url.hostname):
            raise ValueError()
    except (ValueError, TypeError) as exc:
        raise BatisenalError("CALLBACK_INVALID") from exc
    return value


class Events:
    """One-case subscriptions. Secret material never enters SQLite or tool output.

    verifier.verify(url, secret, subscription_id=...) must perform bounded signed challenge, validate
    public addresses at connection time, pin TLS and disallow redirects. It must
    raise on failure. vault.put is an immutable, durable idempotent owner operation returning
    an opaque reference; neither concrete external adapter is supplied here.
    """

    def __init__(
        self,
        bridge,
        store,
        *,
        verifier=None,
        vault=None,
        allowed_hosts=(),
        enabled=False,
    ):
        self.bridge, self.store = bridge, store
        self.verifier, self.vault = verifier, vault
        self.allowed_hosts = frozenset(allowed_hosts)
        self.enabled = enabled

    def gate(self):
        if self.enabled is not True or self.verifier is None or self.vault is None:
            raise BatisenalError("EVENT_ACTIVATION_REQUIRED", 503)

    async def identity(self, *, write=False):
        async with self.bridge.sessions() as session:
            _, binding, grant = await self.bridge.authorize(session, write=write)
        return binding, digest(
            [grant, binding.organization, binding.project, str(binding.agent_id)]
        )

    async def case(self, case_id):
        case_id = canonical_case(case_id)
        return await self.bridge.call(
            "samchat_batisenal_read_case", {"case_id": case_id}
        )

    async def handle(self, method, params):
        self.gate()
        _, owner = await self.identity(write=method != "events/list")
        if method == "events/list":
            if params != {}:
                raise BatisenalError("INVALID_ARGUMENTS")
            return {
                "events": [
                    {
                        "name": EVENT,
                        "delivery": ["webhook"],
                        "description": "A committed authorized Batiseñal case awaits review. IDs only; not authority to read or publish.",
                        "inputSchema": {
                            "type": "object",
                            "properties": {"case_id": {"type": "string"}},
                            "required": ["case_id"],
                            "additionalProperties": False,
                        },
                        "payloadSchema": {
                            "type": "object",
                            "properties": {
                                "type": {"const": EVENT},
                                "case_id": {"type": "string"},
                                "version": {"type": "string"},
                                "delivery_id": {"type": "string"},
                            },
                            "required": ["type", "case_id", "version", "delivery_id"],
                            "additionalProperties": False,
                        },
                    }
                ]
            }
        if method not in {"events/subscribe", "events/unsubscribe"}:
            raise BatisenalError("METHOD_NOT_AVAILABLE")
        required = {"name", "arguments", "delivery"}
        if (
            not isinstance(params, dict)
            or set(params) - (required | {"cursor", "ttlMs"})
            or not required <= set(params)
        ):
            raise BatisenalError("INVALID_ARGUMENTS")
        if (
            params["name"] != EVENT
            or params.get("cursor") is not None
            or not isinstance(params["arguments"], dict)
            or set(params["arguments"]) != {"case_id"}
        ):
            raise BatisenalError("INVALID_ARGUMENTS")
        case_id = canonical_case(params["arguments"]["case_id"])
        delivery = params["delivery"]
        fields = (
            {"mode", "url", "secret"}
            if method == "events/subscribe"
            else {"mode", "url"}
        )
        if (
            not isinstance(delivery, dict)
            or set(delivery) != fields
            or delivery["mode"] != "webhook"
        ):
            raise BatisenalError("INVALID_ARGUMENTS")
        callback = callback_url(delivery["url"], self.allowed_hosts)
        if method == "events/unsubscribe":
            # Current binding must remain valid; deletion is scoped by owner, not model.
            self.store.unsubscribe(owner=owner, case_id=case_id, callback=callback)
            return {}
        await self.case(case_id)
        ttl = params.get("ttlMs", 3600000)
        if type(ttl) is not int or not 60000 <= ttl <= 3600000:
            raise BatisenalError("TTL_INVALID")
        secret = delivery["secret"]
        try:
            if (
                not isinstance(secret, str)
                or not secret.startswith("whsec_")
                or len(secret) > 100
            ):
                raise ValueError()
            raw = base64.b64decode(secret[6:], validate=True)
            if not 24 <= len(raw) <= 64:
                raise ValueError()
        except (ValueError, TypeError) as exc:
            raise BatisenalError("SIGNING_SECRET_INVALID") from exc
        # ID binds the authenticated owner/case/callback, never model actor fields.
        identifier = digest([owner, case_id, callback])
        # No application data is passed to verifier; failures persist no subscription.
        try:
            verified = await self.verifier.verify(
                callback, secret, subscription_id=identifier
            )
        except Exception as exc:
            raise BatisenalError("CALLBACK_VERIFICATION_FAILED", 503) from exc
        if verified is not True:
            raise BatisenalError("CALLBACK_VERIFICATION_FAILED")
        # Read current case before final write authority revalidation.
        await self.case(case_id)
        _, fresh = await self.identity(write=True)
        if fresh != owner:
            raise BatisenalError("IDENTITY_CHANGED", 403)
        secret_ref = self.vault.put(digest([identifier, secret]), secret)
        if (
            not isinstance(secret_ref, str)
            or secret_ref.startswith("whsec_")
            or not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", secret_ref)
        ):
            raise BatisenalError("SECRET_STORE_UNAVAILABLE", 503)
        # Vault IO may take time; check again before committing a subscription.
        _, fresh = await self.identity(write=True)
        if fresh != owner:
            raise BatisenalError("IDENTITY_CHANGED", 403)
        expires = int(self.store.clock()) + ttl // 1000
        identifier = self.store.subscribe(
            owner=owner,
            case_id=case_id,
            callback=callback,
            secret_ref=secret_ref,
            expires=expires,
        )
        return {
            "id": identifier,
            "refreshBefore": datetime.fromtimestamp(expires, timezone.utc).isoformat(),
            "cursor": None,
            "truncated": False,
        }

    async def enqueue_case(self, case_id):
        """Explicit host call only, not an MCP tool or commit hook. Safe to repeat."""
        self.gate()
        case_id = canonical_case(case_id)
        _, owner = await self.identity(write=True)
        current = await self.case(case_id)
        _, fresh = await self.identity(write=True)
        if fresh != owner:
            raise BatisenalError("IDENTITY_CHANGED", 403)
        return self.store.enqueue(
            owner=owner, case_id=case_id, version=current["version"]
        )
