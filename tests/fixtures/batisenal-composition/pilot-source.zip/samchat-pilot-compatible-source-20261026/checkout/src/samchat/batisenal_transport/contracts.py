"""Host-owned adapters. Defining these protocols does not grant authority."""

from typing import Protocol

from starlette.requests import Request


class ConnectionResolver(Protocol):
    async def __call__(self, request: Request) -> str:
        """Validate bearer credentials; return a request-local verified reference.

        Never trust actor/scope from body, query, headers other than verified
        credentials, cookies or inherited root. The existing IdentityProvider
        must revalidate that reference on each Bridge operation.
        """


class SecretVault(Protocol):
    def put(self, version: str, secret: str) -> str:
        """Persist immutable secret version under approved encryption/access owner.

        Return an opaque reference; replay identical version must be idempotent.
        No generated signing secret: material comes from an authentic subscription.
        """

    def get(self, reference: str) -> str:
        """Resolve only host-owned reference; fail closed if absent/revoked.

        No raw values in audit/logs/DB records/tool output. Concrete storage,
        credentials, retention and revocation remain an activation checkpoint.
        """
