"""
Utilities for gastos module.
"""
