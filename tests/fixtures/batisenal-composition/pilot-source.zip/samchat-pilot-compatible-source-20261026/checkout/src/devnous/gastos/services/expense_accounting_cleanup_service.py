"""Accounting cleanup helpers for expense COI readiness.

This service persists cleanup decisions on ExpenseReport so COI export can
reuse the chosen accounts without reclassification.
"""

from __future__ import annotations

from contextlib import asynccontextmanager
import logging
import unicodedata
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional
from uuid import UUID

from sqlalchemy import and_, or_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from samchat.assistant.historical_accounting_precedent import (
    query_historical_accounting_precedents,
)

from ..models import CFDIReport, CuentaContable, ExpenseReport

DEFAULT_CLEANUP_CONTRA_CUENTA_CODIGO = "2120-000-000"
DEFAULT_CLEANUP_CONTRA_CUENTA_NOMBRE = "ACREEDORES DIVERSOS"
_NON_FISCAL_ACCOUNT_CODES = {"5300-016-003"}
_NON_FISCAL_ACCOUNT_NAMES = {
    "sin requisitos fiscales",
    "no deducible",
    "gastos no deducibles",
    "gastos no deducibles ctt",
    "gastos no deducibles dcc",
    "gastos no deducibles del cutt",
    "gastos no deducibles de md",
    "gastos no deducibles ltb",
    "gastos no deducibles hwc",
}
_CLEANUP_DOCUMENT_TYPES = {"all", "informe", "solicitud"}
_CLEANUP_ISSUE_TYPES = {
    "all",
    "main_account",
    "counterpart",
    "cfdi",
    "fiscal",
}
from .budget_concept_account_service import (
    cleanup_expense_loader_options,
    resolve_effective_budget_concept,
)
from .expense_accounting_service import build_expense_accounting_preview
from .hospedaje_tax_service import normalize_hospedaje_rate, normalize_hospedaje_state


logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class CFDICleanupOption:
    """Compact CFDI option for the cleanup dropdown."""

    id: UUID
    uuid: str
    label: str
    total: Optional[float]
    emisor_nombre: Optional[str]
    fecha: Any



@asynccontextmanager
async def _optional_nested_transaction(session: AsyncSession):
    begin_nested = getattr(session, "begin_nested", None)
    if begin_nested is None:
        yield
        return
    async with begin_nested():
        yield

def _money_or_none(value: Any) -> Optional[float]:
    if value in (None, ""):
        return None
    try:
        return round(float(value), 2)
    except (TypeError, ValueError):
        return None


def _truthy(value: Any) -> bool:
    return str(value or "").strip().lower() in {
        "1",
        "true",
        "on",
        "yes",
        "si",
        "sí",
    }


def _clean_text_part(value: Any) -> str:
    text = str(value or "").strip()
    return text if text and text not in {"-", "\u2014"} else ""


def _normalize_cleanup_search(value: Any) -> str:
    compact = " ".join(str(value or "").strip().split())[:200].casefold()
    decomposed = unicodedata.normalize("NFKD", compact)
    return "".join(char for char in decomposed if not unicodedata.combining(char))


def normalize_cleanup_document_type(value: Any) -> str:
    normalized = str(value or "all").strip().lower()
    return normalized if normalized in _CLEANUP_DOCUMENT_TYPES else "all"


def normalize_cleanup_issue_type(value: Any) -> str:
    normalized = str(value or "all").strip().lower()
    return normalized if normalized in _CLEANUP_ISSUE_TYPES else "all"


def _cleanup_related_documents(expense: ExpenseReport) -> list[Any]:
    documents: list[Any] = []
    seen: set[str] = set()
    for relationship in ("documento", "informe_documento", "solicitud_documento"):
        document = getattr(expense, relationship, None)
        if document is None:
            continue
        identity = str(getattr(document, "id", None) or id(document))
        if identity in seen:
            continue
        seen.add(identity)
        documents.append(document)
    return documents


def _cleanup_expense_document_type(expense: ExpenseReport) -> str:
    document_types = {
        str(getattr(document, "tipo", "") or "").strip().lower()
        for document in _cleanup_related_documents(expense)
    }
    document_types.discard("")
    if len(document_types) != 1:
        return ""
    document_type = next(iter(document_types))
    return document_type if document_type in {"informe", "solicitud"} else ""


def cleanup_expense_matches_filters(
    expense: ExpenseReport,
    *,
    search_q: str = "",
    document_type: str = "all",
) -> bool:
    """Match one already-loaded cleanup row without inferring document identity."""

    selected_document_type = normalize_cleanup_document_type(document_type)
    if (
        selected_document_type != "all"
        and _cleanup_expense_document_type(expense) != selected_document_type
    ):
        return False

    token = _normalize_cleanup_search(search_q)
    if not token:
        return True

    employee = getattr(expense, "empleado", None)
    cfdi = getattr(expense, "cfdi_report", None)
    haystack: list[Any] = [
        getattr(expense, "id", None),
        getattr(expense, "numero_referencia", None),
        getattr(expense, "concepto", None),
        getattr(expense, "proyecto", None),
        getattr(expense, "cfdi_uuid_manual", None),
        getattr(expense, "numero_factura", None),
        getattr(employee, "nombre", None),
        getattr(cfdi, "cfdi_uuid", None),
        getattr(cfdi, "emisor_nombre", None),
        getattr(cfdi, "emisor_rfc", None),
    ]
    for document in _cleanup_related_documents(expense):
        beneficiary_names = [
            getattr(getattr(document, relationship, None), "nombre", None)
            for relationship in (
                "beneficiario_empleado",
                "beneficiario_proveedor_cliente",
                "proveedor_cliente",
            )
        ]
        haystack.extend(
            [
                getattr(document, "id", None),
                getattr(document, "numero_referencia", None),
                getattr(document, "estado", None),
                getattr(document, "concepto_pago", None),
                getattr(document, "referencia_operaciones", None),
                getattr(document, "proyecto_otro", None),
                getattr(document, "numero_factura", None),
                getattr(document, "cfdi_uuid_manual", None),
                *beneficiary_names,
            ]
        )
    account = getattr(expense, "cuenta_gastos", None)
    haystack.extend(
        getattr(getattr(account, relationship, None), "nombre", None)
        for relationship in (
            "beneficiario_empleado",
            "beneficiario_proveedor_cliente",
            "empleado",
        )
    )
    return any(token in _normalize_cleanup_search(value) for value in haystack)


def cleanup_issues_match_filter(issues: Iterable[Any], issue_type: str) -> bool:
    normalized_issue_type = normalize_cleanup_issue_type(issue_type)
    normalized_issues = [_normalize_cleanup_search(issue) for issue in issues]
    if normalized_issue_type == "all":
        return bool(normalized_issues)
    if normalized_issue_type == "main_account":
        return any("falta cuenta de cargo" in issue for issue in normalized_issues)
    if normalized_issue_type == "counterpart":
        return any("falta contrapartida" in issue for issue in normalized_issues)
    if normalized_issue_type == "cfdi":
        return any("falta cfdi" in issue for issue in normalized_issues)
    return any(
        "falta cuenta de iva" in issue or "falta cuenta de retencion" in issue
        for issue in normalized_issues
    )


def _historical_precedent_query_for_expense(expense: ExpenseReport) -> str:
    """Build a conservative evidence query for historical accounting lookup."""

    cfdi = getattr(expense, "cfdi_report", None)
    empleado = getattr(expense, "empleado", None)
    document = getattr(expense, "documento", None)
    parts = [
        getattr(expense, "concepto", None),
        getattr(expense, "proyecto", None),
        getattr(expense, "fase_torneo", None),
        getattr(expense, "metodo_pago", None),
        getattr(expense, "numero_factura", None),
        getattr(cfdi, "emisor_nombre", None),
        getattr(cfdi, "emisor_rfc", None),
        getattr(empleado, "nombre", None),
        getattr(document, "numero_referencia", None),
    ]
    seen: set[str] = set()
    tokens: list[str] = []
    for value in parts:
        text = _clean_text_part(value)
        key = text.casefold()
        if not text or key in seen:
            continue
        seen.add(key)
        tokens.append(text)
    return " ".join(tokens[:8])


async def build_historical_precedent_evidence(
    session: AsyncSession,
    expense: ExpenseReport,
    *,
    limit: int = 3,
) -> Dict[str, Any]:
    """Return read-only accounting precedent evidence for cleanup review.

    This is intentionally advisory: it never assigns cuentas contables and never
    changes the expense. Historical usage can support a human decision, but it is
    not authority to classify a current gasto.
    """

    query = _historical_precedent_query_for_expense(expense)
    if not query:
        return {
            "status": "invalid_query",
            "headline": "Sin busqueda historica suficiente",
            "summary": "El gasto no tiene concepto, CFDI, empleado o documento suficiente para buscar precedentes.",
            "query": "",
            "candidates": [],
            "safety_summary": {
                "read_only": True,
                "account_assignment_performed": False,
            },
            "non_claims": [
                "No asigna automaticamente la cuenta contable.",
                "No reemplaza la revision de Finanzas/Contabilidad.",
            ],
        }
    try:
        async with _optional_nested_transaction(session):
            report = await query_historical_accounting_precedents(
                session,
                query=query,
                company_code="01",
                fiscal_year=getattr(expense, "edicion", None),
                limit=limit,
            )
        payload = report.to_dict()
        payload.setdefault("safety_summary", {})[
            "account_assignment_performed"
        ] = False
        return payload
    except Exception as exc:  # pragma: no cover - defensive fail-closed path
        return {
            "status": "precedent_lookup_failed",
            "headline": "Precedente historico no disponible",
            "summary": f"No se pudo consultar el historico contable: {exc}",
            "query": query,
            "candidates": [],
            "safety_summary": {
                "read_only": True,
                "account_assignment_performed": False,
            },
            "non_claims": [
                "No asigna automaticamente la cuenta contable.",
                "No crea ni modifica gastos, polizas, catalogos o partidas.",
            ],
        }


def _normalize_account_name(value: Any) -> str:
    return " ".join(str(value or "").strip().lower().split())


def _allows_cleanup_without_cfdi(expense: ExpenseReport) -> bool:
    account = getattr(expense, "cuenta_contable", None)
    if account is None:
        return False
    return (
        str(getattr(account, "codigo", "") or "").strip() in _NON_FISCAL_ACCOUNT_CODES
        or _normalize_account_name(getattr(account, "nombre", None))
        in _NON_FISCAL_ACCOUNT_NAMES
    )


def resolve_default_cleanup_contra_cuenta(
    cuentas: Iterable[CuentaContable],
) -> Optional[CuentaContable]:
    """Return the standard liability account used as cleanup contrapartida."""

    for cuenta in cuentas:
        if cuenta.codigo == DEFAULT_CLEANUP_CONTRA_CUENTA_CODIGO:
            return cuenta
    return None


def _cfdi_option_label(cfdi: CFDIReport) -> str:
    uuid = str(cfdi.cfdi_uuid or "").strip() or str(cfdi.id)
    emisor = str(cfdi.emisor_nombre or cfdi.emisor_rfc or "emisor sin dato").strip()
    total = float(cfdi.total or 0.0)
    fecha = (
        cfdi.fecha.strftime("%Y-%m-%d") if getattr(cfdi, "fecha", None) else "sin fecha"
    )
    return f"{uuid} · {emisor} · ${total:,.2f} · {fecha}"


async def list_unassigned_cfdi_options(
    session: AsyncSession,
    *,
    limit: int = 500,
) -> List[CFDICleanupOption]:
    """Return CFDI rows not currently linked to active expenses."""

    linked_cfdi_ids = (
        select(ExpenseReport.cfdi_report_id)
        .where(
            ExpenseReport.cfdi_report_id.isnot(None),
            ExpenseReport.estado_gasto == "activo",
        )
        .distinct()
    )
    result = await session.execute(
        select(CFDIReport)
        .where(~CFDIReport.id.in_(linked_cfdi_ids))
        .order_by(CFDIReport.fecha.desc().nullslast(), CFDIReport.created_at.desc())
        .limit(max(1, min(int(limit or 500), 1000)))
    )
    return [
        CFDICleanupOption(
            id=cfdi.id,
            uuid=cfdi.cfdi_uuid or "",
            label=_cfdi_option_label(cfdi),
            total=float(cfdi.total) if cfdi.total is not None else None,
            emisor_nombre=cfdi.emisor_nombre,
            fecha=cfdi.fecha,
        )
        for cfdi in result.scalars().all()
    ]


async def load_cleanup_expenses(
    session: AsyncSession,
    *,
    extra_conditions: Optional[Iterable[Any]] = None,
    search_q: str = "",
    document_type: str = "all",
    issue_type: str = "all",
) -> List[ExpenseReport]:
    """Load active expenses that still need accounting cleanup."""

    conditions = [
        ExpenseReport.estado_gasto == "activo",
    ]
    if extra_conditions:
        conditions.extend(list(extra_conditions))

    loader_options = [
        selectinload(ExpenseReport.empleado),
        selectinload(ExpenseReport.cfdi_report),
        selectinload(ExpenseReport.cuenta_contable),
        selectinload(ExpenseReport.contra_cuenta_contable),
        selectinload(ExpenseReport.cuenta_iva),
        *cleanup_expense_loader_options(),
    ]
    query = select(ExpenseReport).options(*loader_options).where(and_(*conditions))
    result = await session.execute(query.order_by(ExpenseReport.fecha.desc()))
    candidates = result.scalars().all()

    # Show rows that still need human/accounting action, not rows that are merely
    # missing a persisted fallback field. Counterpart accounts can be resolved
    # deterministically from payment method/catalog rules, and non-fiscal expense
    # accounts intentionally allow missing CFDI. Use the same readiness contract as
    # the export path so counters and rows move together.
    pending: List[ExpenseReport] = []
    for expense in candidates:
        if not cleanup_expense_matches_filters(
            expense,
            search_q=search_q,
            document_type=document_type,
        ):
            continue
        state = await build_cleanup_preview(session, expense)
        if cleanup_issues_match_filter(state.get("issues") or [], issue_type):
            pending.append(expense)
    return pending


async def build_cleanup_preview(
    session: AsyncSession,
    expense: ExpenseReport,
    *,
    include_historical_precedent: bool = False,
) -> Dict[str, Any]:
    """Build the fiscal/accounting preview plus readiness labels."""

    preview = await build_expense_accounting_preview(session, expense)
    taxes = preview.get("taxes") or {}
    effective_concept = resolve_effective_budget_concept(expense)
    mapped_cuenta_id = getattr(effective_concept, "cuenta_contable_id", None)
    issues = []
    if not getattr(expense, "cuenta_contable_id", None) and not mapped_cuenta_id:
        issues.append("Falta cuenta de cargo")
    if not getattr(expense, "contra_cuenta_contable_id", None) and not preview.get(
        "contra_account"
    ):
        issues.append("Falta contrapartida")
    if not getattr(expense, "cfdi_report_id", None) and not _allows_cleanup_without_cfdi(expense):
        issues.append("Falta CFDI vinculado")
    if float(taxes.get("iva_trasladado") or 0.0) > 0 and not (
        taxes.get("iva_account") or {}
    ).get("codigo"):
        issues.append("Falta cuenta de IVA")
    for retention in taxes.get("retenciones") or []:
        if not (retention.get("account") or {}).get("codigo"):
            issues.append(f"Falta cuenta de retención {retention.get('label')}")

    status = "Listo COI" if not issues else "Pendiente"
    state = {
        "preview": preview,
        "issues": issues,
        "status": status,
    }
    if include_historical_precedent:
        state["historical_precedent_evidence"] = await build_historical_precedent_evidence(
            session,
            expense,
        )
    return state


async def safe_build_cleanup_preview(
    session: AsyncSession,
    expense: ExpenseReport,
    *,
    include_historical_precedent: bool = False,
) -> Dict[str, Any]:
    """Build cleanup preview without allowing optional enrichment to blank a page.

    Accounting cleanup screens are operational work queues. They must remain
    usable even when advisory previews, historical lookups, or fiscal
    enrichments fail for a single expense row. The returned state is explicit
    about the degradation so the UI can show the row and let Contabilidad keep
    working manually.
    """

    try:
        async with _optional_nested_transaction(session):
            return await build_cleanup_preview(
                session,
                expense,
                include_historical_precedent=include_historical_precedent,
            )
    except Exception:  # pragma: no cover - defensive operational guard
        logger.warning(
            "cleanup preview failed; rendering degraded row",
            extra={"expense_id": str(getattr(expense, "id", ""))},
            exc_info=True,
        )
        amount = float(getattr(expense, "gasto_cantidad", 0.0) or 0.0)
        return {
            "preview": {
                "taxes": {
                    "iva_trasladado": 0.0,
                    "retenciones": [],
                    "retenciones_total": 0.0,
                    "impuestos_locales": [],
                    "impuestos_locales_total": 0.0,
                    "gastos_no_deducibles": [],
                    "gastos_no_deducibles_total": 0.0,
                    "base_gasto": amount,
                    "neto_contrapartida": amount,
                },
                "notes": [
                    "Vista degradada: no se pudieron calcular sugerencias fiscales/contables para esta fila.",
                    "Puedes clasificar manualmente o reintentar mas tarde.",
                ],
                "contra_account": {},
            },
            "issues": [
                "Preview contable no disponible",
                *([] if getattr(expense, "cuenta_contable_id", None) else ["Falta cuenta de cargo"]),
                *([] if getattr(expense, "contra_cuenta_contable_id", None) else ["Falta contrapartida"]),
                *([] if getattr(expense, "cfdi_report_id", None) else ["Falta CFDI vinculado"]),
            ],
            "status": "Pendiente",
            "historical_precedent_evidence": {
                "status": "preview_degraded",
                "headline": "Sugerencias no disponibles",
                "summary": "La fila se muestra sin enriquecimiento opcional para evitar pantalla blanca.",
                "query": "",
                "candidates": [],
                "safety_summary": {
                    "read_only": True,
                    "account_assignment_performed": False,
                },
            } if include_historical_precedent else {},
        }


async def save_expense_cleanup(
    session: AsyncSession,
    expense_id: UUID,
    *,
    cuenta_contable_id: Optional[str] = None,
    contra_cuenta_contable_id: Optional[str] = None,
    cuenta_iva_id: Optional[str] = None,
    retention_account_ids: Optional[Dict[str, str]] = None,
    cfdi_report_id: Optional[str] = None,
    iva: Any = None,
    hospedaje_entidad_fiscal: Any = None,
    hospedaje_tasa_impuesto: Any = None,
    hospedaje_impuesto_monto: Any = None,
    hospedaje_impuesto_confirmado: Any = None,
) -> ExpenseReport:
    """Save cleanup choices into existing ExpenseReport fields."""

    result = await session.execute(
        select(ExpenseReport)
        .options(selectinload(ExpenseReport.cuenta_contable))
        .options(selectinload(ExpenseReport.contra_cuenta_contable))
        .options(selectinload(ExpenseReport.cuenta_iva))
        .where(ExpenseReport.id == expense_id)
    )
    expense = result.scalar_one_or_none()
    if expense is None:
        raise ValueError("Gasto no encontrado")

    if getattr(expense, "informe_documento_id", None):
        from ..models import Documento

        owner = await session.get(Documento, expense.informe_documento_id)
        if (
            owner is not None
            and getattr(owner, "informe_origen_id", None)
            and owner.estado == "aprobado"
        ):
            raise ValueError(
                "La comprobación parcial ya está contabilizada; no puede reclasificarse sin reversión."
            )

    if cuenta_contable_id:
        cuenta = await _load_active_account(
            session, cuenta_contable_id, "Cuenta contable"
        )
        expense.cuenta_contable_id = cuenta.id
    elif expense.cuenta_contable_id is None:
        effective_concept = resolve_effective_budget_concept(expense)
        mapped_cuenta_id = getattr(effective_concept, "cuenta_contable_id", None)
        if mapped_cuenta_id:
            cuenta = await _load_active_account(
                session, str(mapped_cuenta_id), "Cuenta contable mapeada"
            )
            expense.cuenta_contable_id = cuenta.id

    if contra_cuenta_contable_id:
        contra = await _load_active_account(
            session, contra_cuenta_contable_id, "Contrapartida"
        )
        expense.contra_cuenta_contable_id = contra.id

    if cuenta_iva_id:
        cuenta_iva = await _load_active_account(session, cuenta_iva_id, "Cuenta IVA")
        expense.cuenta_iva_id = cuenta_iva.id

    if retention_account_ids:
        normalized_retention_accounts: Dict[str, str] = {}
        for impuesto_code, raw_account_id in retention_account_ids.items():
            code = str(impuesto_code or "").strip()
            account_id = str(raw_account_id or "").strip()
            if not code or not account_id:
                continue
            account = await _load_active_account(
                session,
                account_id,
                f"Cuenta retención {code}",
            )
            normalized_retention_accounts[code] = str(account.id)
        expense.retencion_cuentas_json = normalized_retention_accounts or None

    if cfdi_report_id:
        cfdi = await _load_cfdi(session, cfdi_report_id)
        expense.cfdi_report_id = cfdi.id
        if cfdi.cfdi_uuid:
            expense.cfdi_uuid_manual = cfdi.cfdi_uuid
    elif not expense.cfdi_report_id and getattr(expense, "nova_request_id", None):
        cfdi = await _load_single_cfdi_by_nova_request_id(
            session, expense.nova_request_id
        )
        if cfdi is not None:
            expense.cfdi_report_id = cfdi.id
            if cfdi.cfdi_uuid:
                expense.cfdi_uuid_manual = cfdi.cfdi_uuid

    iva_amount = _money_or_none(iva)
    if iva in ("", None):
        expense.iva = None
    elif iva_amount is None:
        raise ValueError("El IVA capturado es inválido")
    else:
        expense.iva = iva_amount

    if hospedaje_entidad_fiscal not in (None, ""):
        expense.hospedaje_entidad_fiscal = normalize_hospedaje_state(
            hospedaje_entidad_fiscal
        )
    elif hospedaje_entidad_fiscal == "":
        expense.hospedaje_entidad_fiscal = None

    if hospedaje_tasa_impuesto in (None, ""):
        expense.hospedaje_tasa_impuesto = None
    else:
        rate = normalize_hospedaje_rate(hospedaje_tasa_impuesto)
        if rate is None:
            raise ValueError("La tasa de hospedaje es inválida")
        expense.hospedaje_tasa_impuesto = rate

    hosp_amount = _money_or_none(hospedaje_impuesto_monto)
    if hospedaje_impuesto_monto in (None, ""):
        expense.hospedaje_impuesto_monto = None
    elif hosp_amount is None:
        raise ValueError("El monto de hospedaje es inválido")
    else:
        expense.hospedaje_impuesto_monto = hosp_amount

    expense.hospedaje_impuesto_confirmado = _truthy(hospedaje_impuesto_confirmado)

    session.add(expense)
    await session.commit()
    return expense


async def _load_active_account(
    session: AsyncSession,
    raw_id: str,
    label: str,
) -> CuentaContable:
    try:
        account_id = UUID(str(raw_id))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} inválida") from exc

    result = await session.execute(
        select(CuentaContable).where(
            CuentaContable.id == account_id,
            CuentaContable.activo.is_(True),
        )
    )
    account = result.scalar_one_or_none()
    if account is None:
        raise ValueError(f"{label} inválida o inactiva")
    return account


async def _load_cfdi(session: AsyncSession, raw_id: str) -> CFDIReport:
    try:
        cfdi_id = UUID(str(raw_id))
    except (TypeError, ValueError) as exc:
        raise ValueError("CFDI inválido") from exc

    result = await session.execute(select(CFDIReport).where(CFDIReport.id == cfdi_id))
    cfdi = result.scalar_one_or_none()
    if cfdi is None:
        raise ValueError("CFDI no encontrado")
    return cfdi


async def _load_single_cfdi_by_nova_request_id(
    session: AsyncSession,
    nova_request_id: str,
) -> Optional[CFDIReport]:
    result = await session.execute(
        select(CFDIReport)
        .where(CFDIReport.nova_request_id == nova_request_id)
        .order_by(CFDIReport.created_at.desc())
        .limit(2)
    )
    matches = result.scalars().all()
    return matches[0] if len(matches) == 1 else None


__all__ = [
    "CFDICleanupOption",
    "DEFAULT_CLEANUP_CONTRA_CUENTA_CODIGO",
    "DEFAULT_CLEANUP_CONTRA_CUENTA_NOMBRE",
    "build_cleanup_preview",
    "safe_build_cleanup_preview",
    "build_historical_precedent_evidence",
    "cleanup_expense_matches_filters",
    "cleanup_issues_match_filter",
    "list_unassigned_cfdi_options",
    "load_cleanup_expenses",
    "normalize_cleanup_document_type",
    "normalize_cleanup_issue_type",
    "resolve_default_cleanup_contra_cuenta",
    "save_expense_cleanup",
]
