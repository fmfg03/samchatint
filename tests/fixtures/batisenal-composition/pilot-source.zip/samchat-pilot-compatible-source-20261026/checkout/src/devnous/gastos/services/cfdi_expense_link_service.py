"""
CFDI fiscal UUID normalization and ExpenseReport ↔ CFDIReport linking.

Canonical storage: uppercase UUID string (SAT-style), after strip + uuid.UUID parse.
Matching is case- and whitespace-tolerant for legacy rows via upper(trim(...)) in SQL.
"""
from __future__ import annotations

import logging
import re
from typing import Optional
from uuid import UUID

from sqlalchemy import func, or_, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from .amex_accounting_identity_service import accounting_expense_condition
from sqlalchemy.orm import lazyload

from ..models import Aprobacion, CFDIReport, Documento, ExpenseReport

logger = logging.getLogger(__name__)

_CFDI_UUID_PREFIX_RE = re.compile(r"^[0-9a-fA-F]{8}$")


class ExpenseCFDIDuplicateError(ValueError):
    """A fiscal UUID is already linked to another active expense."""

    def __init__(self, fiscal_uuid: str, duplicate_id: Optional[UUID] = None):
        self.fiscal_uuid = fiscal_uuid
        self.duplicate_id = duplicate_id
        super().__init__(
            "La factura ya está vinculada a otra partida activa. "
            "Solicita a Finanzas y Operaciones que revisen ese registro. "
            "No marques ‘Factura compartida’ para continuar."
        )

# PostgreSQL: link any pending expense that has a manual fiscal UUID to a CFDI
# row by UUID string.
BULK_LINK_EXPENSES_TO_CFDI_REPORTS_SQL = text(
    """
    UPDATE expense_reports er
    SET cfdi_report_id = c.id
    FROM cfdi_reports c
    WHERE UPPER(TRIM(er.cfdi_uuid_manual)) = UPPER(TRIM(c.cfdi_uuid))
        AND er.cfdi_report_id IS NULL
        AND er.cfdi_uuid_manual IS NOT NULL
        AND TRIM(er.cfdi_uuid_manual) <> ''
    """
)

# PostgreSQL: same logic for documentos. SOLICITUD a terceros capture the CFDI
# UUID up-front.
BULK_LINK_DOCUMENTOS_TO_CFDI_REPORTS_SQL = text(
    """
    UPDATE documentos d
    SET cfdi_report_id = c.id
    FROM cfdi_reports c
    WHERE UPPER(TRIM(d.cfdi_uuid_manual)) = UPPER(TRIM(c.cfdi_uuid))
        AND d.cfdi_report_id IS NULL
        AND d.cfdi_uuid_manual IS NOT NULL
        AND TRIM(d.cfdi_uuid_manual) <> ''
    """
)


def normalize_cfdi_uuid_to_canonical(raw: str) -> str:
    """Return stripped, validated UUID in uppercase (canonical storage)."""
    s = (raw or "").strip()
    if not s:
        raise ValueError("CFDI UUID vacío")
    return str(UUID(s)).upper()


def try_normalize_cfdi_uuid_to_canonical(raw: Optional[str]) -> Optional[str]:
    if raw is None or not str(raw).strip():
        return None
    return normalize_cfdi_uuid_to_canonical(str(raw))


def is_cfdi_uuid_prefix_candidate(raw: Optional[str]) -> bool:
    return bool(_CFDI_UUID_PREFIX_RE.match((raw or "").strip()))


async def find_cfdi_report_by_fiscal_uuid(
    session: AsyncSession, fiscal_uuid: str
) -> Optional[CFDIReport]:
    """Lookup CFDI by fiscal cfdi_uuid; case- and trim-insensitive."""
    canon = normalize_cfdi_uuid_to_canonical(fiscal_uuid)
    # A fiscal-only ingestion may have added its report in this transaction.
    # Evidence guards suppress autoflush so pending caller confirmation flags
    # cannot become "persisted" merely through this lookup.
    for pending in getattr(session, "new", ()):
        if (
            isinstance(pending, CFDIReport)
            and str(pending.cfdi_uuid or "").strip().upper() == canon
        ):
            return pending
    result = await session.execute(
        select(CFDIReport).where(func.upper(func.trim(CFDIReport.cfdi_uuid)) == canon)
    )
    return result.scalar_one_or_none()


async def find_cfdi_report_by_fiscal_uuid_or_prefix(
    session: AsyncSession, fiscal_uuid_or_prefix: str
) -> Optional[CFDIReport]:
    """
    Lookup CFDI by full fiscal UUID or by the first 8 UUID characters.

    Prefix lookup only returns a row when the match is unique.
    """
    raw = (fiscal_uuid_or_prefix or "").strip()
    try:
        return await find_cfdi_report_by_fiscal_uuid(session, raw)
    except ValueError:
        pass

    if not _CFDI_UUID_PREFIX_RE.match(raw):
        raise ValueError("CFDI UUID inválido")

    prefix = raw.upper()
    result = await session.execute(
        select(CFDIReport)
        .where(func.upper(func.trim(CFDIReport.cfdi_uuid)).like(f"{prefix}-%"))
        .limit(2)
    )
    matches = list(result.scalars().all())
    if len(matches) == 1:
        return matches[0]
    return None


async def _enforce_expense_cfdi_uniqueness(
    session: AsyncSession,
    *,
    expense: ExpenseReport,
    report: Optional[CFDIReport],
    allow_shared: bool,
    shared_reason: Optional[str],
    actor_id: Optional[UUID],
) -> None:
    # Serialize competing captures of the same fiscal UUID.  A database unique
    # constraint cannot express the approved shared-invoice exception, so the
    # transaction-scoped PostgreSQL advisory lock protects check-then-link.
    await session.execute(
        text("SELECT pg_advisory_xact_lock(hashtext(:lock_key))"),
        {"lock_key": expense.cfdi_uuid_manual},
    )
    conditions = [
        func.upper(func.trim(ExpenseReport.cfdi_uuid_manual))
        == expense.cfdi_uuid_manual
    ]
    if report is not None:
        conditions.append(ExpenseReport.cfdi_report_id == report.id)
    duplicate_result = await session.execute(
        select(ExpenseReport.id)
        .where(
            ExpenseReport.id != expense.id,
            ExpenseReport.estado_gasto != "cancelado",
            accounting_expense_condition(ExpenseReport),
            or_(*conditions),
        )
        .limit(1)
    )
    duplicate_id = duplicate_result.scalar_one_or_none()
    if not duplicate_id and not allow_shared:
        expense.cfdi_compartido_confirmado = False
        expense.cfdi_compartido_motivo = None
        return
    reason = (shared_reason or "").strip()
    if not allow_shared:
        raise ExpenseCFDIDuplicateError(expense.cfdi_uuid_manual, duplicate_id)
    if not reason:
        raise ValueError("Indique el motivo de la factura compartida.")
    if actor_id is None:
        raise ValueError("No se pudo identificar al usuario que confirmó la factura compartida.")
    expense.cfdi_compartido_confirmado = True
    expense.cfdi_compartido_motivo = reason
    session.add(
        Aprobacion(
            tipo_entidad="gasto",
            entidad_id=expense.id,
            aprobador_id=actor_id,
            accion="confirmar_cfdi_compartido",
            comentario=(
                f"CFDI {expense.cfdi_uuid_manual}: {reason}. "
                + (
                    f"Compartido con partida {duplicate_id}."
                    if duplicate_id
                    else "Primera partida de una factura compartida."
                )
            ),
        )
    )


async def link_expense_to_cfdi_if_manual_uuid_set(
    session: AsyncSession,
    expense: ExpenseReport,
    *,
    clear_report_if_no_match: bool = False,
    require_unique: bool = False,
    allow_shared: bool = False,
    shared_reason: Optional[str] = None,
    actor_id: Optional[UUID] = None,
) -> bool:
    """
    Normalize expense.cfdi_uuid_manual and set cfdi_report_id if a CFDI exists.

    Returns True if a CFDI row was found and linked. If no row matches and
    clear_report_if_no_match is true, sets cfdi_report_id to None.
    """
    raw = expense.cfdi_uuid_manual
    if raw is None or not str(raw).strip():
        if clear_report_if_no_match:
            expense.cfdi_report_id = None
        return False
    canon = None
    try:
        canon = normalize_cfdi_uuid_to_canonical(str(raw))
    except ValueError:
        try:
            with session.no_autoflush:
                report = await find_cfdi_report_by_fiscal_uuid_or_prefix(
                    session, str(raw)
                )
        except ValueError:
            logger.warning(
                "Invalid cfdi_uuid_manual on expense %s; skipping link", expense.id
            )
            return False
    else:
        with session.no_autoflush:
            report = await find_cfdi_report_by_fiscal_uuid(session, canon)
    protected_evidence = False
    if report:
        from .cfdi_ingestion_service import validate_cfdi_evidence_link

        protected_evidence = await validate_cfdi_evidence_link(
            session, report.cfdi_uuid, expense, cfdi_report=report
        )
        if report.id is None:
            await session.flush([report])
        expense.cfdi_uuid_manual = normalize_cfdi_uuid_to_canonical(report.cfdi_uuid)
        expense.cfdi_report_id = report.id
    elif canon is not None:
        expense.cfdi_uuid_manual = canon
    if require_unique and not protected_evidence:
        await _enforce_expense_cfdi_uniqueness(
            session,
            expense=expense,
            report=report,
            allow_shared=allow_shared,
            shared_reason=shared_reason,
            actor_id=actor_id,
        )
    if report:
        return True
    if clear_report_if_no_match:
        expense.cfdi_report_id = None
    return False


async def bulk_link_pending_expenses_to_cfdi_reports(session: AsyncSession) -> int:
    """
    Link all expenses that have manual fiscal UUID and no cfdi_report_id yet.
    Commit is the caller's responsibility.
    """
    return await _bulk_link_pending_with_evidence_guard(session, ExpenseReport)


async def bulk_link_pending_documentos_to_cfdi_reports(session: AsyncSession) -> int:
    """
    Link all documentos (typically SOLICITUD a terceros) that have a manual fiscal UUID
    and no cfdi_report_id yet. Commit is the caller's responsibility.
    """
    return await _bulk_link_pending_with_evidence_guard(session, Documento)


async def _bulk_link_pending_with_evidence_guard(session: AsyncSession, model) -> int:
    # Local imports preserve the canonical owners without an ingestion/link cycle.
    from .cfdi_ingestion_service import find_blocking_cfdi_evidence, lock_cfdi_identity
    from .documento_service import (
        SolicitudValidationError,
        validate_shared_cfdi_payment_amount,
    )

    candidates = (
        (
            await session.execute(
                select(model.id)
                .join(
                    CFDIReport,
                    func.upper(func.trim(model.cfdi_uuid_manual))
                    == func.upper(func.trim(CFDIReport.cfdi_uuid)),
                )
                .where(model.cfdi_report_id.is_(None))
                .order_by(func.upper(func.trim(model.cfdi_uuid_manual)), model.id)
            )
        )
        .scalars()
        .all()
    )
    linked = 0
    # Bulk callers may catch an error and commit; roll back this whole operation
    # on unexpected failure rather than retaining a partially guarded batch.
    async with session.begin_nested():
        for identifier in candidates:
            candidate = (
                await session.execute(
                    select(model)
                    .options(lazyload("*"))
                    .where(model.id == identifier)
                    .with_for_update()
                    .execution_options(populate_existing=True)
                )
            ).scalar_one_or_none()
            if candidate is None or candidate.cfdi_report_id is not None:
                continue
            try:
                fiscal_uuid = normalize_cfdi_uuid_to_canonical(
                    candidate.cfdi_uuid_manual
                )
            except ValueError:
                continue
            related_ids = (
                [candidate.id]
                if model is Documento
                else [
                    value
                    for value in (
                        candidate.documento_id,
                        candidate.solicitud_documento_id,
                        candidate.informe_documento_id,
                    )
                    if value is not None
                ]
            )
            # Document upload locks its document before its UUID. Follow that
            # order for related expenses, then UUID before shared-balance lock.
            if model is ExpenseReport and related_ids:
                await session.execute(
                    select(Documento.id)
                    .where(Documento.id.in_(related_ids))
                    .order_by(Documento.id)
                    .with_for_update()
                )
            await lock_cfdi_identity(session, fiscal_uuid)
            owners = (
                (
                    await session.execute(
                        select(Aprobacion.entidad_id).where(
                            Aprobacion.tipo_entidad == "documento",
                            Aprobacion.accion == "adjuntar_factura",
                            or_(
                                Aprobacion.comentario == fiscal_uuid,
                                Aprobacion.entidad_id.in_(related_ids),
                            ),
                        )
                    )
                )
                .scalars()
                .all()
            )
            # Historical evidence owners remain evidence owners even after
            # their reservation stops consuming the invoice balance.
            if set(related_ids).intersection(owners):
                continue
            report = await find_cfdi_report_by_fiscal_uuid(session, fiscal_uuid)
            if report is None:
                continue
            reservation = await find_blocking_cfdi_evidence(session, fiscal_uuid)
            if reservation:
                if not candidate.cfdi_compartido_confirmado:
                    continue
                try:
                    await validate_shared_cfdi_payment_amount(
                        session,
                        cfdi_report=report,
                        requested_amount=(
                            candidate.monto_solicitado
                            if model is Documento
                            else candidate.gasto_cantidad
                            - (candidate.propina_no_deducible or 0)
                        ),
                        exclude_documento_id=(
                            candidate.id if model is Documento else None
                        ),
                        exclude_expense_id=(
                            candidate.id if model is ExpenseReport else None
                        ),
                    )
                except SolicitudValidationError:
                    continue
            candidate.cfdi_report_id = report.id
            await session.flush()  # Subsequent candidates must see this allocation.
            linked += 1
    return linked


async def link_documento_to_cfdi_if_manual_uuid_set(
    session: AsyncSession,
    documento: Documento,
    *,
    clear_report_if_no_match: bool = False,
) -> bool:
    """Mirror of link_expense_to_cfdi_if_manual_uuid_set for documentos."""
    raw = getattr(documento, "cfdi_uuid_manual", None)
    if raw is None or not str(raw).strip():
        if clear_report_if_no_match:
            documento.cfdi_report_id = None
        return False
    try:
        canon = normalize_cfdi_uuid_to_canonical(str(raw))
    except ValueError:
        logger.warning(
            "Invalid cfdi_uuid_manual on documento %s; skipping link", documento.id
        )
        return False
    with session.no_autoflush:
        report = await find_cfdi_report_by_fiscal_uuid(session, canon)
    if report:
        from .cfdi_ingestion_service import validate_cfdi_evidence_link

        await validate_cfdi_evidence_link(session, canon, documento, cfdi_report=report)
        if report.id is None:
            await session.flush([report])
        documento.cfdi_uuid_manual = canon
        documento.cfdi_report_id = report.id
        return True
    documento.cfdi_uuid_manual = canon
    if clear_report_if_no_match:
        documento.cfdi_report_id = None
    return False
