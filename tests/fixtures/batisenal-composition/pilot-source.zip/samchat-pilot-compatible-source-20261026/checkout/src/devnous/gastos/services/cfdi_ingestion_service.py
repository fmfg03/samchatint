"""Canonical CFDI XML ingestion and entity linking."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from types import SimpleNamespace
from typing import Any, Dict, List, Optional, Union
from uuid import uuid4

from sqlalchemy import and_, or_, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from .amex_accounting_identity_service import accounting_expense_condition

from ..models import Aprobacion, CFDIReport, Documento, Empleado, ExpenseReport
from .cfdi_expense_link_service import (
    find_cfdi_report_by_fiscal_uuid,
    normalize_cfdi_uuid_to_canonical,
)
from .cfdi_parser import parse_cfdi_xml
from .cfdi_upload_resolver import merge_cfdi_upload_bytes, resolve_cfdi_upload

CFDIEntity = Union[ExpenseReport, Documento]

SAT_ORIGEN = "sat"

_CFDI_DATA_FIELDS = (
    "version",
    "serie",
    "folio",
    "fecha",
    "sello",
    "forma_pago",
    "no_certificado",
    "certificado",
    "subtotal",
    "descuento",
    "moneda",
    "tipo_cambio",
    "total",
    "tipo_de_comprobante",
    "metodo_pago",
    "lugar_expedicion",
    "exportacion",
    "emisor_rfc",
    "emisor_nombre",
    "emisor_regimen_fiscal",
    "receptor_rfc",
    "receptor_nombre",
    "receptor_uso_cfdi",
    "receptor_domicilio_fiscal",
    "receptor_regimen_fiscal",
    "timbre_version",
    "fecha_timbrado",
    "rfc_prov_certif",
    "sello_cfd",
    "no_certificado_sat",
    "sello_sat",
    "total_impuestos_trasladados",
    "conceptos",
    "descripcion_concepto_principal",
    "impuestos_detalle",
)

# Differences in these fields mean two XMLs claiming the same UUID represent
# materially different fiscal documents. Formatting-only XML differences do not.
_MATERIAL_IDENTITY_FIELDS = (
    "fecha",
    "subtotal",
    "total",
    "moneda",
    "tipo_de_comprobante",
    "emisor_rfc",
    "receptor_rfc",
    "sello",
    "no_certificado",
    "sello_cfd",
    "no_certificado_sat",
)


def _is_sat_source_of_truth(report: CFDIReport) -> bool:
    return (getattr(report, "origen", None) or "").strip().lower() == SAT_ORIGEN


def _report_has_canonical_xml(report: CFDIReport) -> bool:
    return bool((getattr(report, "xml_raw", None) or "").strip())


def _entity_linked_to_report(
    entity: Optional[CFDIEntity],
    report: CFDIReport,
) -> bool:
    return bool(
        entity is not None
        and getattr(entity, "cfdi_report_id", None) == report.id
    )


@dataclass(frozen=True)
class _ExistingIngestPlan:
    conflicts: List[str]
    apply_fiscal_data: bool
    overwrite: bool
    pdf_attach_only: bool


def _plan_existing_cfdi_ingest(
    report: CFDIReport,
    parsed: Dict[str, Any],
    *,
    xml_raw: Optional[str],
    entity: Optional[CFDIEntity],
    source: str,
) -> _ExistingIngestPlan:
    """Decide whether incoming upload may enrich, replace, or only re-link."""
    if _is_sat_source_of_truth(report) and source != SAT_ORIGEN:
        return _ExistingIngestPlan(
            conflicts=[],
            apply_fiscal_data=False,
            overwrite=False,
            pdf_attach_only=True,
        )

    incoming_xml = bool(xml_raw and str(xml_raw).strip())
    existing_xml = _report_has_canonical_xml(report)

    # Canonical XML already stored: PDF uploads are attachments only.
    if not incoming_xml and existing_xml:
        return _ExistingIngestPlan(
            conflicts=[],
            apply_fiscal_data=False,
            overwrite=False,
            pdf_attach_only=True,
        )

    conflicts = _material_conflicts(report, parsed)

    if incoming_xml:
        if existing_xml and conflicts:
            return _ExistingIngestPlan(
                conflicts=conflicts,
                apply_fiscal_data=False,
                overwrite=False,
                pdf_attach_only=False,
            )
        return _ExistingIngestPlan(
            conflicts=[],
            apply_fiscal_data=True,
            overwrite=not existing_xml,
            pdf_attach_only=False,
        )

    same_entity = _entity_linked_to_report(entity, report)
    if same_entity:
        return _ExistingIngestPlan(
            conflicts=[],
            apply_fiscal_data=False,
            overwrite=False,
            pdf_attach_only=True,
        )

    return _ExistingIngestPlan(
        conflicts=conflicts,
        apply_fiscal_data=True,
        overwrite=False,
        pdf_attach_only=False,
    )


class CFDIIngestionError(ValueError):
    """Base error for invalid CFDI ingestion."""


class CFDIConflictError(CFDIIngestionError):
    """Raised when an existing UUID has materially different XML data."""

    def __init__(self, cfdi_uuid: str, conflicting_fields: List[str]):
        self.cfdi_uuid = cfdi_uuid
        self.conflicting_fields = conflicting_fields
        super().__init__(
            "El CFDI ya existe con datos fiscales diferentes: "
            + ", ".join(conflicting_fields)
        )


class CFDIDuplicateLinkError(CFDIIngestionError):
    """Raised when a CFDI is already linked and sharing was not confirmed."""

    def __init__(self, cfdi_uuid: str):
        self.cfdi_uuid = cfdi_uuid
        super().__init__(
            "La factura ya está vinculada a otro gasto o solicitud. "
            "Confirme explícitamente que es una factura compartida para continuar."
        )


@dataclass(frozen=True)
class CFDIUsageConflict:
    """Authorized, display-safe identity of the record that reserved a CFDI."""

    referencia: str
    empleado_id: Any
    responsable: str
    creado_en: datetime
    estado: str

    def message(self) -> str:
        return (
            f"La factura está reservada en la solicitud {self.referencia}, creada por "
            f"{self.responsable} el {self.creado_en:%d-%m-%Y %H:%M}, "
            f"estado {self.estado}."
        )


@dataclass
class CFDIIngestionResult:
    status: str
    cfdi_report: CFDIReport
    cfdi_uuid: str
    linked: bool
    warnings: List[str] = field(default_factory=list)


def _normalized_material_value(value: Any) -> Any:
    if isinstance(value, str):
        return value.strip().upper()
    if isinstance(value, float):
        return round(value, 6)
    return value


def _material_conflicts(existing: CFDIReport, parsed: Dict[str, Any]) -> List[str]:
    conflicts: List[str] = []
    for name in _MATERIAL_IDENTITY_FIELDS:
        stored = getattr(existing, name, None)
        incoming = parsed.get(name)
        if stored in (None, "") or incoming in (None, ""):
            continue
        if _normalized_material_value(stored) != _normalized_material_value(incoming):
            conflicts.append(name)
    return conflicts


def validate_cfdi_material_identity(
    existing: Any, parsed: Dict[str, Any], *, xml_evidence: bool = True
) -> None:
    """Reject contradictory fiscal evidence using the canonical identity fields."""
    # A text PDF cannot establish signatures or the XML issue timestamp.
    compared = (
        parsed
        if xml_evidence
        else {
            key: parsed.get(key)
            for key in ("subtotal", "total", "moneda", "emisor_rfc", "receptor_rfc")
            if key in parsed.get("_pdf_explicit_fields", parsed)
            and key in getattr(existing, "_pdf_explicit_fields", parsed)
        }
    )
    conflicts = _material_conflicts(existing, compared)
    if conflicts:
        raise CFDIConflictError(parsed["cfdi_uuid"], conflicts)


def _apply_parsed_data(
    report: CFDIReport, parsed: Dict[str, Any], *, overwrite: bool
) -> bool:
    changed = False
    for name in _CFDI_DATA_FIELDS:
        incoming = parsed.get(name)
        current = getattr(report, name, None)
        if incoming in (None, ""):
            continue
        if overwrite or current in (None, "", [], {}):
            if current != incoming:
                setattr(report, name, incoming)
                changed = True
    return changed


async def _other_expense_links(
    session: AsyncSession, report_id: Any, entity: Optional[CFDIEntity]
) -> int:
    conditions = [
        ExpenseReport.cfdi_report_id == report_id,
        accounting_expense_condition(ExpenseReport),
    ]
    if isinstance(entity, ExpenseReport) and getattr(entity, "id", None):
        conditions.append(ExpenseReport.id != entity.id)
    result = await session.execute(
        select(ExpenseReport.id).where(and_(*conditions)).limit(1)
    )
    return 1 if result.scalar_one_or_none() is not None else 0


_CFDI_RESERVING_DOCUMENT_STATES = {
    "control_presupuestal", "enviado", "aprobado", "en_proceso_pago",
    "pagado", "cerrado", "reembolsado", "aplicado", "liquidado",
}


async def lock_cfdi_identity(session: AsyncSession, fiscal_uuid: str) -> None:
    """Serialize evidence and canonical intake by fiscal identity on PostgreSQL."""
    if session.get_bind().dialect.name == "postgresql":
        await session.execute(
            text("SELECT pg_advisory_xact_lock(hashtext(:key))"),
            {"key": f"cfdi-evidence:{fiscal_uuid}"},
        )


async def find_blocking_cfdi_evidence(
    session: AsyncSession,
    fiscal_uuid: str,
    *,
    exclude_documento_id: Optional[Any] = None,
    exclude_documento_ids: Optional[List[Any]] = None,
) -> Optional[CFDIUsageConflict]:
    """Late evidence reserves its UUID without changing accounting or fiscal links."""
    fiscal_uuid = normalize_cfdi_uuid_to_canonical(fiscal_uuid)
    conditions = [
        Aprobacion.tipo_entidad == "documento",
        Aprobacion.accion == "adjuntar_factura",
        Aprobacion.comentario == fiscal_uuid,
        Documento.estado.in_(_CFDI_RESERVING_DOCUMENT_STATES),
    ]
    if exclude_documento_id is not None:
        conditions.append(Documento.id != exclude_documento_id)
    if exclude_documento_ids:
        conditions.append(Documento.id.not_in(exclude_documento_ids))
    result = await session.execute(
        select(
            Documento.numero_referencia,
            Documento.empleado_id,
            Empleado.nombre,
            Documento.creado_en,
            Documento.estado,
        )
        .join(Aprobacion, Aprobacion.entidad_id == Documento.id)
        .join(Empleado, Empleado.id == Documento.empleado_id)
        .where(*conditions)
        .limit(1)
    )
    row = result.first()
    return CFDIUsageConflict(*row) if row is not None else None


async def validate_cfdi_evidence_link(
    session: AsyncSession,
    fiscal_uuid: str,
    entity: CFDIEntity,
    *,
    cfdi_report: Optional[CFDIReport] = None,
    incoming_total: Any = None,
) -> bool:
    """Guard accounting links to a UUID reserved only as late evidence.

    Returns whether an active evidence reservation required shared allocation.
    Caller flags cannot substitute for a confirmation already stored in the DB.
    """
    from .documento_service import validate_shared_cfdi_payment_amount

    fiscal_uuid = normalize_cfdi_uuid_to_canonical(fiscal_uuid)
    is_document = isinstance(entity, Documento)
    model = Documento if is_document else ExpenseReport
    related_ids = (
        [entity.id]
        if is_document
        else [
            value
            for value in (
                getattr(entity, "documento_id", None),
                getattr(entity, "solicitud_documento_id", None),
                getattr(entity, "informe_documento_id", None),
            )
            if value is not None
        ]
    )
    with session.no_autoflush:
        stored_columns = [model.cfdi_report_id, model.cfdi_compartido_confirmado]
        if not is_document:
            stored_columns.extend(
                [
                    model.documento_id,
                    model.solicitud_documento_id,
                    model.informe_documento_id,
                ]
            )
        stored = (
            await session.execute(
                select(*stored_columns).where(model.id == entity.id).with_for_update()
            )
        ).first()
        if stored is not None and not is_document:
            related_ids = list(
                set(related_ids + [value for value in stored[2:] if value])
            )
        if related_ids:
            await session.execute(
                select(Documento.id)
                .where(Documento.id.in_(related_ids))
                .order_by(Documento.id)
                .with_for_update()
            )
        await lock_cfdi_identity(session, fiscal_uuid)
        owners = (
            (
                await session.execute(
                    select(Aprobacion.entidad_id).where(
                        Aprobacion.tipo_entidad == "documento",
                        Aprobacion.accion == "adjuntar_factura",
                        or_(
                            Aprobacion.comentario == fiscal_uuid,
                            Aprobacion.entidad_id.in_(related_ids),
                        ),
                    )
                )
            )
            .scalars()
            .all()
        )
        report = cfdi_report or await find_cfdi_report_by_fiscal_uuid(
            session, fiscal_uuid
        )
        if (
            stored is not None
            and stored[0] is not None
            and report is not None
            and report.id is not None
            and stored[0] == report.id
        ):
            # Enriching an already recognized link does not promote late
            # evidence. Preserve that persisted link and its existing approval.
            return bool(owners)
        if set(related_ids).intersection(owners):
            raise CFDIDuplicateLinkError(fiscal_uuid)
        if not await find_blocking_cfdi_evidence(session, fiscal_uuid):
            return False
        if (
            stored is None
            or stored[1] is not True
            or not getattr(entity, "cfdi_compartido_confirmado", False)
        ):
            raise CFDIDuplicateLinkError(fiscal_uuid)
        if report is None:
            # Validate before constructing/adding a new canonical report, so a
            # caught rejection cannot leave a partial report for caller commit.
            report = SimpleNamespace(
                cfdi_uuid=fiscal_uuid, total=incoming_total, id=None
            )
        await validate_shared_cfdi_payment_amount(
            session,
            cfdi_report=report,
            requested_amount=(
                entity.monto_solicitado
                if is_document
                else entity.gasto_cantidad - (entity.propina_no_deducible or 0)
            ),
            exclude_documento_id=entity.id if is_document else None,
            exclude_expense_id=entity.id if not is_document else None,
        )
        return True


async def find_blocking_cfdi_usage(
    session: AsyncSession,
    report_id: Any,
    *,
    exclude_documento_id: Optional[Any] = None,
) -> Optional[CFDIUsageConflict]:
    """Return the record that reserved a CFDI once it reaches budget control."""
    documento_conditions = [
        Documento.cfdi_report_id == report_id,
        Documento.estado.in_(_CFDI_RESERVING_DOCUMENT_STATES),
        Documento.cfdi_compartido_confirmado.is_(False),
    ]
    if exclude_documento_id is not None:
        documento_conditions.append(Documento.id != exclude_documento_id)
    documento_result = await session.execute(
        select(Documento.numero_referencia, Documento.empleado_id, Empleado.nombre, Documento.creado_en, Documento.estado)
        .join(Empleado, Empleado.id == Documento.empleado_id)
        .where(and_(*documento_conditions)).limit(1)
    )
    row = documento_result.first()
    if row is not None:
        return CFDIUsageConflict(*row)

    expense_result = await session.execute(
        select(Documento.numero_referencia, Documento.empleado_id, Empleado.nombre, Documento.creado_en, Documento.estado)
        .join(ExpenseReport, or_(
            ExpenseReport.informe_documento_id == Documento.id,
            ExpenseReport.documento_id == Documento.id,
        ))
        .join(Empleado, Empleado.id == Documento.empleado_id)
        .where(
            ExpenseReport.cfdi_report_id == report_id,
            ExpenseReport.cfdi_compartido_confirmado.is_(False),
            accounting_expense_condition(ExpenseReport),
            Documento.estado.in_(_CFDI_RESERVING_DOCUMENT_STATES),
            *([Documento.id != exclude_documento_id] if exclude_documento_id is not None else []),
        ).limit(1)
    )
    row = expense_result.first()
    if row is not None:
        return CFDIUsageConflict(*row)
    report = await session.get(CFDIReport, report_id)
    if report is None:
        return None
    return await find_blocking_cfdi_evidence(
        session, report.cfdi_uuid, exclude_documento_id=exclude_documento_id
    )


async def has_existing_cfdi_usage(
    session: AsyncSession, report_id: Any, entity: Optional[CFDIEntity] = None,
) -> bool:
    exclude_id = getattr(entity, "id", None) if isinstance(entity, Documento) else None
    return await find_blocking_cfdi_usage(
        session, report_id, exclude_documento_id=exclude_id
    ) is not None


async def _ingest_cfdi_parsed(
    session: AsyncSession,
    parsed: Dict[str, Any],
    *,
    source: str,
    entity: Optional[CFDIEntity] = None,
    nova_request_id: Optional[str] = None,
    numero_referencia: Optional[str] = None,
    allow_shared: bool = False,
    require_shared_confirmation: bool = False,
    xml_raw: Optional[str] = None,
) -> CFDIIngestionResult:
    if not parsed or not parsed.get("cfdi_uuid"):
        raise CFDIIngestionError(
            "El CFDI no es válido o no contiene UUID"
        )

    try:
        canonical_uuid = normalize_cfdi_uuid_to_canonical(parsed["cfdi_uuid"])
    except ValueError as exc:
        raise CFDIIngestionError("El CFDI contiene un UUID inválido") from exc
    parsed["cfdi_uuid"] = canonical_uuid

    if entity is None:
        await lock_cfdi_identity(session, canonical_uuid)
    else:
        await validate_cfdi_evidence_link(
            session, canonical_uuid, entity, incoming_total=parsed.get("total")
        )

    report = await find_cfdi_report_by_fiscal_uuid(session, canonical_uuid)
    warnings: List[str] = []
    status = "reused"

    if report is None:
        report = CFDIReport(
            id=uuid4(),
            cfdi_uuid=canonical_uuid,
            nova_request_id=nova_request_id,
            numero_referencia=numero_referencia,
            origen=source,
            xml_parsed=True,
            parsed_at=datetime.utcnow(),
            xml_raw=xml_raw,
        )
        _apply_parsed_data(report, parsed, overwrite=True)
        session.add(report)
        status = "created"
    else:
        plan = _plan_existing_cfdi_ingest(
            report,
            parsed,
            xml_raw=xml_raw,
            entity=entity,
            source=source,
        )
        if plan.conflicts:
            raise CFDIConflictError(canonical_uuid, plan.conflicts)

        incoming_xml = bool(xml_raw and str(xml_raw).strip())
        had_canonical_xml = _report_has_canonical_xml(report)

        if _is_sat_source_of_truth(report) and source != SAT_ORIGEN:
            warnings.append(
                "CFDI protegido por ingest SAT; los datos fiscales no se modificaron."
            )
        elif plan.pdf_attach_only and not incoming_xml and had_canonical_xml:
            warnings.append(
                "CFDI XML existente conservado; el PDF se adjuntó sin modificar datos fiscales."
            )
        elif incoming_xml and not had_canonical_xml and source != SAT_ORIGEN:
            warnings.append(
                "CFDI XML reemplazó datos provisionales extraídos del PDF."
            )

        skip_fiscal_mutation = (
            (_is_sat_source_of_truth(report) and source != SAT_ORIGEN)
            or plan.pdf_attach_only
        )
        if not skip_fiscal_mutation:
            changed = False
            if plan.apply_fiscal_data:
                changed = _apply_parsed_data(
                    report, parsed, overwrite=plan.overwrite
                )
            if xml_raw and (plan.overwrite or not report.xml_raw):
                report.xml_raw = xml_raw
                changed = True
            if not report.xml_parsed:
                report.xml_parsed = True
                changed = True
            if not report.parsed_at:
                report.parsed_at = datetime.utcnow()
                changed = True
            if not report.nova_request_id and nova_request_id:
                report.nova_request_id = nova_request_id
                changed = True
            if not report.numero_referencia and numero_referencia:
                report.numero_referencia = numero_referencia
                changed = True
            if source == SAT_ORIGEN and report.origen != SAT_ORIGEN:
                report.origen = SAT_ORIGEN
                changed = True
            if changed:
                status = "enriched"

    linked = False
    if entity is not None:
        already_linked = getattr(entity, "cfdi_report_id", None) == report.id
        if already_linked:
            status = "already_linked"
        else:
            has_existing_usage = await has_existing_cfdi_usage(
                session, report.id, entity
            )
            if has_existing_usage and require_shared_confirmation and not allow_shared:
                raise CFDIDuplicateLinkError(canonical_uuid)
            if has_existing_usage and not allow_shared:
                warnings.append(
                    "El CFDI ya está vinculado a otro gasto o solicitud; "
                    "se creó un vínculo compartido."
                )
            entity.cfdi_uuid_manual = canonical_uuid
            entity.cfdi_report_id = report.id
            linked = True
            if status == "reused":
                status = "linked"

    return CFDIIngestionResult(
        status=status,
        cfdi_report=report,
        cfdi_uuid=canonical_uuid,
        linked=linked,
        warnings=warnings,
    )


async def ingest_cfdi_from_upload(
    session: AsyncSession,
    *,
    xml_bytes: Optional[bytes] = None,
    pdf_bytes: Optional[bytes] = None,
    source: str,
    entity: Optional[CFDIEntity] = None,
    nova_request_id: Optional[str] = None,
    numero_referencia: Optional[str] = None,
    allow_shared: bool = False,
    require_shared_confirmation: bool = False,
) -> Optional[CFDIIngestionResult]:
    """
    Parse uploaded CFDI bytes and upsert/link a canonical report.

    Non-empty XML takes precedence over PDF. Returns None when neither file
    contains ingestible CFDI data.
    """
    resolved, error = resolve_cfdi_upload(
        xml_bytes=xml_bytes,
        pdf_bytes=pdf_bytes,
    )
    if error:
        raise CFDIIngestionError(error)
    if resolved is None:
        return None

    if resolved.xml_text:
        return await _ingest_cfdi_parsed(
            session,
            resolved.parsed,
            source=source,
            entity=entity,
            nova_request_id=nova_request_id,
            numero_referencia=numero_referencia,
            allow_shared=allow_shared,
            require_shared_confirmation=require_shared_confirmation,
            xml_raw=resolved.xml_text,
        )

    return await _ingest_cfdi_parsed(
        session,
        resolved.parsed,
        source=source,
        entity=entity,
        nova_request_id=nova_request_id,
        numero_referencia=numero_referencia,
        allow_shared=allow_shared,
        require_shared_confirmation=require_shared_confirmation,
        xml_raw=None,
    )


async def ingest_cfdi_parsed(
    session: AsyncSession,
    parsed: Dict[str, Any],
    *,
    source: str,
    entity: Optional[CFDIEntity] = None,
    nova_request_id: Optional[str] = None,
    numero_referencia: Optional[str] = None,
    allow_shared: bool = False,
    require_shared_confirmation: bool = False,
    xml_raw: Optional[str] = None,
) -> CFDIIngestionResult:
    """Upsert and optionally link one canonical CFDI from parser output."""
    return await _ingest_cfdi_parsed(
        session,
        parsed,
        source=source,
        entity=entity,
        nova_request_id=nova_request_id,
        numero_referencia=numero_referencia,
        allow_shared=allow_shared,
        require_shared_confirmation=require_shared_confirmation,
        xml_raw=xml_raw,
    )


async def ingest_cfdi_xml(
    session: AsyncSession,
    xml_content: str,
    *,
    source: str,
    entity: Optional[CFDIEntity] = None,
    nova_request_id: Optional[str] = None,
    numero_referencia: Optional[str] = None,
    allow_shared: bool = False,
    require_shared_confirmation: bool = False,
) -> CFDIIngestionResult:
    """
    Parse, upsert, and optionally link one canonical CFDI by fiscal UUID.

    This function never commits or rolls back. The caller owns the transaction.
    """
    parsed = parse_cfdi_xml(xml_content)
    if not parsed or not parsed.get("cfdi_uuid"):
        raise CFDIIngestionError(
            "El archivo XML no es un CFDI válido o no contiene UUID"
        )

    return await _ingest_cfdi_parsed(
        session,
        parsed,
        source=source,
        entity=entity,
        nova_request_id=nova_request_id,
        numero_referencia=numero_referencia,
        allow_shared=allow_shared,
        require_shared_confirmation=require_shared_confirmation,
        xml_raw=xml_content,
    )
