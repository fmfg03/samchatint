"""
Routes for expense management system.
"""

from .webhook_handler import router as webhook_router
from .admin_routes import router as admin_router
from .user_routes import router as user_router
from .auth_routes import router as auth_router
from .support_routes import router as support_router
from .operations_analytics_routes import router as operations_analytics_router
from .client_executive_routes import router as client_executive_router
from .client_reporting_routes import router as client_reporting_router

__all__ = [
    'webhook_router',
    'admin_router',
    'user_router',
    'auth_router',
    'support_router',
    'operations_analytics_router',
    'client_executive_router',
    'client_reporting_router',
]
