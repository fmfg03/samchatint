from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Optional
from uuid import UUID

from sqlalchemy import and_, func, or_, select, text
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload, undefer

from ..models import (
    Aprobacion,
    Anticipo,
    CFDIReport,
    CuentaDeGastos,
    Documento,
    Empleado,
    ExpenseReport,
    Reembolso,
)
from ..utils.mexico_city_dates import utc_now
from .cuenta_settlement_service import (
    PREAPPROVAL_INFORME_STATES,
    CuentaSettlementValidationError,
    validate_cuenta_surplus_is_returned,
)
from .payment_schedule_service import assign_fecha_pago_on_solicitud_approval
from .amex_accounting_posting_service import ensure_amex_report_approval_posting
from .employee_debtor_accounting_service import (
    ensure_debtor_comprobacion_posting_for_informe,
    ensure_provider_approval_posting,
)
from .customer_success_audit import (
    AuditRequestContext,
    record_customer_success_audit_event,
)
from .documento_semantics import (
    EMPLOYEE_REIMBURSEMENT_CONCEPT_PREFIX,
    approval_subject_empleado,
)
from .documento_service import (
    validate_shared_cfdi_payment_amount,
)
from .cfdi_ingestion_service import find_blocking_cfdi_usage
from .project_authorization_service import (
    actor_is_route_approver,
    invalidate_document_route,
    prepare_document_authorization_route,
    has_operations_reference,
)

logger = logging.getLogger(__name__)

APPROVER_ROLES = {"finanzas", "admin", "superadmin", "super_admin"}
FINANCE_ADMIN_ROLES = {"finanzas", "admin"}
BUDGET_CONTROL_STATE = "control_presupuestal"


async def reserve_documento_cfdis_or_raise(
    session: AsyncSession, documento: Documento, actor: Empleado
) -> None:
    """Atomically reserve this document's CFDIs when it enters budget control."""
    report_ids = set()
    if (
        getattr(documento, "cfdi_report_id", None)
        and documento.cfdi_compartido_confirmado
    ):
        cfdi_report = await session.get(CFDIReport, documento.cfdi_report_id)
        if cfdi_report is None:
            raise DocumentoWorkflowValidationError(
                "invalid_cfdi_amount",
                "No se encontró la factura compartida vinculada a la solicitud.",
            )
        await validate_shared_cfdi_payment_amount(
            session,
            cfdi_report=cfdi_report,
            requested_amount=documento.monto_solicitado,
            exclude_documento_id=documento.id,
        )
    if (
        getattr(documento, "cfdi_report_id", None)
        and not documento.cfdi_compartido_confirmado
    ):
        report_ids.add(documento.cfdi_report_id)
    if documento.tipo == "INFORME":
        expense_report_ids = await session.execute(
            select(
                ExpenseReport.cfdi_report_id,
                ExpenseReport.cfdi_compartido_confirmado,
            ).where(
                or_(
                    ExpenseReport.informe_documento_id == documento.id,
                    ExpenseReport.documento_id == documento.id,
                ),
                ExpenseReport.cfdi_report_id.isnot(None),
                ExpenseReport.estado_gasto != "cancelado",
            )
        )
        report_ids.update(
            report_id
            for report_id, cfdi_compartido_confirmado in expense_report_ids.all()
            if not cfdi_compartido_confirmado
        )
    for report_id in sorted(report_ids, key=str):
        await session.execute(
            text("SELECT pg_advisory_xact_lock(hashtext(:lock_key))"),
            {"lock_key": f"cfdi-reservation:{report_id}"},
        )
        conflict = await find_blocking_cfdi_usage(
            session, report_id, exclude_documento_id=documento.id
        )
        if conflict is not None:
            message = (
                "No se puede continuar porque el UUID CFDI ya está reservado en otro "
                "gasto o solicitud; este control evita duplicar comprobantes. Si el "
                "vínculo es un duplicado, un superadmin puede revisarlo y liberarlo "
                "desde la consola de comprobantes."
            )
            if conflict.empleado_id == actor.id or actor.rol in APPROVER_ROLES:
                message = conflict.message()
            raise DocumentoWorkflowValidationError("duplicate_cfdi", message)


def documento_requires_budget_control(documento: Documento) -> bool:
    """Return True when a document must pass through budget classification first.

    Standalone supplier/third-party payment requests and expense reports need
    budget classification before approval. Personal requests generated from an
    expense report (advance/reimbursement/AMEX settlement) inherit budget from
    the report lines, so they must not pass through Control Presupuestal again.
    """
    if getattr(documento, "is_supplier_advance", False):
        return False
    if getattr(documento, "budget_concept_id", None):
        return False
    if documento.tipo == "INFORME":
        return True
    if documento.tipo == "SOLICITUD":
        return getattr(documento, "cuenta_gastos_id", None) is None
    return False


class DocumentoWorkflowError(Exception):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


class DocumentoWorkflowPermissionError(DocumentoWorkflowError):
    pass


class DocumentoWorkflowValidationError(DocumentoWorkflowError):
    pass


@dataclass(slots=True)
class DocumentoWorkflowResult:
    documento: Documento
    aprobacion: Aprobacion


async def _load_documento(
    session: AsyncSession, documento_id: UUID
) -> Optional[Documento]:
    result = await session.execute(
        select(Documento)
        .options(
            selectinload(Documento.empleado),
            selectinload(Documento.beneficiario_empleado),
            undefer(Documento.fase),
        )
        .where(Documento.id == documento_id)
        .with_for_update()
    )
    return result.scalar_one_or_none()


async def _load_actor(session: AsyncSession, actor_id: UUID) -> Optional[Empleado]:
    return await session.get(Empleado, actor_id)


async def _informe_documento_for_cuenta(
    session: AsyncSession, cuenta_gastos_id: UUID
) -> Optional[Documento]:
    result = await session.execute(
        select(Documento)
        .where(
            Documento.cuenta_gastos_id == cuenta_gastos_id,
            Documento.tipo == "INFORME",
        )
        .order_by(Documento.creado_en.asc())
        .limit(1)
    )
    return result.scalar_one_or_none()


async def _solicitud_linked_informe_is_approved(
    session: AsyncSession, documento: Documento
) -> bool:
    if documento.tipo != "SOLICITUD" or documento.cuenta_gastos_id is None:
        return False
    informe = await _informe_documento_for_cuenta(session, documento.cuenta_gastos_id)
    return informe is not None and informe.estado == "aprobado"


def is_employee_reimbursement_solicitud(documento: Documento) -> bool:
    concept = str(getattr(documento, "concepto_pago", None) or "")
    return (
        documento.tipo == "SOLICITUD"
        and documento.cuenta_gastos_id is not None
        and concept.startswith(EMPLOYEE_REIMBURSEMENT_CONCEPT_PREFIX)
    )


async def _sync_reimbursement_budget_or_raise(
    session: AsyncSession, documento: Documento
) -> None:
    """Prevent reimbursement approval routing before informe budget assignment."""
    if (
        not is_employee_reimbursement_solicitud(documento)
        or getattr(documento, "budget_concept_id", None)
    ):
        return

    informe = await _informe_documento_for_cuenta(session, documento.cuenta_gastos_id)
    if informe is None or not getattr(informe, "budget_concept_id", None):
        raise DocumentoWorkflowValidationError(
            "budget_concept_required",
            "La solicitud de reembolso no puede enviarse a aprobación hasta que "
            "Control Presupuestal asigne partida al informe vinculado.",
        )
    documento.budget_concept_id = informe.budget_concept_id


async def _sync_reimbursement_budget_from_informe(
    session: AsyncSession, documento: Documento
) -> Optional[Documento]:
    if not is_employee_reimbursement_solicitud(documento):
        return None
    informe = await _informe_documento_for_cuenta(session, documento.cuenta_gastos_id)
    if informe is not None and getattr(informe, "budget_concept_id", None):
        documento.budget_concept_id = informe.budget_concept_id
    return informe


async def _linked_informe_approval_actor_id(
    session: AsyncSession, documento: Documento
) -> Optional[UUID]:
    if documento.tipo != "SOLICITUD" or documento.cuenta_gastos_id is None:
        return None
    informe = await _informe_documento_for_cuenta(session, documento.cuenta_gastos_id)
    if informe is None or informe.estado != "aprobado":
        return None

    result = await session.execute(
        select(Aprobacion.aprobador_id)
        .where(
            Aprobacion.tipo_entidad == "documento",
            Aprobacion.entidad_id == informe.id,
            Aprobacion.accion == "aprobar",
        )
        .order_by(Aprobacion.fecha.desc())
        .limit(1)
    )
    approved_actor_id = result.scalar_one_or_none()
    if approved_actor_id is not None:
        return approved_actor_id

    # A regularization is deliberately distinct from an historical approval:
    # it records a current superadmin attestation when the original audit row
    # is missing, without fabricating the original approver or timestamp.
    regularization_result = await session.execute(
        select(Aprobacion.aprobador_id)
        .where(
            Aprobacion.tipo_entidad == "documento",
            Aprobacion.entidad_id == informe.id,
            Aprobacion.accion == "regularizar_aprobacion_reembolso",
        )
        .order_by(Aprobacion.fecha.desc())
        .limit(1)
    )
    return regularization_result.scalar_one_or_none()


async def approve_reimbursement_solicitud_for_approved_informe(
    session: AsyncSession,
    documento: Documento,
    *,
    now: Optional[datetime] = None,
    comentario: Optional[str] = None,
) -> Optional[Aprobacion]:
    """Approve a reimbursement solicitud using the linked informe approval."""
    informe = await _sync_reimbursement_budget_from_informe(session, documento)
    if (
        informe is None
        or informe.estado != "aprobado"
        or not getattr(informe, "budget_concept_id", None)
    ):
        return None
    aprobador_id = await _linked_informe_approval_actor_id(session, documento)
    if aprobador_id is None:
        return None
    await prepare_document_authorization_route(session, documento)
    if has_operations_reference(documento) and not await actor_is_route_approver(
        session, actor_id=aprobador_id, documento_id=documento.id
    ):
        return None
    aprobacion = _auto_approve_solicitud_with_approved_informe(
        documento=documento,
        aprobador_id=aprobador_id,
        now=now or utc_now(),
        comentario=comentario,
    )
    session.add(aprobacion)
    return aprobacion


async def _document_has_recorded_approval(
    session: AsyncSession, documento_id: UUID
) -> bool:
    result = await session.execute(
        select(Aprobacion.id)
        .where(
            Aprobacion.tipo_entidad == "documento",
            Aprobacion.entidad_id == documento_id,
            Aprobacion.accion == "aprobar",
        )
        .limit(1)
    )
    return result.scalar_one_or_none() is not None


def _raise_if_document_already_advanced(has_recorded_approval: bool) -> None:
    if has_recorded_approval:
        raise DocumentoWorkflowValidationError(
            "documento_already_advanced",
            "El documento ya tiene una aprobacion registrada; no puede aprobarse "
            "ni rechazarse desde la bandeja del aprobador anterior. Debe continuar "
            "o corregirse desde el siguiente flujo operativo.",
        )


def _auto_approve_solicitud_with_approved_informe(
    *,
    documento: Documento,
    aprobador_id: UUID,
    now: datetime,
    comentario: Optional[str] = None,
) -> Aprobacion:
    documento.estado = "aprobado"
    documento.aprobado_en = now
    assign_fecha_pago_on_solicitud_approval(documento)
    return Aprobacion(
        tipo_entidad="documento",
        entidad_id=documento.id,
        aprobador_id=aprobador_id,
        accion="aprobar",
        comentario=(
            comentario
            or "Auto-aprobada: el informe de gastos vinculado ya estaba aprobado."
        ),
        fecha=now,
    )


async def promote_solicitudes_ready_for_payment(
    session: AsyncSession,
    *,
    actor_id: Optional[UUID | str] = None,
) -> int:
    """Promote reimbursement solicitudes when their linked informe is approved."""
    result = await session.execute(
        select(Documento).where(
            Documento.tipo == "SOLICITUD",
            Documento.estado.in_(["borrador", "control_presupuestal", "enviado"]),
            Documento.cuenta_gastos_id.isnot(None),
            Documento.concepto_pago.like(
                f"{EMPLOYEE_REIMBURSEMENT_CONCEPT_PREFIX}%"
            ),
        )
    )
    solicitudes = result.scalars().all()
    if not solicitudes:
        return 0

    del actor_id  # retained for API compatibility; approvals inherit informe actor

    now = utc_now()
    promoted = 0
    promoted_ids: list[UUID] = []
    for documento in solicitudes:
        aprobacion = await approve_reimbursement_solicitud_for_approved_informe(
            session,
            documento,
            now=now,
        )
        if aprobacion is None:
            continue
        promoted += 1
        promoted_ids.append(documento.id)

    if promoted:
        await session.commit()
        try:
            from .documento_telegram import (
                schedule_solicitud_pending_payment_telegram_notifications,
            )

            for documento_id in promoted_ids:
                schedule_solicitud_pending_payment_telegram_notifications(
                    documento_id=str(documento_id),
                )
        except Exception:
            logger.exception(
                "Failed to schedule Finance pending payment Telegram notifications"
            )
    return promoted


async def _count_active_document_expenses(
    session: AsyncSession,
    *,
    documento_id: UUID,
    cuenta_gastos_id: Optional[UUID] = None,
) -> int:
    expense_links = [
        ExpenseReport.documento_id == documento_id,
        ExpenseReport.informe_documento_id == documento_id,
    ]
    if cuenta_gastos_id:
        expense_links.append(ExpenseReport.cuenta_gastos_id == cuenta_gastos_id)
    result = await session.execute(
        select(func.count(ExpenseReport.id)).where(
            and_(
                or_(*expense_links),
                ExpenseReport.estado_gasto != "cancelado",
            )
        )
    )
    return int(result.scalar_one() or 0)


FINANCIAL_TERMINAL_DOCUMENT_STATES = {"pagado", "cerrado", "reembolsado", "aplicado", "liquidado"}
NON_TERMINAL_SETTLEMENT_STATES = {"cancelado", "cancelada", "rechazado", "rechazada", "anulado", "anulada"}


def _normalized_state(value: object) -> str:
    return str(value or "").strip().lower()


async def documento_financial_terminal_reason(
    session: AsyncSession,
    documento: Documento,
) -> Optional[str]:
    """Return a reason when a document already reached a financial terminal step.

    A document that has been paid, reimbursed, or applied against advances must
    never re-enter authorization. This helper is intentionally based on durable
    financial evidence, not only on the mutable ``estado`` field, because older
    bugs could leave a paid document in an editable/rejected state.
    """
    estado = _normalized_state(getattr(documento, "estado", None))
    if estado in FINANCIAL_TERMINAL_DOCUMENT_STATES:
        return f"estado terminal '{estado}'"
    if getattr(documento, "pagado_en", None):
        return "pago registrado"
    if getattr(documento, "gasto_generado_id", None):
        return "gasto generado por pago"

    anticipo_result = await session.execute(
        select(func.count(Anticipo.id)).where(
            Anticipo.documento_id == documento.id,
            func.lower(func.coalesce(Anticipo.estado, "")).notin_(
                NON_TERMINAL_SETTLEMENT_STATES
            ),
        )
    )
    if int(anticipo_result.scalar_one() or 0) > 0:
        return "anticipo registrado o aplicado"

    reembolso_filters = [Reembolso.documento_id == documento.id]
    if getattr(documento, "cuenta_gastos_id", None):
        reembolso_filters.append(Reembolso.cuenta_gastos_id == documento.cuenta_gastos_id)
    settlement_filters = []
    if documento.tipo == "INFORME" and estado in PREAPPROVAL_INFORME_STATES:
        # Returning an advance does not approve its expenses. The INFORME must
        # still complete its first authorization cycle; reimbursements stay locked.
        settlement_filters.append(
            func.lower(func.coalesce(Reembolso.tipo, "")) != "devolucion"
        )
    reembolso_result = await session.execute(
        select(func.count(Reembolso.id)).where(
            or_(*reembolso_filters),
            *settlement_filters,
            func.lower(func.coalesce(Reembolso.estado, "")).notin_(
                NON_TERMINAL_SETTLEMENT_STATES
            ),
        )
    )
    if int(reembolso_result.scalar_one() or 0) > 0:
        return "reembolso/devolucion registrado"

    return None


async def documento_has_approval(session: AsyncSession, documento: Documento) -> bool:
    result = await session.execute(
        select(func.count(Aprobacion.id)).where(
            Aprobacion.tipo_entidad == "documento",
            Aprobacion.entidad_id == documento.id,
            func.lower(func.coalesce(Aprobacion.accion, "")) == "aprobar",
        )
    )
    return int(result.scalar_one() or 0) > 0


async def validate_informe_surplus_before_submission(
    session: AsyncSession, documento: Documento
) -> None:
    """Apply the same surplus invariant to closing, sending, and approval."""
    if documento.tipo != "INFORME":
        return
    if getattr(documento, "informe_origen_id", None):
        origin = await session.get(Documento, documento.informe_origen_id)
        cuenta = (
            await session.get(CuentaDeGastos, origin.cuenta_gastos_id)
            if origin
            else None
        )
        if (
            cuenta is None
            or not cuenta.comprobacion_parcial
            or cuenta.estado != "abierta"
        ):
            raise DocumentoWorkflowValidationError(
                "invalid_partial_case",
                "El informe original no está abierto para comprobación parcial.",
            )
        from .cuenta_settlement_service import (
            _sum_active_gastos,
            _sum_requested_solicitudes,
            sum_active_advance_returns,
        )

        from .amex_expense_service import company_amex_sql_condition

        if (
            await session.execute(
                select(func.count(ExpenseReport.id)).where(
                    ExpenseReport.cuenta_gastos_id == cuenta.id,
                    ExpenseReport.estado_gasto != "cancelado",
                    company_amex_sql_condition(),
                )
            )
        ).scalar_one():
            raise DocumentoWorkflowValidationError(
                "partial_amex_not_allowed",
                "Un anticipo parcial no puede incluir gastos AMEX empresa.",
            )
        if await _sum_active_gastos(
            session, cuenta.id
        ) + await sum_active_advance_returns(
            session, cuenta.id
        ) > await _sum_requested_solicitudes(
            session, cuenta.id
        ):
            raise DocumentoWorkflowValidationError(
                "partial_advance_exceeded",
                "Los gastos y devoluciones superan el anticipo pagado.",
            )
        return
    if documento.cuenta_gastos_id is None:
        return
    try:
        await validate_cuenta_surplus_is_returned(session, documento.cuenta_gastos_id)
    except CuentaSettlementValidationError as exc:
        raise DocumentoWorkflowValidationError(exc.code, exc.message) from exc


async def documento_workflow_locked_reason(
    session: AsyncSession,
    documento: Documento,
) -> Optional[str]:
    financial_reason = await documento_financial_terminal_reason(session, documento)
    if financial_reason is not None:
        return f"cierre financiero: {financial_reason}"
    if await documento_has_approval(session, documento):
        return "autorizacion registrada"
    return None


async def _reopen_informe_de_gastos_on_reject(
    session: AsyncSession, documento: Documento
) -> None:
    """Reopen a rejected INFORME so the employee can edit and resubmit it.

    Closing an informe sets its Cuenta de Gastos to ``cerrada`` and sends the
    INFORME documento to approval. When that documento is rejected we return both
    to their editable state (cuenta ``abierta``, documento ``borrador``) so the
    existing close/edit flow can run again. The rejection itself stays recorded
    in the Aprobacion history. No-op for SOLICITUD or documents without a linked
    cuenta.
    """
    if documento.tipo != "INFORME":
        return
    if getattr(documento, "informe_origen_id", None):
        documento.estado = "borrador"
        documento.enviado_en = None
        return
    if documento.cuenta_gastos_id is None:
        return
    cuenta = await session.get(CuentaDeGastos, documento.cuenta_gastos_id)
    if cuenta is not None and cuenta.estado == "cerrada":
        cuenta.estado = "abierta"
        cuenta.closed_at = None
    documento.estado = "borrador"
    documento.enviado_en = None


async def transition_documento_workflow(
    session: AsyncSession,
    *,
    documento_id: UUID | str,
    actor_id: UUID | str,
    action: str,
    comentario: Optional[str] = None,
    surface: str = "web",
    request_context: Optional[AuditRequestContext] = None,
) -> DocumentoWorkflowResult:
    normalized_action = (action or "").strip().lower()
    if normalized_action not in {"send", "approve", "reject", "cancel", "withdraw"}:
        raise DocumentoWorkflowValidationError(
            "invalid_action",
            "action must be one of: send, approve, reject, cancel, withdraw",
        )

    documento_uuid = UUID(str(documento_id))
    actor_uuid = UUID(str(actor_id))

    # AMEX recognition/cut locks global before document. Never invert that order
    # while capturing an approval snapshot. Non-report workflows keep their path.
    if normalized_action == "approve":
        amex_report = (
            await session.execute(
                select(Documento.id)
                .join(
                    ExpenseReport,
                    ExpenseReport.cuenta_gastos_id == Documento.cuenta_gastos_id,
                )
                .where(
                    Documento.id == documento_uuid,
                    Documento.tipo == "INFORME",
                    ExpenseReport.estado_gasto != "cancelado",
                    (
                        ExpenseReport.pagado_con_amex_empresa.is_(True)
                        | (
                            ExpenseReport.pagado_con_amex_empresa.is_(None)
                            & (ExpenseReport.origen == "amex_batch")
                        )
                    ),
                )
                .limit(1)
            )
        ).scalar_one_or_none()
        if amex_report is not None:
            from .amex_recognition_service import lock_recognition

            await lock_recognition(session)

    documento = await _load_documento(session, documento_uuid)
    if documento is None:
        raise DocumentoWorkflowValidationError(
            "documento_not_found", "Documento not found"
        )

    actor = await _load_actor(session, actor_uuid)
    if actor is None:
        raise DocumentoWorkflowValidationError("actor_not_found", "Actor not found")

    now = utc_now()
    comentario_normalizado = (comentario or "").strip() or None
    auto_aprobacion: Optional[Aprobacion] = None
    if getattr(documento, "informe_origen_id", None):
        if not (documento.motivo_comprobacion_parcial or "").strip():
            raise DocumentoWorkflowValidationError(
                "partial_reason_required",
                "Falta el motivo confirmado por el solicitante.",
            )
        if normalized_action == "approve" and not comentario_normalizado:
            raise DocumentoWorkflowValidationError(
                "partial_approval_comment_required",
                "Registra tus comentarios sobre la comprobación parcial y el motivo del solicitante.",
            )

    financial_reason = await documento_financial_terminal_reason(session, documento)
    if financial_reason is not None:
        raise DocumentoWorkflowValidationError(
            "workflow_locked_document",
            (
                "Este documento ya tiene cierre financiero ("
                f"{financial_reason}). No puede rechazarse, reenviarse ni regresar "
                "al circuito de autorizacion."
            ),
        )

    if normalized_action in {"send", "reject", "cancel", "withdraw"}:
        if await documento_has_approval(session, documento):
            raise DocumentoWorkflowValidationError(
                "authorization_closed_document",
                (
                    "Este documento ya fue autorizado por al menos un autorizador. "
                    "No puede rechazarse, reabrirse ni regresar al circuito editable."
                ),
            )

    if normalized_action == "send":
        if documento.empleado_id != actor.id:
            raise DocumentoWorkflowPermissionError("owner_mismatch", "Access denied")
        if documento.estado != "borrador":
            raise DocumentoWorkflowValidationError(
                "invalid_estado",
                "El documento solo puede enviarse cuando está en estado 'borrador'.",
            )
        if documento.tipo == "INFORME":
            await validate_informe_surplus_before_submission(session, documento)
            gastos_count = await _count_active_document_expenses(
                session,
                documento_id=documento_uuid,
                cuenta_gastos_id=documento.cuenta_gastos_id,
            )
            if gastos_count == 0:
                raise DocumentoWorkflowValidationError(
                    "no_gastos",
                    "El documento tipo INFORME debe tener al menos un gasto activo "
                    "antes de poder enviarse.",
                )
        await _sync_reimbursement_budget_or_raise(session, documento)
        if is_employee_reimbursement_solicitud(
            documento
        ) and not await _solicitud_linked_informe_is_approved(session, documento):
            raise DocumentoWorkflowValidationError(
                "informe_approval_required",
                "La solicitud de reembolso no se envía a aprobación separada; "
                "pasará a Programación de Pago cuando se apruebe el informe "
                "de gastos vinculado.",
            )
        if not has_operations_reference(documento):
            await invalidate_document_route(session, documento.id)
        await prepare_document_authorization_route(session, documento)
        if documento_requires_budget_control(documento):
            documento.estado = BUDGET_CONTROL_STATE
            documento.enviado_en = None
            await reserve_documento_cfdis_or_raise(session, documento, actor)
            aprobacion_accion = "enviar_control_presupuestal"
            comentario_normalizado = (
                comentario_normalizado
                or "Enviado a Control Presupuestal para asignar concepto presupuestal."
            )
        else:
            documento.estado = "enviado"
            documento.enviado_en = now
            await reserve_documento_cfdis_or_raise(session, documento, actor)
            aprobacion_accion = "enviar"
            informe_aprobador_id = await _linked_informe_approval_actor_id(
                session, documento
            )
            if informe_aprobador_id is not None and (
                not has_operations_reference(documento)
                or await actor_is_route_approver(
                    session, actor_id=informe_aprobador_id, documento_id=documento.id
                )
            ):
                auto_aprobacion = _auto_approve_solicitud_with_approved_informe(
                    documento=documento,
                    aprobador_id=informe_aprobador_id,
                    now=now,
                )

    elif normalized_action == "approve":
        if documento.estado != "enviado":
            raise DocumentoWorkflowValidationError(
                "invalid_estado",
                "El documento solo puede aprobarse cuando está en estado 'enviado'.",
            )
        await validate_informe_surplus_before_submission(session, documento)
        if is_employee_reimbursement_solicitud(
            documento
        ) and not await _solicitud_linked_informe_is_approved(session, documento):
            raise DocumentoWorkflowValidationError(
                "informe_approval_required",
                "La solicitud de reembolso no se aprueba por separado; debe "
                "aprobarse primero el informe de gastos vinculado.",
            )
        _raise_if_document_already_advanced(
            await _document_has_recorded_approval(session, documento_uuid)
        )
        route_exists = (
            await session.execute(
                text(
                    "SELECT 1 FROM documento_authorization_routes "
                    "WHERE documento_id = :documento_id"
                ),
                {"documento_id": str(documento.id)},
            )
        ).scalar_one_or_none() is not None
        if route_exists or has_operations_reference(documento):
            if not await actor_is_route_approver(
                session, actor_id=actor.id, documento_id=documento.id
            ) and (
                has_operations_reference(documento)
                or actor.rol not in {"superadmin", "super_admin"}
            ):
                raise DocumentoWorkflowValidationError(
                    "not_route_approver",
                    "No ocupas un puesto autorizado para esta solicitud.",
                )
        else:
            approval_subject = approval_subject_empleado(documento)
            if approval_subject is not None and approval_subject.aprobador_id:
                es_aprobador_asignado = approval_subject.aprobador_id == actor.id
                es_finanzas_o_admin = actor.rol in FINANCE_ADMIN_ROLES
                es_superadmin = actor.rol in {"superadmin", "super_admin"}
                if not (es_aprobador_asignado or es_finanzas_o_admin or es_superadmin):
                    raise DocumentoWorkflowValidationError(
                        "not_assigned_approver",
                        "No eres el aprobador asignado para este beneficiario. Contacta a "
                        "finanzas o administraci\u00f3n.",
                    )
            elif actor.rol not in APPROVER_ROLES:
                raise DocumentoWorkflowPermissionError(
                    "insufficient_role",
                    "Access denied. Insufficient permissions.",
                )
        if documento.tipo == "INFORME":
            gastos_count = await _count_active_document_expenses(
                session,
                documento_id=documento_uuid,
                cuenta_gastos_id=documento.cuenta_gastos_id,
            )
            if gastos_count == 0:
                raise DocumentoWorkflowValidationError(
                    "no_gastos",
                    "El documento tipo INFORME debe tener al menos un gasto activo "
                    "antes de poder aprobarse.",
                )
        try:
            from .authorization_profile_service import (
                build_authorization_route_hard_block,
            )

            authorization_route_block = await build_authorization_route_hard_block(
                session, documento, actor
            )
        except Exception:
            logger.exception(
                "Failed to evaluate hard authorization strategy enforcement",
                extra={"documento_id": str(documento.id)},
            )
            authorization_route_block = None
        if authorization_route_block is not None:
            raise DocumentoWorkflowValidationError(
                "authorization_strategy_required",
                str(authorization_route_block.get("message") or "Ruta de autorización inválida."),
            )
        if getattr(documento, "informe_origen_id", None):
            final_lot_total = (
                await session.execute(
                    select(
                        func.coalesce(func.sum(ExpenseReport.gasto_cantidad), 0)
                    ).where(
                        ExpenseReport.informe_documento_id == documento.id,
                        ExpenseReport.estado_gasto != "cancelado",
                    )
                )
            ).scalar_one()
            documento.monto_total = Decimal(str(final_lot_total or 0)).quantize(
                Decimal("0.01")
            )
        documento.estado = "aprobado"
        documento.aprobado_en = now
        assign_fecha_pago_on_solicitud_approval(documento)
        if documento.tipo == "INFORME":
            amex_posting = await ensure_amex_report_approval_posting(
                session,
                informe_documento=documento,
            )
            if amex_posting.status == "pending":
                raise DocumentoWorkflowValidationError(
                    "accounting_posting_pending",
                    "No se puede aprobar el informe AMEX hasta completar su configuraci\u00f3n "
                    f"contable ({amex_posting.reason or 'incompleta'}).",
                )
            posting = await ensure_debtor_comprobacion_posting_for_informe(
                session,
                informe_documento=documento,
            )
            if posting.status == "pending":
                raise DocumentoWorkflowValidationError(
                    "accounting_posting_pending",
                    "No se puede aprobar el informe hasta completar su configuraci\u00f3n "
                    f"contable ({posting.reason or 'incompleta'}).",
                )
        elif documento.tipo == "SOLICITUD":
            posting = await ensure_provider_approval_posting(
                session,
                documento=documento,
            )
            if posting.status == "pending":
                raise DocumentoWorkflowValidationError(
                    "accounting_posting_pending",
                    "No se puede aprobar la solicitud hasta completar su configuraci\u00f3n "
                    f"contable ({posting.reason or 'incompleta'}).",
                )
        if (
            getattr(documento, "supplier_advance_id", None)
            and documento.estado == "cerrado"
        ):
            comentario_normalizado = (
                comentario_normalizado or ""
            ) + " Factura cubierta por anticipo; cierre sin transferencia bancaria."
        aprobacion_accion = "aprobar"

    elif normalized_action == "reject":
        if documento.estado != "enviado":
            raise DocumentoWorkflowValidationError(
                "invalid_estado",
                "El documento solo puede rechazarse cuando está en estado 'enviado'.",
            )
        _raise_if_document_already_advanced(
            await _document_has_recorded_approval(session, documento_uuid)
        )
        route_exists = (
            (
                await session.execute(
                    text(
                        "SELECT 1 FROM documento_authorization_routes "
                        "WHERE documento_id = :documento_id"
                    ),
                    {"documento_id": str(documento.id)},
                )
            ).scalar_one_or_none()
            is not None
        )
        if route_exists or has_operations_reference(documento):
            if not await actor_is_route_approver(
                session, actor_id=actor.id, documento_id=documento.id
            ) and (
                has_operations_reference(documento)
                or actor.rol not in {"superadmin", "super_admin"}
            ):
                raise DocumentoWorkflowValidationError(
                    "not_route_approver",
                    "No ocupas un puesto autorizado para esta solicitud.",
                )
        else:
            approval_subject = approval_subject_empleado(documento)
            if approval_subject is not None and approval_subject.aprobador_id:
                es_aprobador_asignado = approval_subject.aprobador_id == actor.id
                es_finanzas_o_admin = actor.rol in FINANCE_ADMIN_ROLES
                es_superadmin = actor.rol in {"superadmin", "super_admin"}
                if not (es_aprobador_asignado or es_finanzas_o_admin or es_superadmin):
                    raise DocumentoWorkflowValidationError(
                        "not_assigned_approver",
                        "No eres el aprobador asignado para este beneficiario. Contacta a "
                        "finanzas o administraci\u00f3n.",
                    )
            elif actor.rol not in APPROVER_ROLES:
                raise DocumentoWorkflowPermissionError(
                    "insufficient_role",
                    "Access denied. Insufficient permissions.",
                )
        documento.estado = "rechazado"
        aprobacion_accion = "rechazar"
        await _reopen_informe_de_gastos_on_reject(session, documento)

    elif normalized_action == "withdraw":
        if documento.tipo != "SOLICITUD":
            raise DocumentoWorkflowValidationError(
                "invalid_tipo",
                "Solo las solicitudes pueden retirarse desde este flujo.",
            )
        if documento.empleado_id != actor.id:
            raise DocumentoWorkflowPermissionError("owner_mismatch", "Access denied")
        if documento.estado != "enviado":
            raise DocumentoWorkflowValidationError(
                "invalid_estado",
                "La solicitud solo puede retirarse mientras está en revisión.",
            )
        documento.estado = "borrador"
        documento.enviado_en = None
        aprobacion_accion = "editar"
        if comentario_normalizado:
            comentario_normalizado = (
                f"Retirada por el solicitante: {comentario_normalizado}"
            )
        else:
            comentario_normalizado = "Retirada por el solicitante para edición."

    else:
        if documento.tipo != "SOLICITUD":
            raise DocumentoWorkflowValidationError(
                "invalid_tipo",
                "Solo las solicitudes pueden cancelarse desde este flujo.",
            )
        if documento.empleado_id != actor.id:
            raise DocumentoWorkflowPermissionError("owner_mismatch", "Access denied")
        if documento.estado != "borrador":
            raise DocumentoWorkflowValidationError(
                "invalid_estado",
                "La solicitud solo puede cancelarse en borrador.",
            )
        documento.estado = "cancelado"
        documento.enviado_en = None
        documento.cfdi_report_id = None
        documento.cfdi_uuid_manual = None
        documento.cfdi_compartido_confirmado = False
        aprobacion_accion = "cancelar"

    aprobacion = Aprobacion(
        tipo_entidad="documento",
        entidad_id=documento_uuid,
        aprobador_id=actor.id,
        accion=aprobacion_accion,
        comentario=comentario_normalizado,
        fecha=now,
    )
    session.add(aprobacion)
    if auto_aprobacion is not None:
        session.add(auto_aprobacion)
    if normalized_action == "approve" and documento.tipo == "INFORME":
        from .amex_report_evidence_service import record_amex_final_report_approval

        try:
            await session.flush()
            await record_amex_final_report_approval(
                session, informe=documento, approval=aprobacion
            )
        except Exception:
            await session.rollback()
            raise
    await session.commit()
    await session.refresh(documento)
    await session.refresh(aprobacion)

    action_labels = {
        "send": "documento.sent",
        "approve": "documento.approved",
        "reject": "documento.rejected",
        "cancel": "documento.cancelled",
        "withdraw": "documento.withdrawn",
    }
    authorization_strategy_evidence = None
    if normalized_action == "send":
        try:
            from .authorization_profile_service import (
                build_document_authorization_evidence,
            )

            authorization_strategy_evidence = (
                await build_document_authorization_evidence(session, documento)
            )
        except Exception:
            logger.exception(
                "Failed to build advisory authorization strategy evidence",
                extra={"documento_id": str(documento.id)},
            )
    audit_metadata = {
        "documento_tipo": documento.tipo,
        "documento_estado": documento.estado,
        "aprobacion_id": str(aprobacion.id),
        "comentario": comentario_normalizado,
        "auto_approved": auto_aprobacion is not None,
    }
    if authorization_strategy_evidence is not None:
        audit_metadata["authorization_strategy"] = authorization_strategy_evidence

    authorization_route_warning = None
    if normalized_action == "approve":
        try:
            from .authorization_profile_service import (
                build_authorization_route_soft_warning,
            )

            authorization_route_warning = await build_authorization_route_soft_warning(
                session, documento
            )
        except Exception:
            logger.exception(
                "Failed to build soft authorization route warning",
                extra={"documento_id": str(documento.id)},
            )
    if authorization_route_warning is not None:
        audit_metadata["authorization_route_warning"] = authorization_route_warning

    await record_customer_success_audit_event(
        session,
        action=action_labels.get(normalized_action, f"documento.{normalized_action}"),
        actor_empleado_id=actor.id,
        target_empleado_id=documento.empleado_id,
        documento_id=documento.id,
        documento_referencia=documento.numero_referencia,
        entity_type="documento",
        entity_id=documento.id,
        surface=surface,
        request_context=request_context,
        summary=(
            f"{actor.nombre} ejecutó {normalized_action} sobre "
            f"{documento.numero_referencia}"
        ),
        metadata=audit_metadata,
        commit=True,
    )

    try:
        if normalized_action == "send" and documento.estado == BUDGET_CONTROL_STATE:
            from .documento_telegram import schedule_budget_control_telegram_notifications

            schedule_budget_control_telegram_notifications(
                documento_id=str(documento_uuid),
                actor_id=str(actor.id),
            )
        else:
            from .documento_telegram import (
                schedule_document_workflow_telegram_notifications,
            )

            schedule_document_workflow_telegram_notifications(
                documento_id=str(documento_uuid),
                action=normalized_action,
                actor_id=str(actor.id),
                comentario=comentario_normalizado,
            )
    except Exception:
        logger.exception(
            "Failed to schedule Telegram notifications for document workflow"
        )

    return DocumentoWorkflowResult(documento=documento, aprobacion=aprobacion)
