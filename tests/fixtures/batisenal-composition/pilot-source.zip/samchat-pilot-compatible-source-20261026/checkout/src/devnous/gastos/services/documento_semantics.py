"""Business semantics shared by document routes and presentation layers."""

from __future__ import annotations

from typing import Any

EMPLOYEE_REIMBURSEMENT_CONCEPT_PREFIX = "Reembolso de saldo a favor"


def effective_account_beneficiary_id(cuenta: Any) -> Any:
    """Return the employee beneficiary without changing report ownership."""
    return getattr(cuenta, "beneficiario_empleado_id", None) or getattr(
        cuenta, "empleado_id", None
    )


def effective_account_provider_beneficiary_id(cuenta: Any) -> Any:
    """Return provider/operator beneficiary id when the report is for a non-employee."""
    return getattr(cuenta, "beneficiario_proveedor_cliente_id", None)


def account_uses_provider_beneficiary(cuenta: Any) -> bool:
    """True when reimbursement/bank account must resolve against provider/operator."""
    return effective_account_provider_beneficiary_id(cuenta) is not None


def effective_account_beneficiary(cuenta: Any, *, explicit_only: bool = False) -> Any:
    """Resolve the beneficiary party shown for a Cuenta de Gastos."""
    if cuenta is None:
        return None
    return (
        getattr(cuenta, "beneficiario_empleado", None)
        or getattr(cuenta, "beneficiario_proveedor_cliente", None)
        or (None if explicit_only else getattr(cuenta, "empleado", None))
    )


def effective_document_beneficiary(
    documento: Any, *, explicit_only: bool = False
) -> Any:
    """Resolve the beneficiary consistently across reports and document views.

    A report may name an employee or a registered provider/operator directly on
    the document.  Older or linked records retain that party only on their
    Cuenta de Gastos, so fall back to the account before the requester.
    ``explicit_only`` excludes legacy owner/requester fallbacks for views that
    require an evidenced beneficiary. Existing callers retain their semantics.
    """
    if documento is None:
        return None
    cuenta = getattr(documento, "cuenta_gastos", None)
    return (
        getattr(documento, "beneficiario_empleado", None)
        or getattr(documento, "beneficiario_proveedor_cliente", None)
        or effective_account_beneficiary(cuenta, explicit_only=explicit_only)
        or (None if explicit_only else getattr(documento, "proveedor_cliente", None))
        or (None if explicit_only else getattr(documento, "empleado", None))
    )


def effective_document_beneficiary_name(
    documento: Any, *, fallback: str = "—", explicit_only: bool = False
) -> str:
    """Return the effective beneficiary name without inventing a party."""
    beneficiary = effective_document_beneficiary(documento, explicit_only=explicit_only)
    name = str(getattr(beneficiary, "nombre", "") or "").strip()
    return name or fallback


def effective_document_project_name(documento: Any, *, fallback: str = "") -> str:
    """Return the explicit project/tournament label already owned by a document."""
    if documento is None:
        return fallback
    manual_project = str(getattr(documento, "proyecto_otro", None) or "").strip()
    if manual_project:
        return manual_project
    tournament = getattr(documento, "torneo", None)
    tournament_name = str(getattr(tournament, "name", None) or "").strip()
    if tournament_name:
        return tournament_name
    account = getattr(documento, "cuenta_gastos", None)
    account_tournament = getattr(account, "torneo", None)
    account_tournament_name = str(
        getattr(account_tournament, "name", None) or ""
    ).strip()
    return account_tournament_name or fallback


def reimbursement_concept_from_cuenta(cuenta: Any) -> str:
    """Build the SOLICITUD concept for an employee reimbursement from an expense report.

    Keep the legacy prefix so existing reimbursement detection remains stable,
    while carrying the user-entered report motive/description for quick review.
    """
    prefix = EMPLOYEE_REIMBURSEMENT_CONCEPT_PREFIX
    if cuenta is None:
        return prefix

    report_ref = str(getattr(cuenta, "referencia_base", None) or "").strip()
    report_description = str(getattr(cuenta, "nombre", None) or "").strip()
    parts = [prefix]
    if report_description:
        parts.append(report_description)
    if report_ref:
        parts.append(f"I-{report_ref}")
    return " — ".join(parts)


def is_employee_reimbursement(documento: Any) -> bool:
    """Identify system-generated employee reimbursements, including legacy rows."""
    concept = str(getattr(documento, "concepto_pago", None) or "").strip()
    return bool(
        getattr(documento, "tipo", None) == "SOLICITUD"
        and getattr(documento, "cuenta_gastos_id", None)
        and getattr(documento, "beneficiario_empleado_id", None)
        and concept.startswith(EMPLOYEE_REIMBURSEMENT_CONCEPT_PREFIX)
    )


def approval_subject_empleado(documento: Any) -> Any:
    """Return the employee whose assigned approver governs approval routing.

    Third-party expense reports and advances are owned by the requester, but the
    approval lane belongs to the employee who receives/benefits from the funds.
    Existing direct documents keep the requester as the approval subject.
    """
    return getattr(documento, "beneficiario_empleado", None) or getattr(
        documento, "empleado", None
    )


def approval_subject_empleado_id(documento: Any) -> Any:
    """Return the effective employee id for approval routing without loading relations."""
    return getattr(documento, "beneficiario_empleado_id", None) or getattr(
        documento, "empleado_id", None
    )
