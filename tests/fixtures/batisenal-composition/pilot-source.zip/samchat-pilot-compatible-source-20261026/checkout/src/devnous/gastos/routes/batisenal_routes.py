"""Same-origin, session-authenticated Batiseñal HTTP surface."""

from __future__ import annotations

import json
import os
import secrets
from functools import wraps

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, Response
from sqlalchemy.exc import SQLAlchemyError

from ..services import batisenal_service as service
from ..services.support_ticket_service import SupportTicketValidationError

HEADERS = {
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "no-referrer",
}


def widget_html(module=None):
    """The shared navigation only loads the widget when explicitly enabled."""
    if os.getenv("BATISENAL_ENABLED") != "1":
        return ""
    # Only a fixed navigation identifier enters the automatic context adapter.
    module = (
        module
        if module
        in {"panel", "operacion", "contabilidad", "nomina", "admin", "soporte"}
        else "panel"
    )
    return (
        f'<button type="button" data-batisenal-open data-batisenal-module="{module}">Batiseñal · pedir ayuda</button>'
        '<script src="/static/batisenal.js" defer></script>'
    )


def guarded(function):
    @wraps(function)
    async def call(*args, **kwargs):
        try:
            return await function(*args, **kwargs)
        except service.BatisenalError as exc:
            raise HTTPException(exc.status, exc.code, headers=HEADERS) from exc
        except SupportTicketValidationError as exc:
            raise HTTPException(400, str(exc), headers=HEADERS) from exc
        except SQLAlchemyError as exc:
            await kwargs["session"].rollback()
            raise HTTPException(503, "STORE_UNAVAILABLE", headers=HEADERS) from exc

    return call


async def read_payload(request, policy):
    origin = request.headers.get("origin", "")
    if origin != str(request.base_url).rstrip("/"):
        raise service.BatisenalError("ORIGIN_DENIED", 403)
    expected = request.session.get("batisenal_csrf")
    supplied = request.headers.get("x-batisenal-csrf", "")
    if not expected or not secrets.compare_digest(expected, supplied):
        raise service.BatisenalError("CSRF_DENIED", 403)
    if request.headers.get("content-type", "").split(";")[0] != "application/json":
        raise service.BatisenalError("CONTENT_TYPE_INVALID", 415)
    maximum = 4 * ((policy.max_image_bytes + 2) // 3) + 64000
    raw = bytearray()
    async for chunk in request.stream():
        raw.extend(chunk)
        if len(raw) > maximum:
            raise service.BatisenalError("BODY_TOO_LARGE", 413)
    try:
        data = json.loads(raw)
    except (ValueError, UnicodeError) as exc:
        raise service.BatisenalError("JSON_INVALID") from exc
    if not isinstance(data, dict):
        raise service.BatisenalError("JSON_INVALID")
    return data


def build_router(employee_dependency, session_dependency, resolve_principal):
    """Dependency injection supports the real session owner and isolated fixtures."""
    router = APIRouter(prefix="/soporte/batisenal", tags=["batisenal"])

    async def authorize(request, session, employee):
        if os.getenv("BATISENAL_ENABLED") != "1":
            raise service.BatisenalError("NOT_ENABLED", 503)
        return await resolve_principal(session, employee, request.method)

    @router.get("", response_class=HTMLResponse)
    @guarded
    async def page(
        request: Request,
        session=Depends(session_dependency),
        employee=Depends(employee_dependency),
    ):
        await authorize(request, session, employee)
        return HTMLResponse(
            '<!doctype html><html lang="es"><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            "<title>Batiseñal | SamChat</title><body><main><h1>Soporte SamChat</h1>"
            '<a href="/panel">Volver a SamChat</a><p>Casos y conversación con soporte.</p>'
            + widget_html()
            + "</main></body></html>",
            headers=HEADERS,
        )

    @router.get("/bootstrap")
    @guarded
    async def bootstrap(
        request: Request,
        session=Depends(session_dependency),
        employee=Depends(employee_dependency),
    ):
        principal = await authorize(request, session, employee)
        policy = service.Policy.environment()
        token = request.session.setdefault("batisenal_csrf", secrets.token_urlsafe(32))
        return JSONResponse(
            dict(
                csrf=token,
                scopes=sorted(principal.grants),
                max_image_bytes=policy.max_image_bytes,
                max_pixels=policy.max_pixels,
                retention_days=policy.retention_days,
            ),
            headers=HEADERS,
        )

    @router.get("/cases")
    @guarded
    async def listing(
        request: Request,
        session=Depends(session_dependency),
        employee=Depends(employee_dependency),
    ):
        principal = await authorize(request, session, employee)
        from fastapi.encoders import jsonable_encoder

        return JSONResponse(
            jsonable_encoder(await service.list_cases(session, principal)),
            headers=HEADERS,
        )

    @router.post("/cases")
    @guarded
    async def create(
        request: Request,
        session=Depends(session_dependency),
        employee=Depends(employee_dependency),
    ):
        principal = await authorize(request, session, employee)
        policy = service.Policy.environment()
        payload = await read_payload(request, policy)
        if set(payload) - {
            "organization",
            "project",
            "request_key",
            "confirmed",
            "title",
            "description",
            "context",
            "image",
        }:
            raise service.BatisenalError("FIELDS_INVALID")
        identifier = await service.create_case(session, principal, payload, policy)
        return JSONResponse({"id": identifier}, status_code=201, headers=HEADERS)

    @router.get("/cases/{ticket_id}")
    @guarded
    async def detail(
        ticket_id: str,
        request: Request,
        session=Depends(session_dependency),
        employee=Depends(employee_dependency),
    ):
        principal = await authorize(request, session, employee)
        from fastapi.encoders import jsonable_encoder

        value = await service.case_detail(session, principal, ticket_id)
        from ..services.batisenal_pilot_service import private_review_only

        value["private_review_only"] = value["id"] == getattr(
            request.app.state, "batisenal_private_pilot_case", None
        ) or await private_review_only(session, value["id"])
        return JSONResponse(jsonable_encoder(value), headers=HEADERS)

    @router.post("/cases/{ticket_id}")
    @guarded
    async def reply(
        ticket_id: str,
        request: Request,
        session=Depends(session_dependency),
        employee=Depends(employee_dependency),
    ):
        principal = await authorize(request, session, employee)
        row = await service.visible_case(session, principal, ticket_id)
        if str(row.ticket_id) == getattr(
            request.app.state, "batisenal_private_pilot_case", None
        ) and principal.permits(row.organization, row.project, "support"):
            raise service.BatisenalError("PILOT_PRIVATE_REVIEW_ONLY", 403)
        payload = await read_payload(request, service.Policy.environment())
        if set(payload) - {"request_key", "confirmed", "body", "status"}:
            raise service.BatisenalError("FIELDS_INVALID")
        await service.reply_case(session, principal, ticket_id, payload)
        return JSONResponse({"id": ticket_id}, headers=HEADERS)

    @router.get("/cases/{ticket_id}/image")
    @guarded
    async def image(
        ticket_id: str,
        request: Request,
        session=Depends(session_dependency),
        employee=Depends(employee_dependency),
    ):
        principal = await authorize(request, session, employee)
        row = await service.visible_case(session, principal, ticket_id)
        if not row.image:
            raise service.BatisenalError("NOT_FOUND", 404)
        return Response(
            row.image,
            media_type="image/png",
            headers={
                **HEADERS,
                "Content-Disposition": 'inline; filename="batisenal.png"',
                "Content-Security-Policy": "default-src 'none'; sandbox",
            },
        )

    @router.get("/cases/{ticket_id}/agent-drafts")
    @guarded
    async def agent_drafts(
        ticket_id: str,
        request: Request,
        session=Depends(session_dependency),
        employee=Depends(employee_dependency),
    ):
        from ..services.batisenal_agent_service import private_drafts

        principal = await authorize(request, session, employee)
        return JSONResponse(
            await private_drafts(session, principal, ticket_id), headers=HEADERS
        )

    @router.post("/cases/{ticket_id}/agent-drafts/{draft_id}")
    @guarded
    async def publish_agent_draft(
        ticket_id: str,
        draft_id: str,
        request: Request,
        session=Depends(session_dependency),
        employee=Depends(employee_dependency),
    ):
        from ..services.batisenal_agent_service import publish_draft

        principal = await authorize(request, session, employee)
        row = await service.visible_case(session, principal, ticket_id)
        if str(row.ticket_id) == getattr(
            request.app.state, "batisenal_private_pilot_case", None
        ):
            raise service.BatisenalError("PILOT_PRIVATE_REVIEW_ONLY", 403)
        payload = await read_payload(request, service.Policy.environment())
        if set(payload) != {"confirmed"}:
            raise service.BatisenalError("FIELDS_INVALID")

        async def reauthorize():
            from types import SimpleNamespace
            from uuid import UUID

            from sqlalchemy import select

            from ..models import Empleado

            fields = (
                Empleado.id,
                Empleado.activo,
                Empleado.rol,
                Empleado.departamento,
                Empleado.nombre,
                Empleado.correo,
            )
            current = (
                (
                    await session.execute(
                        select(*fields).where(Empleado.id == UUID(str(employee.id)))
                    )
                )
                .mappings()
                .first()
            )
            if current is None:
                raise service.BatisenalError("IDENTITY_NOT_ALLOWED", 403)
            fresh = SimpleNamespace(**dict(current))
            fresh.id = str(fresh.id)
            fresh.impersonator_empleado_id = getattr(
                employee, "impersonator_empleado_id", None
            )
            return await authorize(request, session, fresh)

        # Human signed-session surface only; deliberately absent from MCP tools.
        result = await publish_draft(
            session,
            principal,
            ticket_id,
            draft_id,
            confirmed=payload["confirmed"],
            reauthorize=reauthorize,
        )
        return JSONResponse(result, headers=HEADERS)

    return router


async def resolve_web_principal(session, employee, method):
    from ..services.access_control_service import (
        AccessControlLookupError,
        can_access_tool,
        explicit_tool_decision,
    )
    from .dependencies import _load_effective_permissions

    async def allowed(tool, write_action):
        action = "ver" if method == "GET" else write_action
        try:
            for check in {"ver", action}:
                if (
                    await explicit_tool_decision(session, employee, tool, check)
                    is False
                ):
                    return False
        except AccessControlLookupError as exc:
            raise service.BatisenalError("AUTHORITY_UNAVAILABLE", 503) from exc
        return await can_access_tool(session, employee, tool, action)

    tokens = await _load_effective_permissions(session, employee.id)
    return service.principal_from_tokens(
        employee,
        tokens,
        can_request=await allowed("soporte.self", "crear"),
        can_support=await allowed("admin.soporte", "editar"),
    )
