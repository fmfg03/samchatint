"""Telegram runtime for the internal gastos/documentos slice."""

from __future__ import annotations

import logging
from typing import Any, Dict, List
from uuid import UUID

from . import documento_telegram as gastos_tg
from .documento_workflow_service import (
    DocumentoWorkflowPermissionError,
    DocumentoWorkflowValidationError,
    transition_documento_workflow,
)
from .reimbursement_payment_run_service import (
    ensure_approved_informe_reimbursement_for_payment_run,
)

logger = logging.getLogger(__name__)


class TelegramDocumentRuntime:
    """Owns Telegram document commands/callbacks for gastos/documentos."""

    def __init__(self, gateway: Any) -> None:
        self.gateway = gateway

    async def execute_approve(self, chat_id: int, empleado: Any, doc_uuid: UUID) -> bool:
        session_maker = self.gateway._resolve_auth_session_maker()
        if not session_maker:
            await self.gateway.send_message(
                chat_id, "⚠️ No hay conexión a la base de datos."
            )
            return False
        try:
            async with session_maker() as session:
                workflow_result = await transition_documento_workflow(
                    session,
                    documento_id=doc_uuid,
                    actor_id=empleado.id,
                    action="approve",
                    surface="telegram",
                )
                reimbursement_warning = None
                try:
                    reimbursement_result = (
                        await ensure_approved_informe_reimbursement_for_payment_run(
                            session,
                            informe_doc=workflow_result.documento,
                            actor_id=empleado.id,
                        )
                    )
                except Exception:
                    logger.exception(
                        "Failed to route informe reimbursement after Telegram approval",
                        extra={"documento_id": str(doc_uuid)},
                    )
                    reimbursement_result = None
                    reimbursement_warning = (
                        "No se pudo generar automáticamente la solicitud de "
                        "reembolso."
                    )
        except DocumentoWorkflowValidationError as exc:
            if exc.code == "invalid_estado":
                await self.gateway.send_message(
                    chat_id,
                    "ℹ️ Este documento ya fue procesado o no está pendiente.",
                )
            else:
                await self.gateway.send_message(chat_id, f"⚠️ {exc.message}")
            return exc.code in {"invalid_estado", "authorization_closed_document", "workflow_locked_document"}
        except DocumentoWorkflowPermissionError as exc:
            await self.gateway.send_message(chat_id, f"⚠️ {exc.message}")
            return False
        except Exception:
            logger.exception("Telegram document approve failed")
            await self.gateway.send_message(
                chat_id,
                "❌ No se pudo aprobar. Intenta de nuevo o usa la web.",
            )
            return False
        success_msg = "✅ Documento *aprobado* correctamente."
        if reimbursement_result is not None and reimbursement_result.changed:
            success_msg += (
                "\nSolicitud de reembolso lista en programación de pagos."
            )
        reimbursement_warning = (
            reimbursement_warning
            or (reimbursement_result.warning if reimbursement_result else None)
        )
        if reimbursement_warning:
            success_msg += f"\n⚠️ {reimbursement_warning}"
        await self.gateway.send_message(chat_id, success_msg)
        return True

    async def execute_reject(
        self,
        chat_id: int,
        empleado: Any,
        doc_uuid: UUID,
        comentario: str,
    ) -> None:
        session_maker = self.gateway._resolve_auth_session_maker()
        if not session_maker:
            await self.gateway.send_message(
                chat_id, "⚠️ No hay conexión a la base de datos."
            )
            return
        try:
            async with session_maker() as session:
                await transition_documento_workflow(
                    session,
                    documento_id=doc_uuid,
                    actor_id=empleado.id,
                    action="reject",
                    comentario=comentario or None,
                    surface="telegram",
                )
        except DocumentoWorkflowValidationError as exc:
            if exc.code == "invalid_estado":
                await self.gateway.send_message(
                    chat_id,
                    "ℹ️ Este documento ya fue procesado o no está pendiente.",
                )
            else:
                await self.gateway.send_message(chat_id, f"⚠️ {exc.message}")
            return
        except DocumentoWorkflowPermissionError as exc:
            await self.gateway.send_message(chat_id, f"⚠️ {exc.message}")
            return
        except Exception:
            logger.exception("Telegram document reject failed")
            await self.gateway.send_message(
                chat_id,
                "❌ No se pudo rechazar. Intenta de nuevo o usa la web.",
            )
            return
        await self.gateway.send_message(
            chat_id,
            "✅ Documento *rechazado*. El solicitante recibirá aviso si tiene Telegram.",
        )

    async def complete_pending_reject(
        self, chat_id: int, user_id: int, text: str
    ) -> None:
        uid = int(user_id)
        raw = self.gateway._gastos_reject_pending.pop(uid, None)
        if not raw:
            return
        empleado = await self.gateway._get_authorized_empleado(user_id)
        if not empleado:
            await self.gateway.send_message(
                chat_id, "⚠️ Tu Telegram no está vinculado a un empleado activo."
            )
            return
        try:
            doc_uuid = UUID(raw)
        except ValueError:
            await self.gateway.send_message(
                chat_id, "⚠️ Identificador de documento inválido."
            )
            return
        await self.execute_reject(chat_id, empleado, doc_uuid, text.strip())

    async def send_pendientes(self, chat_id: int, user_id: int) -> None:
        """Offer pending-document details without promising decision authority."""
        empleado = await self.gateway._get_authorized_empleado(user_id)
        if not empleado:
            await self.gateway.send_message(
                chat_id,
                "⚠️ Tu Telegram no está vinculado a un empleado activo.",
            )
            return
        session_maker = self.gateway._resolve_auth_session_maker()
        if not session_maker:
            await self.gateway.send_message(
                chat_id, "⚠️ Base de datos no configurada para este bot."
            )
            return
        async with session_maker() as session:
            docs = await gastos_tg.query_pending_documentos_for_approver(
                session, empleado
            )
        if not docs:
            await self.gateway.send_message(
                chat_id, "✅ No tienes documentos pendientes por aprobar."
            )
            return
        rows: List[List[Dict[str, str]]] = []
        for doc in docs[:20]:
            label = f"{doc.numero_referencia} · {doc.tipo}"[:60]
            rows.append(
                [{"text": label, "callback_data": gastos_tg.list_detail_callback_data(doc.id)}]
            )
        await self.gateway.send_message(
            chat_id,
            f"📥 *Pendientes* ({len(docs)}). Toca un documento para ver el detalle.",
            reply_markup={"inline_keyboard": rows},
        )

    async def send_mis_solicitudes(self, chat_id: int, user_id: int) -> None:
        empleado = await self.gateway._get_authorized_empleado(user_id)
        if not empleado:
            await self.gateway.send_message(
                chat_id,
                "⚠️ Tu Telegram no está vinculado a un empleado activo.",
            )
            return
        session_maker = self.gateway._resolve_auth_session_maker()
        if not session_maker:
            await self.gateway.send_message(
                chat_id, "⚠️ Base de datos no configurada para este bot."
            )
            return
        async with session_maker() as session:
            docs = await gastos_tg.query_documentos_for_requester(session, empleado.id)
        if not docs:
            await self.gateway.send_message(
                chat_id, "No hay documentos recientes registrados a tu nombre."
            )
            return
        rows: List[List[Dict[str, str]]] = []
        for doc in docs[:20]:
            label = f"{doc.numero_referencia} · {doc.estado}"[:60]
            rows.append(
                [{"text": label, "callback_data": gastos_tg.requester_view_callback_data(doc.id)}]
            )
        await self.gateway.send_message(
            chat_id,
            f"📋 *Tus documentos* (últimos {len(docs)}). Toca uno para ver el detalle.",
            reply_markup={"inline_keyboard": rows},
        )

    async def send_solicitud_ref(self, chat_id: int, user_id: int, ref: str) -> None:
        empleado = await self.gateway._get_authorized_empleado(user_id)
        if not empleado:
            await self.gateway.send_message(
                chat_id,
                "⚠️ Tu Telegram no está vinculado a un empleado activo.",
            )
            return
        session_maker = self.gateway._resolve_auth_session_maker()
        if not session_maker:
            await self.gateway.send_message(
                chat_id, "⚠️ Base de datos no configurada para este bot."
            )
            return
        async with session_maker() as session:
            doc = await gastos_tg.find_documento_by_referencia_for_requester(
                session,
                empleado_id=empleado.id,
                referencia=ref,
            )
            if not doc:
                await self.gateway.send_message(
                    chat_id,
                    "No encontré un documento con esa referencia a tu nombre.",
                )
                return
            doc = await gastos_tg.load_documento_for_telegram(session, doc.id)
            ctx = await gastos_tg.build_documento_telegram_context(session, doc)
        text = "📄 *Tu documento*\n\n" + gastos_tg.format_documento_resumen_es(
            doc, context=ctx
        )
        await self.gateway.send_message(chat_id, text)


    async def _clear_callback_keyboard(self, callback_query: Dict[str, Any]) -> None:
        message = callback_query.get("message") or {}
        chat = message.get("chat") or {}
        chat_id = chat.get("id")
        message_id = message.get("message_id")
        if chat_id is None or message_id is None:
            return
        edit_markup = getattr(self.gateway, "edit_message_reply_markup", None)
        if edit_markup is None:
            return
        try:
            await edit_markup(int(chat_id), int(message_id), reply_markup={"inline_keyboard": []})
        except Exception:
            logger.exception("Failed to clear Telegram inline keyboard")

    async def _document_is_actionable_for_approver(
        self,
        session_maker: Any,
        empleado: Any,
        doc_uuid: UUID,
    ) -> bool:
        async with session_maker() as session:
            doc = await gastos_tg.load_documento_for_telegram(session, doc_uuid)
            return bool(
                doc
                and await gastos_tg.approver_can_see_document_in_queue_live(
                    session, empleado, doc
                )
            )

    async def handle_callback(self, callback_query: Dict[str, Any]) -> bool:
        """Allow superadmin consultation while enforcing decision authority."""
        data = (callback_query.get("data") or "").strip()
        parsed = gastos_tg.parse_documento_callback(data)
        if not parsed:
            return False
        prefix, doc_uuid = parsed
        callback_id = callback_query["id"]
        user_id = callback_query["from"]["id"]
        chat_id = callback_query["message"]["chat"]["id"]

        empleado = await self.gateway._get_authorized_empleado(user_id)
        if not empleado:
            await self.gateway.answer_callback_query(callback_id, "Sin acceso")
            await self.gateway.send_message(
                chat_id,
                "⚠️ Tu Telegram no está vinculado a un empleado activo.",
            )
            return True

        session_maker = self.gateway._resolve_auth_session_maker()
        if not session_maker:
            await self.gateway.answer_callback_query(callback_id, "Sin base de datos")
            return True

        if prefix == gastos_tg.CB_VIEW_REQUESTER:
            async with session_maker() as session:
                doc = await gastos_tg.load_documento_for_telegram(session, doc_uuid)
                if not doc or not gastos_tg.requester_can_view_document(empleado, doc):
                    await self.gateway.answer_callback_query(callback_id, "No disponible")
                    return True
                ctx = await gastos_tg.build_documento_telegram_context(session, doc)
                msg = "📄 *Tu documento*\n\n" + gastos_tg.format_documento_resumen_es(
                    doc, context=ctx
                )
            await self.gateway.answer_callback_query(callback_id)
            await self.gateway.send_message(chat_id, msg)
            return True

        if prefix == gastos_tg.CB_DETAIL_APPROVER:
            async with session_maker() as session:
                doc = await gastos_tg.load_documento_for_telegram(session, doc_uuid)
                if not doc or doc.estado != "enviado":
                    await self.gateway.answer_callback_query(callback_id, "No disponible")
                    return True
                can_decide = await gastos_tg.approver_can_see_document_in_queue_live(
                    session, empleado, doc
                )
                is_superadmin = (
                    (getattr(empleado, "rol", "") or "").strip().lower()
                    in gastos_tg.SUPERADMIN_ROLES
                )
                if not can_decide and not is_superadmin:
                    await self.gateway.answer_callback_query(callback_id, "No disponible")
                    return True
                ctx = await gastos_tg.build_documento_telegram_context(session, doc)
                body = gastos_tg.format_documento_resumen_es(
                    doc,
                    context=ctx,
                    include_actions_hint=can_decide,
                )
                msg = "📋 *Detalle para aprobación*\n\n" + body
                kb = gastos_tg.approval_inline_keyboard(doc.id) if can_decide else None
            await self.gateway.answer_callback_query(callback_id)
            await self.gateway.send_message(chat_id, msg, reply_markup=kb)
            return True

        if prefix == gastos_tg.CB_APPROVE:
            async with session_maker() as session:
                doc = await gastos_tg.load_documento_for_telegram(session, doc_uuid)
                if not doc or not await gastos_tg.approver_can_see_document_in_queue_live(
                    session, empleado, doc
                ):
                    await self.gateway.answer_callback_query(callback_id, "Ya no está pendiente")
                    await self.gateway.send_message(
                        chat_id,
                        "ℹ️ Este documento ya no está pendiente para tu aprobación. "
                        "Si volvió a revisión después de un rechazo de Finanzas, abre /pendientes para tomar la versión vigente.",
                    )
                    return True
            await self.gateway.answer_callback_query(callback_id, "Procesando…")
            should_clear = await self.execute_approve(chat_id, empleado, doc_uuid)
            if should_clear:
                await self._clear_callback_keyboard(callback_query)
            return True

        if prefix == gastos_tg.CB_REJECT:
            if not await self._document_is_actionable_for_approver(session_maker, empleado, doc_uuid):
                await self.gateway.answer_callback_query(callback_id, "Ya fue procesado")
                await self._clear_callback_keyboard(callback_query)
                await self.gateway.send_message(
                    chat_id,
                    "ℹ️ Este documento ya no está pendiente para tu aprobación. "
                    "Usa /pendientes para ver solo las solicitudes vigentes.",
                )
                return True
            self.gateway._gastos_reject_pending[int(user_id)] = str(doc_uuid)
            await self.gateway.answer_callback_query(callback_id)
            await self._clear_callback_keyboard(callback_query)
            await self.gateway.send_message(
                chat_id,
                "✏️ Escribe el *motivo del rechazo* en el siguiente mensaje.\n"
                "Para cancelar sin rechazar, envía `/cancel` (si no tienes otra acción pendiente del asistente).",
            )
            return True
        return False
