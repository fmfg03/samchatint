# SamChat Engineering Canon for ChatGPT

Version: 2026-09-10

Repository: `fmfg03/samchatint`

Repository baseline inspected: `main` at `7684713cc2e529b8f48768553cd1acc6f7e1e39b`

Purpose: reason about SamChat as an engineering system. This is not a product pitch, a deployment receipt, or a substitute for inspecting the target code before a change.

## 1. Primary rule

SamChat is one repository with several non-equivalent runtimes, business domains, persistence patterns, and maturity levels.

Never reason about “the SamChat app,” “the SamChat database,” or “the SamChat auth system” without naming the target surface.

## 2. Evidence levels

Keep these levels separate:

1. `proposal`: promised or described in the 2025 SOW.
2. `planned`: accepted direction without connected runtime evidence.
3. `coded_not_wired`: code exists but has no live route, tool, UI, permission, or owning workflow.
4. `repo_live`: connected in current `main` through code plus route/tool/UI/test evidence.
5. `deployed_verified`: observed in the active production release with health and workflow evidence.
6. `business_accepted`: validated by the owning user group through UAT or explicit acceptance.

Code in `main` is not automatically deployed. Deployed code is not automatically accepted. A proposal is never implementation evidence.

## 3. Canonical runtime order

When the user does not name a runtime, use this order:

1. Live `sam.chat` web work: `copa_telmex_dashboard.py`.
2. Gastos, finance, operations, admin, users, support, and webhooks: `src/devnous/gastos/` as mounted by the live web runtime.
3. Governed assistant: `src/samchat/assistant/`, mounted by the live web runtime.
4. Tournament registration and review: dashboard routes plus `src/devnous/copa_telmex/`, `src/devnous/tournaments/`, and `src/samchat/tournaments_v2/` as applicable.
5. Generic DevNous API: `src/devnous/api.py`.
6. CLI: `src/samchat/main.py`.
7. MCP platform/demo: `mcp_platform_launcher.py`.
8. Nested applications such as `copatelmex/`, `goal-fest-page/`, and `samchat-mvp/`: separate scope.

The production service declared by the repository remains `samchat-gastos.service`, launching:

```text
uvicorn copa_telmex_dashboard:app --host 127.0.0.1 --port 8000
```

## 4. Current live-web composition

`copa_telmex_dashboard.py` is a composite FastAPI application. Current repository evidence shows it mounts:

- session middleware;
- auth routes;
- admin routes;
- user routes;
- support routes;
- webhook ingress under `/ingress`;
- the assistant router;
- health and readiness endpoints;
- registration review, team, and player operations.

Default consequence: changes to this runtime can affect real financial, authorization, tournament, or evidence workflows.

## 5. Canonical product lanes in current `main`

| Lane | Canonical owner | Current repository status |
| --- | --- | --- |
| Documentos, gastos, approvals, payments | `src/devnous/gastos/` | `repo_live` |
| Registration and OCR review | `copa_telmex_dashboard.py`, `src/devnous/copa_telmex/`, OCR services | `repo_live` |
| Governed assistant | `src/samchat/assistant/` | `repo_live`, predominantly read-only/proposal-first |
| Finance command center | `src/samchat/finance_platform/` plus admin routes | `repo_live` |
| Presupuestos | `src/samchat/budgets/` plus `admin_budget_routes.py` | `repo_live` |
| Accounts receivable | `src/samchat/ar/` plus `/admin/finanzas/cuentas-por-cobrar` | `repo_live`; business UAT still unproven |
| Cashflow planning | `src/samchat/cashflow/` plus `/admin/finanzas/cashflow` | `repo_live`; read-model/UI |
| Payment Run | payment services plus `/admin/finanzas/payment-run` | `repo_live`; business UAT still unproven |
| Sam Inbox | `src/samchat/sam_inbox/` plus `/admin/sam-inbox` | `repo_live`; read-only projection |
| Runtime artifact index | `src/samchat/artifacts/` plus `/admin/artifacts` | `repo_live`; discoverability only |
| Sports/owner projections | `src/samchat/sports_platform/` and assistant owner-pack modules | mixed: connected read models, incomplete source coverage |
| Sponsor approval/proof workflow | `src/samchat/sports_platform/sponsor_media.py` | model/projection exists; persistent end-to-end workflow is not proven |

## 6. Data boundaries

SamChat is hybrid.

### Direct Postgres paths

Strong signals include:

- `DATABASE_URL` in the live dashboard;
- `POSTGRESQL_URL` in DevNous configuration;
- SQLAlchemy models and sessions in gastos, assistant, finance, budgets, AR, cashflow, accounting, payroll, and registration review;
- direct SQL used by operational services such as Payment Run.

### Supabase-dependent paths

Strong signals include:

- `src/samchat/tournaments_v2/supabase_client.py`;
- `src/devnous/tournaments/core/supabase_sync.py`;
- assistant bridge/query paths that still consume Supabase semantics;
- nested applications with Supabase auth, functions, or migrations.

### Required behavior

Before changing schema, reads, writes, or auth:

1. name the runtime;
2. name the owning domain;
3. identify direct Postgres, Supabase, or hybrid behavior;
4. identify the canonical write owner;
5. identify migration and rollback requirements.

Do not create a new persistence path when a canonical service already owns the workflow.

## 7. Auth and authority boundaries

The live runtime combines several identity mechanisms; they are not interchangeable:

- internal signed session cookie and `empleados` identity;
- role and permission checks for admin, finance, accounting, operations, and superadmin functions;
- a Supabase-to-local assistant auth bridge;
- Telegram authorization through `telegram_user_id`;
- explicit employee/position configuration for selected payment and approval paths.

High-risk actions require more than a visible button or tool definition. Verify:

- current employee identity;
- role and effective permissions;
- project/position-specific authorization route;
- beneficiary constraints;
- explicit confirmation when the assistant is involved;
- idempotency and an audit receipt.

### 7.1 Direction executive boards and reports

Date: 2026-09-11

Reason: this amendment governs the pending correction to #314 and #315 from a
customer-role interpretation to an internal Direction authority surface. The primary routes are
`/direccion/tableros` and `/direccion/reportes`; temporary legacy GET
redirects do not retain a customer-facing authorization or write API.

The non-superadmin authorization contract is position-scoped, not role-scoped:

1. the session resolves to an active internal `empleado`;
2. the employee has an active assignment to one of
   `direccion_general`, `direccion_administracion_finanzas`,
   `direccion_goat`, or `director_operaciones`;
3. that position is actively mapped to a portfolio, and the requested
   tournament/report belongs to that active assigned scope.

`superadmin` has supervision over active portfolios. `admin` does not receive
global access merely by role. The `cliente` role is neither a prerequisite nor
an authorization concept for these surfaces. Specific permissions may restrict
actions within the surface, but never create portfolio or tournament scope or
substitute the eligible position. There is no global fallback for
position-scoped employees.

Executive board and published-report consumption are read-only within assigned
scope. Report schedule configuration, draft creation and state transitions are
internal governed writes requiring their specific authority and audited actor.
Eligible Direction positions may consume cross-domain executive reads from
Operations, Finance, and Marketing, but every read must remain constrained to
the active portfolios and tournaments already resolved by the Direction guard.
This cross-domain visibility never delegates the owning domain's create,
modify, approve, pay, publish, or delete authority. A specific denial prevails.
Read models must use canonical domain sources, distinguish unavailable from
zero, and must not manufacture missing people, events, amounts, dates, or
relationships. Personal contact fields must not be emitted in URLs, logs,
metrics, exception details, or general-purpose exports.

The physical `client_*` tables, package names, and route-module filenames are
temporary compatibility debt. Do not rename them in this correction; a
separate migration, compatibility inventory, rollback plan, and approval are
required.

Evidence: the Direction authorization correction is deployed at
`06ff7d9f5bb5af85b9ae3360e66d527aec62e1a0`, and active portfolio/tournament
scope is configured for the eligible positions. The expanded dashboard slice
reuses the strict budget snapshot and tournament SOUL/entity dossier, exposes
explicit gaps, and adds aggregate age without exposing individual player birth
dates. It remains repository work under review until merge, and is neither
`deployed_verified` nor `business_accepted` for this expanded scope.

## 8. Canonical financial workflow invariants

### 8.1 Document states are business state

`Documento.estado` is not presentation metadata. It drives queues, permissions, Payment Run eligibility, rejection behavior, and history.

Do not infer a payment status from a fallback label. Derive it from the canonical document state, payment evidence, and cutoff membership.

### 8.2 Budget control occurs once for approved expense-report reimbursements

Business rule:

- an `INFORME` requiring budget classification must receive its budget concept before final approval;
- a reimbursement `SOLICITUD` derived from that approved, classified `INFORME` inherits the budget concept and approver;
- the derived reimbursement must not repeat Control Presupuestal;
- it can enter Programación de Pagos only when the linked `INFORME` is approved and actually has a budget concept.

Repository status at this baseline:

- PR #303 is merged and recovers eligible reimbursements stuck in `control_presupuestal`;
- PR #306 is merged and prevents ineligible requests from appearing as falsely `programada` in payment history;
- PR #304 merged and deployed as `dcbeea8423030e0123101a35378d765ea3c96f32`;
  it adds the explicit guard that the approved linked `INFORME` must itself have
  `budget_concept_id` before auto-promotion.

Do not describe the safety invariant as business-closed until the historical
reconciliation, affected-reference verification, and Finance UAT are evidenced.

#### 8.2.1 One COI policy per expense report

For COI export, the canonical grouping key is the owning `INFORME`, not the
individual `ExpenseReport` row. All active expenses owned by one `INFORME`
share one policy header and one `FIN_PARTIDAS` closure while preserving each
expense's movement lines, tax splits, and CFDI block.

The document, preview, monthly batch, consolidated workbook, and ZIP paths must
use the same grouping contract. A per-expense download must resolve and redirect
to the owning `INFORME` when one exists. Standalone third-party requests remain
ungrouped unless their owning workflow defines a separate document policy.

An `INFORME` export fails closed when any active expense is not COI-ready.
Expense dates in different accounting months do not by themselves block a
normal report. The failure must not
emit a partial policy or update any expense to `contabilizado`. Successful batch
status updates apply to all included report expenses in one transaction.

Amendment date: 2026-10-05. Reason: explicit human approval to remove the
cross-month restriction and address PR #458 review findings. Monthly COI and
Finance discovery use the same canonical policy period: `Documento.aprobado_en`
for normal reports, and the immutable initial `AmexAccountingCut.accounting_date`
for company-AMEX reports. Both include all active items under one complete
policy, even when expense dates differ from the discovery period. Missing
approval dates or AMEX cuts stay visible as blockers in expense-period discovery
and never authorize a partial or fallback export. AMEX exports must use
`cut_expense_cfdis`, preserving existing cut-creation and evidence controls.
Evidence: shared predicates in `expense_coi_export_service.py`, route integration,
SQL-backed period-selection tests and frozen-cut regression tests in
`tests/unit/gastos/test_coi_exportable_status_ui.py`. These are approved source
changes under PR review; deployment and authenticated UAT remain unproven.

Amendment date: 2026-10-13. Explicit human approval of technical specification and this canon text. Reason: use the approved expense account as accounting source without repeating its comprobacion. Evidence: `docs/roadmap/amex-approved-informe-20261013-spec.md` and its approved story. Approved candidate; implementation validation, merge, deployment and Finance UAT remain pending.

Reconocimiento conserva un origen exacto statement/report con una sola ancla válida. Report-first mantiene UUID de consumo, representación report, evidencia real de aprobación y confirmación financiera/versiones; no fabrica UUID importado. Captura de evidencia operativa ocurre en la transacción de aprobación final; preview es puro y confirmación/corte Finance es atómica, idempotente por huella completa de fuente, decisiones, fecha/periodo y evidencia.

Asociación bancaria posterior usa header real statement/report_bridge, ancla importada única y asociaciones INSERT-only a consumos report-first plenamente reconocidos. Selección explícita valida economía exacta y conjunto completo; no matching heurístico ni fusionar identidades o cortes. Header bridge nunca postea, incluso sin hijos. Ownership y exclusión legacy/bridge se protegen mediante constraints y guard triggers parent/child, sin mutación/borrado de anclas económicas ni asociaciones. Importación no origina segundo gasto/póliza. Schema nuevo sólo se provisiona con migración autorizada; helpers/runtime no ejecutan DDL.


Amendment date: 2026-10-13. Explicit human approval of the technical specification and exact canon text. Reason: a clear statement-to-policy workflow and separation of report attention from AMEX manual queues. Evidence: `docs/roadmap/amex-statement-workflow-20261013-story.md` and `docs/roadmap/amex-statement-workflow-20261013-spec.md`. Approved implementation scope; merge, owner-run migration, deployment and authenticated Finance UAT require their own receipts.

El recorrido AMEX conserva imports e items con archivo exacto, tarjeta, titular, período y actor declarados; replay de importación no crea cargos adicionales. Tablas y guards se provisionan mediante migración owner-run, excluida de startup. Una política de presentación por UUID de beneficiario explícito se comparte entre descubrimiento, selectores y contadores, sin alterar owners financieros ni cubrir conflictos de identidad con fallbacks al capturista. Vínculos de navegación usan FK a cortes reales y guardan confirmación/payload; no sustituyen AmexReportBankAssociation. Confirmación y link por INFORME son transaccionales, con decisiones y source/version actuales; exportación usa snapshots completos sin cambios de granularidad. Cargos sin fuente aprobada permanecen bloqueados para generación independiente. Datos financieros/históricos y límites de permisos se preservan.

Amendment date: 2026-10-14. Explicit human approval of the technical specification and exact canon text on 2026-10-15. Reason: direct statement/SAT-to-budget/accounting workflow without a fabricated expense report. Evidence: `docs/roadmap/amex-sat-budget-direct-20261015-spec.md` and its approved story; implementation, migration, merge, deployment and Finance UAT remain separate gates.

El origen AMEX directo se autoriza mediante revisiones append-only de contexto fiscal declarado y fuente original privada de bytes/signo/perfil verificables, evidencia de matching/status, clasificación, asignación y corte propios, sin simular Documento o retirar guards de los owners INFORME. Comparte identidad económica/uniqueness y exclusión cross-source con statement/report/bridge; modo direct exige proof de corte y journal reales. Snapshots, decisiones, membership y receipts reconocidos son inmutables; locks y constraints evitan doble reconocimiento entre fuentes. Presupuesto proyecta cargos reales sin Documento y resuelve mapping desde la partida, con pasivo de tarjeta; pending y journal no duplican gasto. Consultas SAT se reutilizan acotadas y auditadas, sin inferir vigencia de descarga ni ampliar credenciales/downloads. Schema se instala mediante owner-run migration explícita y no startup DDL. Exportación directa utiliza snapshots completos preservando contratos y cortes INFORME existentes.

#### 8.2.2 Monthly DIOT read contract

Amendment date: 2026-10-09. This canon diff received explicit human approval.
The connected monthly DIOT read owner is `monthly_diot_service.py`; the existing
`diot_exporter.py` remains the fiscal-row and TXT/XLSX renderer. Period
resolution uses `Documento.fecha_pago_efectiva` from a direct paid-document link
first, then only a unique paid `SOLICITUD` date on the same `CuentaDeGastos`.
Missing or ambiguous dates must not be guessed.

The monthly TXT route fails closed on in-period fiscal blockers. The audit XLSX
remains available and carries separate blocker and undated queues. Active,
non-reversal expenses are the only candidates. Reused CFDIs require complete
shared-invoice confirmation and a valid aggregate application; confirmed shares
are prorated by applied fiscal amount. IVA withholding comes exclusively from
the CFDI XML `retenciones` detail. No new persistence path, migration, background
job, SAT submission, or financial write is introduced.

Evidence: isolated worktree based on `7d857ad326a`, focused tests, route import
verification, and read-only production classification. Merge, deployment,
authenticated Finance UAT, and business acceptance remain unproven.


### Proposed 2026-10-06 amendment: partial paid-advance comprobaciones

Requires explicit human PR review. Reason: Francisco requests applicant-confirmed
motives, approver comments, an open original report until zero, and incremental
accounting without duplicate recognition. This proposal does not establish
production or business acceptance.

For an open, unapproved, non-AMEX report with an actually paid advance and its
existing debtor posting, the applicant may explicitly submit the newly captured
expenses as a child `INFORME`. The original report remains an open case container;
it must never be approved or exported again in partial mode. Each child owns
only its explicitly assigned expenses and retains its confirmed applicant motive.
The authorized approver must read that motive and record comments. Budget-control
and accounting-readiness gates still apply. Each approved child has its own
idempotent debtor recognition and one atomic COI policy in its approval month.
Previously approved expenses cannot be reassigned or mutated; corrections require
accounting reversal rather than overwriting recognized evidence.

Actual, evidenced advance returns reduce the same collaborator debtor balance.
Repeated submissions reuse the original result; additional returns require new
submission identities. The original closes only when all children are approved,
no active expenses remain unassigned, and the persisted debtor auxiliary is zero.
Ordinary full reimbursement and company-AMEX immutable-cut rules remain intact.

Evidence: `docs/roadmap/partial-advance-comprobaciones.md`, scoped implementation,
SQLite-backed workflow/ledger tests and isolated PostgreSQL/WASM migration tests.
No production migration, deployment, authenticated UAT, or historical mutation
has been performed.

### 8.3 Payment Run

Canonical states visible to Payment Run are:

- `aprobado` and unpaid: eligible to schedule/close;
- `en_proceso_pago`: inside a closed operational cutoff and awaiting payment proof;
- `pagado` or `pagado_en` present: paid history.

Requests in `borrador`, `enviado`, `control_presupuestal`, or `rechazado` are not scheduled payments.

Closing a Payment Run is an operational cutoff. It does not by itself prove that money moved. Payment proof/confirmation is a separate authority step.

### 8.4 Accounts receivable

AR is not the inverse of AP and must not reuse Payment Run semantics.

Canonical AR separation:

- expected income;
- issued CFDI;
- approval of the income/CFDI link;
- accepted collection match;
- accounting entry for CxC;
- accounting entry for collection;
- reversal with audit trail.

Candidate bank movements do not prove collection. `ar_collection_matches` is the accepted-match authority in current code.

### 8.5 Cashflow

Cashflow must keep separate:

- actual bank cash;
- approved AP obligations;
- budget plan;
- issued or expected income;
- collection proven through accepted AR matching;
- derived forecast.

Never label forecast or a collection candidate as actual cash.

## 9. Assistant engineering contract

The product model follows a governed Claude Code-style work loop:

1. understand the business objective;
2. load relevant current context;
3. create or resume a case when continuity matters;
4. select candidate tools using semantic metadata;
5. execute reads under policy;
6. test answer sufficiency;
7. render evidence, gaps, and proposed actions;
8. show a preview/business diff for any intended write;
9. obtain explicit authority;
10. execute idempotently and return a receipt.

The assistant is the primary conversational work interface, but it is not a parallel source of financial or tournament truth.

Current safe default: read, investigate, compare, summarize, draft, preview, and export where a connected contract exists. Writes require the owning canonical action plus policy, authority, confirmation, and audit.

## 10. Tournament and OCR boundaries

Registration review is a governed intake path with session, asset, draft, reprocess, adjudication, and commit concepts.

Preserve these distinctions:

- generated OCR data;
- human-reviewed data;
- validated draft;
- committed team/player state;
- post-commit authority and incident evidence.

Minimum roster eligibility, duplicate-photo detection, tournament scope, and blocking incident policy must be recalculated at commit time. Do not insert a player with a blocking incident as eligible downstream.

External FMF verification is not proven merely because a rule, route name, or mock API exists.

## 11. Schema and migration rules

- Production web startup must not become an uncontrolled schema-owner process.
- Owner-run migrations must be explicit, idempotent where feasible, backed up, and verified before application deployment.
- Runtime `ensure_*_schema` helpers are not blanket authorization for new DDL.
- Backfills default to dry-run and must require explicit selectors, actor, and apply confirmation.
- Any repair that changes financial or authorization state needs a recovery snapshot or equivalent audit evidence.

## 12. CI and release truth

Current repository evidence contains two GitHub workflow files:

- `.github/workflows/assistant-scoped-gate.yml`;
- `.github/workflows/test.yml`.

There is no `.github/workflows/nightly.yml` at the inspected baseline. Therefore, a three-level Fast PR / Main / Nightly architecture is not current repo truth.

The assistant-scoped workflow currently runs on both pull requests and pushes to integrated branches. At PR #350 head under review on 2026-09-19, the Test Suite is Python 3.12-only because the repository uses PEP 701 syntax; it directly runs the complete unit and integration suites, applies an exact accepted-failure baseline for the documented unit debt, enforces 85% changed-code coverage, and makes pip-audit plus the exact high-confidence Bandit baseline blocking. The aggregate `Test Suite / Required PR gate` is the intended stable protection check after it is observed successfully on `main`. This is repository work under review, not deployment or business-acceptance evidence.

Production deployment is governed by one active systemd drop-in:

```text
/etc/systemd/system/samchat-gastos.service.d/50-current-release.conf
```

Release validation must confirm:

- exact deployed commit;
- one active drop-in;
- correct `WorkingDirectory`;
- release guards;
- `/healthz` and `/readyz`;
- no restart loop;
- a focused workflow smoke for the changed domain.

## 13. Source hierarchy

When sources disagree, use this order:

1. observed production runtime behavior and exact deployed commit;
2. runtime entrypoint and owning service code on that commit;
3. repository `AGENTS.md` and explicit SSOT documents;
4. routes, models, migrations, tests, and release guards;
5. accepted UAT evidence;
6. subsystem docs;
7. roadmap and closeout docs;
8. root README marketing sections;
9. SOW claims as scope evidence only.

## 14. Default answer protocol

For any SamChat question:

1. state the target runtime;
2. state the target domain;
3. state the data boundary;
4. state the evidence level: proposal, code, deployed, or accepted;
5. identify the canonical read and write owners;
6. state missing evidence;
7. only then recommend or implement.

## 15. Forbidden assumptions

Do not assume:

- `main` is deployed;
- a route proves a complete end-to-end workflow;
- a passing unit test proves production data correctness;
- the root README describes the live product accurately;
- all persistence is Postgres or all persistence is Supabase;
- assistant memory can override live data or policy;
- a closed Payment Run means paid;
- an AR candidate means collected;
- a generated sponsor package means external publication occurred;
- contractual KPI targets are measured outcomes;
- a code repair has corrected production records before deploy and reconciliation.

## 16. Safe short summary

SamChat is a multi-surface repository centered on the `copa_telmex_dashboard.py` FastAPI runtime under `samchat-gastos.service`. Its active product spine combines governed gastos/document workflows, Payment Run, budgets, AR, cashflow, Sam Inbox, tournament/OCR operations, and a read-mostly assistant. Persistence and identity are hybrid. Every answer must distinguish proposal, current repository code, verified deployment, and business acceptance. Financial and tournament writes must use canonical services with explicit authority, idempotency, audit, and evidence.

## 17. Final rule

When a clean product narrative conflicts with code, deployed behavior, or business evidence, preserve the conflict and state it explicitly.

## 18. Direction report scope amendment

Date: 2026-10-02. Proposed for explicit human review in the report redesign draft
PR, implementing Francisco's explicit 18:27 UTC authorization for SUPERADMIN.

For read-only Direction surfaces, SUPERADMIN may resolve all active rows of the
current installation's local `tournaments` catalog without manufacturing portfolio
assignments. The present local schema has no cross-organization tournament
directory; this exception must never become a global external-catalog fallback.
If the installation becomes multi-tenant, this read needs an explicit tenant
predicate before it may be reused. Position/cartera rules for other profiles,
explicit source/action denials, publication and financial write authority remain.

One, several or all authorized tournament UUIDs define the signed context. Every
ID is validated before source reads and revalidated for Sam and PDF/XLSX. Changing
the resolved all-selection invalidates an old context. Documentary facts are read
independently of budget versions via the budgets-owned fiscal-base helper and the
gastos-owned payable-amount resolver, using a set-scoped read per source and
identity deduplication. Missing amount, currency, attribution, shared allocation,
date and truncation coverage are source-specific; no budget artifact fallback
supplies factual values. No DDL or financial state writes are introduced.

Evidence level: isolated implementation and synthetic verification, pending draft
PR review. Production reconciliation, deployment and business UAT are not implied.

## 19. Copa Telmex registration PostgreSQL candidate amendment

Date: 2026-10-05

Reason: human-approved first delivery of registration read-source consolidation; preserve the distinction between local candidate, production activation, and canonical intake. The final diff and this amendment were explicitly approved in the conversation.

El candidato de primera entrega de inscripción incorpora `copa_telmex_tournament_editions` mediante migración explícita, y una proyección compartida de solo lectura en `registration_read_model.py`. La resolución exige identidad exacta y edición inequívoca; fuente fallida, ámbito ausente, inactivo o ambiguo producen estados explícitos. Para ediciones configuradas, la lectura precede al enrutamiento heredado y no tiene fallback silencioso al roster Supabase. SOUL admite exclusión de inscripción antes de consultar equipos, jugadores, responsables y registros, manteniendo otros dominios. La proyección ejecutiva no expone datos personales individuales. La migración no se aplica en startup. El reconciliador del piloto es local y no concede aprobación, elegibilidad ni efectos de escritura en bases.

Evidence: `docs/roadmap/ctt-postgres-registration-first-delivery.md` and its scoped test and review receipts. This is an isolated-worktree candidate; merge, deployment, data application, authenticated UAT, and business acceptance remain separate.

## 20. Copa Telmex governed batch-admission candidate amendment

Date: 2026-10-06

The candidate adds owner-migrated batch, document-binding, and team-staff tables.
Runtime `create_all` excludes all three. Manifest validation recomputes immutable
source, payload, page, and staff-evidence identities before persistence. Batch and
session UUIDs are deterministic; atomic insert plus batch-row locking serializes
concurrent retries. Rollback refuses destructive schema removal after admitted
documents or staff records exist. The authenticated endpoint renders only declared
PDF pages and writes registration-review drafts with `human_reviewed=false` and
`canonical_import_ready=false`. The existing team commit path remains blocked for
staff-bearing drafts because no current Zaubern receipt authorizes ordered staff
slots.

Evidence: `docs/roadmap/ctt-pilot-batch-admission.md`, focused unit and regression
tests, and isolated PostgreSQL migration/constraint/rollback tests. This remains
repository evidence under review, not deployment, data admission, UAT, or
business acceptance.


### AMEX directo: recuperación auditada de cobertura temporal

Fecha: 2026-10-15. Texto y especificación técnica aprobados explícitamente por el usuario con «aprobada». Razón: corregir cargos omitidos por período conservando fuentes y controles financieros. Evidencia: `docs/roadmap/amex-qa-remediation-20261015-spec.md`, sección 9, y assessment QA asociado. Candidato aprobado para implementación; migración, aplicación productiva, promoción y UAT mantienen sus propios checkpoints.

La recuperación acotada de período utiliza revisiones y recibos append-only vinculados a las filas originales omitidas, con una única relación de fuente efectiva compartida por Python y guards SQL. Los headers, originales, membresía física y anclas existentes permanecen inmutables; sólo se crean anclas para cargos demostrados antes no importados. Matching, vigencia, presupuesto, reconocimiento, unicidad fiscal y freeze resuelven la misma fuente efectiva. El corte conserva cobertura total y evidencia de la revisión. Versiones, locks y constraints rechazan correcciones concurrentes incompatibles, fuentes ajenas, doble reconocimiento y recuperación después de un corte. El esquema se instala mediante migración owner-run explícita y no permite downgrade operativo a código que ignore recuperaciones existentes.
## 21. Approved budget distribution revision rules

Date: 2026-10-14. Human approval: Francisco, evidence
`Sentinel_e34dca62ad888191ae00a160c9ee5b09`. Reason: reconcile weekly planning
and executive period reads while preserving authorized budget history.
Evidence: `docs/roadmap/budget-distribution-20261014-candidate.md`.

Una revisión de distribución puede sustituir al presupuesto activo, incluso
congelado, únicamente al aprobarse con las mismas partidas e importes y con
las semanas conciliadas al total. El original conserva su historial; otro
ajuste requiere otra revisión. Cada semana se asigna al mes en que empieza;
el acumulado incluye completo el mes seleccionado. Las 26 categorías fijas
quedan en N/D hasta que Finanzas confirme qué partidas corresponden a cada
una. La tabla por partidas reales sí muestra los periodos.

The candidate keeps the owning budgets services and existing permissions;
approved successor selection is explicit rather than an arbitrary replacement
of a frozen source. Missing planning evidence stays missing. No production
write, merge, deployment or business acceptance follows from these rules.
Git publication is separately authorized by
`Sentinel_a80479c5cb1081919315d4fa293a5777`. Finance crosswalk and authenticated
UAT remain pending; economic replacement and retirement need separate design.


### AMEX: sugerencias y cancelación de cuenta de gastos

Fecha:2026-10-20. Especificación y texto exacto aprobados explícitamente por el usuario mediante «aprobada». Razón: sugerencias de CFDI y contabilización sin duplicidades según la política operativa indicada por Plataforma Sports. Evidencia: `docs/roadmap/amex-suggestions-settlement-20261020-story.md` y `docs/roadmap/amex-suggestions-settlement-20261020-spec.md`, sección10. Estado: implementación autorizada; pruebas, validación, publicación, migración, despliegue y aceptación financiera conservan evidencia y checkpoints separados.

Sugerencias DIRECT son lecturas fiscalmente acotadas y explicables, sin descarga, reserva o asignación automática por semejanza. Confirmación revalida fuente/versiones, XML, autoridad, vigencia y uso mediante los owners canónicos. Corte versionado conserva método de pago, evidencia de complemento y política aplicada a las tarjetas autorizadas de Plataforma Sports. Cancelación de cuenta de gastos exige asignaciones append-only a créditos reales de líneas contables históricas con identidad y residual exactos; no usa saldo auxiliar agregado ni cuenta inferida por nombre. Póliza, cancelaciones, cobertura bancaria y corte comparten transacción y constraints de unicidad/noexceso; pasivo ya reconocido no se genera de nuevo. Guards y esquema sólo cambian mediante migración owner-run explícita y metadata-contract verificado. Los snapshots reconocidos se exportan inmutables y una asociación report_bridge nunca se vuelve asiento por sí sola.


### AMEX directo: declaración explícita Sin CFDI

Fecha:2026-10-21. Texto exacto y especificación aprobados por el usuario mediante «aprobada». Razón: resolver cargos nuevos que no tendrán CFDI sin fabricar evidencia fiscal. Evidencia: `docs/roadmap/amex-no-cfdi-20261021-story.md` y `docs/roadmap/amex-no-cfdi-20261021-spec.md`, §10. Estado: construcción y pruebas autorizadas; validación final, publicación, migración, despliegue y aceptación financiera requieren sus propios recibos.

Sin CFDI se representa mediante decisiones append-only, cabeza actual versionada y vínculo real del miembro de corte a su declaración. La cobertura new_no_cfdi comparte los owners de fuente bancaria, presupuesto, consumo, póliza y exportación; exige fuente/contexto vigentes, autoridad y motivo, presupuesto/mapping y movimientos exactos de gasto/pasivo sin identidad ni líneas fiscales inventadas. Guards y transacción impiden tratamientos simultáneos, cobertura parcial, doble reconocimiento y mutación de evidencia final; la rama new conserva íntegramente su contrato CFDI. Esquema e integridad se provisionan mediante migración owner-run y metadata-contract exacto, nunca DDL de startup ni reparación histórica implícita.


## Corrección auditada de signos AMEX directo

Date: 2026-10-22

Reason: explicit human approval of the sign-correction specification and this exact amendment. Evidence: `docs/roadmap/amex-sign-correction-20261022-story.md` and `docs/roadmap/amex-sign-correction-20261022-spec.md`.

Approved design, 2026-10-22: AMEX DIRECT sign-profile corrections preserve the original statement file, import receipts and physical source fields. A dedicated append-only revision may supply the effective movement type and expense anchor only for an unrecognized, unclassified statement with no incompatible fiscal, payment, budget or accounting dependencies. The operation requires the owning financial authority, exact-source preview, confirmation, idempotency, audit and atomic application. Expense anchors created under the superseded interpretation must be cancelled with traceability; corrected debits receive their own anchors through the expense owner. All matching, budget and accounting consumers must use the same effective revision. No automatic correction, trigger bypass, historical backfill or new fiscal classification is authorized. This amendment records approved design only; implementation, deployment and Finance acceptance require their own evidence.
