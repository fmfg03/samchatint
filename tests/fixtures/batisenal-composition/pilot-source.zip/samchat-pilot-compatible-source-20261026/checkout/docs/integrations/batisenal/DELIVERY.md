# Entrega MCP inerte: composición y límites

2026-10-24. Estado `coded_not_wired`. Extiende `TRANSPORT.md`; no monta rutas ni crea servicios. La implementación aislada está autorizada; la aceptación del alcance del piloto no autoriza activación.

## Fuentes y contratos

- `src/samchat/batisenal_transport/callback.py`: HTTPS con resolución pública validada completa, conexión a IP numérica fija, SNI/verificación de certificado del host original, sin redirects/proxy, timeout total máximo 10 s; challenge firmado con eco exacto. HMAC SHA-256 sobre bytes `id.timestamp.body`, cabeceras Standard Webhooks y `X-MCP-Subscription-Id`; máximo 256 KiB. Respuesta HTTP limitada a 4 KiB; chunked se rechaza de manera segura.
- `contracts.py`: `ConnectionResolver` verifica credencial y devuelve referencia request-local; `SecretVault` persiste versiones inmutables y recupera referencias opacas. Son interfaces, **no implementaciones OAuth/vault reales**. Sus concreciones requieren inventario del host y aprobación; no usar fixtures fuera de tests.
- `delivery_store.py`: SQLite operacional propio, leases de 30 s, fencing, máximo tres intentos, pausas 5/10 s, recibos append-only incluso tras crash; reanudación explícita, no bucle. Rotación admite dos claves durante 300 s y rechaza una tercera durante esa ventana. La ventana es configuración conservadora del candidato y debe cotejarse con el receptor real antes de activar.
- `delivery.py`: `Sender.once()` hace una entrega autorizada; revalida identidad/suscripción tras DNS y tras TLS justo antes de escribir. Rotación concurrente interrumpe sin enviar y permite reintento acotado. Revocación detiene. HTTP 2xx significa recepción, nunca análisis, resolución ni respuesta del agente. Timeout/cancelación pueden significar entrega incierta; reintentos conservan eventId/bytes y renuevan firma. El receptor debe deduplicar y soportar desorden.
- `events.py`: pasa el ID canónico de suscripción a la verificación firmada antes de persistir suscripción. La cola se llena por `enqueue_case` explícito autorizado. No hay hook atómico en commit de negocio, daemon ni scheduler.

Contrato consultado en la fase de construcción: [MCP Events](https://developers.openai.com/plugins/build/mcp-events), [autenticación](https://developers.openai.com/plugins/build/auth), [Standard Webhooks](https://github.com/standard-webhooks/standard-webhooks/blob/main/spec/standard-webhooks.md). La prueba usa red fake: no verifica interoperabilidad con un receptor oficial.

## Dependencias y migración

Base exacta del delta: `23990d55de19c9df70802307e0fd0b4538e61348`, que incorpora los candidatos previos de Batiseñal, correcciones, retirada y transporte. No aplicar a un checkout original sin reconciliar esa cadena.

Owner de lectura/escritura de casos: servicios existentes de Batiseñal sobre soporte/SQLAlchemy. Bridge nunca consulta SQL arbitrario. Owner operacional del transporte: `DeliveryStore` sobre un SQLite exclusivo aprobado; no sustituye Postgres ni Supabase de negocio. `ConnectionResolver`, IdentityProvider y vault son responsabilidad del host, aún sin integración real.

Migración explícita, en ese store propio: primero `database/migrations/20261023_batisenal_transport_sqlite.sql`, luego `20261023_batisenal_delivery_sqlite.sql`. No DDL de startup. La segunda añade columnas y receipts inmutables, no purga ni backfill de casos. Es de aplicación única, no idempotente: el operador deberá confirmar versión antes de ejecutar. En esta fase sólo se aplicó a SQLite temporal sintético. No se eligió ni creó ruta productiva.

La composición futura necesita `Bridge`, `create_app`, `Events`, `DeliveryStore`, `CallbackVerifier(PinnedHTTPS(...))`, `Sender`, resolver y vault verificados. Todo gate permanece apagado por defecto; el ejemplo conceptual no autoriza `enabled=True`. No incluir emisor en un lifecycle automático. Una futura ejecución explícita necesita la misma referencia de conexión autenticada que Bridge revalida. No pasar actor/company/project desde el modelo.

## Checkpoint de piloto

Alcance aceptado: `prod-ryzen-20260728`, esta conversación padre, Francisco revisor, un caso ficticio, 60 min, lectura de contexto y retorno como borrador privado. El JSON actualizado está en `artifacts/delivery/approval-proposal.json`; versiones anteriores se preservan. No se creó suscripción, identidad, callback o secreto. IDs de conversación no son una URL ni prueba de identidad.

Antes de proponer comandos de montaje faltan rutas permitidas reales de fuente/config del gateway, entrypoint y versión efectiva, propietario/runtime del servicio y reverse proxy, autenticación soportada y mecanismo/rutas de vault/store. No se accedió a producción ni se eludieron lecturas denegadas. Después de ese inventario debe revisarse el diff concreto de montaje, identidad/grants exactos, almacenamiento/credenciales y expiración, y autorizarse activación y transmisión. El piloto debe vincular explícitamente caso/empresa/proyecto/destino/expiración; el transporte genérico probado no acredita esa configuración real.

Evento: sólo IDs opacos/versión. Herramientas: perfil, pendientes autorizados, contexto sintético y dos extractos fijos con procedencia, actividad, preview y borrador privado. No adjuntos, datos fiscales, proveedor nuevo, pago, SQL, filesystem libre ni publicación automática. Francisco publica por flujo humano existente con sus permisos y versión/CSRF; el agente no recibe ese permiso.

Rollback: apagar gates y retirar sólo montaje del piloto, desuscribir y revocar únicamente su grant mediante operador autorizado. Conservar schema, casos, historial, drafts, receipts y auditoría; no DROP ni purga. Retirada legado sigue off. No cambios de seguridad ni downgrade global.

Canon unchanged: transporte aislado inerte, owners de negocio/autoridad preservados; ninguna capacidad pasa a runtime o aceptación por estas pruebas. Los tres hashes del canon coinciden con el registro.
