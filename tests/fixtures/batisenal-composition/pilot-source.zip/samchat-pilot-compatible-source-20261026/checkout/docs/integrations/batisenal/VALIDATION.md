# Actualización final: adaptador Chatty, 2026-10-23

La fase Chatty conserva las 43 pruebas previas y añade 25: 22 contratos/API,
1 recorrido Chromium y 2 PostgreSQL nativo. **68/68 aprobadas, 0 fallidas y 0
omitidas**, 66.26 s, 795 advertencias heredadas de SQLAlchemy/datetime. Cobertura
acotada: 601/660 instrucciones (91.06%) en cuatro módulos Python; ninguna medida
de cobertura JavaScript. Black/isort (14 archivos), flake8 acotado, mypy (4
módulos), Bandit (sin findings), compilación Python y `node --check` aprobados.
Diff checks aprobados; checkout original intacto.

El revisor independiente aprobó 19 pruebas en su corte, incluidas dos regresiones
propias; ambos defectos encontrados se corrigieron y entraron a la suite final.
Logs: `artifacts/chatty-bridge-20261023/final-tests.txt` y XML, coverage, checks y
`independent-review.md/XML`. Recorrido nuevo: cola → inicio explícito del stub →
borrador privado → revisión humana → publicación única tras respuesta HTTP perdida
→ respuesta en el mismo caso sin recarga manual. No hay IA conectada acreditada.

PostgreSQL nativo 17.11 en contenedor propio sin red/puertos, socket Unix y DB
sintética. Se probaron locks, reintentos concurrentes e inmutabilidad de las tres
tablas nuevas. El contenedor se eliminó al terminar. Runtime completo real,
sesiones sintéticas, sin overrides: healthz200; bootstrap401/200; creación201;
caso/imagen200; otra empresa404; respuesta200. readyz503 por esquema global
incompleto previamente documentado, sin fingir readiness ni reparar otros módulos.

No ejecutado/no autorizado: transporte OAuth/MCP real, suscripción/despertar del
dot, callback/emisor Events, IA real, publicación automática, activación productiva,
UAT de usuarios reales o nuevo upload Library. Ver [CHATTY.md](CHATTY.md).
Las secciones siguientes conservan el historial de la fase base/UX, no reemplazan
esta evidencia final.

---

# Validación del candidato

Fecha: 2026-10-23. Evidencia sintética aislada; sin servidor de producción.

## Resultados

- **43 pruebas aprobadas**, cero fallidas en la última ejecución: 27 API/servicio, 6 PostgreSQL nativo
  y 10 recorridos/regresiones reales de Chromium. Montan `support_routes.router`, sus rutas
  Batiseñal y la navegación compartida; sólo login, DB y página de trabajo son
  fixtures. Resolución real de perfiles, reglas y autoridad de Batiseñal.
- Cobertura de los dos módulos nuevos Python: **93,83 %** de instrucciones.
  No es cobertura completa del monolito ni de JavaScript.
- Migración en PostgreSQL/WASM PGlite 0.3.14: instalación y seis rechazos por
  integridad/inmutabilidad aprobados; reaplicación falla sin perder filas.
- Black e isort: nueve archivos nuevos Python. Flake8: esos archivos y el servicio
  existente de tickets, con las exclusiones E203/W503/E501 ya definidas por el repo.
- Mypy limitado a los dos módulos nuevos (`follow-imports=skip`): sin errores.
- Bandit sobre los dos módulos nuevos: sin hallazgos.
- `node --check` para JS y prueba de migración, compilación Python de todos los
  archivos Python cambiados y `git diff --check`: aprobados.
- Hashes de los tres cánones verificados; checkout fuente sigue limpio en rama
  `work`, commit base sin cambiar. No se hizo commit, push, PR, merge ni despliegue.

## Revisión independiente y PostgreSQL nativo

Un subagente de sólo lectura identificó tres defectos y revalidó sus correcciones:
recarga de recursos al clonar DOM (eliminada dependencia html2canvas), pérdida de
clave de respuesta al reabrir y reenvío tras POST exitoso/GET fallido. La revisión
inicial pasó 4 pruebas Chromium; no quedan hallazgos concretos abiertos en su alcance.
Evidencia independiente persistida: `security-review.xml` y `security-review.md`.

PostgreSQL **nativo** 17.11 (`postgres:17-alpine`) se ejecutó en un contenedor
propio, `--network none`, sin puertos TCP, datos tmpfs y socket Unix privado.
Seis tests ejecutan el cuerpo de la migración SQL real dentro de transacciones
de fixture: ciclo completo, denegación usuario/empresa/proyecto, cinco creaciones
concurrentes, cinco reintentos concurrentes de respuesta, triggers inmutables y
reaplicación que falla sin perder filas. Esto es distinto de la prueba PGlite/WASM.

## Cobertura funcional y negativa

| Área | Evidencia ejecutada |
|---|---|
| Identidad/ámbito | Usuario activo; anónimo/inactivo rechazados; otro usuario de la misma empresa no ve el caso; otra empresa/proyecto no lista, lee, descarga ni responde; sin ámbitos superadmin denegado; suplantación denegada |
| Perfiles/reglas | Revocación activa comprobada en próxima solicitud; denegaciones de ver/crear/editar respetadas incluso para superadmin; error de store de reglas bloquea |
| API/CSRF/XSS | Origin, token CSRF, content-type, claves desconocidas, JSON, límites y UUID inválidos; texto de ataque se muestra literalmente y no ejecuta; patrones comunes de secretos removidos |
| PNG | Bytes inválidos, tipo SVG/GIF/BMP, tamaño y píxeles rechazados; PNG/RGBA normalizados; metadatos y trailing bytes eliminados; lectura privada no-store |
| Idempotencia | Repetición y conflicto de payload; cinco creaciones y cinco respuestas concurrentes en PostgreSQL producen un solo registro/evento; navegador pierde respuesta después del commit y reintenta con el mismo identificador; reapertura y consulta fallida no duplican respuestas |
| Captura/UI | Apertura sin captura ni envío; dibujo real de geometría protegida en canvas con Chromium; recorte y máscara; quitar y cancelar captura pendiente; error NotAllowedError del renderer simulado; cero requests externos |
| Navegación | beforeunload interrumpido conserva borrador; cerrar descarta borrador/imagen; reapertura sin adjunto. No se promete restauración tras cierre forzado |
| Ciclo/auditoría | Conversación solicitante/soporte; todas las transiciones de estado; requester no puede cambiar estado; replay de respuesta no duplica evento; consulta usuario de respuesta/resolución |
| Retención/atomicidad | Vencimiento oculta y rechaza acceso sin borrar; fallo de almacenamiento no deja caso parcial; tablas nuevas excluidas de startup metadata |
| Rutas anteriores | No enumeran ni acceden/modifican Batiseñal, incluso superadmin; el marcador reservado no es aceptado en ticket viejo |

La captura no requiere permiso del sistema operativo: no usa getDisplayMedia.
El rechazo probado corresponde al contexto canvas simulado, no a un diálogo nativo de
captura. La captura exitosa sí usó canvas 2D real.

## No ejecutado / límites de aceptación

- Suite global del repositorio, mypy/lint de todo el monolito y CI remota.
- Runtime global saludable: se ejecutó `copa_telmex_dashboard.app`, lifespan,
  middlewares y dependencias de identidad/DB reales, sin overrides. `/healthz`
  devuelve 200, `/readyz` 503: base sintética mínima sin tablas globales
  `budget_lines`, `client_report_audit_logs`, `client_report_drafts`,
  `client_report_schedules`, `copa_telmex_registration_batch_upload_files` y
  `copa_telmex_registration_batch_uploads`, más columnas/índices/constraints
  registrados en `full-runtime-result.json`. Startup captura el error al consultar
  uploads vencidos. No se amplió el alcance para provisionar los otros módulos.
  La identidad sintética con cookie firmada local sí completa bootstrap, creación,
  adjunto, respuesta y consulta; otra empresa recibe 404. No prueba login externo.
- Validación con versión/configuración del despliegue, proxy, todos los frontends
  y carga multitrabajador. Las pruebas nativas usan PostgreSQL 17.11 y conexiones
  concurrentes; no procesos de aplicación múltiples. No se han compilado los
  frontends Copa América/Telmex (el runtime informa dist ausente).
- UAT autenticada por empleados/puestos reales, datos reales, acceso a producción,
  provisión de perfiles, despliegue, carga masiva y pruebas de larga duración.
- OAuth/MCP externo de Batiseñal, identidad del asistente de Francisco y cualquier
  notificación push. No existe transmisión real entre cuentas ChatGPT.
- Recuperación de borradores tras cierre forzado, purga física y política de
  backups. Se documenta retención lógica y conservación sin borrado.

No se declara aceptación completa ni disponibilidad productiva.

## Incidencias durante construcción

Se corrigieron fixtures UUID numéricos incompatibles con la afinidad SQLite, un
stub de rechazo de renderer que Playwright invocaba al evaluar la asignación y
una captura móvil tomada antes de terminar bootstrap. La cobertura inicial por
nombre de módulo falló al importar anticipadamente el monolito; se usa
`coverage run --include=...` para instrumentar la ejecución real. El reporte final
se generó después del último cambio. El lint final corrigió un import no usado y
el tipo de tuple de grants. Se aisló también la bandera de la fixture para no contaminar otras pruebas y se
verificó que un rechazo definitivo de envío desbloquea la edición, mientras que
una pérdida de respuesta conserva la clave de reintento. Son fallos de iteración
resueltos, no fases omitidas.

Descargar Chromium de Playwright devolvió 403 `Domain forbidden`; no se eludió la
restricción ni se reintentó por otro destino. Se usó `/usr/bin/chromium`, ya
instalado en el entorno. El navegador local completó los recorridos.

## Reproducir en este entorno aislado

Entorno Python: `/workspace/batisenal-venv`; paquetes exactos guardados en
`artifacts/batisenal/test-environment.txt`. No se modificaron requirements globales.

```bash
cd /workspace/samchat-batisenal
PYTHONPATH=src:tests/batisenal EXPENSE_REPORT_RECEIPT_BLOB_COLUMN=archivo_data \
 /workspace/batisenal-venv/bin/coverage run \
 --include='*/batisenal_service.py,*/batisenal_routes.py' \
 -m pytest tests/batisenal --no-cov -q
/workspace/batisenal-venv/bin/coverage report --fail-under=85
node tests/batisenal/check_migration.mjs \
 /workspace/batisenal-deps/node_modules/@electric-sql/pglite/dist/index.js
/workspace/batisenal-venv/bin/python scripts/batisenal/serve_synthetic.py
```

El último comando abre un puerto libre sólo en loopback y muestra las URLs de
login ficticio de Alice y soporte, seguido de `/panel`. No se monta ese login en
el producto. La base de esa demo es temporal y se elimina al terminar el proceso.
Los tests usan sus propios puertos libres y cierran sus servidores al terminar.

## Artefactos

`artifacts/batisenal/` contiene logs de pytest, cobertura JSON/texto, Bandit,
resultados PostgreSQL nativo/WASM y runtime completo, entorno de pruebas, receipt del navegador, cinco PNG
de interfaz y una DB **exclusivamente sintética** (`synthetic-browser.db`).
El receipt del navegador identifica el caso sintético creado y respondido.
La DB no contiene credenciales reales; nunca debe tratarse como migración de datos.
`candidate.patch`, `SHA256SUMS` y el ZIP de entrega se generan al cerrar la revisión.

Para repetir los tests nativos, configurar `BATISENAL_TEST_NATIVE_URL` con
`postgresql+asyncpg://postgres@/batisenal_review?host=/workspace/batisenal-native/socket`.
Sin esa variable los seis tests nativos se omiten explícitamente. El archivo
`artifacts/batisenal/full-runtime-check.py` reproduce la comprobación del runtime
sobre una DB sintética vacía. Requiere PYTHONPATH `src:tests/batisenal:.`,
DATABASE_URL/POSTGRESQL_URL al socket privado, SAMCHAT_ENV=test,
SAMCHAT_ENV_FILE apuntando a un archivo vacío, SESSION_SECRET_KEY sintética,
APP_URL=http://127.0.0.1, BATISENAL_ENABLED=1, CTT_BATCH_STAGING_ROOT privado y
EXPENSE_REPORT_RECEIPT_BLOB_COLUMN=archivo_data. Ejecutar con `env -i`.
Bloquea conexiones/DNS externos mediante audit hook. `--reuse-fixture` sólo
reutiliza la DB sintética ya creada por esa misma comprobación.

## Comprobación adicional de bootstrap completo

Se revisaron README, install_matrix, runtime_map, guía de release, workflow CI,
provisionador de reporting, migraciones de lotes y documentación de fixtures AMEX.
Existen procedimientos por módulo, pero no se encontró una cadena documentada y
autocontenida para levantar una base sintética completa del runtime desde cero.
Las guías históricas de DevNous advierten que no son el bootstrap actual.
Se conserva `/readyz` 503 y sus objetos faltantes exactos en la evidencia; no se
aplicaron parches a readiness ni se ensambló un nuevo bootstrap de módulos ajenos.
Detalle y fuentes: `artifacts/batisenal/bootstrap-review.md`.
Esta comprobación de bootstrap no cambió producto; la fase UX posterior sí actualizó código y ejecutó de nuevo la suite final.

## Pulido UX autorizado y recorrido de Operaciones

Se implementaron contexto explícito restringido, pregunta breve, campos opcionales,
guía determinista sin IA/diagnóstico causal, plantilla de respuesta y consulta
automática acotada. README documenta contrato, catálogo, tiempos y límites.
La integración real automática es el área activa de navegación. Referencia/error
se probaron con adapter de pago **sintético**, no con el módulo real sin su esquema.

La suite final contiene 27 API/servicio, 6 PostgreSQL nativo y 10 navegador:
4 regresiones previas, 2 recorridos Operaciones y 4 de polling/carreras. Se verifican
pregunta con contexto existente, error desconocido, referencia secreta/importe/
campos extra descartados por adapter, cancelación con borrador de negocio intacto,
respuesta que llega sin recargar manualmente, borrador de respuesta conservado,
reintento sin duplicación y otro usuario/empresa sin acceso a caso/adjunto.
Polling: lecturas seriales, timeout, backoff, límite120 con reloj virtual, cierre,
revocación y resultados tardíos durante escritura o edición. El recorrido de
Operaciones usa temporización real para recibir respuesta; no simula su llegada.

Revisión independiente en sólo lectura: 10/10 navegador aprobados. Se detectaron
y corrigieron tres carreras nuevas: error tardío que eliminaba controles de retry,
borrador/confirmación de respuesta sin protección y GET tardío o nueva consulta
que podía reemplazar una respuesta recién escrita. Evidencia en
`artifacts/ux-polish-20261023/independent-review.xml`. Un ajuste final sólo de CSS
protege ancho/alineación de checkbox frente a estilos del módulo anfitrión.

Durante iteración, el test de recorte necesitó desplazar el canvas a la vista al
plegar detalles; el test del tope120 necesitó avanzar el reloj por ciclos y dejar
resolver microtareas; se corrigió un alias de fixture para flake8 F811. No son
fallos abiertos de producto. Los resultados finales posteriores sustituyen esos
logs intermedios; no se afirma que las primeras ejecuciones fueran verdes.

La evidencia UX está en `artifacts/ux-polish-20261023/`, con capturas compactas,
respuesta/seguimiento y cancelación, receipt JSON, pruebas y reporte. La versión
anterior del ZIP se conserva separadamente como before-ux. No se reintentó Library.

Se verificó además que cada receipt/captura coincida con su DB persistida;
los escenarios de polling y cancelación guardan bases separadas para no
sobrescribir la evidencia del recorrido principal.

La revisión visual final detectó estado desfasado en la fila de bandeja; se
sincronizó por ID con la conversación mediante textContent. El recorrido exige
ambos estados actualizados; el revisor confirmó el cambio sin nuevos hallazgos.
