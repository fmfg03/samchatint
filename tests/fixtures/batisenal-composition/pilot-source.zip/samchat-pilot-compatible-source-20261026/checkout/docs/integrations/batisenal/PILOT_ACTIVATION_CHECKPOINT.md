# Checkpoint único: aplicación montable, activación pendiente

2026-10-24. Candidato `/workspace/samchat-batisenal-pilot`. Estado: código montado y probado sólo en la aplicación sintética local. No está instalado ni aceptado en producción. Canon unchanged: implementación y validación del piloto autorizado; sin cambiar autoridades de negocio ni declarar entrega productiva.

## Recorrido implementado

La persona de Operaciones abre Batiseñal desde la navegación existente durante su tarea. Problema, contexto permitido y captura voluntaria comparten un panel; la captura protegida no toma contenido de otras ventanas. Revisa y confirma antes de crear el caso. Minimizar conserva texto y clave de envío en memoria hasta recargar, y detiene la consulta automática; reabrir revalida acceso. La conversación permanece en el mismo caso y la respuesta en cola no se anuncia como IA trabajando.

Soporte conecta una sesión individual SamChat mediante consentimiento PKCE y cuenta activa. La vista muestra persona, caso, empresa/proyecto, origen sintético o IA configurada, ventana máxima y borrador privado. Autorización no equivale a consulta iniciada. La conexión acepta sólo un caso atestado por el owner y 60 minutos absolutos desde el primer consentimiento; nuevas conexiones/tokens no amplían esa ventana. La vista de retorno distingue permiso vigente, revocado o vencido, estado del caso y borrador privado. El solicitante no ve ese borrador.

La atestación persistente del caso bloquea publicación en los owners `reply_case` (soporte) y `publish_draft`, incluso al desmontar la UI o revocar el piloto. No hay control de publicación en la vista del piloto. El seguimiento del solicitante y el historial se conservan. La publicación ordinaria de casos ajenos al piloto no cambió. Publicar el resultado del piloto requeriría una decisión y cambio explícitos posteriores; no quitar su atestación para eludir el bloqueo.

## Código real y llamada de montaje

El archivo **implementado** `src/devnous/gastos/routes/batisenal_pilot_routes.py` exporta `mount_pilot(app, composition)`. Se llama explícitamente antes del startup sobre el `app` SamChat que ya tiene `SessionMiddleware`. No se añadió una llamada automática en `copa_telmex_dashboard.py`. La composición debe ser `samchat.batisenal_pilot.SupportPilot`, con los owners existentes y configuración de servidor:

```python
from devnous.gastos.routes.batisenal_pilot_routes import mount_pilot
from devnous.gastos.routes.dependencies import get_current_empleado
from samchat.batisenal_pilot import SupportPilot

# Todos los objetos son aportados por el host tras aprobación; no se crean aquí.
composition = SupportPilot(
    sessions=session_maker,                    # mismo owner que get_db_session
    employee_dependency=get_current_empleado, # no login ni actor alternos
    authorization=authorization_config,
    resource=resource_config,
    oauth_store=support_oauth_store,           # support_only=True
    signer=host_signer,
    audit=transport_audit,
    pilot=one_case_pilot,
    clock=server_clock,
    enabled=pilot_enabled,                    # False por defecto; nunca derivado del cliente
)
mount_pilot(app, composition)
```

La función comprueba config/paths y colisiones antes de montar. Ni constructor ni mounting crean esquema, claves, perfiles, atestaciones o permisos. El host debe resolver los objetos de la receta con su configuración aprobada; no son variables de entorno inventadas. `tests/batisenal_pilot/test_application.py` acredita esta composición con fixtures y `get_current_empleado` real sobre PostgreSQL nativo.

Rutas **implementadas y probadas localmente**, todavía no instaladas en `sam.chat`:

| Método | Ruta | Función |
| --- | --- | --- |
| GET | `/soporte/batisenal/piloto/authorize` | Sesión existente, validación de petición, inicio de revisión |
| POST | `/soporte/batisenal/piloto/consent` | Formulario acotado, Origin/CSRF, preview y confirmación vinculada; retorno sólo al redirect registrado |
| POST | `/soporte/batisenal/piloto/token` | Código de un uso y PKCE; sin cookies, refresh ni identidad server-owner |
| GET | `/soporte/batisenal/piloto/case` | Retorno al caso y revisión privada autorizada |
| POST | `/soporte/batisenal/piloto/revoke` | Revocar este piloto conservando caso/historial |
| GET | `/soporte/batisenal/piloto/style.css` | Estilo local, sin CDN o recursos externos |
| POST | `/soporte/batisenal/piloto/mcp` | Perfil y cinco herramientas acotadas; sin Events ni publicación |
| GET | `/.well-known/oauth-authorization-server/soporte/batisenal/piloto` | Metadata de issuer según RFC 8414 |
| GET | `/.well-known/oauth-protected-resource/soporte/batisenal/piloto/mcp` | Metadata de recurso según RFC 9728; challenge 401 apunta aquí |

Origen productivo propuesto `https://sam.chat`; issuer `https://sam.chat/soporte/batisenal/piloto`; recurso ese issuer más `/mcp`. Cliente y redirect reales siguen sin configurarse; no se inventó callback. El gateway administrativo `agentius-https.service` y su `/mcp`, `agentius:access`, `server-owner`, permisos de host y catálogo estático no se modifican ni traducen a autoridad empresarial.

## Stores y permisos que requeriría el cambio productivo

- Release SamChat: integrar código de Batiseñal/puente y este delta sobre un release identificado; la base local `d4afc74b3b4bb152766826b2c0fa92ce253de866` preserva el candidato delivery, no es la base productiva conocida. Punto real de composición: `copa_telmex_dashboard.py`, junto al owner de sesiones y routers existentes. No aplicar este patch directamente sobre otro commit sin reconciliar.
- PostgreSQL del owner SamChat. Migraciones requeridas, aplicar **sólo las ausentes**: `20260919_agent_action_receipts_v01.sql`, `20261001_private_oauth_storage_review.sql`, `20261023_support_batisenal.sql`, `20261023_support_batisenal_agent.sql`, `20261024_batisenal_pilot.sql`. Prerrequisitos: empleados, perfiles/reglas y tickets/comentarios existentes. Cinco cuerpos SQL ejecutados antes en PostgreSQL aislado; en esta fase se reutilizan para el HTTP sintético. No bootstrap global ni DDL al startup.
- Stores: `private_oauth_*`, `agent_action_receipts`, `support_batisenal_*` y tablas `support_batisenal_pilot_*`. Auditoría de transporte propuesta en **nuevo** `/var/lib/samchat/batisenal-pilot/transport.sqlite3`, owner SamChat por verificar, directorio privado. Aplicar su SQL SQLite existente sólo al store nuevo. Tablas de Events quedan vacías, sin workers/subscripciones. Nunca reutilizar `/var/lib/agentius-https/oauth.sqlite3`.
- Custodia: referencia de signer/verificador del host y cliente/redirect aprobado. No se eligió ruta de clave, vault ni usuario real, y no se generó credencial real. Deben constar en el manifiesto técnico no secreto antes de autorizar instalación.
- Piloto propuesto: empresa `prueba_batisenal`, proyecto `e2e_chatty`, un caso creado expresamente con fixture sintética y atestación owner. Tests usan `acme/demo`. Francisco como revisor previsto; su empleado/perfil debe identificarse y consentir individualmente.
- Facultades explícitas: soporte `admin.soporte`, `batisenal:prueba_batisenal:e2e_chatty:support`, `batisenal:prueba_batisenal:e2e_chatty:agent`; solicitante sintético `soporte.self`, `batisenal:prueba_batisenal:e2e_chatty:request`. OAuth sólo `batisenal.support`. Ninguna concesión por rol root/host. Datos: título/descripción/contexto revisado, conversación sintética, dos extractos con procedencia; sin adjuntos o consultas fiscales. Herramientas: profile/list_pending/read_case/record_activity/prepare_reply/submit_draft.

## Único bloqueo de inventario productivo

La consulta de sólo lectura `systemctl show samchat-gastos.service --no-pager -p User -p Group -p WorkingDirectory -p FragmentPath -p DropInPaths -p ActiveState -p MainPID`, sesión propia `72333782-df31-4a64-9355-aa071f06febd`, request `batisenal-samchat-mount-metadata-20261024-01`, cwd `/tmp`, fue rechazada con **UNRECONCILED_PROCESSES / INVALID_ARGUMENT**, sin job ID. No se reintentó ni se cambió a administración/otra ruta. Recibo local: `artifacts/pilot/application/inventory-block.json`. No se retomó guardian.

Dato mínimo faltante: **manifiesto efectivo de montaje de SamChat** con release/WorkingDirectory/ExecStart saneado, UID/GID, archivo/bloque de proxy de `sam.chat`, owner de conexiones PostgreSQL, referencia no secreta de custodia de firma y client_id/redirect autorizado. El nombre `samchat-gastos.service` procede del repositorio; no se confirmó activo ahora. Evidencia anterior de Agentius `20261021-r1` aportada por Francisco el 24 de octubre pertenece al gateway, no resuelve este manifiesto. No hace falta exportar código retenido ni valores secretos.

## Aceptación y rollback

La decisión productiva futura será integrar el release concreto con esta llamada y sus objetos, migraciones ausentes/store/perfiles/caso, rutas proxy exactas y habilitación única de 60 minutos. Cualquier reload/restart necesario debe figurar expresamente en el diff operativo aprobado; no está ejecutado ni autorizado aquí. Falta la prueba visual con un navegador soportado cuyo sandbox funcione; Chromium actual abortó por helper SUID y no se alteró su seguridad.

Prueba real pendiente: desde esta conversación, consentimiento individual → lectura del caso sintético → borrador real de Chatty → revisión privada de Francisco dentro del mismo caso; confirmar aislamiento, mismo request_key en reintento y corte temporal real. No Events ni publicación. ASGI/DOM locales no acreditan esta aceptación.

Rollback: deshabilitar composición, retirar sólo rutas/metadata/proxy añadidos y volver al release identificado por procedimiento aprobado; revocar únicamente vínculo/grant y permisos añadidos del piloto. Conservar atestación, caso, drafts, historial, auditoría, esquema y store. **La privacidad permanece por la atestación persistente**, no por el flag de UI. Sin DROP/purga, quitar atestaciones, cambios Agentius/guardian o privilegios ajenos.
