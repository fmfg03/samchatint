# Chatty y Batiseñal — adaptador candidato sin activar

Fecha: 2026-10-23. Base y checkout aislado descritos en README.md.
Estado `coded_not_wired`: implementación local probada; sin conexión real a
Chatty, suscripción MCP, publicación automática, proveedor/modelo nuevo ni coste
facturable activado. Los tests usan identidad y agente stub sintéticos. Ninguna
prueba con `source_kind=ai_agent` acredita una conversación real con ChatGPT.

## Historia autorizada y límite

La persona puede seguir trabajando después de enviar su consulta. Un agente
externo autorizado consulta el caso con contexto y procedimientos verificables,
separa hechos de inferencias y prepara una respuesta. Inicialmente la respuesta
es un **borrador privado**: soporte humano debe revisarlo antes de publicarlo a
los participantes. Una guía determinista sigue identificada como tal; no se
renombra como IA. El agente nunca modifica pagos, documentos, permisos o estado
financiero y nunca marca un caso resuelto.

Se implementaron estas capacidades independientes de la activación conforme a la
delegación. La publicación automática y los permisos/canales reales no están
autorizados. No se creó un endpoint de entrada a ChatGPT ni se reutilizó la
sesión/root de Francisco.

## Integraciones inspeccionadas y ownership

- `src/samchat/private_plugin/mcp_boundary.py`: frontera SDK sin montar,
  herramientas deshabilitadas. Su `IdentityProvider` y `AuditSink` son contratos
  existentes de composición, no OAuth ni auditoría productiva ya acreditados.
- `src/samchat/readonly_gateway/mcp.py`: conector offline sólo lectura. No se
  convirtió en un canal de escritura ni se cambió su catálogo.
- `src/samchat/batisenal_bridge.py`: nuevo dispatcher consultable para
  `tools/list` y `tools/call`; no listener/HTTP, negociación MCP ni deployment.
  El host aprobado tendría que componerlo tras su transporte autenticado.
- Runtime destino: `copa_telmex_dashboard.py`; dominio soporte; Postgres directo.
  Read/write owner de casos: `batisenal_service.py` sobre soporte canónico.
  `batisenal_agent_service.py` posee sólo actividad/borradores/procedencia.
  La publicación reutiliza `reply_case(..., commit=False)` en una transacción
  que también persiste el vínculo de procedencia; no hay segundo backend de tickets.
- Las herramientas disponibles anunciadas de Agentius no incluyen Batiseñal ni
  Events. No se llamó al servidor real ni se cambió gateway alguno. El padre
  verificó por separado que la fuente de eventos no está activada.

## Identidad y permisos

El dispatcher arranca con `enabled=False`. Para cualquier listado o llamada,
el host debe aportar referencia request-local desde transporte autenticado,
`IdentityProvider.resolve_current`, `AuditSink` persistente y un `Binding`
configurado en servidor. No existen credenciales en este paquete.

Se verifica identidad activa, no revocada, caducidad, issuer, audience,
installation, subject, vínculo estable `profile_id`, grant y organización exactos.
La combinación subject/profile/grant/organización debe resolver **un solo**
binding. Éste fija el UUID técnico del agente, la cuenta local existente,
compañía/proyecto y origen `ai_agent` o `synthetic_stub`. Ningún argumento de
herramienta puede enviar actor, permisos, empresa, proyecto o procedencia.

En cada llamada se relee la cuenta activa y los perfiles efectivos. Se exige la
intersección de scope restrictivo `batisenal.support`, binding exacto,
`batisenal:<org>:<project>:support`, **nuevo permiso explícito**
`batisenal:<org>:<project>:agent` y facultad `admin.soporte` correspondiente.
Denegaciones específicas prevalecen también para superadmin. El permiso agent
solo no da soporte y support solo no da acceso de agente. La identidad se limita
al ámbito único del binding aunque la cuenta tenga otros permisos. No se crea,
reactiva, vincula ni promociona ninguna cuenta automáticamente.

Las lecturas de cuenta seleccionan sólo atributos usados por el owner de
permisos; `raiseload` evita cargar documentos/relaciones financieras del ORM.
Esos atributos no se incluyen en el resultado de la herramienta.
Las escrituras del agente repiten identidad y permisos después del row lock.
La publicación humana relee cuenta/perfiles/denegaciones bajo ese mismo lock.
No hay un método MCP para publicar. No se acepta un booleano del modelo como
aprobación humana.

## Herramientas y retorno

Todas usan esquemas cerrados y rechazan campos extra. Entrada máxima 32 KiB,
salida máxima 64 KiB. IDs seleccionan casos; no otorgan autoridad.

| Herramienta | Entrada | Resultado/efecto |
|---|---|---|
| `samchat_batisenal_list_pending` | `{}` | Ventana máxima de 200 casos autorizados, IDs y versiones; pendiente o borrador privado. No historia completa ni loop. |
| `samchat_batisenal_read_case` | `case_id` | Contexto/texto/conversación como datos no confiables, versión y dos extractos de política con procedencia. Sin imagen. |
| `samchat_batisenal_record_activity` | `case_id`, `version`, `request_key`, `kind` | Recibo `started` o `source_unavailable`. No respuesta ni resolución. |
| `samchat_batisenal_prepare_reply` | `case_id`, `version`, `response` | Vista previa normalizada y hash; sin escritura. |
| `samchat_batisenal_submit_draft` | Lo anterior + `request_key`, `preview_hash` | Borrador privado persistido, ID estable, `published=false`. |

`response` exige observation, inference, next_step, verification,
missing_evidence (cada uno máximo 1000 caracteres) y source_ids (hasta cuatro).
No hay SQL, paths, URL fetch, shell, herramientas de documentos ni API de pago.
El agente debe leer antes de registrar started; ese recibo sólo acredita una
invocación explícita de inicio, no razonamiento interno ni diagnóstico correcto.
Una entrega Events/HTTP exitosa tampoco es prueba de inicio.

La versión es una huella del hilo canónico. Una propuesta obsoleta se rechaza.
El hash de preview liga caso, versión, texto saneado, fuentes y origen configurado.
Misma clave/contenido recupera el mismo draft; clave repetida/contenido distinto
falla. Los locks y constraints se probaron con PostgreSQL nativo.

Soporte abre **Revisar borradores de agente** en el panel existente, lee el texto
plano completo y confirma **Publicar propuesta revisada**. El POST de sesión
exige Origin/CSRF y permisos. La identidad del revisor no viene del cliente.
Borrador inmutable + versión actual + confirmación producen una sola respuesta y
su recibo, incluso si se pierde la respuesta HTTP. Una falla en procedencia
revierte también comentario, estado y auditoría. Publicar deja `en_revision`;
la verificación humana posterior conserva el flujo de soporte existente.

El texto publicado muestra **Chatty · IA, revisada por soporte** sólo cuando el
binding autenticado estaba configurado como `ai_agent`. El stub aparece como
**Stub sintético · no es Chatty**. Operadores normales siguen como Soporte.
Se conserva UUID técnico, cuenta local, hash del grant, versión, fuentes,
revisor y recibos; no tokens. El origen atestigua la identidad técnica configurada,
no demuestra por sí mismo qué modelo produjo cada frase.

## Procedencia y evidencia insuficiente

El catálogo inicial contiene únicamente dos secciones fijas del canon:
`support_outcome` y `support_evidence`, con ruta y SHA-256 verificado. Son política
de interacción/evidencia, **no procedimientos contables ni diagnóstico operativo**.
Si falta archivo/integridad, no se entrega conocimiento ni acepta una propuesta;
sí puede registrarse source_unavailable sin inventar una fuente.

No se rastrea el repositorio ni se permite escoger rutas arbitrarias. Ampliar el
catálogo requiere revisión de owner, ámbito, contenido y versión. La descripción,
comentarios y cualquier captura de usuario son datos no confiables: nunca órdenes
a ejecutar, URLs a visitar ni motivo para ampliar privilegios. Sin evidencia o
sin fuentes disponibles, la propuesta queda `escalated`; con fuentes, como máximo
`awaiting_verification`. Las fuentes citadas no validan automáticamente la
veracidad semántica de la respuesta: la revisión humana sigue siendo necesaria.

## Experiencia asíncrona

El acuse aparece **después del commit**: recibida/en cola, se revisará con su
contexto, puede continuar y encontrará la respuesta en el mismo caso.
`queued` no se presenta como Chatty analizando. Un recibo técnico explícito
permite `consultation_started`; un stub produce `synthetic_started`, claramente
sin IA real. El borrador da `private_review`, y sólo un comentario publicado
produce `response_available`. `source_unavailable` muestra `attention_error`.
Una nueva respuesta del solicitante genera nueva versión y vuelve a pendiente.

`BATISENAL_DELAY_SECONDS`: 60–86400, por defecto 900. Se evalúa al consultar, sin
job ni vigilancia permanente. Excederlo muestra demora, nunca porcentaje ni SLA.
`BATISENAL_ESTIMATE_MINUTES`: 0–1440, por defecto 0 = deshabilitado. No habilitar
estimación hasta contar con evidencia operativa y aprobación del plazo orientativo.
El polling del panel conserva sus límites previos: sólo abierto/visible, máximo
120 consultas, timeout/backoff, sin solapamiento y detención al cerrar.

## MCP Events: contrato previsto, no suscripción implementada

La documentación oficial describe Events para plugins/dots, autenticación y
suscripciones reales. El host deberá implementar `events/list`,
`events/subscribe`, `events/unsubscribe` según la negociación compatible
MCP 2.0 / 2026-07-28. El callback se recibe de una suscripción auténtica, no se
inventa ni se acepta desde contenido del caso. 2xx sólo confirma recepción;
puede haber duplicados y desorden. Límite documentado: 256 KiB por evento.

Este candidato sólo incluye `requested_event_data`: datos de aplicación
`batisenal.requested`, case_id opaco, versión y delivery_id opaco, sin texto,
empresa, usuarios o adjuntos. **No es el sobre HTTP completo, un emisor, una
outbox ni una implementación de esos tres métodos.** El host real debe resolver
suscriptor/destinatario, permisos actuales, firma/autenticación de entrega,
revocación, reintentos y deduplicación con el contrato completo aprobado.
El evento despierta una consulta; nunca autoriza lectura o publicación. Una
versión vieja obliga a releer; la idempotencia del caso/draft no depende del orden
de eventos. No se agregó correo/Slack intermediario ni polling de servidor.

Fuentes oficiales consultadas el 2026-10-23:
- https://developers.openai.com/plugins/build/mcp-events
- https://developers.openai.com/plugins/build/auth

## Checkpoint mínimo antes de conectar realmente

1. Aprobar identidad técnica de Chatty y vínculo servidor a una cuenta existente
   activa, issuer/audience/installación/grant y compañías/proyectos exactos.
   Revisar permisos support+agent y denegaciones; no heredar root personal.
2. Aprobar **datos compartidos**: evento sólo IDs/versiones; lectura del título,
   descripción, contexto revisado y conversación de ese caso, más las dos fuentes
   fijas. Los textos pueden contener datos que el usuario escribió: saneamiento
   no es clasificación infalible. **Adjuntos y consultas fiscales quedan fuera**.
3. Elegir/aprobar composición de autenticación del puente y almacenamiento de
   identidad/auditoría/credenciales por su owner. Implementarla y probarla sin
   reutilizar secretos personales. Este candidato no provee OAuth/introspección.
4. Aprobar y aplicar migraciones de soporte al destino, composición MCP de las
   cinco herramientas y prueba autenticada con scopes reales. Actualmente no
   están montadas en Agentius ni anunciadas por un plugin.
5. Aprobar host Events/dot destinatario y su suscripción real, y completar el
   emisor con callback obtenido de esa suscripción. Falta esa implementación y
   su prueba de recepción/retorno; no se promete respuesta en minutos todavía.
6. Mantener inicialmente **retorno privado** por submit_draft → revisión humana
   → publicación en el caso. Publicación automática a participantes necesita
   decisión y autorización adicionales; no existe herramienta que la habilite.

El permiso para construir el candidato no satisface ninguno de estos checkpoints
productivos. No se pide al usuario resolver tareas locales que ya están probadas.

## Esquema, retención y reversión

Nueva migración owner-run `20261023_support_batisenal_agent.sql`, después de la
migración base: activity, drafts y publications, con FKs, unicidad y triggers
inmutables. No se aplica desde startup ni provisiona perfiles. Se debe aplicar
antes de usar esta versión del panel, que consulta procedencia y atención.
Retención de acceso se hereda del caso (90 días configurables); vencimiento deniega
lecturas/publicación sin borrar nada. No se agregó purga física.

Reversión: deshabilitar la composición Bridge y el widget, detener entregas en
el host autorizado si algún día se activa, conservar evidencia y tablas. Volver
al candidato anterior elimina la UI de revisión; no borrar drafts/publicaciones
ni permitir acceso legacy al marcador privado. No ejecutar DROP sobre evidencia
existente. Migración aplicada, runtime completo, aceptación de usuario y conexión
externa deben tener recibos separados.

Canon unchanged: esta extensión candidata respeta owners, identidad, confirmación,
idempotencia, evidencia y límites de autoridad del canon. No cambia reglas de
negocio ni declara una capacidad externa desplegada; no se propone editar canons.
