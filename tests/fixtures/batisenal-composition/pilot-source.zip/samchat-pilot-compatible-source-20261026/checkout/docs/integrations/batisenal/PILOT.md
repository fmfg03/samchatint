# Piloto individual de soporte: candidato aislado

Estado: implementado y probado localmente, sin montaje ni activación. Runtime destino: SamChat `copa_telmex_dashboard.py`; dominio soporte, owners de casos/borradores existentes, Postgres de negocio. La prueba usa ASGI en proceso y SQLite sintético. No es Chatty real.

## Composición implementada

`samchat.batisenal_pilot.SupportPilot` recibe sesiones del owner, dependencia canónica `get_current_empleado`, configuración OAuth específica de soporte, verificador de recurso, store OAuth explícito, signer aportado por el host, auditoría, reloj de servidor y `Pilot` con caso/empresa/proyecto elegidos en servidor. Arranca `enabled=False`. No lee credenciales del entorno, crea usuarios, concede permisos, genera claves reales, inicia listeners ni monta rutas.

Reutiliza consentimiento/código PKCE y verificación JWT de `private_plugin`; la sesión firmada SamChat debe resolver a empleado activo y no suplantado. El request del modelo no puede seleccionar actor, empresa o proyecto. `SupportAuthorizationConfig` admite exclusivamente `batisenal.support`; `OAuthStore(support_only=True)` exige ese mismo conjunto. La configuración existente de sólo lectura y el store por defecto continúan rechazándolo. `agentius:access`, `server-owner` y facultades de host no se traducen.

La identidad técnica del agente y su perfil estable se registran en el binding; el empleado individual que consiente permanece trazable y requiere permisos empresariales explícitos, también siendo superadmin. No hay herencia del root del servidor. No se configuró aún a Francisco ni a ninguna persona real.

La interfaz `browser_call(request, operation)` expone preparación/confirmación/revocación para su composición por el host autenticado. Consume el Origin/CSRF canónico existente; devuelve preview con caso, empresa/proyecto, duración máxima y modo `private_draft`. Su fingerprint y registro persistido vinculan el consentimiento al alcance mostrado y a la persona, incluso si cambia la composición durante un await. `exchange(parameters)` implementa intercambio PKCE mediante el owner OAuth. `mcp` es el ASGI protegido para montar explícitamente; sólo tools/profile, sin Events. El host todavía debe montar su vista/handlers de consentimiento e intercambio y el recurso MCP bajo el origen/issuer aprobados; no se modificó el gateway activo ni se entregó una UI de login nueva.

## Ventana y caso

El owner debe provisionar previamente una atestación del caso sintético en `support_batisenal_pilot_fixtures`; no hay herramienta o parámetro de modelo que marque un caso real como sintético. El contenido del título tampoco acredita esa condición. No se insertan atestaciones por startup.

La primera confirmación fija en esa fila una ventana global por caso de 3600 segundos. Nuevos perfiles, consentimiento repetido, nuevos tokens, refresh externo, reconexión o reinicio no la amplían. El flujo reutilizado no emite refresh tokens. Cada vínculo individual guarda la misma ventana, puede revocarse y nunca se resucita por reconsentimiento. Se deniega cualquier otro caso, incluso de la misma empresa/proyecto; pendientes muestra como máximo el caso configurado.

Se releen identidad, facultades, piloto y atestación; se comprueba reloj después de las esperas de autorización. Actividad/draft revalidan bajo lock y antes de commit o retorno idempotente. Un fallo revierte la transacción de negocio. Las lecturas no devuelven contenido tras un guard final vencido. PostgreSQL nativo y carreras de bloqueo de ese motor no se acreditan con las pruebas SQLite.

## Privacidad, respuestas y auditoría

Se mantienen preview, hash, versión, deduplicación y owner de borrador privado. No existe herramienta MCP de publicación. Solicitante y actores ajenos no ven borradores privados; soporte autorizado los revisa mediante las rutas existentes. El vencimiento del agente conserva caso, borradores, historial y revisión humana. La prueba deja cero comentarios publicados y origen `synthetic_stub`.

Los procedimientos compartidos siguen siendo dos extractos fijos del canon con procedencia: no son evidencia de la causa del error ni manual contable. Las respuestas distinguen observación, inferencia, siguiente paso, verificación y faltantes. No se comparten adjuntos ni datos fiscales con un proveedor.

OAuth, consentimiento/piloto y caso/draft tienen recibos durables; el transporte usa su `AuditSink` persistente ya existente. No se asume cobertura de `Store.audit` del gateway ni se guardan bearer o mensajes libres en su lugar. Errores de autenticación se traducen a códigos fijos, sin secretos. Contexto de bearer es por request y se limpia en concurrencia/cancelación.

## Esquema y activación pendientes

Migración nueva propuesta: `database/migrations/20261024_batisenal_pilot.sql`, sobre las migraciones base/agente de soporte y el storage OAuth previamente revisado. Crea atestaciones, vínculos de piloto, recibos y consentimientos; constraints limitan ventana y triggers PostgreSQL prohíben extenderla o desrevocar el vínculo. No aplica DDL, backfill, permisos o credenciales por sí sola. SQL PostgreSQL suministrado, **no ejecutado** en esta fase; las pruebas de integridad ejecutaron el metadata equivalente SQLite, sin acreditar los triggers PG.

Único checkpoint productivo: autorizar la composición revisada de un recurso SamChat individual (sesión/consentimiento, issuer/resource/client y custodia de firma reales, store/migraciones verificadas, caso sintético y facultades explícitas de Francisco/agente), y su montaje durante la prueba acotada. No ampliar el `/mcp` administrativo ni sus scopes; no emitir credenciales ni montar nada antes de esa aprobación. Events permanece apagado.

La aceptación exige una invocación real desde esta conversación: caso de Operaciones → lectura autenticada → respuesta de Chatty como draft → revisión de Francisco en el mismo caso; comprobar otro caso/empresa denegados y corte temporal real. Hoy sólo hay simulación del razonamiento del agente, aunque la verificación criptográfica local sí ejecuta código real con clave de prueba.

Reversión: no montar, o desmontar sólo el recurso de piloto y revocar su vínculo; conservar datos, historial, auditoría y esquema. Sin DROP ni purgas. Los controles de host y guardian quedan fuera de este cambio.

Canon unchanged: implementación aislada del alcance aprobado, mantiene owners/autoridad y no cambia verdad contractual, runtime ni aceptación. Los tres hashes del canon coinciden con el registro.

## Verificación posterior, 2026-10-24

Se ejecutaron las migraciones relevantes y el recorrido de soporte/OAuth/piloto en PostgreSQL 17.11 nativo aislado, con fixtures y claves sintéticas. Ver `artifacts/pilot/integration/RESULTADO.md`; las limitaciones SQLite/no-PG anteriores describen la fase inicial. No cambió código del producto. Chromium abortó por sandbox antes de abrir página; la comprobación visual de esta fase continúa pendiente, sin bypass. El checkpoint actualizado y único es `PILOT_ACTIVATION_CHECKPOINT.md`, con archivos, rutas/stores propuestos, dependencias y el manifiesto efectivo de SamChat aún faltante. No hay activación autorizada.

## Integración de aplicación y UX posterior

Se implementó `batisenal_pilot_routes.mount_pilot` con vista y handlers HTTP reales, metadata y retorno al caso. La llamada sigue explícita y no está añadida al startup productivo. `tests/batisenal_pilot/test_application.py` monta la composición con el resolver canónico y PostgreSQL sintético; no es sólo el wrapper fixture de la fase inicial. El panel existente conserva texto/idempotencia al minimizar, revisa acceso al volver, separa revisión privada y añade selección de captura por teclado. La atestación conserva el bloqueo de publicación en los owners incluso después de desmontar. Ver el checkpoint actualizado y `artifacts/pilot/application/RESULTADO.md`. QA visual/Chatty real/activación siguen pendientes.
