# Suplemento de alcance v0.1 — piloto de instalación sintética

Aclaración explícita de Francisco, recibida el 25 de octubre de 2026 a las 22:09 UTC: «Sí, la primera», en respuesta a la opción de piloto exclusivamente sintético de una instalación, conservando controles de usuario, proyecto y caso y sin acreditar aislamiento entre Sports, GOAT y 1218.

## Decisión vigente

En **este piloto exclusivamente**, organización es el namespace de la instalación sintética configurado por el servidor. No significa razón social ni empresa financiera. No se asignan informes reales a una empresa, no se cambia la política financiera productiva y no se deriva autoridad de RFC, nombres de proyectos, roles host o scopes de soporte.

La identidad procede de la sesión canónica y el enlace individual existente. El único INFORME debe pertenecer al empleado sintético autorizado. Se reutiliza la regla canónica de lectura del propietario (`requester_can_view_document`) y las denegaciones actuales de módulo/acción. Proyecto deriva de `Documento.torneo_id` y, cuando no existe, de `CuentaDeGastos.torneo_id`, conforme al owner de autorización de proyecto; una etiqueta manual no es autoridad. No se invoca el owner que persiste rutas de aprobación como si fuera una lectura pura. Discrepancias, cambios de propietario/proyecto o permisos perdidos deniegan acceso. La relación caso/informe y su procedencia deben persistir en servidor; no aceptarse del modelo.

La prueba de denegación entre namespaces, usuarios, proyectos y casos sintéticos **no demuestra separación financiera entre razones sociales dentro de una misma instalación**. Antes de datos reales o informes multiempresa seguirá siendo necesario resolver el owner/mapping financiero descrito en SCOPE_DECISION.md.

## Garantías que no cambian

Invocación explícita; un caso/informe/actor; lectura canónica sin mutaciones de negocio; snapshot y fuentes/reglas versionadas; contenido hostil tratado como datos; TTL absoluto máximo de 60 minutos independiente de refresh; revocación actual; privacidad de borrador del actor; recibo inmutable con vigencia dinámica; unicidad transaccional e idempotencia; recuperación tras timeout; stale snapshot rechazado. La autorización, revisión y guard de expiración se comprueban bajo un protocolo compartido con todos los escritores pertinentes y después de esperas. El modelo no resuelve identidad ni concede permisos.

La composición permanece apagada por defecto y sólo es habilitable en el entorno sintético aislado previsto para pruebas. No Events, proveedor nuevo, publicación de respuesta, credenciales reales, permisos instalados, gateway productivo, cambios de servicios, push, merge ni despliegue.

## Estado y procedencia

El bloque previo de contrato/política quedó congelado y entregado separadamente:

- Library: `libfile_bc1818e15bec8191afe198e28f806191`.
- ZIP: `batisenal-v01-delta-20261025.zip`.
- SHA256: `91d14ae219998226c65d3165a9eace6b665875d66eeee135150a2c0498af917e`.
- 68 unitarias de contrato y 13 pruebas PostgreSQL nativo son evidencia de ese bloque, no aceptación del nuevo cableado.

Sus documentos de decisión pendiente describen fielmente el corte anterior; este suplemento levanta esa dependencia únicamente en el alcance elegido. No se reescribe ni sobrescribe la entrega previa. Los diez errores de tipos heredados siguen documentados.

Este suplemento aún no acredita código del protocolo agregado, snapshots/recibos v0.1 ni binding real a Chatty. La implementación posterior debe conservar un delta separado y probar los cambios reales. QA visual y binding real permanecen comprobaciones independientes; no sustituirlos por DOM, stubs o pase del núcleo.

Canon unchanged: aclaración limitada a fixtures y namespace aislado, sin nueva política financiera productiva. Cualquier extensión a empresa financiera requiere definición y revisión humana propias.
