# Batiseñal — candidato aislado, 2026-10-23

Estado: candidato de código para revisión e integración. No desplegado, no
aceptado por usuarios reales, sin canales externos activados. Base
`d591cc4a13987d33d2336bcf872401f3a6c7acb6`, copia independiente
`/workspace/samchat-batisenal`, rama `feat/batisenal-candidate`.

## Extensión Chatty, sin conexión real

La fase posterior incorpora un adaptador MCP sin montar, desactivado por defecto,
para lectura autorizada, recibos de atención y borradores privados. Soporte revisa
y publica en el mismo caso; no hay publicación automática, proveedor nuevo ni
suscripción Events. Identidad/grants se verifican en servidor por ámbito exacto.
La guía determinista continúa identificada como tal.
Contrato, datos compartidos y checkpoint: [CHATTY.md](CHATTY.md).
La versión actual requiere además `20261023_support_batisenal_agent.sql` antes
de usar la UI; no se aplica en startup. Resultado final: 68 pruebas aprobadas.

## Historia y criterios

Una persona activa pide ayuda durante el uso normal de SamChat, revisa exactamente
el contexto que comparte y puede consultar la conversación y el estado. Soporte
responde solamente dentro de empresas/proyectos explícitamente autorizados. El
alcance de construcción y pruebas procede de la delegación del usuario; no concede
permisos a empleados ni autoriza migración, publicación o despliegue.

Criterios implementados: botón en navegación compartida; descripción y campos
editables de módulo/acción/folio/error; captura voluntaria; previsualización,
recorte, ocultación y eliminación local; ticket persistente; PNG privado;
bandeja de ámbitos autorizados; respuestas y estados; confirmación, idempotencia,
auditoría y límites. El archivo `VALIDATION.md` separa evidencia ejecutada y pendiente.

## Propiedad y arquitectura

Runtime de destino: `copa_telmex_dashboard.py`, router de soporte de
`devnous.gastos`. Persistencia: SQLAlchemy/Postgres. Read/write owner:
`support_ticket_service.py` y su extensión `batisenal_service.py`. Reutiliza
`support_tickets`, `support_ticket_comments` y sus estados. No se crean un segundo
backend de casos, una cuenta ChatGPT, identidad OAuth, cola externa ni bot.

Dos tablas nuevas guardan ámbito/contexto/PNG/vencimiento y recibos de auditoría.
Su metadata es independiente de `Base`: startup no instala el esquema. La
migración SQL explícita agrega constraints, índice de ámbito e inmutabilidad de
metadatos/auditoría. Cada creación y cada respuesta/estado se guardan atómicamente.
Un ID de solicitud, huella del payload y constraints impiden duplicados; las
respuestas bloquean la fila del ticket en PostgreSQL.

Los tickets Batiseñal llevan el marcador reservado `batisenal:private`. Las rutas
y listas heredadas los excluyen, incluso para superadmin, evitando que el acceso
antiguo sin ámbito se convierta en un bypass. Se rechaza ese marcador en el
formulario antiguo. Las nuevas rutas deben montarse antes de `/soporte/{id}`.

## Permisos existentes, sin concesiones implícitas

Se reutiliza la unión de perfiles activos de `access_profiles` y
`empleado_access_profiles`, resuelta por `_load_effective_permissions`. Se
intersecta con `soporte.self` (ver/crear) y `admin.soporte` (ver/editar), incluidas
las denegaciones explícitas de `access_control_rules`, también para superadmin.
Identidad inactiva o suplantada se rechaza. Una consulta fallida de reglas bloquea.

Tokens exactos admitidos en `permissions` de un perfil **ya autorizado**:

- `batisenal:<organizacion>:<proyecto>:request`: crear y leer/responder sólo los propios.
- `batisenal:<organizacion>:<proyecto>:support`: bandeja, lectura, respuestas y estado
  de ese ámbito, además de la facultad existente de soporte admin.

Organización/proyecto son identificadores estables explícitos, minúsculos,
`[a-z0-9_-]{1,64}`. No hay comodín, inferencia desde nombre/RFC/departamento,
asignación por rol, fallback global ni alta automática. Un token de Batiseñal
NO otorga acceso a documentos, contabilidad o un torneo. Módulo/folio/error son
texto aportado y revisado, no pruebas de propiedad de un documento.

No se encontró una relación universal empresa/proyecto en la identidad web
`Empleado` (tampoco `empresa_id`); por eso **no se infiere** desde el rol. La
revisión de los ámbitos y sus titulares queda a cargo del dueño de los perfiles.
Este candidato no escribe perfiles reales. Sin esa configuración, responde
`SCOPE_NOT_CONFIGURED`. El cuestionario siguiente hace esa decisión revisable.

| Empresa ID | Proyecto ID | Puesto | Perfil existente | Titulares activos | Solicitar | Atender | Denegaciones | Evidencia/aprobador |
|---|---|---|---|---|---|---|---|---|
| Pendiente | Pendiente | Pendiente | Pendiente | Pendiente | Pendiente | Pendiente | Pendiente | Pendiente |

Francisco necesita su identidad local activa y facultades verificadas en cada
ámbito. Un asistente necesita integración e identidad delegada revisadas por
separado; no puede usar la sesión personal de Francisco ni concederse soporte.

## Captura y privacidad

Abrir Batiseñal no captura ni adjunta nada. La captura es una representación
rasterizada de la geometría visible de **esta página de SamChat**, con todo texto,
controles, imágenes, canvas, iframe y pseudo-contenido ocultos por construcción.
Se dibujan cajas directamente con canvas 2D, usando sólo coordenadas y colores.
No se clona el documento ni se cargan recursos de origen; no requiere librerías de captura.
No se usa `getDisplayMedia`, escritorio, selector de ventana, clipboard, cámara,
consola, cookies, almacenamiento ni lectura de otros tabs. El renderer no recibe
los valores originales. Se preservan disposición y colores; no es una copia
literal de los datos de la pantalla. Los detalles útiles se añaden a los campos
editables. Esto sacrifica fidelidad para mantener los datos ocultos por defecto.

La imagen permanece en memoria de la página, con selección rectangular para
recorte/ocultación irreversible de píxeles. Quitar/cancelar/cerrar no sube archivos.
No hay adjuntos previos a la confirmación. Sólo se envía el PNG final. El backend
comprueba bytes reales PNG/JPEG, dimensiones, límites y decodificación; genera un
PNG nuevo sin EXIF, metadatos, nombre original ni bytes anexados. SVG, GIF y otros
formatos no se aceptan. El navegador no ofrece carga arbitraria de archivos.

Texto siempre plano (`textContent`, nunca HTML de usuario). Cliente y servidor
eliminan patrones comunes de credenciales y query/fragment de URLs pegadas. No
es un detector exhaustivo de datos sensibles: la revisión humana sigue siendo
obligatoria. No se copian título de página, query strings ni contenidos de documentos.
El área de navegación usa un catálogo fijo; referencia y error sólo entran por
el adaptador explícito y restringido descrito abajo. Todos son editables antes
de confirmar. No se usan datos fiscales reales en fixtures.

CSRF: token aleatorio en sesión firmada, encabezado propio y Origin exacto en
cada POST JSON; sin CORS. Lecturas/adjuntos usan `no-store`, `nosniff` y
`no-referrer`. El PNG exige el mismo guard que el caso. El proxy de integración
debe conservar el host/esquema de la URL pública; no relajar Origin para arreglarlo.

## Ayuda compacta y contexto permitido

La consulta pregunta por el resultado esperado cuando existe el error sintético
conocido; en ausencia de evidencia pregunta brevemente qué se intentó y ocurrió.
El asunto se sugiere. Contexto y captura quedan en detalles opcionales; la vista
previa muestra exactamente el payload saneado. Cerrar sólo descarta la consulta
sin enviar; no modifica el borrador del módulo anfitrión. Después del envío se
pliega la consulta y las capturas del caso permanecen plegadas.

Integración real acreditada por código: `render_top_navigation(active_area)` pasa
al botón un módulo del catálogo fijo panel/operacion/contabilidad/nomina/admin/soporte.
Un área desconocida se convierte en panel. No se inspeccionan URLs ni mensajes HTML.
El resto se entrega mediante un evento explícito desde un owner revisado:

```javascript
window.dispatchEvent(new CustomEvent('samchat:batisenal-context', {detail: {
  module: 'payment_request',
  reference: 'PAGO-DEMO-042',
  error: 'DEMO_VALIDACION_EVENTO'
}}));
```

Este ejemplo está implementado **sólo en la pantalla sintética** del test de
Operaciones. No hay adapter del módulo de pagos real activado. El consumidor
acepta módulos del catálogo anterior más payment_request; referencias sólo UUID
minúsculo o PAGO-DEMO seguido de 1–8 dígitos. No acepta importes, cuentas, nombres,
mensajes libres, tokens, organización ni proyecto desde el evento. El único error
catalogado es DEMO_VALIDACION_EVENTO (simulado); cualquier otro se reduce a
ERROR_NO_CATALOGADO, sin conservar su contenido. El contexto se vincula al path
actual; el owner debe emitir contexto nuevo o un evento con detail=null al cambiar
de entidad en la misma ruta. No es una prueba de autoridad ni de causalidad.

La guía está rotulada **determinista**, sin proveedor IA ni llamadas facturables.
Explica lo observado, una comprobación segura y el resultado a verificar; si falta
evidencia lo declara y escala con el contexto existente. No diagnostica causas
contables, autoriza pagos ni promete resolución. Soporte dispone de una plantilla
opcional Observé / Puedes intentar / Comprueba; sus marcadores deben completarse
antes de enviar. El texto final requiere confirmación humana.

## Consulta de respuestas dentro del panel

Se inicia al abrir, sólo con permisos válidos, y consulta cada 5 segundos mientras
el documento es visible y no hay envío pendiente. Máximo 120 intentos automáticos
por apertura/reanudación explícita; sin intervalos permanentes fuera del panel.
Los GET se serializan con los manuales. Timeout de 8 segundos, reintentos tras
error transitorio con espera de 10/20/30 segundos (tope30); no se solapan.
Cerrar o pagehide aborta lecturas, invalida resultados tardíos y cancela el timer.
401/403/404/410 detiene consulta y retira el caso; un resultado tardío nunca borra
controles de un envío incierto ni de una vista distinta. Cada consulta pasa los
guards reales de identidad/empresa/proyecto del backend.

Se actualizan conversación/estado/auditoría sin reemplazar la respuesta sin enviar.
Editar una respuesta invalida su confirmación; navegar advierte del borrador.
La consulta de un caso tardía tampoco puede reemplazar texto recién escrito.
No hay push, correo, vigilancia externa ni promesa de respuesta inmediata.

## Configuración y retención

| Variable | Predeterminado | Límite aceptado |
|---|---:|---|
| `BATISENAL_ENABLED` | desactivado | exactamente `1` para activar |
| `BATISENAL_MAX_IMAGE_BYTES` | 2097152 (2 MiB) | 1024–8388608 |
| `BATISENAL_MAX_PIXELS` | 4000000 | 1–8000000 |
| `BATISENAL_RETENTION_DAYS` | 90 | 1–3650 |

Máximo asunto: 200 caracteres; descripción/respuesta: 8000; cada contexto: 500;
una captura por caso; JSON acotado mientras se recibe; bandeja últimos 200 casos.
El vencimiento se fija al crear. Cambiar la configuración no reescribe datos
anteriores. Después de vencer, el caso deja de listarse y su lectura responde
410 sólo al usuario autorizado. **No se purga ningún dato**, anterior ni nuevo.
Una política futura de borrado físico/backups exige aprobación, procedimiento de
owner y auditoría independientes; los triggers impiden borrado operativo casual.
No hay promesa de eliminación física a los 90 días.

Reintentos conservan clave y payload mientras está abierta la página; incluso
si se pierde la respuesta después del commit, el mismo envío devuelve el mismo
ID. El formulario queda bloqueado para no cambiar un envío incierto. Cerrar se
bloquea mientras haya envío sin confirmar. La navegación advierte sobre borradores;
forzar cierre/recarga pierde el borrador local (no se persiste texto sensible).
Un envío ya guardado sigue disponible en la bandeja: revisar allí antes de abrir
otro caso. No se implementa cola offline ni recuperación de borradores entre tabs.

## Integración externa futura (NO activa)

Existe el perímetro histórico `src/samchat/private_plugin`; no se modificó ni
activó. `docs/integrations/chatgpt-access` no estaba en este checkout. No fue
necesario consumir Library ni el ZIP histórico, y no se supone materialización
de archivos del hilo padre.

Contrato previsto para una herramienta conectada:

1. Validar token/audience/vigencia, identidad local y organización por el owner
   OAuth existente, sin aceptar actor/organización/facultades del prompt.
2. Revalidar perfiles y ámbitos actuales y resolver el `Principal` de soporte.
3. Preparar preview local y obtener confirmación explícita ligada al contenido.
4. Invocar el mismo owner de casos con clave idempotente; devolver ID/estado.
5. Leer respuestas mediante consulta autenticada al mismo caso.

Una herramienta de ChatGPT no puede capturar una página arbitraria del navegador;
la captura se inicia dentro de SamChat y se revisa allí. Harían falta un handoff
privado, scopes de herramienta, almacenamiento de confirmación y revisión de
seguridad para unir ambas superficies. No hay endpoint bearer de Batiseñal,
registro MCP, consentimiento OAuth nuevo, conversación ChatGPT-a-ChatGPT ni push.
No se envían correos, Telegram, Slack u otros mensajes. El caso se consulta en la
bandeja. El futuro canal no debe reaprovechar cookies ni pasar por CSRF relajado.

## Integración y reversión pendientes

1. Revisar diff, especificación y matriz de puestos/empresa/proyecto con el owner.
2. Revalidar migración y concurrencia sobre la versión/configuración del despliegue real,
   con backup y autorización de owner. No se ejecutó en servidor de destino ni producción.
3. Aplicar migración explícita, revisar hashes de frontend y permisos del usuario
   DB existente, configurar perfiles aprobados y valores de retención/límites.
4. Integrar código por el flujo de revisión del repositorio y activar bandera sólo
   bajo autorización de despliegue. UAT autenticada por puesto/empresa/proyecto.
5. Revisar observabilidad, cuotas operativas y política de eliminación física antes
   de una adopción amplia. Ninguno de estos pasos se hizo por esta delegación.

Reversión segura: desactivar `BATISENAL_ENABLED`, conservar tablas y auditoría,
y conservar **siempre** el filtro reservado de las rutas heredadas. No volver a
un binario anterior que permita leer estos tickets sin ámbito. No eliminar la
migración ni casos para hacer rollback; respaldos/restauraciones quedan al owner.

**Canon unchanged**: extensión candidata de soporte conforme a los invariantes
existentes de identidad, preview, idempotencia y auditoría. No se cambia la verdad
contractual, el inventario histórico, autoridad financiera ni estado productivo.
No se editaron los cánones ni sus hashes; la promoción/aceptación requiere evidencia
propia y revisión humana.
