-- ISOLATED transport-store candidate only. SQLite, NOT PostgreSQL business DDL.
-- Explicit owner-run on a new private test store; never startup/provision accounts.
BEGIN IMMEDIATE;
CREATE TABLE transport_audit (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 actor_hash TEXT, action TEXT NOT NULL, outcome TEXT NOT NULL,
 created_at INTEGER NOT NULL
);
CREATE TRIGGER transport_audit_no_update BEFORE UPDATE ON transport_audit
BEGIN SELECT RAISE(ABORT,'AUDIT_IMMUTABLE'); END;
CREATE TRIGGER transport_audit_no_delete BEFORE DELETE ON transport_audit
BEGIN SELECT RAISE(ABORT,'AUDIT_IMMUTABLE'); END;
CREATE TABLE transport_subscriptions (
 id TEXT PRIMARY KEY, owner TEXT NOT NULL, case_id TEXT NOT NULL,
 callback TEXT NOT NULL, secret_ref TEXT NOT NULL,
 expires INTEGER NOT NULL, active INTEGER NOT NULL CHECK(active IN(0,1)),
 generation INTEGER NOT NULL CHECK(generation>0)
);
CREATE INDEX transport_subscription_owner ON transport_subscriptions(owner,case_id);
CREATE TABLE transport_deliveries (
 id TEXT PRIMARY KEY,
 subscription TEXT NOT NULL REFERENCES transport_subscriptions(id),
 version TEXT NOT NULL, created_at INTEGER NOT NULL,
 state TEXT NOT NULL CHECK(state IN('pending','delivered','stopped')),
 UNIQUE(subscription,version)
);
COMMIT;
