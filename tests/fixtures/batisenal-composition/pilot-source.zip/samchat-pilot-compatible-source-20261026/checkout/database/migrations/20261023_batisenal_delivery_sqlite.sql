-- Explicit isolated transport-store upgrade after transport_sqlite.sql.
-- No credentials, business DDL, daemon, grants, backfill or purge.
BEGIN IMMEDIATE;
ALTER TABLE transport_subscriptions ADD COLUMN previous_secret_ref TEXT;
ALTER TABLE transport_subscriptions ADD COLUMN previous_until INTEGER NOT NULL DEFAULT 0;
ALTER TABLE transport_deliveries ADD COLUMN attempts INTEGER NOT NULL DEFAULT 0;
ALTER TABLE transport_deliveries ADD COLUMN next_attempt INTEGER NOT NULL DEFAULT 0;
ALTER TABLE transport_deliveries ADD COLUMN lease_until INTEGER NOT NULL DEFAULT 0;
ALTER TABLE transport_deliveries ADD COLUMN lease_generation INTEGER NOT NULL DEFAULT 0;
CREATE TABLE transport_delivery_receipts (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 delivery_id TEXT NOT NULL REFERENCES transport_deliveries(id),
 attempt INTEGER NOT NULL,
 outcome TEXT NOT NULL CHECK(outcome IN ('received','retry','stopped','uncertain')),
 http_status INTEGER,
 created_at INTEGER NOT NULL,
 UNIQUE(delivery_id, attempt)
);
CREATE TRIGGER transport_receipts_no_update BEFORE UPDATE ON transport_delivery_receipts
BEGIN SELECT RAISE(ABORT,'DELIVERY_RECEIPT_IMMUTABLE'); END;
CREATE TRIGGER transport_receipts_no_delete BEFORE DELETE ON transport_delivery_receipts
BEGIN SELECT RAISE(ABORT,'DELIVERY_RECEIPT_IMMUTABLE'); END;
COMMIT;
