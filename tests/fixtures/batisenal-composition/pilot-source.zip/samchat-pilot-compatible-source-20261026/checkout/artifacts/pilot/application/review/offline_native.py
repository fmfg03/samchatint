"""Review harness: permit only the inspected isolated PostgreSQL Unix socket."""
import sys
from pathlib import Path
socket_path=str((Path('artifacts/pilot/integration/socket')/'.s.PGSQL.5432').resolve())
def guard(event,args):
    if event=='socket.connect' and args[1]!=socket_path:
        raise RuntimeError('REVIEW_EXTERNAL_NETWORK_FORBIDDEN')
    if event in {'socket.getaddrinfo','socket.sendto'}:
        raise RuntimeError('REVIEW_EXTERNAL_NETWORK_FORBIDDEN')
sys.addaudithook(guard)
import pytest
raise SystemExit(pytest.main(sys.argv[1:]))
